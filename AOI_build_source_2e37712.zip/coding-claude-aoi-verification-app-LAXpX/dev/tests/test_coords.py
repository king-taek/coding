"""좌표 파서 단위 테스트.

보고서 예시 5개(Camtek INI) + LIVE 파일명 1개로 파서를 검증한다.
무거운 의존성 없이 순수 로직만 테스트하므로 importorskip 불필요.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from aoi_verification.app.coords.camtek_ini import _extract_coord as _extract_raw_coord
from aoi_verification.app.coords.camtek_live import resolve as live_resolve
from aoi_verification.app.coords.wafer_geometry import FALLBACK_CAMTEK


def _extract_coord(content):
    """이 파일의 기대값은 전부 **TB500 격자** 기준 — 기하를 명시해 고정한다.

    (die 기하는 이제 폴더에서 읽는다. 다른 디바이스는 test_wafer_geometry.py 가 본다.)"""
    return _extract_raw_coord(content, FALLBACK_CAMTEK)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _make_ini_section(**kv) -> str:
    return "\n".join(f"{k}={v}" for k, v in kv.items())


def _approx(a: float, b: float, tol: float = 1e-3) -> bool:
    return abs(a - b) <= tol


# ---------------------------------------------------------------------------
# Camtek INI — 보고서 5개 예시 검증
# ---------------------------------------------------------------------------
class TestCamtekIni:
    def test_example1(self):
        """보고서 예시 1: X=253716.003307344 Y=91798.7938704543 Col=6 Row=2 → col=4 row=5"""
        content = _make_ini_section(X="253716.003307344", Y="91798.7938704543",
                                     Col="6", Row="2")
        c = _extract_coord(content)
        assert c is not None
        assert c.col == 4
        assert c.row == 5
        assert c.x == 30229.0    # floor — 장비 표기는 버림
        assert c.y == 1987.0
        assert c.source == "camtek_ini"

    def test_example2(self):
        """보고서 예시 2: Col=7 Row=5 → col=5 row=2"""
        content = _make_ini_section(X="285837.569021826", Y="241931.965714178",
                                     Col="7", Row="5")
        c = _extract_coord(content)
        assert c is not None
        assert c.col == 5
        assert c.row == 2
        assert c.x == 25103.0
        assert c.y == 17404.0

    def test_example3(self):
        """경계 예시 — die 인덱스는 **좌표에서 유도**한다(INI 의 Col/Row 필드가 아니라).

        이 항목은 INI 가 ``Row=6`` 이라고 적었지만 ``floor(Y/pitch_y) = 7`` 이다.
        옛 기대값(``row=1``, ``y=68156``)은 보고서 공식을 INI 필드에 그대로 대입한
        메아리였다 — ``y=68156`` 은 pitch(44905.4)보다 큰 '**die 내부** 좌표' 라
        장비 화면에 나올 수 없는 값이다.  유도 인덱스로 재면 ``y`` 가 die 안
        (``0 ≤ y < pitch_y``)으로 돌아온다.

        (INI 필드가 이렇게 어긋나는 실물은 레시피별 Row 원점 차이에서 온다 —
        ``docs/디바이스_하드코딩_조사.md`` §6-F.)"""
        content = _make_ini_section(X="183424.006310378", Y="337589.125854985",
                                     Col="4", Row="6")
        c = _extract_coord(content)
        assert c is not None
        assert c.col == 2
        assert c.row == 0
        assert c.x == 34433.0
        assert c.y == float(int(337589.125854985 - 7 * 44905.4))   # floor, y_index=7
        assert 0 <= c.y < 44905.4                  # die 안에 있다

    def test_example4(self):
        """보고서 예시 4: Col=4 Row=3 → col=2 row=4"""
        content = _make_ini_section(X="182587.539096461", Y="149593.522482771",
                                     Col="4", Row="3")
        c = _extract_coord(content)
        assert c is not None
        assert c.col == 2
        assert c.row == 4
        assert c.x == 33596.0
        assert c.y == 14877.0

    def test_example5(self):
        """보고서 예시 5: Col=4 Row=2 → col=2 row=5"""
        content = _make_ini_section(X="180377.576920526", Y="100976.81821231",
                                     Col="4", Row="2")
        c = _extract_coord(content)
        assert c is not None
        assert c.col == 2
        assert c.row == 5
        assert c.x == 31386.0
        assert c.y == 11166.0

    def test_faultx_fallback(self):
        """X/Y 없으면 FaultX/FaultY 사용."""
        content = _make_ini_section(FaultX="253716.003307344", FaultY="91798.7938704543",
                                     Col="6", Row="2")
        c = _extract_coord(content)
        assert c is not None
        assert c.col == 4
        assert c.row == 5

    def test_equipment_screen_reading(self):
        """★ 정답 기준 — 장비(AOI Data Viewer) 웨이퍼 맵 **직접 판독** 실측.

        INI ``Col=8, Row=5`` → 장비 화면 ``col=6, row=2``.
        맵 규약: 왼쪽 맨 아래가 (0,0), 오른쪽·위로 1씩 증가(col·row 둘 다 0-based).

        이 한 건이 ``row = 7 − Row`` 를 확정한다 — ``row = Row − 3`` 은 실측 Row 범위
        1..6 에서 음수가 나와 0-based 맵에 존재할 수 없다.
        (이전 세션이 ``CAMTEK_ROW_TOTAL`` 을 7→6 으로 바꿔 전 구간 row 가 1 작아졌던
        회귀의 재발 방지용이다.  이 값을 건드리려면 장비 화면을 다시 판독할 것.)"""
        content = _make_ini_section(X="334789.573892829", Y="267755.638995209",
                                     Col="8", Row="5")
        c = _extract_coord(content)
        assert c is not None
        assert (c.col, c.row) == (6, 2)

    def test_missing_keys_returns_none(self):
        """필수 키 누락 시 None 반환."""
        content = _make_ini_section(X="100.0", Y="200.0")   # Col/Row 없음
        assert _extract_coord(content) is None

    def test_empty_section_returns_none(self):
        assert _extract_coord("") is None


# ---------------------------------------------------------------------------
# Camtek LIVE 파일명 파서
# ---------------------------------------------------------------------------
class TestCamtekLive:
    def test_standard_filename(self):
        """보고서 예시 1과 대응하는 LIVE 파일명 — col/row 토큰을 **보정 없이** 쓴다.

        이 파일명의 die 좌표(30229.803, 1987.994)는 ``test_example1`` 의 Camtek 항목과
        같은 값이고, 그 항목이 내는 ``(col,row)`` 도 ``(4,5)`` 다 — 토큰 그대로다.
        예전엔 row 를 −1 해서 4 를 냈고, INI↔LIVE 가 1 어긋난 채 ±1 게이트에 가려져
        있었다(→ ``docs/디바이스_하드코딩_조사.md`` §6-G)."""
        p = Path(
            "R_TB500_LIVE_PI4_VLP-PDIS3_W6317098XYB5_4_5_Over Sized Bump"
            "_30229.803_1987.994.jpg"
        )
        c = live_resolve(p)
        assert c is not None
        assert c.col == 4
        assert c.row == 5                    # 보정 없음 — Camtek 예시1 의 row 와 같다
        assert _approx(c.x, 30229.803)
        assert _approx(c.y, 1987.994)
        assert c.source == "camtek_live"

    def test_matches_camtek_ini_convention(self):
        """★ 같은 결함을 두 소스가 **같은 (col,row)** 로 내야 한다.

        보고서 예시 1 의 Camtek INI 항목과 그에 대응하는 LIVE 파일명을 나란히 넣는다.
        여기가 어긋나면 소스 간 규약이 틀어진 것이다(게이트가 흡수해도 빚이다)."""
        ini = _extract_coord(_make_ini_section(
            X="253716.003307344", Y="91798.7938704543", Col="6", Row="2"))
        live = live_resolve(Path(
            "R_TB500_LIVE_PI4_VLP-PDIS3_W6317098XYB5_4_5_Over Sized Bump"
            "_30229.803_1987.994.jpg"))
        assert (live.col, live.row) == (ini.col, ini.row)
        assert abs(live.x - ini.x) <= 1 and abs(live.y - ini.y) <= 1

    def test_integer_coords(self):
        """x/y 가 정수만 있어도 파싱 가능."""
        p = Path("R_DEV_W123_3_2_Defect_12345_6789.jpg")
        c = live_resolve(p)
        assert c is not None
        assert c.col == 3
        assert c.row == 2
        assert c.x == 12345.0
        assert c.y == 6789.0

    def test_non_live_filename_returns_none(self):
        """R_ 로 시작하지 않으면 None."""
        p = Path("253715.91797.c.-1104740629.1.jpeg")
        assert live_resolve(p) is None

    def test_defect_name_with_spaces(self):
        """DefectName 에 공백이 있어도 파싱 가능 — _PAT 은 공백 포함 허용."""
        p = Path("R_TB500_W1_2_3_Over Sized Bump_100.5_200.0.jpg")
        c = live_resolve(p)
        assert c is not None
        assert c.col == 2
        assert c.row == 3

    def test_row_token_zero_is_valid(self):
        """★ row 토큰 0 은 실물에 존재한다 — 예전 −1 정규화의 전제를 반증한다.

        그 코드는 'row 토큰은 1..6 표시 규약' 을 전제로 −1 했는데, 실측 파일에 0 이 있다.
        −1 하면 row 가 −1 이 돼 ``(col,row) ±1`` 게이트에서 die 하나를 통째로 놓친다."""
        c = live_resolve(Path(
            "TB500_RDL4 - Multi_FDV-RDL4_W7548303XYC2_3_0_"
            "27582.7103387744_43144.6146330819_Foreign Material.jpg"))
        assert c is not None
        assert (c.col, c.row) == (3, 0)

    @pytest.mark.parametrize("name", [
        "W6459076XYG1_2_0_23_2.jpg",
        "W6459081XYE1_1_2_14_2.jpg",
        "W6460162XYF4_2_1_7_1.jpg",
    ])
    def test_kla_filename_rejected(self, name):
        """KLA 이미지 파일명은 LIVE 로 파싱되지 않아야 한다."""
        assert live_resolve(Path(name)) is None

    @pytest.mark.parametrize("name", [
        # 실물(저장소 사본) — 음수 토큰이 섞인 KLA 계열
        "00MEU018XYG1_-1_4_23_1.jpg",
        "00MEU018XYG1_4_3_23_2.jpg",
        "00MEU018XYG1_-8_-2_23_4.jpg",
        "08235234EWA1_-2_-2_31_2.jpg",
        "08235234EWA1_2_-1_7_1.jpg",
        # Camtek INI 점표기 — LIVE 가 아니다
        "255348.116718.c.473266639.1.jpeg",
        "29648.164545.c._2_.jpeg",
    ])
    def test_real_non_live_filenames_rejected(self, name):
        """★ 저장소 실물 중 LIVE 가 **아닌** 파일명 전수 — 하나도 파싱되면 안 된다.

        ``00MEU018XYG1_-1_4_23_1`` 이 특히 중요하다.  `-1` 을 정수 토큰으로 보지
        않으면 '처음 연속한 정수 쌍' 이 `4`,`23` 으로 밀려 앞 토큰이 2개가 되고
        (KLA 배제 규칙을 통과해) **col=4, row=23 으로 오인**한다.
        """
        assert live_resolve(Path(name)) is None


# ---------------------------------------------------------------------------
# ★★ R-0 — 파일명 스키마 오인으로 x·y 에 크기·면적이 들어가던 버그
#
#   옛 정규식 ``_(\d+)_(\d+)_.+_(num)_(num)$`` 는 greedy ``.+`` + ``$`` 앵커라
#   좌표 뒤에 토큰이 더 붙으면 **뒤쪽 두 수치**를 집었다.
#
#     ..._4_5_Over Sized Bump_30229.803_1987.994_12.5_18.3_229.1
#     옛 결과  x=18.3  y=229.1   ← DYSize·DArea      x 오차 30,212 µm
#
#   col/row 는 맞아서 자체모순이 없고 ±1 게이트도 통과한다 → **조용히 틀린다.**
#
# ⚠ 출처 등급(`docs/좌표_판단오류_회고.md` R3): 이 스키마는 `문서` 다 — 실물 미확보.
#   근거는 참고 저장소 `Defect_Tracking/camtek_filename.py` 주석의 토큰 순서뿐이다.
# ---------------------------------------------------------------------------
class TestFilenameSchemaR0:
    _WITH_SIZES = ("R_TB500_LIVE_PI4_VLP-PDIS3_W6317098XYB5_4_5_Over Sized Bump"
                   "_30229.803_1987.994_12.5_18.3_229.1.jpg")

    def test_sizes_do_not_leak_into_xy(self):
        """★ 좌표 뒤에 크기·면적이 붙어도 x·y 는 **앞쪽 두 수치**다."""
        c = live_resolve(Path(self._WITH_SIZES))
        assert c is not None
        assert (c.col, c.row) == (4, 5)
        assert _approx(c.x, 30229.803)
        assert _approx(c.y, 1987.994)

    def test_old_regex_behaviour_is_gone(self):
        """옛 동작(x=18.3, y=229.1)이 되살아나면 실패한다 — 회귀 가드 본체."""
        c = live_resolve(Path(self._WITH_SIZES))
        assert not _approx(c.x, 18.3), "옛 정규식이 되살아났다 (DYSize 를 x 로 읽음)"
        assert not _approx(c.y, 229.1), "옛 정규식이 되살아났다 (DArea 를 y 로 읽음)"

    def test_extra_tokens_are_kept_separately(self):
        """남는 수치는 버리지 않고 ``extra`` 로 분리해 둔다(엑셀 열 추가 시 쓸 값)."""
        from aoi_verification.app.coords.camtek_live import parse_live_name
        got = parse_live_name(Path(self._WITH_SIZES).stem)
        assert (got.x, got.y) == (30229.803, 1987.994)
        assert got.extra == (12.5, 18.3, 229.1)

    def test_same_defect_two_schemas_agree(self):
        """★ 같은 결함이 크기 토큰 유/무 두 형태로 와도 **같은 좌표**를 내야 한다.

        R7(두 소스면 일치를 단언) 을 스키마 사이에 적용한 것이다.  '변환 결과' 만
        단언하면 그 변환이 옳은지 영영 안 묻는다(→ 회고 E2).
        """
        base = live_resolve(Path(
            "R_TB500_LIVE_PI4_VLP-PDIS3_W6317098XYB5_4_5_Over Sized Bump"
            "_30229.803_1987.994.jpg"))
        with_sizes = live_resolve(Path(self._WITH_SIZES))
        assert (base.col, base.row) == (with_sizes.col, with_sizes.row)
        assert _approx(base.x, with_sizes.x)
        assert _approx(base.y, with_sizes.y)

    @pytest.mark.parametrize("stem,expect", [
        # (A) x/y 뒤에 이름            — 실물로 검증된 배치
        ("TB500_RDL4 - Multi_FDV-RDL4_W7548304XYG4_5_4_31863.2366998812"
         "_26908.4427394723_Irregular Bump", (5, 4, 31863.2366998812, 26908.4427394723)),
        # (B) x/y 앞에 이름            — 실물로 검증된 배치
        ("R_TB500_W1_4_5_Bump_30229.803_1987.994", (4, 5, 30229.803, 1987.994)),
        # (C) 뒤에 크기·면적           — 문서 근거 (실물 미확보)
        ("R_TB500_W1_4_5_Bump_30229.803_1987.994_12.5_18.3_229.1",
         (4, 5, 30229.803, 1987.994)),
        # 이름 없는 정수 배치          — 앞 토큰이 2개라 LIVE 로 본다
        ("cam_live_3_2_1000_2000", (3, 2, 1000.0, 2000.0)),
    ])
    def test_three_layouts_one_path(self, stem, expect):
        """세 배치가 **한 경로**로 처리된다 — 정규식을 갈아 끼우지 않는다."""
        from aoi_verification.app.coords.camtek_live import parse_live_name
        got = parse_live_name(stem)
        assert got is not None
        assert (got.col, got.row) == expect[:2]
        assert _approx(got.x, expect[2]) and _approx(got.y, expect[3])

    def test_competing_hypothesis_is_undetermined(self):
        """⚠ 구분되지 않는 것을 명시한다 (회고 R1 — "미구분" 을 기록에 남긴다).

        (C) 의 토큰 순서가 ``x_y_DX_DY_DArea`` 라는 근거는 **참고 저장소 문서 한 줄**
        뿐이다.  크기·면적이 x/y **앞**에 오는 배치라면 우리 값은 틀린다.
        지금 표본은 두 가설을 구분하지 못한다 — 실물 1건이 오면 닫힌다.

        다만 어느 가설이든 **옛 코드보다 나쁘지 않다**: 옛 코드는 (C) 에서
        마지막 두 수치를 집어 확실히 틀렸다.  이 테스트는 그 사실을 못 박는다.
        """
        from aoi_verification.app.coords.camtek_live import parse_live_name
        got = parse_live_name(
            "R_TB500_W1_4_5_Bump_30229.803_1987.994_12.5_18.3_229.1")
        # 채택한 가설: 앞 두 개가 좌표
        assert (got.x, got.y) == (30229.803, 1987.994)
        # 경쟁 가설이 맞다면 좌표는 이것이었을 것 — 표본이 구분해 주지 않는다
        assert got.extra[-2:] == (18.3, 229.1)
        # 어느 쪽이든 옛 동작(마지막 두 개)은 아니다
        assert (got.x, got.y) != got.extra[-2:]


# ---------------------------------------------------------------------------
# 통합: coords.__init__.resolve 우선순위
# ---------------------------------------------------------------------------
class TestCoordResolve:
    def test_live_priority_over_ini(self, tmp_path):
        """LIVE 파일명이 있으면 INI 를 무시."""
        from aoi_verification.app.coords import resolve

        # INI 파일 생성 (다른 좌표)
        ini = tmp_path / "ColorImageGrabingInfo.ini"
        ini.write_text(
            "[R_TB500_W1_4_5_Bump_30229.803_1987.994.jpeg]\n"
            "X=999999.0\nY=999999.0\nCol=6\nRow=2\n",
            encoding="utf-8",
        )
        # LIVE 형식 파일명 — 파일이 실제로 존재할 필요 없음(resolve 는 경로만 파싱)
        img = tmp_path / "R_TB500_W1_4_5_Bump_30229.803_1987.994.jpg"
        c = resolve(img)
        # LIVE 파서가 먼저이므로 LIVE 좌표 반환
        assert c is not None
        assert c.source == "camtek_live"
        assert c.col == 4
        assert c.row == 5                    # 토큰 그대로 (보정 없음)

    def test_kla_filename_falls_through_to_kla_resolver(self, tmp_path):
        """KLA 파일명은 camtek_live 를 건너뛰고 kla_info 로 해석돼야 한다."""
        from aoi_verification.app.coords import resolve
        from aoi_verification.app.coords import kla_info

        kla_info.load_folder.cache_clear()
        kla_info.load_folder_raw.cache_clear()
        info = tmp_path / "INFO.001"
        info.write_text(
            'DiePitch 3.7247930000e+004 4.4905340000e+004;\n'
            'TiffFileName W6459076XYG1_2_0_23_2.jpg;\n'
            'DefectList\n'
            ' 2 67855.280 14093.720 11819.421 13870.779 2 0 '
            '2.600 3.900 10.16 3.9 23 3 0 0 1 1 0 2671 0 1 1 1 0;\n',
            encoding="utf-8",
        )
        img = tmp_path / "W6459076XYG1_2_0_23_2.jpg"
        c = resolve(img)
        assert c is not None
        assert c.source == "kla"
        assert c.col == 5
        assert c.row == 4      # YINDEX 0 + KLA_ZERO_Y(4) — 장비 화면 기준


# ---------------------------------------------------------------------------
# 회귀: 실측 데이터에서 KLA ↔ Camtek 의 같은 결함이 같은 (col,row) 로 정렬
# ---------------------------------------------------------------------------
_COORD_DATA = Path(__file__).resolve().parents[2] / "dev" / "좌표 확인"


@pytest.mark.skipif(not _COORD_DATA.exists(), reason="실측 데이터 폴더 없음")
def test_real_pair_kla_camtek_rows_align():
    """dev/좌표 확인 실측 쌍: Camtek 예시1(Col=7,Row=3) ↔ KLA 예시1(XINDEX=2,YINDEX=0).

    두 좌표가 121 µm 밖에 안 떨어져 있어 **같은 물리적 결함**임이 확인된 쌍이다.
    따라서 두 변환이 같은 (col,row) 를 내야 한다 — 이 테스트의 요점은 **정렬**이다.

    ★ ``col`` 은 정확히 일치한다.  ``row`` 는 **이 픽스처의 한계로 1 어긋난다**:

    · KLA `(5,3)` 이 정답 규약이다 — `SampleCenterLocation` 유도값이고, 사용자가 장비로
      확인한 KLA↔Camtek 대응 7건(2개 device)이 이 규칙을 지지한다(조사 §6-K).
    · Camtek 쪽은 이 폴더에 ``Params_WaferInfo.ini`` 가 없어(사진만 복사된 픽스처)
      ``Center_Y`` 를 못 읽고 옛 식으로 폴백해 1 크게 나온다.  **실물 스캔 결과 폴더에는
      그 파일이 사진과 같은 자리에 늘 있다**(사용자 확인).

    ±1 이웃 게이트 안이라 **매칭은 정상**이다.  Camtek 쪽 폴백을 고치면 이 테스트가
    실패하므로, 그때 `== kla.row` 로 조여서 빚을 갚았다는 걸 못 박을 것."""
    from aoi_verification.app.coords import camtek_ini, kla_info

    camtek_ini.load_folder.cache_clear()
    kla_info.load_folder.cache_clear()
    kla_info.load_folder_raw.cache_clear()

    cam = camtek_ini.resolve(
        _COORD_DATA / "Camtek" / "예시1" / "272646.165679.c.1000203959.2.jpeg")
    kla = kla_info.resolve(
        _COORD_DATA / "KLA" / "예시1" / "W6459076XYG1_2_0_23_2.jpg")
    assert cam is not None and kla is not None
    assert cam.col == kla.col == 5                       # col 은 정렬 — 이게 핵심
    assert (kla.col, kla.row) == (5, 3)                  # 장비 확인 규약
    assert cam.row - kla.row == 1                        # ★ 픽스처 한계(위 설명)
    assert abs(cam.row - kla.row) <= 1                   # ±1 게이트 안 → 매칭 정상


# ---------------------------------------------------------------------------
# ★ 실측 쌍 2 — 다른 로트·다른 KLA 장비 (W6458244XYE1, TB500_RDL1 - Multi)
#
# 기존 쌍(예시1~3)과 독립적이다: KLA 장비가 "K3" 가 아니라 "Tool", 제품 스텝이
# RDL2_NEW 가 아니라 RDL1_NEW, Camtek 은 EagleG5 의 x20/x5 2레시피 스캔이다.
# 여기서 얻는 것(→ docs/디바이스_하드코딩_조사.md §6-G):
#
#   · ``zero_x`` 는 KLA 파일만으로 산출된다(``−min(XINDEX)`` = 3).  Camtek 에 맞춰
#     튜닝한 값이 아니다.  그게 Camtek ``col_origin=2`` 와 정확히 맞으므로
#     **col_origin=2 가 독립적으로 확인**된다.
#   · 같은 결함의 recipe1·recipe2 사진이 **둘 다** 같은 KLA 결함에 붙는다.
# ---------------------------------------------------------------------------
_RDL1_PX, _RDL1_PY = 37247.9, 44905.3

# KLA 결함 14 (FrontSideADRImg_572445) — 20.8×16.9 µm 큰 결함이라 두 장비가 다 잡았다.
_RDL1_KLA_HEAD = (
    'DiePitch 3.7247930000e+004 4.4905340000e+004;\n'
    'WaferID "W6458244XYE1";\n'
    'SampleTestPlan 30\n'
    '  -3 -1 \n  -3 0 \n  -2 -2 \n  -2 -1 \n  -2 0 \n  -2 1 \n  -1 -3 \n  -1 -2 \n'
    '  -1 -1 \n  -1 0 \n  -1 1 \n  -1 2 \n  0 -3 \n  0 -2 \n  0 -1 \n  0 0 \n'
    '  0 1 \n  0 2 \n  1 -3 \n  1 -2 \n  1 -1 \n  1 0 \n  1 1 \n  1 2 \n'
    '  2 -2 \n  2 -1 \n  2 0 \n  2 1 \n  3 -1 \n  3 0 ;\n'
    'DefectRecordSpec 30 DEFECTID X Y XREL YREL XINDEX YINDEX XSIZE YSIZE '
    'DEFECTAREA DSIZE CLASSNUMBER TEST CLUSTERNUMBER ROUGHBINNUMBER FINEBINNUMBER '
    'REVIEWSAMPLE CHANNELID MANSEMCLASS AUTOSEMCLASS MICROSIGCLASS MACROSIGCLASS '
    'INTENSITY KILLPROB MACROSIGID ZABS EMRADIUS DWBINCODE IMAGECOUNT IMAGELIST ;\n'
    'DefectList;\n'
    'TiffFileName FrontSideADRImg_572445.jpg;\n'
    'DefectList\n'
    ' 14 73606.560 -37010.910 17371.701 7760.430 2 -1 20.800 16.900 351.360000 '
    '20.800 0 3 0 0 4 1 4 0 0 0 0 3731 0.0000 0 0 0.000000 2 1 1 1 0;\n'
    'EndOfFile;\n'
)

# 같은 결함을 Camtek 이 레시피별로 한 장씩 찍었다.
_RDL1_CAMTEK = [
    ("278197.216679.c.-189109460.1", 278197.718521499, 216679.594004774, 7, 4, 1),
    ("278199.216685.c.-1515889540.2", 278199.842373130, 216682.837907621, 7, 4, 2),
]


def _make_rdl1_folders(tmp_path):
    from aoi_verification.app.coords import camtek_ini, kla_info
    from aoi_verification.app.coords import wafer_geometry as wg
    for f in (wg.camtek_geometry, wg.kla_geometry, camtek_ini.load_folder,
              camtek_ini.load_raw_folder, camtek_ini.load_recipe_folder,
              kla_info.load_folder, kla_info.load_folder_raw):
        f.cache_clear()
    kla = tmp_path / "kla"
    kla.mkdir()
    (kla / "W6458244XYE1.001").write_text(_RDL1_KLA_HEAD, encoding="utf-8")
    cam = tmp_path / "camtek"
    cam.mkdir()
    (cam / "ColorImageGrabingInfo.ini").write_text("".join(
        f"[{s}.jpeg]\nX={X}\nY={Y}\nCol={c}\nRow={r}\nRecipeNumber={n}\n"
        for s, X, Y, c, r, n in _RDL1_CAMTEK), encoding="utf-8")
    (cam / "Params_WaferInfo.ini").write_text(
        f"[Geometry]\nDieStep_X={_RDL1_PX:.6f}\nDieStep_Y={_RDL1_PY:.6f}\n"
        f"[Geometric]\nDiameter=300000.000000\n", encoding="utf-8")
    return kla, cam


def test_real_pair2_zero_x_is_derived_and_confirms_col_origin(tmp_path):
    """★ ``zero_x`` 는 KLA 파일만으로 나온다 — Camtek 에 맞춘 값이 아니다."""
    from aoi_verification.app.coords import wafer_geometry as wg
    kla, _cam = _make_rdl1_folders(tmp_path)
    g = wg.kla_geometry(kla)
    assert g.source == "DiePitch+SampleTestPlan"     # 파일에서 산출했다는 증거
    assert g.zero_x == 3                             # −min(XINDEX) = −(−3)


@pytest.mark.parametrize("stem", [c[0] for c in _RDL1_CAMTEK])
def test_real_pair2_kla_camtek_align(tmp_path, stem):
    """★ 실측 쌍 2 — 두 레시피 사진 **모두** 같은 KLA 결함과 (col,row) 가 일치한다.

    거리 125 µm 로 같은 물리 결함임이 확인된 쌍이다(기존 쌍 112~121 µm 과 같은 수준)."""
    import math
    from aoi_verification.app.coords import camtek_ini, kla_info
    kla, cam = _make_rdl1_folders(tmp_path)
    k = kla_info.load_folder(kla)["frontsideadrimg_572445"]
    c = camtek_ini.load_folder(cam)[stem]
    assert (c.col, c.row) == (k.col, k.row) == (5, 3)
    assert math.hypot(c.x - k.x, c.y - k.y) <= 200


@pytest.mark.parametrize("bad", ["X=nan", "X=inf", "Col=inf"])
def test_one_non_finite_entry_does_not_empty_the_folder(tmp_path, bad):
    """좌표 전반 점검(2026-10-24) — 항목 하나의 값이 nan/inf 여도 **나머지 항목은 남는다**.

    예전에는 ``floor(nan)``·``int(inf)`` 예외를 ``load_folder`` 의 바깥 except 가 삼켜
    폴더 전체가 {} 가 됐다(경고도 없이 그 슬롯 사진이 전부 '좌표 없음').  합성 입력."""
    from aoi_verification.app.coords import camtek_ini
    good = "[good_1.jpeg]\nX=102450.6\nY=156233.9\nCol=4\nRow=3\n"
    key, _ = bad.split("=")
    fields = {"X": "102460.6", "Y": "156240.9", "Col": "4", "Row": "3"}
    fields[key] = bad.split("=")[1]
    body = "".join(f"{k}={v}\n" for k, v in fields.items())
    (tmp_path / "ColorImageGrabingInfo.ini").write_text(
        good + "[bad_2.jpeg]\n" + body, encoding="utf-8")
    camtek_ini.load_folder.cache_clear()
    camtek_ini.load_abs_folder.cache_clear()
    got = camtek_ini.load_folder(tmp_path)
    assert "good_1" in got
    assert "bad_2" not in got


def test_clear_caches_picks_up_a_rewritten_or_late_ini(tmp_path):
    """점검(2026-10-24) — 좌표 캐시 키가 폴더뿐이라, 앱을 켠 채 INI 가 **늦게 생기거나**
    (첫 읽기가 빈 결과로 캐시) **다시 쓰이면** 앱을 다시 켤 때까지 옛 값을 썼다.
    검증을 시작할 때 ``coords.clear_caches()`` 를 부르면 새 파일을 읽는다.  합성 입력."""
    from aoi_verification.app import coords
    from aoi_verification.app.coords import camtek_ini
    coords.clear_caches()
    assert camtek_ini.load_folder(tmp_path) == {}            # 아직 INI 가 없다
    ini = tmp_path / "ColorImageGrabingInfo.ini"
    ini.write_text("[a_1.jpeg]\nX=102450.6\nY=156233.9\nCol=4\nRow=3\n", encoding="utf-8")
    assert camtek_ini.load_folder(tmp_path) == {}            # 캐시가 옛 빈 결과를 낸다
    coords.clear_caches()
    first = camtek_ini.load_folder(tmp_path)["a_1"]
    ini.write_text("[a_1.jpeg]\nX=104450.6\nY=156233.9\nCol=4\nRow=3\n", encoding="utf-8")
    coords.clear_caches()
    assert camtek_ini.load_folder(tmp_path)["a_1"].x != first.x


def test_scan_start_clears_coordinate_caches():
    """배선 가드 — 검증 시작 경로가 ``coords.clear_caches()`` 를 부른다."""
    src = (Path(__file__).resolve().parents[2] / "aoi_verification" / "app" / "ui"
           / "main_window.py").read_text(encoding="utf-8")
    i = src.index("_cache.reset_mtime_cache()")
    assert "_coords.clear_caches()" in src[i:i + 300]


def test_truncated_kla_info_file_warns_and_keeps_what_it_read(tmp_path, caplog):
    """좌표 전반 점검(2026-10-24, 관측) — LSU TB500 RDL4 44장 중 2장의 ``.001`` 이 결함 행
    중간에서 끊겨 뒤쪽 사진 58장이 좌표 없이 조용히 빠졌다.  읽은 결함은 그대로 쓰고,
    끊겼다는 사실은 경고로 남긴다(정상 파일은 경고 없음)."""
    import logging
    from aoi_verification.app.coords import kla_info
    kla, _cam = _make_rdl1_folders(tmp_path)
    with caplog.at_level(logging.WARNING, logger="aoi.coords"):
        assert "frontsideadrimg_572445" in kla_info.load_folder(kla)
    assert "EndOfFile" not in caplog.text
    cut = _RDL1_KLA_HEAD.replace("EndOfFile;\n", "TiffFileName FrontSideADRImg_9.jpg;\n"
                                 "DefectList\n 15 1.0 2.0 3.0")
    (kla / "W6458244XYE1.001").write_text(cut, encoding="utf-8")
    kla_info.load_folder.cache_clear()
    kla_info.load_folder_raw.cache_clear()
    caplog.clear()
    with caplog.at_level(logging.WARNING, logger="aoi.coords"):
        got = kla_info.load_folder(kla)
    assert "frontsideadrimg_572445" in got and "frontsideadrimg_9" not in got
    assert "EndOfFile" in caplog.text


def test_fused_number_row_is_dropped_not_shifted(tmp_path, caplog):
    """좌표 전반 점검(2026-10-24, 관측) — LSU ``59295773EWA7.001`` 에 두 수가 붙어 적힌 행
    ``43 9784.08023366.970 28203.080 3213.973 0 0 9.990 …`` 이 있었다.  예전 정규식은 한 칸씩
    밀려 YREL=0·XINDEX=0·YINDEX=9('9.990' 의 앞 글자)로 읽어 col/row 를 (3,12) 로 조용히
    틀리게 냈다.  그 행은 버리고 경고한다(행 문자열은 실물 그대로)."""
    import logging
    from aoi_verification.app.coords import kla_info
    kla, _cam = _make_rdl1_folders(tmp_path)
    fused = (" 43 9784.08023366.970 28203.080 3213.973 0 0 9.990 13.730 137.150000 13.730 "
             "23 3 0 0 3 3 0 2373 0 1 1 1 0;\n")
    text = _RDL1_KLA_HEAD.replace(
        "EndOfFile;\n", "TiffFileName FrontSideADRImg_43.jpg;\nDefectList\n" + fused
        + "EndOfFile;\n")
    (kla / "W6458244XYE1.001").write_text(text, encoding="utf-8")
    with caplog.at_level(logging.WARNING, logger="aoi.coords"):
        got = kla_info.load_folder(kla)
    assert "frontsideadrimg_43" not in got
    assert "frontsideadrimg_572445" in got           # 정상 행은 그대로
    assert "형식이 깨져" in caplog.text
