"""Defect 추출 — 매칭 없이 wafer/LOT 폴더에서 고른 사진과 그 정보를 엑셀로.

사용자 결정(요약):
· 입력: wafer 폴더·LOT 폴더 모두(자동 판별), 한 번에 호기 1개, Camtek·KLA 모두.
· 진입: 설정 화면의 [Defect 추출] — 같은 화면을 한쪽 폴더만 받는 모드로 바꾼다.
· 선별: 매칭의 후보 선별 화면·조작 그대로.
· 엑셀: 양식.xlsx, 시트 1개(세로), A=No · B=Slot · C=사진 · D=정보 — **미매칭 사진
  정보를 적듯이**(D열 글자로 보이게) + Wafer Map 시트.  정렬 slot → 파일명.
· KLA slot명: 매칭과 같다(정보파일 우선, OCR 폴백).  KLA 여부는 묻지 않는다 —
  호기 K-n 이거나 폴더에 KLA 정보파일이 있으면 KLA(사용자 지적으로 바뀜).
· 저장: 결과 엑셀과 같은 방식, 이름에 '추출'.  간단한 요약 후 저장.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from aoi_verification.app.models.result import (EXTRACT_MODE, FinalResult,  # noqa: E402
                                                MissEntry, extract_result)
from aoi_verification.app.models.slot import (extract_slot_dirs,           # noqa: E402
                                              rename_slots_by_wafer_id,
                                              scan_one_side)


def _touch_jpeg(p: Path) -> Path:
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image
        Image.new("RGB", (40, 30), color=(80, 120, 200)).save(str(p), "JPEG")
    except ImportError:
        p.write_bytes(b"")
    return p


# ── 폴더 판별 ────────────────────────────────────────────────────────────────
def test_lot_folder_gives_one_slot_per_subfolder(tmp_path):
    for slot, names in {"S1": ["b.jpg", "a.jpg"], "S2": ["c.jpg"]}.items():
        for n in names:
            _touch_jpeg(tmp_path / slot / n)
    (tmp_path / "S3").mkdir()                          # 사진 없는 슬롯도 목록엔 있다
    sr = scan_one_side(tmp_path)
    assert sorted(sr.slots) == ["S1", "S2", "S3"]
    assert [it.filename for it in sr.slots["S1"].ref_images] == ["a.jpg", "b.jpg"]
    assert all(it.side == "ref" and it.slot == "S1"
               for it in sr.slots["S1"].ref_images)
    assert sr.slots["S2"].ref_dir == tmp_path / "S2"
    assert not sr.slots["S1"].val_images
    assert sr.ref_only == [] and sr.val_only == []


def test_lot_folder_honours_subset(tmp_path):
    for slot in ("S1", "S2", "S3"):
        _touch_jpeg(tmp_path / slot / "a.jpg")
    assert sorted(scan_one_side(tmp_path, only={"S1", "S3"}).slots) == ["S1", "S3"]


def test_wafer_folder_is_one_slot_even_with_subfolders(tmp_path):
    """★ Camtek wafer 폴더에는 `_recipe_files_…` 같은 하위 폴더가 함께 있다 —
    '하위 폴더가 있으면 LOT' 으로 판정하면 그 폴더들이 슬롯이 되고 사진은 사라진다."""
    wafer = tmp_path / "GIX5703110"
    _touch_jpeg(wafer / "1_2_d.jpg")
    (wafer / "_recipe_files_GX57001305").mkdir()
    sr = scan_one_side(wafer, only={"_recipe_files_GX57001305"})   # only 는 무시된다
    assert list(sr.slots) == ["GIX5703110"]
    assert [it.filename for it in sr.slots["GIX5703110"].ref_images] == ["1_2_d.jpg"]
    assert sr.slots["GIX5703110"].ref_dir == wafer


def test_lot_folder_with_stray_photos_is_still_a_lot(tmp_path):
    """★ KLA LOT 폴더 바로 안에 안내 사진(1.JPG, REPORT.JPG)이 있어도 하위 폴더가 슬롯이다.
    실측(2026-11-02, INTP-KENDALL-207-2637@6412): 이 사진 6장 때문에 슬롯 25개가 1개로 나왔다.
    슬롯 판정은 사진 또는 KLA 정보파일(.001)을 가진 하위 폴더가 2개 이상일 때다."""
    _touch_jpeg(tmp_path / "REPORT.JPG")
    _touch_jpeg(tmp_path / "1.JPG")
    _touch_jpeg(tmp_path / "S1" / "a.jpg")
    (tmp_path / "S2").mkdir()
    (tmp_path / "S2" / "lot_WAFER2.001").write_bytes(b"")     # 사진 없이 정보파일만
    sr = scan_one_side(tmp_path)
    assert sorted(sr.slots) == ["S1", "S2"]
    assert extract_slot_dirs(tmp_path).keys() == sr.slots.keys()


def test_one_content_subfolder_does_not_make_a_lot(tmp_path):
    """하위 폴더 하나만 내용이 있으면 wafer 폴더 규칙을 그대로 쓴다."""
    _touch_jpeg(tmp_path / "x.jpg")
    _touch_jpeg(tmp_path / "S1" / "a.jpg")
    (tmp_path / "S2").mkdir()
    assert list(scan_one_side(tmp_path).slots) == [tmp_path.name]


def test_ignored_photos_do_not_make_a_wafer_folder(tmp_path):
    """웨이퍼 전경 사진만 있는 폴더는 wafer 폴더가 아니다(열거가 걸러 내는 사진)."""
    _touch_jpeg(tmp_path / "CognexInSight17xx_Bottom_Slot21.jpg")
    _touch_jpeg(tmp_path / "S1" / "a.jpg")
    assert list(scan_one_side(tmp_path).slots) == ["S1"]


def test_scan_reports_progress(tmp_path):
    for slot in ("S1", "S2"):
        _touch_jpeg(tmp_path / slot / "a.jpg")
    seen = []
    scan_one_side(tmp_path, progress=lambda d, t: seen.append((d, t)))
    assert seen == [(1, 2), (2, 2)]


# ── KLA slot명 ───────────────────────────────────────────────────────────────
def test_kla_folders_are_renamed_to_wafer_id(tmp_path):
    for slot in ("2026-08-02-23-09_4", "2026-08-03-20-28_2"):
        _touch_jpeg(tmp_path / slot / "x.jpg")
    sr = scan_one_side(tmp_path)
    kla = rename_slots_by_wafer_id(sr, {"2026-08-02-23-09_4": "a1033abqewg3"})
    # 표기는 매칭과 같은 대문자 정규화
    assert sorted(sr.slots) == ["2026-08-03-20-28_2", "A1033ABQEWG3"]
    assert kla == {"A1033ABQEWG3": "2026-08-02-23-09_4"}
    s = sr.slots["A1033ABQEWG3"]
    assert s.name == "A1033ABQEWG3"
    assert all(it.slot == "A1033ABQEWG3" for it in s.ref_images)
    assert s.ref_dir == tmp_path / "2026-08-02-23-09_4"      # 원본 폴더는 그대로


def test_kla_rename_never_overwrites_another_slot(tmp_path):
    """★ 두 폴더가 같은 WaferID 를 내면 두 번째는 폴더명 그대로 남는다 — 덮으면
    한쪽 웨이퍼의 사진이 조용히 사라진다."""
    for slot in ("K1", "K2"):
        _touch_jpeg(tmp_path / slot / "x.jpg")
    sr = scan_one_side(tmp_path)
    kla = rename_slots_by_wafer_id(sr, {"K1": "W1", "K2": "W1"})
    assert sorted(sr.slots) == ["K2", "W1"]
    assert kla == {"W1": "K1"}


# ── 결과 묶음 ────────────────────────────────────────────────────────────────
def test_kla_is_detected_from_info_file_without_asking(tmp_path):
    """KLA 여부는 묻지 않는다 — 폴더 하나라도 KLA 정보파일이 있으면 KLA, 없으면 Camtek."""
    pytest.importorskip("PyQt6.QtWidgets")
    from aoi_verification.app.coords import kla_info
    from aoi_verification.app.ui.main_window import MainWindow

    camtek = tmp_path / "camtek"
    for slot in ("S1", "S2"):
        _touch_jpeg(camtek / slot / "a.jpg")
    kla = tmp_path / "kla"
    for slot in ("2026-08-02-23-09_4", "2026-08-03-20-28_2"):
        _touch_jpeg(kla / slot / "a.jpg")
    (kla / "2026-08-03-20-28_2" / "info.001").write_text(
        'WaferID "W1";\nSlot 3;\n', encoding="ascii")
    kla_info.read_header_ids.cache_clear()
    assert MainWindow._has_kla_info(scan_one_side(camtek)) is False
    assert MainWindow._has_kla_info(scan_one_side(kla)) is True


def test_extract_result_carries_only_picked_photos():
    r = extract_result("3", {"S2": [Path("/x/S2/b.jpg")], "S1": [Path("/x/S1/a.jpg")],
                             "S3": []},
                       kla_folders={"S1": "k"}, slot_numbers={"S1": "6"})
    assert r.mode == EXTRACT_MODE and r.matches == []
    assert [(u.slot, u.path.name, u.side) for u in r.unmatched_refs] == [
        ("S1", "a.jpg", "ref"), ("S2", "b.jpg", "ref")]
    # Wafer map 에는 고른 사진만 — 빈 슬롯은 행을 만들지 않는다.
    assert r.slot_images == {"S1": ([Path("/x/S1/a.jpg")], []),
                             "S2": ([Path("/x/S2/b.jpg")], [])}
    assert r.kla_folders == {"S1": "k"} and r.slot_numbers == {"S1": "6"}
    assert r.val_machine == ""


def test_wafer_map_has_no_match_state_for_extraction(monkeypatch, tmp_path):
    """추출은 매칭을 하지 않았다 — 점을 '미매치' 로 칠하면 거짓이다."""
    from aoi_verification.app.coords import wafer_map as wm
    photo = _touch_jpeg(tmp_path / "S1" / "a.jpg")
    seen = []
    monkeypatch.setattr(wm, "build_map", lambda coords, matched=None:
                        seen.append(matched) or wm.MapData(None, (), ()))
    wm.slot_maps(extract_result("3", {"S1": [photo]}), "S1")
    assert seen == [None, None]
    single = FinalResult(mode="single", ref_machine="1", val_machine="2",
                         slot_images={"S1": ([photo], [])})
    seen.clear()
    wm.slot_maps(single, "S1")
    assert seen == [set(), set()]                     # 매칭 결과는 예전 그대로


# ── 엑셀 ─────────────────────────────────────────────────────────────────────
def _export(result, dst, tpl=None, map_renderer=None):
    from aoi_verification.app.workers.exporter import ExcelExporter
    exp = ExcelExporter(result, dst_path=dst,
                        template_path=tpl or dst.parent / "no_template.xlsx",
                        map_renderer=map_renderer)
    failed = []
    exp.signals.failed.connect(failed.append)
    exp.run()
    assert not failed, failed
    return dst


def _png(_data, size):
    import io

    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (size, size), "white").save(buf, "PNG")
    return buf.getvalue()


def test_excel_layout(qapp, tmp_path):
    pytest.importorskip("openpyxl")
    pytest.importorskip("PIL.Image")
    from openpyxl import load_workbook

    from aoi_verification.app import i18n
    from aoi_verification.app.utils import paths
    from aoi_verification.app.workers import exporter as ex

    a = _touch_jpeg(tmp_path / "src" / "S2" / "a.jpg")
    b = _touch_jpeg(tmp_path / "src" / "S1" / "b.jpg")
    c = _touch_jpeg(tmp_path / "src" / "S1" / "a.jpg")
    result = extract_result("3호기", {"S2": [a], "S1": [b, c]},
                            slot_numbers={"S1": "6"})
    tpl = paths.template_path()
    dst = _export(result, tmp_path / "out.xlsx",
                  tpl=tpl if tpl.exists() else None, map_renderer=_png)

    wb = load_workbook(str(dst), rich_text=True)
    # 시트 1개(요약) + Wafer Map — '미매칭 사진' 시트는 없다.
    assert wb.sheetnames == ["out", i18n.KO.WAFER_MAP_SHEET]
    ws = wb["out"]
    assert ws["C2"].value == "AOI-3"
    assert ws["D2"].value == i18n.KO.EXTRACT_INFO_HEADER
    # 정렬: slot → 파일명
    rows = [(ws[f"A{r}"].value, str(ws[f"B{r}"].value).split("\n")[0],
             str(ws[f"D{r}"].value).split("\n")[0]) for r in (3, 4, 5)]
    assert rows == [(1, "S1", "a.jpg"), (2, "S1", "b.jpg"), (3, "S2", "a.jpg")]
    assert ws["B3"].value == "S1\n(#6)"
    assert len(ws._images) == 3                        # C열 사진
    for r in (3, 4, 5):
        d = ws[f"D{r}"]
        assert d.comment is None                       # '미매칭' 메모 없음
        assert ex.UNMATCHED_FILL not in str(d.fill.fgColor.rgb)   # 미매칭 틴트 없음
    # Wafer Map — 장비가 하나라 맵 칸도 하나.
    wm = wb[i18n.KO.WAFER_MAP_SHEET]
    assert wm["B1"].value.startswith(i18n.KO.EXTRACT_MAP_SHEET_COL)
    assert "AOI-3" in wm["B1"].value
    assert wm["C1"].value is None
    assert [wm.cell(row=r, column=1).value for r in (2, 3, 4)] == [
        i18n.KO.WAFER_MAP_SHEET_ALL, "S1\n(#6)", "S2"]


def test_info_column_is_written_like_an_unmatched_row(qapp, tmp_path):
    """★ 사용자 결정: '마치 미매칭 사진 정보 출력하듯이'.  D열 글자는 매칭 결과의
    미매칭 행이 적는 것과 **한 글자도 다르지 않아야** 한다(같은 생산자)."""
    pytest.importorskip("openpyxl")
    pytest.importorskip("PIL.Image")
    from openpyxl import load_workbook

    p = _touch_jpeg(tmp_path / "src" / "S1" / "a.jpg")
    ext = _export(extract_result("3", {"S1": [p]}), tmp_path / "ext.xlsx")
    ref = _export(FinalResult(mode="single", ref_machine="3", val_machine="4",
                              unmatched_refs=[MissEntry("S1", "ref", p)]),
                  tmp_path / "ref.xlsx")
    d_ext = load_workbook(str(ext), rich_text=True)["ext"]["D3"].value
    d_ref = load_workbook(str(ref), rich_text=True)["ref"]["D3"].value
    assert str(d_ext) == str(d_ref)
    assert "a.jpg" in str(d_ext)


# ── 설정 화면 ────────────────────────────────────────────────────────────────
def test_setup_extract_mode_takes_one_folder(qapp, tmp_path):
    pytest.importorskip("PyQt6.QtWidgets")
    from aoi_verification.app import i18n
    from aoi_verification.app.ui.pages import setup_page as sp

    page = sp.SetupPage()
    try:
        page.ref_path_edit.setText(str(tmp_path))
        page.val_path_edit.setText("")
        assert page._validate() is False               # 매칭은 두 폴더가 필요
        page.set_extract_mode(True)
        assert page.is_extract_mode()
        assert page._validate() is True                # 추출은 한 폴더면 된다
        assert page.val_group.isHidden()
        assert page._setting_cards[1].isHidden()       # 매칭 설정
        assert page._mode_badge_card.isHidden()
        assert not page._setting_cards[0].isHidden()   # 실행 옵션은 남는다
        assert page.start_btn.text() == i18n.KO.BTN_EXTRACT_START
        assert page._title_label.text() == i18n.KO.EXTRACT_TITLE
        # 버튼 글자는 그대로, 왼쪽 메뉴에서 'Defect 추출' 이 눌린 모양(되돌아가기는 [매칭]).
        assert page.extract_btn.property("_railText") == i18n.KO.EXTRACT_BUTTON
        assert page.extract_btn.isChecked() and not page.match_btn.isChecked()
        page.ref_machine_edit.setText("17")
        inp = page._collect_input()
        assert inp.extract is True
        assert inp.ref_root == tmp_path and inp.val_root == tmp_path
        assert inp.ref_machine == "17" and inp.val_machine == ""
        # 되돌리면 원래 화면 그대로(입력값 보존)
        page.set_extract_mode(False)
        assert not page.val_group.isHidden()
        assert not page._setting_cards[1].isHidden()
        assert page.start_btn.text() == i18n.KO.BTN_START
        assert page.ref_path_edit.text() == str(tmp_path)
        assert page._validate() is False
    finally:
        page.deleteLater()


def test_extract_button_sits_in_the_tool_rail(qapp):
    """도구는 왼쪽 레일, 시작 바는 배지(왼쪽 끝) → stretch → … → 주 액션(맨 끝)."""
    from aoi_verification.app.ui.pages import setup_page as sp
    page = sp.SetupPage()
    try:
        bar = page._action_bar
        widgets = [bar.itemAt(i).widget() for i in range(bar.count())]
        stretch_at = next(i for i in range(bar.count())
                          if bar.itemAt(i).spacerItem() is not None)
        assert widgets[0] is page._mode_badge_card and stretch_at == 1
        assert page.extract_btn in page._tool_buttons
        assert page._tool_rail.isAncestorOf(page.extract_btn)
        assert widgets[-1] is page.start_btn
    finally:
        page.deleteLater()


# ── 메인 창 ──────────────────────────────────────────────────────────────────
def test_file_name_follows_result_rule_with_extract(qapp, tmp_path):
    from aoi_verification.app.ui import main_window as mw
    from aoi_verification.app.ui.pages.setup_page import SetupInput

    lot = tmp_path / "LOT"
    (lot / "S1").mkdir(parents=True)
    (lot / "S1" / "Params_WaferInfo.ini").write_text(
        "SetupPath=c:\\job\\TB500_RDL4 - Multi\\Setup1\\\n", encoding="utf-8")
    inp = SetupInput(mode="single", ref_root=lot, val_root=lot, ref_machine="17",
                     val_machine="", threshold=0.7, extract=True)
    assert mw.MainWindow._suggest_result_name(inp) == "17 TB500_RDL4 Defect 추출.xlsx"
    inp.ref_root = inp.val_root = tmp_path / "없음"
    assert mw.MainWindow._suggest_result_name(inp) == "AOI 17 Defect 추출.xlsx"


def _pump_until(cond, timeout_s=30.0):
    import time

    from PyQt6.QtWidgets import QApplication
    end = time.monotonic() + timeout_s
    while time.monotonic() < end:
        QApplication.processEvents()
        if cond():
            return True
        time.sleep(0.01)
    return cond()


def test_end_to_end_select_then_save(qapp, tmp_path, monkeypatch):
    """설정(추출) → 스캔 → 썸네일 → 후보 선별(실제 SelectPage) → 요약 → 저장.

    매칭·검토·결과 화면은 거치지 않고, 저장 뒤에는 설정 화면으로 돌아온다."""
    pytest.importorskip("openpyxl")
    pytest.importorskip("PIL.Image")
    from openpyxl import load_workbook

    from aoi_verification.app.ui import main_window as mw
    from aoi_verification.app.ui.pages.setup_page import SetupInput
    from aoi_verification.app.ui.widgets import save_name_dialog

    lot = tmp_path / "LOT"
    for slot, names in {"S1": ["a.jpg", "b.jpg"], "S2": ["c.jpg"]}.items():
        for n in names:
            _touch_jpeg(lot / slot / n)

    monkeypatch.setattr(mw.MainWindow, "_start_backend_import_async",
                        lambda self: None)
    # 개발 모드의 결과 폴더는 저장소 안(`결과/`)이다 — 테스트가 거기에 쓰면 안 된다.
    results = tmp_path / "결과"
    results.mkdir()
    monkeypatch.setattr(mw.paths, "results_dir", lambda: results)
    win = mw.MainWindow()
    win._on_backend_loaded()                  # 나머지 페이지를 지금 만든다
    choices: list = []

    def fake_choose(_parent, title, text, options, **kw):
        keys = [o[0] for o in options]
        choices.append((title, text, keys))
        assert "kla" not in keys              # KLA 여부는 묻지 않는다
        if "single" in keys:
            return "single"                   # 요약 창 — 한 시트로 저장
        return "close"                        # 저장 완료 → 닫기

    monkeypatch.setattr(mw.sheets, "choose", fake_choose)

    class _Dlg:
        def __init__(self, name, _folder, parent=None, **_kw):
            self.chosen = name

    monkeypatch.setattr(save_name_dialog, "SaveNameDialog", _Dlg)
    monkeypatch.setattr(mw.sheets, "run", lambda dlg, **k: True)
    win.show()                                # 선별은 보이는 화면에서만 결정을 받는다
    try:
        win._on_start(SetupInput(mode="single", ref_root=lot, val_root=lot,
                                 ref_machine="17", val_machine="", threshold=0.7,
                                 extract=True))
        assert _pump_until(lambda: win._stack.currentWidget() is win._select_page)
        # 매칭과 같은 선별 화면 — 3장 중 a, c 를 고르고 b 를 뺀다(방향키와 같은 경로).
        page = win._select_page
        for _ in range(3):
            cur = page._current
            page._decide("exclude" if cur.filename == "b.jpg" else "verify")
            assert _pump_until(lambda: page._current is not cur
                               or not page.get_state().queue, 5)
        assert _pump_until(lambda: win._stack.currentWidget() is win._setup_page)
        summary = [c for c in choices if "single" in c[2]]
        assert summary and "2" in summary[0][1]       # defect 2건
        saved = list(results.glob("*추출*.xlsx"))
        assert len(saved) == 1
        ws = load_workbook(str(saved[0]))[saved[0].stem[:31]]
        names = [str(ws[f"D{r}"].value).split("\n")[0] for r in (3, 4)]
        assert names == ["a.jpg", "c.jpg"]
        # 추출 세션은 이어하기에 남지 않는다
        from aoi_verification.app.models import session as session_mod
        assert session_mod.load() is None
    finally:
        win.close()


# ── Recipe 나누기 ────────────────────────────────────────────────────────────
def _fake_recipes(monkeypatch, table):
    """파일명 → (코드, 이름).  Surface.flt 를 합성하지 않고 분류 규칙만 본다."""
    from aoi_verification.app.workers import exporter as ex
    none = (None, ex.i18n.KO.EXTRACT_RECIPE_NONE)
    monkeypatch.setattr(ex, "recipe_of", lambda p: table.get(Path(p).name, none))


def test_recipe_groups_order_and_none_last(monkeypatch):
    from aoi_verification.app.workers import exporter as ex
    _fake_recipes(monkeypatch, {"a.jpg": (2, "PI"), "b.jpg": (1, "PI_Bubble"),
                                "c.jpg": (2, "PI")})
    got = ex.recipe_groups([Path("/x/a.jpg"), Path("/x/z.jpg"), Path("/x/b.jpg"),
                            Path("/x/c.jpg")])
    assert [(label, [p.name for p in ps]) for label, ps in got] == [
        ("PI_Bubble", ["b.jpg"]), ("PI", ["a.jpg", "c.jpg"]),
        (ex.i18n.KO.EXTRACT_RECIPE_NONE, ["z.jpg"])]


def test_recipe_of_uses_surface_flt_name_then_code(monkeypatch):
    """출처는 Surface.flt recipe(사용자 결정) — 이름이 없으면 코드로 대신한다."""
    from aoi_verification.app.coords import geometry
    from aoi_verification.app.coords.models import DefectGeometry
    from aoi_verification.app.workers import exporter as ex

    def geo(name):
        return geometry.GeometryResult("ok", DefectGeometry(
            1, 1, 1, 1, zone=1, recipe=3, pixel_um=1, recipe_name=name))
    monkeypatch.setattr(geometry, "resolve", lambda p: geo("PI_Bubble"))
    assert ex.recipe_of("/x/a.jpg") == (3, "PI_Bubble")
    monkeypatch.setattr(geometry, "resolve", lambda p: geo(""))
    assert ex.recipe_of("/x/a.jpg") == (3, "Recipe 3")
    monkeypatch.setattr(geometry, "resolve",
                        lambda p: geometry.GeometryResult("no_flt", None))
    assert ex.recipe_of("/x/a.jpg") == (None, ex.i18n.KO.EXTRACT_RECIPE_NONE)


def test_safe_sheet_title():
    from aoi_verification.app.workers.exporter import _safe_sheet_title
    assert _safe_sheet_title("PI/Bubble:[1]", set()) == "PI_Bubble__1_"
    assert _safe_sheet_title("PI", {"PI"}) == "PI (2)"
    assert len(_safe_sheet_title("x" * 40, {"x" * 31})) == 31


def _three_slot_result(tmp_path):
    ps = {n: _touch_jpeg(tmp_path / "src" / slot / n)
          for slot, n in [("S1", "a.jpg"), ("S1", "b.jpg"), ("S1", "c.jpg"),
                          ("S2", "d.jpg")]}
    return extract_result("3", {"S1": [ps["a.jpg"], ps["b.jpg"], ps["c.jpg"]],
                                "S2": [ps["d.jpg"]]})


def test_sheets_layout_one_sheet_per_recipe(qapp, tmp_path, monkeypatch):
    pytest.importorskip("openpyxl")
    pytest.importorskip("PIL.Image")
    from openpyxl import load_workbook

    from aoi_verification.app import i18n
    from aoi_verification.app.workers import exporter as ex

    _fake_recipes(monkeypatch, {"a.jpg": (1, "PI_Bubble"), "c.jpg": (1, "PI_Bubble"),
                                "b.jpg": (2, "PI")})
    dst = tmp_path / "out.xlsx"
    exp = ex.ExcelExporter(_three_slot_result(tmp_path), dst_path=dst,
                           template_path=tmp_path / "none.xlsx", map_renderer=_png,
                           recipe_layout=ex.RECIPE_LAYOUT_SHEETS)
    exp.run()
    wb = load_workbook(str(dst), rich_text=True)
    assert wb.sheetnames == ["PI_Bubble", "PI", i18n.KO.EXTRACT_RECIPE_NONE,
                             i18n.KO.WAFER_MAP_SHEET]

    def rows(name):
        ws = wb[name]
        out, r = [], 3
        while ws[f"A{r}"].value is not None:
            out.append((str(ws[f"B{r}"].value), str(ws[f"D{r}"].value).split("\n")[0]))
            r += 1
        return out
    assert rows("PI_Bubble") == [("S1", "a.jpg"), ("S1", "c.jpg")]
    assert rows("PI") == [("S1", "b.jpg")]
    assert rows(i18n.KO.EXTRACT_RECIPE_NONE) == [("S2", "d.jpg")]
    assert wb["PI"]["D2"].value == i18n.KO.EXTRACT_INFO_HEADER


def test_columns_layout_side_by_side(qapp, tmp_path, monkeypatch):
    """한 시트, Recipe 마다 [사진|정보] 열.  위치를 모르는 사진은 짝이 없으므로 한 장이 한 행."""
    pytest.importorskip("openpyxl")
    pytest.importorskip("PIL.Image")
    from openpyxl import load_workbook

    from aoi_verification.app import i18n
    from aoi_verification.app.workers import exporter as ex

    _fake_recipes(monkeypatch, {"a.jpg": (1, "PI_Bubble"), "c.jpg": (1, "PI_Bubble"),
                                "b.jpg": (2, "PI")})
    dst = tmp_path / "out.xlsx"
    single = tmp_path / "single.xlsx"
    ex.ExcelExporter(_three_slot_result(tmp_path), dst_path=dst,
                     template_path=tmp_path / "none.xlsx", map_renderer=_png,
                     recipe_layout=ex.RECIPE_LAYOUT_COLUMNS).run()
    ex.ExcelExporter(_three_slot_result(tmp_path), dst_path=single,
                     template_path=tmp_path / "none.xlsx").run()
    wb = load_workbook(str(dst), rich_text=True)
    assert wb.sheetnames == ["out", i18n.KO.WAFER_MAP_SHEET]
    ws = wb["out"]
    # 머리: Recipe 이름(두 칸 병합) / AOI-N · 정보
    assert [ws[f"{c}1"].value for c in "CEG"] == ["PI_Bubble", "PI",
                                                 i18n.KO.EXTRACT_RECIPE_NONE]
    assert [ws[f"{c}2"].value for c in "CDEF"] == ["AOI-3", i18n.KO.EXTRACT_INFO_HEADER,
                                                  "AOI-3", i18n.KO.EXTRACT_INFO_HEADER]
    assert "C1:D1" in {str(r) for r in ws.merged_cells.ranges}

    def name(cell):
        return None if cell.value is None else str(cell.value).split("\n")[0]
    # 짝 없는 사진은 섞이지 않는다 — Recipe 순서 → 파일명 순서로 한 장씩
    grid = [(ws[f"A{r}"].value, str(ws[f"B{r}"].value), name(ws[f"D{r}"]),
             name(ws[f"F{r}"]), name(ws[f"H{r}"])) for r in (3, 4, 5, 6)]
    assert grid == [(1, "S1", "a.jpg", None, None),
                    (2, "S1", "c.jpg", None, None),
                    (3, "S1", None, "b.jpg", None),
                    (4, "S2", None, None, "d.jpg")]
    assert ws["A7"].value is None
    assert len(ws._images) == 4                      # 사진 4장
    # 정보 칸 글자는 한 시트 배치의 D열과 같다(같은 생산자)
    ss = load_workbook(str(single), rich_text=True)["single"]
    assert str(ws["D3"].value) == str(ss["D3"].value)


def test_layout_is_ignored_for_match_results(qapp, tmp_path):
    """Recipe 나누기는 추출 전용 — 매칭 결과에 값을 줘도 예전 배치 그대로다."""
    from aoi_verification.app.workers import exporter as ex
    exp = ex.ExcelExporter(FinalResult(mode="single", ref_machine="1", val_machine="2"),
                           dst_path=tmp_path / "o.xlsx",
                           recipe_layout=ex.RECIPE_LAYOUT_SHEETS)
    assert exp._recipe_layout == ex.RECIPE_LAYOUT_SINGLE


def test_export_logs_stage_times(qapp, tmp_path, caplog):
    """느린 단계를 실측으로 가리기 위한 기록 — app.log 로 가는 'aoi.export' 로거."""
    import logging

    from aoi_verification.app.workers import exporter as ex
    p = _touch_jpeg(tmp_path / "src" / "S1" / "a.jpg")
    with caplog.at_level(logging.INFO, logger="aoi.export"):
        ex.ExcelExporter(extract_result("3", {"S1": [p]}), dst_path=tmp_path / "o.xlsx",
                         template_path=tmp_path / "none.xlsx").run()
    text = caplog.text
    assert "저장 소요 [시트" in text and "저장 소요 [파일 쓰기]" in text


def test_summary_offers_layouts_and_remembers(qapp, tmp_path, monkeypatch):
    """요약 창에서 방식을 고르고, 마지막 선택이 다음 기본이 된다."""
    from aoi_verification.app.ui import main_window as mw
    from aoi_verification.app.ui.pages.setup_page import SetupInput
    from aoi_verification.app.ui.widgets import save_name_dialog
    from aoi_verification.app.utils import prefs
    from aoi_verification.app.workers import exporter as ex

    monkeypatch.setattr(mw.MainWindow, "_start_backend_import_async",
                        lambda self: None)
    win = mw.MainWindow()
    seen, started = [], []
    monkeypatch.setattr(mw.sheets, "choose",
                        lambda *a, **k: (seen.append((a[3], k.get("default"))),
                                         ex.RECIPE_LAYOUT_COLUMNS)[1])

    class _Dlg:
        def __init__(self, name, _folder, parent=None, **_kw):
            self.chosen = name
    monkeypatch.setattr(save_name_dialog, "SaveNameDialog", _Dlg)
    monkeypatch.setattr(mw.sheets, "run", lambda dlg, **k: True)
    monkeypatch.setattr(mw.MainWindow, "_start_extract_export",
                        lambda self, r, d, layout: started.append(layout))
    try:
        win._input = SetupInput(mode="single", ref_root=tmp_path, val_root=tmp_path,
                                ref_machine="3", val_machine="", threshold=0.7,
                                extract=True)
        win._working_xlsx = tmp_path / "x.xlsx"
        item = mw.ImageItem("S1", _touch_jpeg(tmp_path / "S1" / "a.jpg"), "ref")
        win._finish_extract({"S1": [item]})
        keys = [o[0] for o in seen[0][0]]
        assert keys[:3] == [ex.RECIPE_LAYOUT_SINGLE, ex.RECIPE_LAYOUT_SHEETS,
                            ex.RECIPE_LAYOUT_COLUMNS]
        assert seen[0][1] == ex.RECIPE_LAYOUT_SINGLE          # 처음엔 한 시트
        assert started == [ex.RECIPE_LAYOUT_COLUMNS]
        assert prefs.load().extract_recipe_layout == ex.RECIPE_LAYOUT_COLUMNS
        win._finish_extract({"S1": [item]})
        assert seen[1][1] == ex.RECIPE_LAYOUT_COLUMNS         # 마지막 선택이 기본
    finally:
        win.close()


# ── Recipe 나란히: 같은 결함(150µm 미만)은 같은 행, 위쪽으로 ─────────────────
def _abs(**xy):
    return lambda p: ("abs",) + xy[str(p)] if str(p) in xy else None


def test_pair_rows_puts_close_defects_on_one_row_first():
    from aoi_verification.app.workers.exporter import pair_rows
    x20 = ["a", "b", "c"]
    x5 = ["p", "q"]
    pos = _abs(a=(0.0, 0.0), b=(1000.0, 0.0), c=(5000.0, 0.0),
               p=(5100.0, 0.0),            # c 와 100µm → 같은 행
               q=(1000.0, 149.9))          # b 와 149.9µm → 같은 행
    assert pair_rows([x20, x5], pos) == [["b", "q"], ["c", "p"], ["a", None]]


def test_pair_rows_threshold_is_strict_and_one_to_one():
    from aoi_verification.app.workers.exporter import pair_rows
    # a–p 는 정확히 150µm → '미만' 이 아니므로 짝이 아니다 → 각자 다른 행.
    pos = _abs(a=(0.0, 0.0), b=(1000.0, 0.0), p=(150.0, 0.0), q=(1003.0, 0.0))
    assert pair_rows([["a", "b"], ["p", "q"]], pos) == [["b", "q"], ["a", None],
                                                        [None, "p"]]
    # q 는 a(2µm)·b(3µm) 둘 다 가깝지만 한 행에만 — 더 가까운 a 와.
    pos = _abs(a=(0.0, 0.0), b=(5.0, 0.0), q=(2.0, 0.0))
    assert pair_rows([["a", "b"], ["q"]], pos) == [["a", "q"], ["b", None]]


def test_pair_rows_three_recipes_needs_all_close():
    from aoi_verification.app.workers.exporter import pair_rows
    pos = _abs(a=(0.0, 0.0), p=(100.0, 0.0), u=(200.0, 0.0), v=(50.0, 0.0))
    # u 는 p 와 100 이지만 a 와 200 → a·p 행에 못 들어간다.  v 는 둘 다 150 미만.
    assert pair_rows([["a"], ["p"], ["u", "v"]], pos) == [["a", "p", "v"],
                                                          [None, None, "u"]]


def test_pair_rows_die_coords_compare_only_within_same_die():
    from aoi_verification.app.workers.exporter import pair_rows
    pos = {"a": ("die", 1, 2, 10.0, 10.0), "p": ("die", 1, 2, 20.0, 10.0),
           "b": ("die", 1, 3, 10.0, 10.0), "q": ("die", 1, 4, 10.0, 10.0)}.get
    # b·q 는 다른 die → 거리를 모른다 → 각자 다른 행.
    assert pair_rows([["a", "b"], ["q", "p"]], pos) == [["a", "p"], ["b", None],
                                                        [None, "q"]]


def test_columns_sheet_pairs_rows_on_top(qapp, tmp_path, monkeypatch):
    pytest.importorskip("openpyxl")
    pytest.importorskip("PIL.Image")
    from openpyxl import load_workbook

    from aoi_verification.app.workers import exporter as ex

    _fake_recipes(monkeypatch, {"a.jpg": (1, "x20"), "b.jpg": (1, "x20"),
                                "c.jpg": (2, "x5"), "d.jpg": (2, "x5")})
    xy = {"a.jpg": (0.0, 0.0), "b.jpg": (9000.0, 0.0),
          "c.jpg": (50000.0, 0.0), "d.jpg": (9050.0, 30.0)}   # b–d 58µm
    monkeypatch.setattr(ex, "defect_position",
                        lambda p: ("abs",) + xy[Path(p).name])
    ps = [_touch_jpeg(tmp_path / "src" / "S1" / n)
          for n in ("a.jpg", "b.jpg", "c.jpg", "d.jpg")]
    dst = tmp_path / "out.xlsx"
    ex.ExcelExporter(extract_result("3", {"S1": ps}), dst_path=dst,
                     template_path=tmp_path / "none.xlsx",
                     recipe_layout=ex.RECIPE_LAYOUT_COLUMNS).run()
    ws = load_workbook(str(dst), rich_text=True)["out"]

    def name(cell):
        return None if cell.value is None else str(cell.value).split("\n")[0]
    # b–d 58µm → 한 행(위).  a–c 는 50mm 떨어짐 → 같은 행에 섞지 않고 각자 한 행.
    assert [(name(ws[f"D{r}"]), name(ws[f"F{r}"])) for r in (3, 4, 5)] == [
        ("b.jpg", "d.jpg"), ("a.jpg", None), (None, "c.jpg")]
    # 따로 표시하지 않는다 — 두 행의 정보 칸 글꼴·채움이 같은 규칙(줄무늬)을 따른다.
    assert all(ws[f"D{r}"].comment is None for r in (3, 4))


def test_choice_buttons_wrap_instead_of_clipping(styled_qapp):
    """버튼이 시트 폭에 한 줄로 안 들어가면 두 열로 접는다 — 글자가 잘리지 않는다."""
    from PyQt6.QtWidgets import QGridLayout

    from aoi_verification.app import i18n
    from aoi_verification.app.ui.widgets import sheet_host as sh
    K = i18n.KO
    many = [("s", K.EXTRACT_SAVE_SINGLE, "primary"),
            ("h", K.EXTRACT_SAVE_SHEETS, "ghost"),
            ("c", K.EXTRACT_SAVE_COLUMNS, "ghost"),
            ("b", K.EXTRACT_SUMMARY_BACK, "ghost")]
    d = sh._ChoiceSheet("t", "body", many, default="s")
    try:
        d.show()
        for _ in range(3):
            styled_qapp.processEvents()
        assert d.width() <= d.maximumWidth()
        for b in d._buttons.values():
            assert b.width() >= b.sizeHint().width(), b.text()
        grids = [d.layout().itemAt(i).layout() for i in range(d.layout().count())]
        assert any(isinstance(g, QGridLayout) for g in grids)
    finally:
        d.deleteLater()
    few = sh._ChoiceSheet("t", "body", many[:2], default="s")
    try:
        grids = [few.layout().itemAt(i).layout() for i in range(few.layout().count())]
        assert not any(isinstance(g, QGridLayout) for g in grids)   # 들어가면 예전 그대로
    finally:
        few.deleteLater()


# ── 여러 LOT ─────────────────────────────────────────────────────────────────
def test_scan_lots_prefixes_slots_with_lot(tmp_path):
    from aoi_verification.app.models.slot import lot_of, scan_lots, slot_label
    for lot in ("LOT_A", "LOT_B"):
        _touch_jpeg(tmp_path / lot / "S1" / "a.jpg")          # 같은 slot 이름
    _touch_jpeg(tmp_path / "x" / "LOT_A" / "S2" / "b.jpg")      # 같은 LOT 폴더명
    roots = [tmp_path / "LOT_A", tmp_path / "LOT_B", tmp_path / "x" / "LOT_A"]
    sr = scan_lots(roots)
    assert sorted(sr.slots) == ["LOT_A (2)/S2", "LOT_A/S1", "LOT_B/S1"]
    assert all(it.slot == "LOT_B/S1" for it in sr.slots["LOT_B/S1"].ref_images)
    assert lot_of("LOT_B/S1") == "LOT_B" and slot_label("LOT_B/S1") == "S1"
    assert lot_of("S1") == "" and slot_label("S1") == "S1"
    # 하나면 예전과 같다 — 접두 없음, only 도 그대로
    assert sorted(scan_lots([tmp_path / "LOT_A"], only={"S1"}).slots) == ["S1"]


def test_kla_rename_keeps_lot_prefix(tmp_path):
    from aoi_verification.app.models.slot import scan_lots
    _touch_jpeg(tmp_path / "LOT_A" / "k1" / "x.jpg")
    _touch_jpeg(tmp_path / "LOT_B" / "k1" / "x.jpg")
    sr = scan_lots([tmp_path / "LOT_A", tmp_path / "LOT_B"])
    kla = rename_slots_by_wafer_id(sr, {"LOT_A/k1": "w1", "LOT_B/k1": "w2"})
    assert sorted(sr.slots) == ["LOT_A/W1", "LOT_B/W2"]
    assert kla == {"LOT_A/W1": "k1", "LOT_B/W2": "k1"}


def _two_lot_result(tmp_path):
    ps = {}
    for lot, slot, n in [("LOT_A", "S1", "a.jpg"), ("LOT_A", "S1", "b.jpg"),
                         ("LOT_B", "S1", "c.jpg")]:
        ps.setdefault(f"{lot}/{slot}", []).append(
            _touch_jpeg(tmp_path / "src" / lot / slot / n))
    return extract_result("3", ps, slot_numbers={"LOT_B/S1": "6"})


def _sheet_rows(ws):
    out, r = [], 3
    while ws[f"A{r}"].value is not None:
        out.append((str(ws[f"B{r}"].value), str(ws[f"D{r}"].value).split("\n")[0]))
        r += 1
    return out


@pytest.mark.parametrize("layout", ["single", "sheets", "columns"])
def test_multi_lot_one_sheet_per_lot(qapp, tmp_path, monkeypatch, layout):
    pytest.importorskip("openpyxl")
    pytest.importorskip("PIL.Image")
    from openpyxl import load_workbook

    from aoi_verification.app import i18n
    from aoi_verification.app.workers import exporter as ex

    _fake_recipes(monkeypatch, {"a.jpg": (1, "PI"), "b.jpg": (1, "PI"),
                                "c.jpg": (1, "PI")})
    dst = tmp_path / "out.xlsx"
    ex.ExcelExporter(_two_lot_result(tmp_path), dst_path=dst,
                     template_path=tmp_path / "none.xlsx", map_renderer=_png,
                     recipe_layout=layout).run()
    wb = load_workbook(str(dst), rich_text=True)
    names = {"single": ["LOT_A", "LOT_B"], "sheets": ["LOT_A PI", "LOT_B PI"],
             "columns": ["LOT_A", "LOT_B"]}[layout]
    assert wb.sheetnames == names + [i18n.KO.WAFER_MAP_SHEET]
    # B열에는 LOT 없이 slot 만(LOT 는 시트 이름이 말한다), 번호는 그대로 찾는다
    assert _sheet_rows(wb[names[0]]) == [("S1", "a.jpg"), ("S1", "b.jpg")]
    assert _sheet_rows(wb[names[1]]) == [("S1\n(#6)", "c.jpg")]


def test_single_lot_sheet_names_unchanged(qapp, tmp_path):
    pytest.importorskip("openpyxl")
    from openpyxl import load_workbook

    from aoi_verification.app.workers import exporter as ex
    p = _touch_jpeg(tmp_path / "src" / "S1" / "a.jpg")
    dst = tmp_path / "out.xlsx"
    ex.ExcelExporter(extract_result("3", {"S1": [p]}), dst_path=dst,
                     template_path=tmp_path / "none.xlsx").run()
    assert load_workbook(str(dst)).sheetnames == ["out"]


def test_wafer_map_switch_controls_the_sheet(qapp, tmp_path, monkeypatch):
    """설정 화면의 스위치를 끄면 렌더러를 넘기지 않는다 → Wafer Map 시트가 없다."""
    from aoi_verification.app.ui import main_window as mw
    from aoi_verification.app.ui.pages.setup_page import SetupInput
    from aoi_verification.app.workers import exporter as ex

    got = []

    class _Exp:
        def __init__(self, *a, **k):
            got.append(k.get("map_renderer"))
            self.signals = type("S", (), {})()
            for n in ("progress", "done", "failed"):
                setattr(self.signals, n, type("Sig", (), {"connect": lambda *a: None})())

        def start(self):
            pass

    monkeypatch.setattr(ex, "ExcelExporter", _Exp)
    monkeypatch.setattr(mw.MainWindow, "_start_backend_import_async",
                        lambda self: None)
    win = mw.MainWindow()
    try:
        for on in (True, False):
            win._input = SetupInput(mode="single", ref_root=tmp_path, val_root=tmp_path,
                                    ref_machine="3", val_machine="", threshold=0.7,
                                    extract=True, extract_wafer_map=on)
            win._start_extract_export(extract_result("3", {}), tmp_path / "o.xlsx",
                                      ex.RECIPE_LAYOUT_SINGLE)
        assert got[0] is not None and got[1] is None
    finally:
        win._loading.hide_overlay()
        win.close()


def test_lot_rows_up_to_ten(qapp):
    from aoi_verification.app import i18n
    from aoi_verification.app.ui.pages import setup_page as sp
    page = sp.SetupPage()
    try:
        assert page._lot_list.isHidden() and not page._scope_row.isHidden()
        page.set_extract_mode(True)
        assert not page._lot_list.isHidden()
        assert page._scope_row.isHidden()                  # 줄마다 [슬롯 선택] 이 대신
        assert not page._lot1_slot_btn.isHidden()
        for _ in range(12):                                # 10개에서 멈춘다
            page._add_lot_row()
        assert len(page._lot_rows) == page.MAX_LOTS == 10
        assert not page._lot_add_btn.isEnabled()
        assert page._lot_add_btn.text() == i18n.KO.EXTRACT_LOT_ADD_FMT.format(n=10, max=10)
        page._remove_lot_row(page._lot_rows[3])
        assert len(page._lot_rows) == 9 and page._lot_add_btn.isEnabled()
        assert [r["label"].text() for r in page._lot_rows[1:]] == [
            f"LOT {k}" for k in range(2, 10)]              # 번호는 다시 매긴다
        page.set_extract_mode(False)
        assert page._lot_list.isHidden() and not page._scope_row.isHidden()
    finally:
        page.deleteLater()


def test_lot_rows_folders_and_slots(qapp, tmp_path, monkeypatch):
    from aoi_verification.app.ui.pages import setup_page as sp
    from aoi_verification.app.ui.widgets import slot_select_dialog as ssd
    a, b = tmp_path / "LOT_A", tmp_path / "LOT_B"
    for lot in (a, b):
        for slot in ("S1", "S2", "S3"):
            (lot / slot).mkdir(parents=True)
    page = sp.SetupPage()
    try:
        page.set_extract_mode(True)
        page.ref_path_edit.setText(str(a))
        page._add_lot_row()
        row = page._lot_rows[1]
        # OS 브라우저는 비동기(`ui/folder_picker.py`) — 고른 결과를 시그널로 흘려 넣는다.
        monkeypatch.setattr(sp.FolderPicker, "open",
                            lambda self, caption, start="": self.picked.emit(str(b)))
        page._browse(row["edit"])                          # 그 줄 자기 칸에 들어간다
        assert row["edit"].text() == str(b) and page.ref_path_edit.text() == str(a)
        page._add_lot_row()                                # 빈 줄은 무시한다
        assert page._validate() is True

        # LOT 별 슬롯 선택 — 선택 창이 고른 결과를 그 줄에만 반영한다
        class _Dlg:
            def __init__(self, names, preselected=None, **k):
                self.names = names
                self.accepted_ok = True
                self.selected = {"S2"}
        monkeypatch.setattr(ssd, "SlotSelectDialog", _Dlg)
        monkeypatch.setattr(sp.sheets, "run", lambda dlg, **k: True)
        page._pick_lot_slots(1)
        assert row["sel"] == {"S2"} and row["slot_btn"].text() == "슬롯 1/3"
        assert page._lot_rows[0]["sel"] is None

        inp = page._collect_input()
        assert inp.extract_roots == [a, b]
        assert inp.extract_slots == [None, {"S2"}]
        # 폴더를 바꾸면 그 줄의 선택은 전체로 돌아간다
        row["edit"].setText(str(a))
        assert row["sel"] is None and row["slot_btn"].text() == "슬롯: 전체"
        # 하나라도 없는 폴더면 막는다
        row["edit"].setText(str(tmp_path / "없음"))
        assert page._validate() is False
    finally:
        page.deleteLater()


def test_scan_lots_takes_slots_per_lot(tmp_path):
    from aoi_verification.app.models.slot import scan_lots
    for lot in ("LOT_A", "LOT_B"):
        for slot in ("S1", "S2"):
            _touch_jpeg(tmp_path / lot / slot / "a.jpg")
    sr = scan_lots([tmp_path / "LOT_A", tmp_path / "LOT_B"], only=[{"S2"}, None])
    assert sorted(sr.slots) == ["LOT_A/S2", "LOT_B/S1", "LOT_B/S2"]
    assert sorted(scan_lots([tmp_path / "LOT_A"], only=[{"S1"}]).slots) == ["S1"]


# ── 선별 화면 문구 — 추출에는 '검증' 이 없다 ─────────────────────────────────
def test_select_page_says_extract_not_verify(styled_qapp):
    """추출 모드면 선별 화면의 '검증' 문구가 '추출' 로 바뀌고, 매칭으로 돌아오면 되돌아온다."""
    from PyQt6.QtWidgets import QLabel

    from aoi_verification.app import i18n
    from aoi_verification.app.ui.pages.select_page import SelectPage

    page = SelectPage()
    try:
        def visible_text():
            labels = [w.text() for w in page.findChildren(QLabel)
                      if w.property("role") in ("paneTitle", "emptyHint")]
            return labels + [page.btn_verify.text(), page.btn_view_excluded.text(),
                             page.btn_verify.toolTip()]

        page.set_extract_mode(True)
        texts = visible_text()
        assert not [t for t in texts if "검증" in t], texts
        assert i18n.KO.EXTRACT_SELECT_TEXT["PANEL_RIGHT_TARGETS"] in texts
        assert page._tx("END_SELECTION_CONFIRM_FMT") == (
            i18n.KO.EXTRACT_SELECT_TEXT["END_SELECTION_CONFIRM_FMT"])
        assert dict((a, lab) for a, lab, _r in page.left_panel._actions)[
            "batch_verify"] == i18n.KO.EXTRACT_SELECT_TEXT["BTN_BATCH_VERIFY"]

        page.set_extract_mode(False)
        texts = visible_text()
        assert i18n.KO.PANEL_RIGHT_TARGETS in texts
        assert page._tx("BTN_VERIFY") == i18n.KO.BTN_VERIFY
    finally:
        page.close()


def test_extract_select_text_keys_exist():
    """바꿔 끼우는 키는 모두 매칭 문구에 실재해야 한다(오타면 조용히 안 바뀐다)."""
    from aoi_verification.app import i18n
    missing = [k for k in i18n.KO.EXTRACT_SELECT_TEXT if not hasattr(i18n.KO, k)]
    assert missing == []


def test_setup_extract_mode_swaps_blocked_hint(qapp):
    from aoi_verification.app import i18n
    from aoi_verification.app.ui.pages.setup_page import SetupPage

    page = SetupPage()
    try:
        page.set_extract_mode(True)
        page.ref_path_edit.setText("")
        page._validate()
        assert page._start_hint.text() == i18n.KO.EXTRACT_BLOCKED_HINT
        page.set_extract_mode(False)
    finally:
        page.close()


# ── 여정 레일 — 추출은 3단계(설정·후보 선별·저장) ───────────────────────────
def test_rail_set_labels_clamps_index(qapp):
    from aoi_verification.app import i18n
    from aoi_verification.app.ui.widgets.journey_rail import JourneyRail

    rail = JourneyRail()
    rail.set_current(4)
    rail.set_navigable((0, 3))
    rail.set_labels(i18n.KO.EXTRACT_JOURNEY_RAIL_STEPS)
    assert rail._labels == i18n.KO.EXTRACT_JOURNEY_RAIL_STEPS
    assert rail._index == 2 and rail._navigable == frozenset({0})


def test_rail_follows_extract_mode(qapp, monkeypatch):
    """설정에서 [Defect 추출] 을 누르면 레일이 3단계로, 되돌리면 5단계로 돌아온다."""
    from aoi_verification.app import i18n
    from aoi_verification.app.ui import main_window as mw

    monkeypatch.setattr(mw.MainWindow, "_start_backend_import_async",
                        lambda self: None)
    win = mw.MainWindow()
    try:
        assert win._rail._labels == i18n.KO.JOURNEY_RAIL_STEPS
        win._setup_page.set_extract_mode(True)
        assert win._rail._labels == i18n.KO.EXTRACT_JOURNEY_RAIL_STEPS
        win._setup_page.set_extract_mode(False)
        assert win._rail._labels == i18n.KO.JOURNEY_RAIL_STEPS
    finally:
        win.close()
