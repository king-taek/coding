"""'진행할 슬롯 선택' 다이얼로그 — 검색 + 밀집 그리드 다중 선택.

이 파일이 지키는 계약은 재설계에서 실제로 고친 결함들이다(자세한 배경은 위젯 docstring):

- 선택 상태는 **QSS 가 칠한다** — 죽은 네온 팔레트 인라인 하드코딩 금지.
- 타일은 **마우스 전용**(사용자 결정) — 포커스를 받지 않으므로 방향키·Space·
  포커스 링이 전부 없다.  가로채는 코드가 아니라 ``NoFocus`` 로 없앤다.
- 토글은 **release-inside** 에서 — 터치 스크롤이 선택을 바꾸지 않게.
- 크기는 ``sizeHint`` 로 알린다 — 시트 호스트가 읽는 값이 그것뿐이다.
- 열 수는 ``reflow_into_grid`` 가 계산한다 — off-by-one 을 두 곳에 복제하지 않는다.
- **0개 선택으로 확인 불가** — 호출부가 빈 집합을 '전체 진행'으로 정규화하므로,
  전부 해제하고 확인하면 의도와 정반대로 모든 슬롯이 돌아간다.
- 검색은 **보기**다 — 숨은 타일의 선택을 지우지 않는다.
"""

from __future__ import annotations

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import inspect
from pathlib import Path

import pytest

pytest.importorskip("PyQt6.QtWidgets")

from PyQt6.QtCore import Qt                            # noqa: E402
from PyQt6.QtWidgets import QApplication               # noqa: E402

from aoi_verification.app import i18n                  # noqa: E402
from aoi_verification.app.ui import theme              # noqa: E402
from aoi_verification.app.ui.widgets import slot_select_dialog as ssd  # noqa: E402
from aoi_verification.app.ui.widgets.slot_select_dialog import (  # noqa: E402
    SlotSelectDialog)

_NAMES = ["S01", "S02", "S03", "S04", "S05"]
_MANY = [f"PI_Opening_{c}{i}" for c in "AB" for i in range(1, 13)]
_QSS = (Path(__file__).resolve().parents[2] / "aoi_verification" / "app" / "ui"
        / "style.qss").read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _shown(qapp, names=_NAMES, w=620, h=560):
    """★ `resize()` 는 show() **뒤에** 걸어야 실제로 먹는다.

    이 다이얼로그는 `enable_window_controls(maximized=False)` 로 스스로 크기를 정한
    뒤(`_size_to_content`) 열린다.  이전 구현은 `maximized=True`(기본값) 였고, 다음
    이벤트 tick 의 showMaximized() 가 크기 요청을 덮어써 `resize(560, 600)` 이 **죽은
    코드**였다 — 그걸 모르고 짠 테스트는 '요청한 폭' 을 검사하며 통과했을 것이다.
    """
    qapp.setStyleSheet(theme.render_qss(_QSS))
    dlg = SlotSelectDialog(names)
    dlg.show()
    dlg.resize(w, h)
    for _ in range(16):
        qapp.processEvents()
    return dlg


# ── 선택 로직 ────────────────────────────────────────────────────────────
def test_preselected_reflected_in_selected(qapp):
    dlg = SlotSelectDialog(_NAMES, preselected={"S02", "S04"})
    assert dlg.selected == {"S02", "S04"}


def test_default_preselects_all(qapp):
    """preselected 미지정 → 전체 선택으로 시작(기존 동작 보존)."""
    dlg = SlotSelectDialog(_NAMES)
    assert dlg.selected == set(_NAMES)


def test_tile_toggle_updates_selection(qapp):
    dlg = SlotSelectDialog(_NAMES, preselected=set())
    assert dlg.selected == set()
    dlg._tiles["S03"].click()              # 좌클릭(release-inside)과 동일
    assert dlg.selected == {"S03"}
    dlg._tiles["S03"].click()
    assert dlg.selected == set()


def test_tiles_are_not_mutually_exclusive(qapp):
    """★ 부모를 공유하는 checkable QPushButton 은 Qt 가 라디오처럼 묶는다.

    autoExclusive 를 끄지 않으면 두 번째 선택이 첫 번째를 **해제**해 다중 선택이
    조용히 단일 선택이 된다."""
    dlg = SlotSelectDialog(_NAMES, preselected=set())
    dlg._tiles["S01"].click()
    dlg._tiles["S02"].click()
    assert dlg.selected == {"S01", "S02"}, "다중 선택이 단일 선택으로 퇴화했다"


def test_set_all(qapp):
    dlg = SlotSelectDialog(_NAMES, preselected={"S01"})
    dlg._set_all(True)
    assert dlg.selected == set(_NAMES)
    dlg._set_all(False)
    assert dlg.selected == set()


def test_head_states_what_will_run(qapp):
    """머리글이 '무슨 일이 일어나는지' 를 큰 글자로 말한다(이전엔 작은 '선택 2 / 5' 뿐)."""
    dlg = SlotSelectDialog(_NAMES, preselected={"S01", "S02"})
    assert "2" in dlg._head.text() and "5" in dlg._head.text()
    dlg._set_all(True)
    assert "모든 슬롯" in dlg._head.text()


# ── 0개 선택 차단 (호출부 정규화 함정) ──────────────────────────────────
def test_zero_selection_cannot_confirm(qapp):
    """전부 해제 후 확인은 막혀야 한다 — 안 막으면 **모든 슬롯**이 돌아간다.

    `setup_page._open_slot_select` 는 `if not chosen ... _reset_slot_selection()` 로
    빈 집합을 '전체 진행'으로 정규화한다.  즉 0개 확인은 조용히 정반대 결과를 낸다."""
    dlg = SlotSelectDialog(_NAMES, preselected=set())
    assert dlg._ok.isEnabled() is False
    assert dlg._blocked.text(), "왜 확인할 수 없는지 말하지 않는다"
    dlg._on_ok()                        # 단축키·Enter 로도 새지 않아야 한다
    assert dlg.accepted_ok is False
    dlg._tiles["S01"].click()
    assert dlg._ok.isEnabled() is True
    assert dlg._blocked.text() == ""


def test_caller_normalization_still_holds(qapp):
    """차단의 **근거**가 호출부에 그대로 있는지 확인한다.

    호출부가 언젠가 빈 집합을 다르게 다루기로 하면 이 차단의 이유도 달라진다 —
    근거를 테스트에 적어 두면 다음 사람이 둘을 함께 본다."""
    from aoi_verification.app.ui.pages import setup_page as sp
    src = inspect.getsource(sp.SetupPage._open_slot_select)
    assert "if not chosen" in src and "_reset_slot_selection" in src


# ── 검색(필터) ──────────────────────────────────────────────────────────
def test_search_filters_without_destroying_selection(qapp):
    """검색은 **보기**다.  숨은 타일의 선택이 풀리면 검색이 파괴적 동작이 된다."""
    dlg = _shown(qapp, _MANY)
    assert len(dlg.selected) == len(_MANY)
    dlg._search.setText("A1")
    for _ in range(6):
        qapp.processEvents()
    assert dlg._visible == ["PI_Opening_A1", "PI_Opening_A10",
                            "PI_Opening_A11", "PI_Opening_A12"]
    assert len(dlg.selected) == len(_MANY), "숨겼더니 선택이 풀렸다"
    dlg._search.setText("")
    for _ in range(6):
        qapp.processEvents()
    assert len(dlg._visible) == len(_MANY)


def test_select_visible_narrows_to_search_hits(qapp):
    """'검색 결과 선택' = 이것만 돌린다 — 나머지는 해제한다."""
    dlg = _shown(qapp, _MANY)
    dlg._search.setText("A1")
    for _ in range(6):
        qapp.processEvents()
    dlg._select_visible()
    assert dlg.selected == set(dlg._visible)


def test_empty_search_result_says_so(qapp):
    """빈 화면을 남기지 않는다 — 왜 아무것도 없는지 말한다."""
    dlg = _shown(qapp, _MANY)
    dlg._search.setText("존재하지않는슬롯")
    for _ in range(6):
        qapp.processEvents()
    assert dlg._visible == []
    assert dlg._empty.isVisible() and dlg._empty.text()
    # 검색 중일 때만 의미 있는 '검색 결과 선택' 은 결과가 없으면 숨는다.
    assert dlg._btn_visible.isVisible() is False


# ── 기하 · 타깃 · 좁은 창 ───────────────────────────────────────────────
def test_no_horizontal_scroll_and_columns_adapt(qapp):
    """열 수는 폭에 맞춰 줄어들고, 가로 스크롤은 어느 폭에서도 생기지 않는다."""
    dlg = _shown(qapp, _MANY, w=620, h=560)
    seen: list[tuple[int, int]] = []
    for w in (620, 520, 420, 380):
        dlg.resize(w, 480)
        for _ in range(12):
            qapp.processEvents()
        bar = dlg._scroll.horizontalScrollBar()
        assert bar.maximum() == 0, f"{w}px 에서 가로 스크롤 {bar.maximum()}px"
        seen.append((w, dlg._grid_cols()))
    cols = [c for _w, c in seen]
    assert cols == sorted(cols, reverse=True), f"열 수가 폭을 안 따른다: {seen}"
    assert cols[0] > cols[-1], f"좁혀도 열이 줄지 않았다: {seen}"


def test_size_hint_is_what_the_sheet_host_reads(qapp):
    """★ 시트 호스트는 ``resize()`` 가 아니라 ``sizeHint()``/``minimumSize`` 를 본다.

    이 창은 앱에서 유일하게 ``full_bleed`` 없이 뜨는 시트다.  ``sizeHint`` 를
    오버라이드하지 않았던 탓에 `_size_to_content` 의 계산이 통째로 버려지고
    시트가 하한(280×140)/최소값 근처로 쪼그라들어 그리드가 두어 줄만 보였다."""
    from PyQt6.QtWidgets import QApplication as _QA
    dlg = SlotSelectDialog(_MANY)
    hint = dlg.sizeHint()
    # 4열이 들어가는 폭을 알린다.
    want_w = (SlotSelectDialog._WANT_COLS * ssd._TILE_MIN_W
              + (SlotSelectDialog._WANT_COLS - 1) * ssd._GRID_SPACING
              + theme.PROFILE.page_margin + 24)
    g = (dlg.screen() or _QA.primaryScreen()).availableGeometry()
    assert hint.width() == min(want_w, int(g.width() * 0.95))
    assert hint.height() >= 560, f"높이 {hint.height()}px — 리스트가 안 보인다"
    # 호스트가 실제로 계산하는 값 = max(hint, minimum, 하한) → 이 크기가 나온다.
    _SHEET_MIN_W, _SHEET_MIN_H = 280, 140
    assert max(hint.width(), dlg.minimumWidth(), _SHEET_MIN_W) == hint.width()
    assert max(hint.height(), dlg.minimumHeight(), _SHEET_MIN_H) == hint.height()
    # 최소값은 목표까지 올리지 않는다 — 좁은 창에서 열 수가 폭을 따라가야 한다.
    assert dlg.minimumWidth() < hint.width()
    # 그래도 화면은 넘지 않는다.
    assert hint.width() <= g.width() and hint.height() <= g.height()


def test_dialog_fits_a_small_screen(qapp):
    """★ 창이 화면 가용 영역을 넘지 않는다.

    800×600 노트북에서 큰 화면 기준 크기를 그대로 쓰면 [확인]이 화면 밖으로 나간다.
    그리고 이 다이얼로그는 **최대화하지 않는다** — 짧은 이름 24개를 고르는 창이 27인치를
    채우면 여백만 늘고 눈이 멀리 이동한다(이전 구현은 항상 최대화됐다)."""
    from PyQt6.QtWidgets import QApplication as _QA
    dlg = SlotSelectDialog(_MANY)
    dlg.show()
    for _ in range(16):
        qapp.processEvents()
    g = (dlg.screen() or _QA.primaryScreen()).availableGeometry()
    assert dlg.width() <= g.width() and dlg.height() <= g.height(), \
        f"창 {dlg.width()}x{dlg.height()} > 화면 {g.width()}x{g.height()}"
    assert not dlg.isMaximized(), "슬롯 선택 창이 화면을 통째로 차지한다"


def test_tile_and_action_targets(qapp):
    dlg = _shown(qapp, _MANY)
    tile = dlg._tiles[_MANY[0]]
    assert tile.height() >= 24, f"타일 {tile.height()}px < 24px (2.5.8 AA)"
    assert tile.height() >= theme.PROFILE.target_min
    assert dlg._ok.height() >= theme.PROFILE.control_h_lg - 1, \
        f"[확인] {dlg._ok.height()}px"


def test_long_name_stays_readable(qapp):
    """긴 슬롯명은 **가운데** 생략 + 툴팁에 전체 — 앞/뒤 생략은 A1/A2 를 구분 못 한다."""
    long_name = "PI_Opening_Zone3_VeryLongRecipeName_A1"
    dlg = _shown(qapp, [long_name] + _NAMES, w=620)
    tile = dlg._tiles[long_name]
    assert tile.toolTip() == long_name
    text = tile.text()
    if text != long_name:                       # 폭이 좁아 줄였다면
        assert "…" in text
        assert text[0] == long_name[0] and text[-1] == long_name[-1], \
            f"가운데 생략이 아니다: {text!r}"


# ── 키보드 — 타일은 마우스 전용(사용자 결정) ────────────────────────────
def test_tiles_take_no_focus(qapp):
    """★ 타일은 포커스를 받지 않는다 — 방향키·Space·포커스 링이 모두 사라진다.

    'NoFocus' 하나가 세 동작을 동시에 없앤다.  가로채는 코드로 막으면 Qt 버전에
    따라 우회로가 생기지만, 받지 않으면 우회로 자체가 없다."""
    dlg = _shown(qapp, _MANY)
    for tile in dlg._tiles.values():
        assert tile.focusPolicy() == Qt.FocusPolicy.NoFocus

    # 탭 순회가 타일에 걸리지 않는다(창을 열면 검색란에 포커스가 있고, 탭을
    # 아무리 돌려도 타일에는 오지 않는다).  ※ `setFocus()` 는 정책을 우회하므로
    # 그것으로는 증명이 안 된다 — 실제 이동 수단인 탭으로 확인한다.
    dlg._search.setFocus()
    for _ in range(4):
        qapp.processEvents()
    for _ in range(len(dlg._tiles) + 8):
        dlg.focusNextChild()
        assert not any(t.hasFocus() for t in dlg._tiles.values()), \
            "탭으로 타일에 포커스가 들어갔다"


def test_arrow_keys_do_nothing(qapp):
    """방향키는 포커스도 선택도 바꾸지 않는다(이동 기능 자체를 제거했다)."""
    from PyQt6.QtGui import QKeyEvent
    dlg = _shown(qapp, _MANY)
    dlg._set_all(False)
    before = dlg.selected
    for key in (Qt.Key.Key_Right, Qt.Key.Key_Left,
                Qt.Key.Key_Down, Qt.Key.Key_Up):
        qapp.sendEvent(dlg, QKeyEvent(QKeyEvent.Type.KeyPress, key,
                                      Qt.KeyboardModifier.NoModifier))
    for _ in range(4):
        qapp.processEvents()
    assert dlg.selected == before, "방향키가 선택을 바꿨다"
    assert not any(t.hasFocus() for t in dlg._tiles.values()), \
        "방향키가 타일로 포커스를 옮겼다"


def test_no_tile_keyboard_machinery_left(qapp):
    """이동 코드가 '조용히' 남아 있지 않은지 — 죽은 경로는 다음 사람을 오도한다.

    ``eventFilter``/``keyPressEvent`` 는 Qt 기반 클래스에도 있으므로 ``hasattr``
    로는 판정할 수 없다.  **이 모듈이 재정의했는지**를 소스에서 본다."""
    code = _code_only()
    for gone in ("def _move_focus", "def eventFilter", "def keyPressEvent",
                 "_ARROWS", "QShortcut", "installEventFilter"):
        assert gone not in code, f"{gone} 가 아직 남아 있다"
    # 화면에 남은 키 안내 문구도 없어야 한다.
    assert not hasattr(i18n.KO, "SLOT_SELECT_KEY_HINT")


# ── 구현 규율 ───────────────────────────────────────────────────────────
def _code_only() -> str:
    """주석·docstring 을 걷어낸 '코드만' 텍스트.

    스타일시트 문자열은 남긴다(그 안의 색 하드코딩을 잡아야 하므로)."""
    import io
    import tokenize
    src = inspect.getsource(ssd)
    parts: list[str] = []
    for tok in tokenize.generate_tokens(io.StringIO(src).readline):
        if tok.type == tokenize.COMMENT:
            continue
        if tok.type == tokenize.STRING and tok.string.startswith(('"""', "'''")):
            continue
        parts.append(tok.string)
    return "\n".join(parts)


def test_no_inline_palette_hardcoding():
    """★ 선택 틴트를 인라인으로 칠하지 않는다.

    이전 구현은 `rgba(57, 255, 20, 0.10)` — 지금 어느 팔레트에도 없는 죽은 네온 초록을
    하드코딩했다.  주석·docstring 은 제거한 버그를 **설명**하므로 검사에서 제외한다
    (그러지 않으면 설명이 위반으로 잡혀 없는 결함을 인증한다)."""
    import re
    code = _code_only()
    assert not re.search(r"#[0-9A-Fa-f]{6}\b", code), "hex 색 리터럴"
    assert not re.search(r"\brgba?\(\s*\d", code), "rgb(a) 색 리터럴"
    assert not re.search(r"theme\.(ACCENT|INK|LINE|PANEL|BG|MUTE|WARN|PASS|DANGER"
                         r"|ELEV|FOCUS)[A-Z_]*\b", code), "theme 색 상수 인라인"


def test_column_math_is_reused_not_duplicated():
    """열 계산은 ``reflow_into_grid`` 하나만 쓴다 — off-by-one 을 두 곳에 두지 않는다."""
    src = inspect.getsource(ssd)
    assert "reflow_into_grid" in src
    # ★ 전체 소스를 훑으면 **제거한 버그를 설명하는 docstring** 이 위반으로 잡힌다
    #   (실제로 잡혔다).  없는 결함을 인증하는 것도 측정 실패다 — 코드만 본다.
    assert "// (_TILE" not in _code_only(), "직접 열 계산 부활"


def test_qss_paints_the_selected_state():
    # ★ `:focus` 는 빠졌다 — 타일이 NoFocus 라 절대 발화하지 않는다.  그릴 수 없는
    #   상태의 스타일을 남겨 두면 키보드 이동이 있는 줄 오해한다.
    for state in (":checked", ":hover", ":disabled"):
        assert f'QPushButton[role="slotTile"]{state}' in _QSS, f"slotTile{state} 없음"
    assert 'QPushButton[role="slotTile"]:focus' not in _QSS, \
        "발화할 수 없는 :focus 규칙이 남아 있다"
    # 차단 이유 라벨도 등급이 있어야 한다(QPushButton 전용 role="warn" 만 있던 함정).
    assert 'QLabel[role="warn"]' in _QSS


# ---------------------------------------------------------------------------
# ★ 타일 둘째 줄 — 그 슬롯에 사진이 몇 장인지
#
# 신고(UI 관련 PDF ②): "일부 슬롯 고르는 팝업에서 slot별로 defect 몇 개 있는지
# 보이게 하기."  세는 기준은 **결함 사진 장수**이고(사용자 결정), 기준·검증 양쪽을
# 보여 준다.  폴더 열거는 슬롯당 2회라 25슬롯이면 50회 — 직전에 고친 '폴더 선택 시
# 멈춤' 과 같은 종류의 정지가 되므로 **UI 스레드에서 세지 않는다.**
# ---------------------------------------------------------------------------
def _lot(tmp_path, ref_per_slot, val_per_slot):
    ref, val = tmp_path / "ref", tmp_path / "val"
    for name, n in ref_per_slot.items():
        d = ref / name
        d.mkdir(parents=True)
        for i in range(n):
            (d / f"a{i}.jpg").write_bytes(b"")
    for name, n in val_per_slot.items():
        d = val / name
        d.mkdir(parents=True)
        for i in range(n):
            (d / f"b{i}.jpg").write_bytes(b"")
    return ref, val


def _counted(qapp, tmp_path, ref_per_slot, val_per_slot):
    from aoi_verification.app.models.slot import list_slot_dirs

    ref, val = _lot(tmp_path, ref_per_slot, val_per_slot)
    dirs = list_slot_dirs(ref)
    dlg = SlotSelectDialog(sorted(dirs), ref_dirs=dirs, val_root=val)
    dlg.show()
    for _ in range(8):
        qapp.processEvents()
    assert dlg._count_scan is not None and dlg._count_scan.wait(10_000), \
        "개수 세기가 끝나지 않았다"
    for _ in range(8):
        qapp.processEvents()
    return dlg


def test_tile_shows_photo_counts_for_both_sides(qapp, tmp_path):
    """기준·검증 장수를 둘 다 보여 준다 — 짝이 안 맞는 슬롯을 시작 전에 알 수 있다."""
    dlg = _counted(qapp, tmp_path, {"S1": 3, "S2": 5}, {"S1": 2, "S2": 5})
    assert dlg._tiles["S1"].count_text() == \
        i18n.KO.SLOT_SELECT_TILE_COUNT_FMT.format(ref="3", val="2")
    assert dlg._tiles["S2"].count_text() == \
        i18n.KO.SLOT_SELECT_TILE_COUNT_FMT.format(ref="5", val="5")
    dlg.deleteLater()


def test_a_slot_missing_on_the_val_side_says_so(qapp, tmp_path):
    """검증 폴더에 없는 슬롯은 '—' — **0 장과 구분된다**(둘은 다른 상황이다)."""
    dlg = _counted(qapp, tmp_path, {"S1": 3, "S9": 4}, {"S1": 0})
    assert i18n.KO.SLOT_SELECT_TILE_COUNT_NONE in dlg._tiles["S9"].count_text()
    assert dlg._tiles["S1"].count_text() == \
        i18n.KO.SLOT_SELECT_TILE_COUNT_FMT.format(ref="3", val="0")
    dlg.deleteLater()


def test_wafer_overview_photos_are_not_counted(qapp, tmp_path):
    """화면의 숫자는 **검증이 실제로 도는 장수**여야 한다.

    웨이퍼 전경 사진(`CognexInSight*`)은 좌표가 없어 매칭에 못 쓰므로 앱이 열거에서
    빼는데, 개수만 따로 세면 화면과 실제가 어긋난다."""
    from aoi_verification.app.models.slot import count_images

    d = tmp_path / "S1"
    d.mkdir(parents=True)
    for i in range(3):
        (d / f"a{i}.jpg").write_bytes(b"")
    (d / "CognexInSight17xx_Bottom_OnPal_Station1_Slot21.jpg").write_bytes(b"")
    assert count_images(d) == 3


def test_counts_say_checking_until_they_arrive(qapp):
    """아직 모를 때 빈칸으로 두지 않는다 — 로딩바 계약과 같은 취지."""
    dlg = _shown(qapp)                       # ref_dirs 없이 = 셀 것이 없다
    assert dlg._tiles["S01"].count_text() == \
        i18n.KO.SLOT_SELECT_TILE_COUNT_PENDING
    dlg.deleteLater()


def test_counting_does_not_touch_files_on_the_ui_thread(qapp, tmp_path):
    """★ 창이 뜨는 순간 UI 스레드가 폴더를 열거하면 NAS 에서 그만큼 멈춘다.

    타이밍이 아니라 **호출 위치**로 못 박는다(직전 세션의 폴더 선택 가드와 같은 방식).
    """
    import os as _os
    import sys
    import threading

    from aoi_verification.app.models.slot import list_slot_dirs

    ref, val = _lot(tmp_path, {"S1": 3, "S2": 4}, {"S1": 3})
    dirs = list_slot_dirs(ref)               # 호출부가 미리 하는 일(스캔 1회)

    ui_thread = threading.get_ident()
    hits: list[str] = []

    def guard(name, orig):
        def patched(*a, **k):
            if threading.get_ident() == ui_thread:
                frame = sys._getframe(1)
                while frame is not None:
                    if "aoi_verification" in frame.f_code.co_filename:
                        hits.append(f"{name} ← "
                                    f"{Path(frame.f_code.co_filename).name}:"
                                    f"{frame.f_lineno}")
                        break
                    frame = frame.f_back
            return orig(*a, **k)
        return patched

    saved = [(_os, "scandir", _os.scandir), (_os, "stat", _os.stat),
             (Path, "is_dir", Path.is_dir), (Path, "iterdir", Path.iterdir),
             (Path, "exists", Path.exists)]
    for mod, name, orig in saved:
        setattr(mod, name, guard(name, orig))
    try:
        dlg = SlotSelectDialog(sorted(dirs), ref_dirs=dirs, val_root=val)
        dlg.show()
        for _ in range(8):
            qapp.processEvents()
        assert hits == [], f"UI 스레드가 폴더를 열거했다: {hits}"
    finally:
        for mod, name, orig in saved:
            setattr(mod, name, orig)
    assert dlg._count_scan.wait(10_000)
    dlg.deleteLater()


def test_the_tile_text_is_still_only_the_name(qapp, tmp_path):
    """개수를 **버튼 텍스트에 합치지 않는다** — `text()` 는 생략된 슬롯명 그 자체다.

    합치면 가운데 생략 계약(`test_long_name_stays_readable`)이 깨지고, 한 버튼에
    서체를 두 가지로 줄 수도 없다."""
    dlg = _counted(qapp, tmp_path, {"S1": 3}, {"S1": 3})
    tile = dlg._tiles["S1"]
    assert tile.text() == "S1", f"이름 줄에 개수가 섞였다: {tile.text()!r}"
    assert "기준" in tile.count_text()
    dlg.deleteLater()


def test_the_count_line_does_not_cover_the_name(qapp, tmp_path):
    """아랫줄이 이름을 덮으면 안 된다 — QSS `padding-bottom` 이 자리를 예약한다."""
    dlg = _counted(qapp, tmp_path, {"S1": 3}, {"S1": 3})
    tile = dlg._tiles["S1"]
    label = tile._count
    assert label.y() > 0 and label.geometry().bottom() <= tile.height(), \
        f"라벨이 타일 밖이다: {label.geometry().getRect()} / 타일 {tile.height()}"
    # 이름 밴드(= 타일 높이 − 아래 padding) 아래에서 시작해야 겹치지 않는다.
    assert label.y() >= tile.height() - 23, \
        f"라벨이 이름 밴드를 침범한다 (top={label.y()}, 타일={tile.height()})"
    assert tile.height() >= theme.PROFILE.target_min, "타일이 클릭 타깃보다 작다"
    dlg.deleteLater()


def test_count_qss_is_rendered_not_hardcoded(qapp):
    """색은 QSS 가 칠한다 — 이 파일 docstring 의 1번 결함(인라인 팔레트)을 반복하지 않는다."""
    out = theme.render_qss(_QSS)
    assert 'QLabel[role="slotTileCount"]' in out
    assert 'QPushButton[role="slotTile"]:checked QLabel[role="slotTileCount"]' in out, \
        "선택 상태에서 아랫줄 대비가 정의되지 않았다"
    src = inspect.getsource(ssd)
    assert "setStyleSheet" not in src.split("_SlotTile")[1].split("class SlotSelect")[0], \
        "타일이 인라인 스타일시트로 색을 굽는다"


# ---------------------------------------------------------------------------
# KLA — 폴더명(검사 시각)이 아니라 정보파일의 WaferID·Slot# 로 보여 준다(사용자 요청)
# ---------------------------------------------------------------------------
def test_kla_tile_shows_wafer_id_and_slot_number(qapp, tmp_path):
    from aoi_verification.app.models.slot import list_slot_dirs

    ref, val = _lot(tmp_path, {"2026-08-02-23-09_4": 2, "S2": 1}, {"W6459076XYG1": 3})
    (ref / "2026-08-02-23-09_4" / "x_TB500INT.271@6324_W6459076XYG1.001").write_text(
        'WaferID "W6459076XYG1";\nSlot 4;\n', encoding="utf-8")
    dirs = list_slot_dirs(ref)
    dlg = SlotSelectDialog(sorted(dirs), ref_dirs=dirs, val_root=val)
    dlg.show()
    for _ in range(8):
        qapp.processEvents()
    assert dlg._count_scan.wait(10_000)
    for _ in range(8):
        qapp.processEvents()
    tile = dlg._tiles["2026-08-02-23-09_4"]
    want = i18n.KO.SLOT_SELECT_KLA_FMT.format(wafer_id="W6459076XYG1", slot="4")
    assert tile.display == want
    assert "W6459076XYG1" in tile.text() and "#4" in tile.text()
    assert "2026-08-02-23-09_4" in tile.toolTip()          # 폴더명은 툴팁에 남는다
    # KLA 기준이면 검증 폴더는 WaferID 이름 — 그 장수를 센다.
    assert tile.count_text() == i18n.KO.SLOT_SELECT_TILE_COUNT_FMT.format(ref="2", val="3")
    # 일반 폴더는 그대로다.
    assert dlg._tiles["S2"].display == "S2"
    # WaferID 로도 검색되고, 고른 결과는 여전히 폴더명이다(스캔이 폴더명으로 연다).
    dlg._search.setText("6459076")
    assert dlg._visible == ["2026-08-02-23-09_4"]
    dlg._select_visible()
    assert dlg.selected == {"2026-08-02-23-09_4"}
    dlg.deleteLater()
