"""설치 폴더 바로가기(.lnk) — exe 대신 run_aoi.bat 으로 켜되 아이콘이 보이게.

.bat 은 아이콘을 못 가지므로 앱이 켜질 때 설치 루트에 바로가기를 만든다.  Windows 가
없는 곳에서도 파일 구조(MS-SHLLINK)를 직접 해석해 검증한다."""

from __future__ import annotations

import struct
from pathlib import Path, PureWindowsPath

from aoi_verification.app import i18n
from aoi_verification.app.utils import shortcut


def _link_info_at(data: bytes) -> int:
    """헤더(76) 뒤 IDList(크기 첫 2바이트 + 그 2바이트)를 건너뛴 LinkInfo 위치."""
    return 76 + 2 + struct.unpack_from("<H", data, 76)[0]


def _id_items(data: bytes) -> list:
    off, items = 78, []
    while True:
        n = struct.unpack_from("<H", data, off)[0]
        if n == 0:
            return items
        items.append(data[off + 2: off + n])
        off += n


def _strings_after_link_info(data: bytes) -> list:
    """헤더(76) → IDList → LinkInfo(크기 첫 4바이트) → StringData 3개를 읽는다."""
    li = _link_info_at(data)
    off = li + struct.unpack_from("<I", data, li)[0]
    out = []
    for _ in range(3):
        n = struct.unpack_from("<H", data, off)[0]
        out.append(data[off + 2: off + 2 + n * 2].decode("utf-16-le"))
        off += 2 + n * 2
    assert data[off:] == b"\0\0\0\0"           # ExtraData 끝 표시로 정확히 끝난다
    return out


def test_lnk_points_at_the_bat_with_the_app_icon():
    root = PureWindowsPath(r"C:\AOI 검증")
    data = shortcut.build_lnk(root / "run_aoi.bat", root,
                              root / "app" / "logo.ico", "AOI 레시피 검증")
    assert struct.unpack_from("<I", data, 0)[0] == 0x4C
    assert data[4:20] == bytes.fromhex("0114020000000000c000000000000046")
    flags = struct.unpack_from("<I", data, 20)[0]
    assert flags & 0x80 and flags & 0x40 and flags & 0x02       # 유니코드·아이콘·LinkInfo
    assert flags & 0x01                                          # IDList — 아래 테스트 참고
    assert struct.unpack_from("<I", data, 60)[0] == 7           # 최소화로 띄움(콘솔 번쩍임 방지)

    li = _link_info_at(data)
    size, head, _flags, _vol, _base, _net, _suf, base_u, _suf_u = \
        struct.unpack_from("<9I", data, li)
    assert head == 0x24                                          # 유니코드 경로 오프셋 포함
    end = li + base_u
    while data[end:end + 2] != b"\0\0":                         # UTF-16 글자 단위로 끝을 찾는다
        end += 2
    target = data[li + base_u: end].decode("utf-16-le")
    assert target == r"C:\AOI 검증\run_aoi.bat"                  # 한글 경로도 그대로

    desc, workdir, icon = _strings_after_link_info(data)
    assert desc == "AOI 레시피 검증"
    assert workdir == r"C:\AOI 검증"
    assert icon == r"C:\AOI 검증\app\logo.ico"


def test_lnk_has_target_id_list_so_explorer_offers_open():
    """LinkInfo 만 있던 바로가기는 우클릭에 '열기' 가 없고 실행이 안 됐다(사용자 신고).

    탐색기는 IDList 로 대상의 종류·메뉴를 정한다 — 내 PC → C:\\ → 나머지 경로."""
    root = PureWindowsPath(r"C:\AOI_Verify")
    data = shortcut.build_lnk(root / "run_aoi.bat", root, root / "a.ico", "x")
    computer, drive, leaf = _id_items(data)
    assert computer == b"\x1f\x50" + bytes.fromhex("e04fd020ea3a6910a2d808002b30309d")
    assert len(drive) + 2 == 0x19 and drive[:4] == b"\x2fC:\\"
    assert leaf[0] == 0x32 and leaf[12:] == b"AOI_Verify\\run_aoi.bat\0"   # 파일 항목


def test_no_id_list_for_unc_paths():
    """드라이브 문자가 없으면 IDList 를 만들지 않는다 — 틀린 IDList 보다 없는 편이 낫다."""
    root = PureWindowsPath(r"\\srv\share\AOI")
    data = shortcut.build_lnk(root / "run_aoi.bat", root, root / "a.ico", "x")
    assert not struct.unpack_from("<I", data, 20)[0] & 0x01
    assert struct.unpack_from("<I", data, 76 + 4)[0] == 0x24    # LinkInfo 가 헤더 바로 뒤


def _install(tmp_path: Path) -> Path:
    root = tmp_path / "AOI_Verify"
    (root / "python").mkdir(parents=True)
    (root / "run_aoi.bat").write_text("@echo off\n")
    (root / "app").mkdir()
    return root


def test_creates_once_next_to_the_bat_even_with_the_old_bat(tmp_path, monkeypatch):
    """옛 bat 은 AOI_APP_HOME 을 안 넘긴다 — 그래도 레이아웃으로 찾아 만든다."""
    monkeypatch.setattr(shortcut.os, "name", "nt")
    root = _install(tmp_path)
    lnk = shortcut.ensure_shortcut(None, root / "app")
    assert lnk == root.resolve() / f"{i18n.KO.APP_TITLE}.lnk"
    first = lnk.stat().st_mtime_ns
    assert shortcut.ensure_shortcut(root, root / "app") == lnk   # 내용이 같으면 다시 안 쓴다
    assert lnk.stat().st_mtime_ns == first


def test_nothing_for_dev_checkout_or_non_windows(tmp_path, monkeypatch):
    monkeypatch.setattr(shortcut.os, "name", "nt")
    dev = tmp_path / "repo"
    dev.mkdir()
    assert shortcut.ensure_shortcut(None, dev) is None             # bat·python 없음
    assert not list(tmp_path.rglob("*.lnk"))
    monkeypatch.setattr(shortcut.os, "name", "posix")
    assert shortcut.ensure_shortcut(None, _install(tmp_path) / "app") is None


def test_failure_never_raises(tmp_path, monkeypatch):
    monkeypatch.setattr(shortcut.os, "name", "nt")
    root = _install(tmp_path)
    (root / f"{i18n.KO.APP_TITLE}.lnk").mkdir()                    # 쓸 수 없는 자리
    assert shortcut.ensure_shortcut(root, root / "app") is None


def test_refresh_bats_copies_the_updated_launcher_to_the_install_root(tmp_path):
    """설치 루트의 bat 은 업데이트가 안 닿는다 — 앱이 app\\scripts 사본으로 바꿔 놓는다."""
    root = tmp_path / "AOI_Verify"
    (root / "python").mkdir(parents=True)
    (root / "python" / "pythonw.exe").write_bytes(b"x")
    scripts = root / "app" / "scripts"
    scripts.mkdir(parents=True)
    (scripts / "run_aoi.bat").write_text("new run\n")
    (scripts / "run_aoi_debug.bat").write_text("new debug\n")
    (root / "run_aoi.bat").write_text("old run\n")          # 옛 bat — AOI_APP_HOME 없음

    changed = shortcut.refresh_bats(None, root / "app")      # 옛 bat 으로 켜도 찾는다
    assert sorted(p.name for p in changed) == ["run_aoi.bat", "run_aoi_debug.bat"]
    assert (root / "run_aoi.bat").read_text() == "new run\n"
    assert (root / "run_aoi_debug.bat").read_text() == "new debug\n"
    assert not list(root.glob("*.new"))
    assert shortcut.refresh_bats(root, root / "app") == []   # 같으면 다시 안 쓴다


def test_refresh_bats_leaves_dev_checkouts_alone(tmp_path):
    repo = tmp_path / "coding"
    (repo / "scripts").mkdir(parents=True)
    (repo / "scripts" / "run_aoi.bat").write_text("x")
    assert shortcut.refresh_bats(None, repo) == []
    assert not (tmp_path / "run_aoi.bat").exists()


def test_main_only_touches_bats_from_pythonw_after_bat_settles():
    """cmd 는 도는 중인 bat 을 다시 읽는다 — 디버그 bat(python.exe) 실행 중엔 바꾸면 안 된다."""
    src = (Path(__file__).resolve().parents[2] / "main.py").read_text(encoding="utf-8")
    body = src[src.index("class _StartupChecks"):src.index("def _wait_startup_checks")]
    assert '== "pythonw"' in body and "_BAT_SETTLE" in body
    assert body.index("refresh_bats") < body.index("ensure_shortcut")   # bat 이 먼저 있어야 바로가기


def test_startup_checks_finish_before_the_main_window_shows(monkeypatch):
    """사용자 요청: bat·바로가기·업데이트 확인을 로딩창에서 끝낸 뒤 메인 창을 띄운다."""
    import importlib.util
    import sys

    root = Path(__file__).resolve().parents[2]
    src = (root / "main.py").read_text(encoding="utf-8")
    body = src[src.index("def _open_main_window"):src.index("def _ensure_deps_installed")]
    assert body.index("_wait_startup_checks(") < body.index("window.show()")

    spec = importlib.util.spec_from_file_location("aoi_main_for_test", root / "main.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    from aoi_verification.app.utils import updater
    monkeypatch.setattr(updater, "check_for_update", lambda: {"sha": "abc"})
    monkeypatch.setattr(sys, "executable", "/x/python.exe")          # bat 은 건드리지 않는 경로
    checks = mod._StartupChecks(started=0.0)
    assert checks.done.wait(5)
    assert checks.info == {"sha": "abc"}
