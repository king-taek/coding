"""셋업 화면 컨트롤 — 빌더 seam 계약 · 액션바 인덱스 · (이후 단계에서 모드 스위치 추가)."""

from __future__ import annotations

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import inspect

import pytest

pytest.importorskip("PyQt6.QtWidgets")

from PyQt6.QtCore import QPoint                                 # noqa: E402
from PyQt6.QtWidgets import QApplication                        # noqa: E402

from aoi_verification.app.ui.pages import setup_page as sp      # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


# 페이지를 다시 만들거나 조각을 옮겨도 공유 로직이 동작하려면 이 속성들이 있어야 한다.
CONTRACT_ATTRS = (
    "ref_path_edit", "val_path_edit", "ref_machine_edit", "val_machine_edit",
    "coord_tol_spin", "slider", "threshold_label",
    "update_btn", "start_btn", "_action_bar",
    "_tol_row", "_threshold_row",
    "auto_group", "scope_group",
)


def test_builder_seam_exists():
    """본문이 작은 빌더로 쪼개져 있어야 조각을 값싸게 옮길 수 있다.

    ※ `_build_automation_card` + `_build_scope_row` 는 **`_build_run_options_card`
    하나로 합쳐졌다** — 값이 둘뿐인 두 설정이 전체폭 카드 두 장을 쓰고 있었다."""
    src = inspect.getsource(sp.SetupPage)
    for name in ("_build_body", "_build_title", "_build_run_options_card",
                 "_build_device_row", "_build_engine_card", "_build_action_bar"):
        assert f"def {name}" in src, f"{name} 빌더 누락"
    # 합쳐진 두 빌더는 되살아나지 말아야 한다(같은 선택을 두 카드가 다시 나누지 않게).
    # `_build_credit` 도 마찬가지다 — 크레딧의 단일 출처는 상태바
    # (`main_window._credit_label`) 이고, 페이지가 다시 넣으면 한 화면에 두 번 보인다
    # (실측 버그 → `test_credit_not_duplicated.py`).
    # 하단 '사용 방법' 접이식 안내와 다크 모드 보기 옵션은 사용자 요청으로 지웠다.
    for gone in ("_build_automation_card", "_build_scope_row", "_build_credit",
                 "_build_howto", "_build_view_options"):
        assert f"def {gone}" not in src, f"{gone} 부활 — 카드가 다시 갈라졌다"


def test_binary_settings_use_compact_segments(qapp):
    """★ 이진 선택은 44px 전체폭 타일이 아니라 34px 세그먼트다.

    타일 크기는 고르는 값의 수가 아니라 **그 선택의 무게**를 따른다 — 자동화 수준·진행
    범위는 값이 둘뿐이고 매번 바꾸지도 않는데 화면의 두 덩어리를 차지하고 있었다."""
    page = sp.SetupPage()
    try:
        for name in ("auto_group", "scope_group"):
            g = getattr(page, name)
            assert len(g.keys()) == 2, f"{name} 이 이진 선택이 아니다"
            for k in g.keys():
                role = g.button(k).property("role")
                assert role == "segment", f"{name}[{k}] role={role!r}"
    finally:
        page.deleteLater()


def test_scope_segment_does_not_open_modal_on_arrow_keys(qapp):
    """'일부 슬롯만' 은 **모달**을 띄운다 — 방향키로 훑다 열려선 안 된다.

    실측: 이 그룹에 → 키 한 번으로 경고창이 떠 테스트 하네스가 2분간 블로킹됐다."""
    page = sp.SetupPage()
    try:
        assert page.scope_group._activate_on_arrow is False
        # 부수효과가 없는 자동화 수준은 반대로 방향키 즉시 커밋이 맞다(라디오 감각).
        assert page.auto_group._activate_on_arrow is True
    finally:
        page.deleteLater()


def test_page_satisfies_attr_contract(qapp):
    page = sp.SetupPage()
    try:
        missing = [a for a in CONTRACT_ATTRS if not hasattr(page, a)]
        assert not missing, f"속성 계약 위반: {missing}"
    finally:
        page.deleteLater()


def test_action_bar_index_contract(qapp):
    """시작 바: 맨 앞은 판정 기준 배지, 그 뒤 stretch, 마지막은 주 액션(start_btn).

    자리 계약 — 새 위젯을 stretch **앞**에 붙이면 주 액션이 가운데로 밀린다.
    매칭 · 도구(사진 정보 · Wafer Map · Defect 추출 · GL 히스토그램)는 시작 바가 아니라
    왼쪽 메뉴에 있고, 업데이트 확인은 그 메뉴 맨 아래(도구 목록과 떨어져)에 있다."""
    page = sp.SetupPage()
    try:
        bar = page._action_bar
        assert bar.itemAt(0).widget() is page._mode_badge_card
        assert bar.itemAt(1).spacerItem() is not None
        tools = page._tool_buttons
        assert tools == [page.match_btn, page.image_info_btn, page.wafer_map_btn,
                         page.extract_btn, page.gl_btn]
        assert all(page._tool_rail.isAncestorOf(b) for b in tools)
        assert page._tool_rail.isAncestorOf(page.update_btn)
        assert page.update_btn not in tools
        assert not any(bar.indexOf(b) >= 0 for b in tools)
        last = bar.itemAt(bar.count() - 1).widget()
        assert last is page.start_btn
    finally:
        page.deleteLater()


# ── 구형 모드: 명시 스위치만이 모드를 바꾼다 (핵심 회귀) ─────────────────────
def test_fresh_prefs_starts_in_coordinate(qapp):
    from aoi_verification.app.utils.prefs import EngineMode
    page = sp.SetupPage()
    try:
        assert page.legacy_switch.is_on() is False
        assert page._current_engine_mode() == EngineMode.COORDINATE
    finally:
        page.deleteLater()


def test_reading_the_explanation_does_not_change_engine(qapp):
    """★ 회귀 핵심: 설명을 열어봐도 엔진은 그대로다.

    예전에는 접이식 섹션의 펼침 상태가 곧 엔진 모드였기 때문에, 설명을 읽으려고
    펼치기만 해도 좌표 → 유사도로 조용히 바뀌었다."""
    from aoi_verification.app.utils.prefs import EngineMode
    page = sp.SetupPage()
    try:
        before = page._current_engine_mode()
        assert page._current_engine_mode() == before == EngineMode.COORDINATE
        # 접이식 상태를 모드 판단에 쓰는 코드가 남아 있지 않아야 한다.
        src = inspect.getsource(sp.SetupPage._current_engine_mode)
        assert "is_expanded" not in src.split('"""')[-1]
    finally:
        page.deleteLater()


def test_switch_and_sub_choice_drive_engine_mode(qapp):
    from aoi_verification.app.utils.prefs import EngineMode
    page = sp.SetupPage()
    try:
        page.legacy_switch.set_on(True, emit=True)
        assert page._current_engine_mode() == EngineMode.BASIC
        page.legacy_group.set_current_key(EngineMode.EFFICIENCY, emit=True)
        assert page._current_engine_mode() == EngineMode.EFFICIENCY
        page.legacy_switch.set_on(False, emit=True)
        assert page._current_engine_mode() == EngineMode.COORDINATE
    finally:
        page.deleteLater()


def test_only_the_active_engine_params_are_visible(qapp):
    """무효한 파라미터는 정리하되, **토글 위에 있는 것은 숨기지 않는다.**

    이 계약은 두 번 뒤집혔고 두 번 다 이유가 있다:
    1. 처음엔 '비활성이되 항상 보임' 이었다(어느 파라미터가 어느 엔진에 속하는지
       눈으로 가르쳐 준다).
    2. 사용자 요청으로 '안 쓰면 숨김' 이 됐다.
    3. 그런데 허용 오차는 **구형 스위치보다 위**에 있어서, 숨기는 순간 스위치가
       위로 튀었다("박스 안 객체들이 움직이면서 토글 위치가 변한다").

    그래서 지금은 **위치로 나눈다** — 스위치 아래(하위 선택·임계치)는 숨기고,
    스위치 위(허용 오차)는 자리를 지킨 채 비활성으로만 보인다."""
    page = sp.SetupPage()
    try:
        page.show()
        for _ in range(6):
            qapp.processEvents()
        # 좌표 모드(기본): 허용 오차는 보이고 쓸 수 있다.
        assert page._tol_row.isVisibleTo(page) is True
        assert page._tol_row.isEnabled() is True
        assert page._threshold_row.isVisibleTo(page) is False
        assert page.legacy_group.isVisibleTo(page) is False
        # 구형 모드: 허용 오차는 **자리를 지키되 비활성**, 나머지가 나타난다.
        page.legacy_switch.set_on(True, emit=True)
        for _ in range(6):
            qapp.processEvents()
        assert page._tol_row.isVisibleTo(page) is True, "숨기면 토글이 튄다"
        assert page._tol_row.isEnabled() is False
        assert page.coord_tol_spin.isEnabled() is False, "자식까지 회색이어야 한다"
        assert page._threshold_row.isVisibleTo(page) is True
        assert page.legacy_group.isVisibleTo(page) is True
        # 되돌리면 원래대로 — 한쪽만 바뀌고 굳지 않는다.
        page.legacy_switch.set_on(False, emit=True)
        for _ in range(6):
            qapp.processEvents()
        assert page._tol_row.isEnabled() is True
        assert page._threshold_row.isVisibleTo(page) is False
    finally:
        page.deleteLater()


def test_legacy_toggle_does_not_move_when_switched(qapp):
    """★ 사용자가 신고한 증상 그대로 — 구형 모드를 켜도 **토글이 제자리에 있다.**

    켜고 끄는 컨트롤이 눌리는 순간 움직이면 연속으로 누를 수 없고, 방금 무엇을
    눌렀는지도 흐려진다."""
    page = sp.SetupPage()
    try:
        page.show()
        page.resize(1280, 900)
        for _ in range(8):
            qapp.processEvents()

        def _toggle_y() -> int:
            return page.legacy_switch.mapTo(page, QPoint(0, 0)).y()

        before = _toggle_y()
        page.legacy_switch.set_on(True, emit=True)
        for _ in range(8):
            qapp.processEvents()
        assert _toggle_y() == before, \
            f"구형 모드를 켜자 토글이 {before}px → {_toggle_y()}px 로 움직였다"

        page.legacy_switch.set_on(False, emit=True)
        for _ in range(8):
            qapp.processEvents()
        assert _toggle_y() == before
    finally:
        page.deleteLater()


def test_no_view_option_switches(qapp):
    """'모션 줄이기'·'다크 모드' 토글은 제거했다(사용자 결정)."""
    page = sp.SetupPage()
    try:
        assert not hasattr(page, "_dark_switch"), "'다크 모드' 스위치가 되살아났다"
        assert not hasattr(page, "_reduce_switch"), "'모션 줄이기' 스위치가 되살아났다"
        assert not hasattr(page, "_on_reduce_motion")
    finally:
        page.deleteLater()


def test_motion_module_has_no_reduce_knobs():
    """모션 줄이기 손잡이는 모듈에서도 사라졌다.

    ★ 단 `enabled()` 의 offscreen 게이트는 남아 있어야 한다 — 사용자 설정이 아니라
    테스트·캡처 **결정성**이고, 크래시 회귀 테스트가 이걸 켜서 애니메이션 경로를
    재현한다."""
    from aoi_verification.app.ui import motion
    for gone in ("set_reduce_motion", "reduce_motion", "os_reduce_motion"):
        assert not hasattr(motion, gone), f"motion.{gone} 잔존"
    from aoi_verification.app.utils import prefs
    assert not hasattr(prefs.UiPrefs(), "reduce_motion"), "prefs.reduce_motion 잔존"
    import inspect
    assert "offscreen" in inspect.getsource(motion.enabled)


def test_active_mode_is_stated_in_words(qapp):
    page = sp.SetupPage()
    try:
        # 좌표 매칭(기본)은 문장을 두지 않는다(사용자 요청).
        assert page._engine_inert_hint.text() == ""
        page.legacy_switch.set_on(True, emit=True)
        assert "구형" in page._engine_inert_hint.text()
    finally:
        page.deleteLater()


def test_collect_input_uses_explicit_switch(qapp, monkeypatch, tmp_path):
    """_collect_input 의 engine_mode 가 스위치 상태를 따른다."""
    from aoi_verification.app.utils.prefs import EngineMode
    page = sp.SetupPage()
    try:
        ref = tmp_path / "ref"; ref.mkdir()
        val = tmp_path / "val"; val.mkdir()
        page.ref_path_edit.setText(str(ref))
        page.val_path_edit.setText(str(val))
        inp = page._collect_input()
        assert inp is not None and inp.engine_mode == EngineMode.COORDINATE
        page.legacy_switch.set_on(True, emit=True)
        page.legacy_group.set_current_key(EngineMode.EFFICIENCY, emit=True)
        inp2 = page._collect_input()
        assert inp2 is not None and inp2.engine_mode == EngineMode.EFFICIENCY
    finally:
        page.deleteLater()


def test_legacy_hint_no_longer_claims_expanding_switches(qapp):
    """거짓 설명 제거 — '펼치면 전환됩니다' 는 더 이상 사실이 아니다."""
    from aoi_verification.app import i18n
    assert "펼치면" not in i18n.KO.LEGACY_MODE_HINT
    # 좌표 데이터 없음 안내는 켤 컨트롤을 지목해야 한다.
    assert "유사도 엔진(구형) 사용" in i18n.KO.COORD_NO_DATA_MSG


# ── 유효성 게이트 · 상태를 컨트롤 안에 ──────────────────────────────────────
def test_start_disabled_until_folders_valid(qapp, tmp_path):
    page = sp.SetupPage()
    try:
        assert page.start_btn.isEnabled() is False       # 초기: 폴더 미지정
        assert page._start_hint.text() != ""             # 이유가 보인다
        (tmp_path / "r").mkdir()
        (tmp_path / "v").mkdir()
        page.ref_path_edit.setText(str(tmp_path / "r"))
        page.val_path_edit.setText(str(tmp_path / "v"))
        page._validate()
        assert page.start_btn.isEnabled() is True
        assert page._start_hint.text() == ""
    finally:
        page.deleteLater()


def test_invalid_folder_shows_inline_reason(qapp):
    page = sp.SetupPage()
    try:
        page.ref_path_edit.setText("/definitely/not/here")
        page._validate()
        assert page.ref_path_edit.property("state") == "invalid"
        err = page.ref_path_edit.property("_errLabel")
        assert err is not None and err.text() != "" and err.isVisibleTo(page)
        assert page.start_btn.isEnabled() is False
    finally:
        page.deleteLater()


def test_messagebox_validation_path_preserved(qapp, monkeypatch):
    """비활성화는 '추가 레이어' — 기존 **경고 팝업** 경로가 살아 있어야 한다.

    (검증 통과 후 폴더가 삭제된 경우처럼 늦게 드러나는 실패를 계속 잡아준다.)

    ※ 팝업은 이제 별도 OS 창(QMessageBox)이 아니라 **앱 내 시트**(`sheet_host`)로 뜬다 —
    가로채는 지점만 바뀌었고 '경고가 뜨고 진행이 중단된다'는 계약은 그대로다."""
    page = sp.SetupPage()
    try:
        calls = []
        monkeypatch.setattr(sp.sheets, "warn",
                            lambda *a, **k: calls.append(a))
        page.ref_path_edit.setText("/definitely/not/here")
        page.val_path_edit.setText("/also/not/here")
        assert page._collect_input() is None      # 중단
        assert calls, "경로 경고 팝업이 사라졌다"
    finally:
        page.deleteLater()


def test_scope_state_lives_in_the_tile(qapp):
    """부분 선택 상태가 옆 라벨이 아니라 타일 라벨에 나타난다."""
    from aoi_verification.app import i18n
    page = sp.SetupPage()
    try:
        assert page.scope_group.current_key() == "all"
        assert page._selected_slots is None
        page.scope_group.set_option_label(
            "subset", i18n.KO.SCOPE_SUBSET_COUNT_FMT.format(n=12, total=40))
        page.scope_group.set_current_key("subset")
        assert "12/40" in page.scope_group.button("subset").text()
        page._reset_slot_selection()
        assert page.scope_group.current_key() == "all"
        assert page.scope_group.button("subset").text() == i18n.KO.SCOPE_SUBSET
        # 상태가 옆 라벨에 사는 옛 구조는 사라졌다.
        assert not hasattr(page, "slot_select_label")
    finally:
        page.deleteLater()


def test_automation_tiles_replace_radios(qapp):
    from aoi_verification.app.utils.prefs import AutomationLevel
    page = sp.SetupPage()
    try:
        assert not hasattr(page, "radio_auto_user")
        assert page.auto_group.current_key() == AutomationLevel.USER_SELECT
        page.auto_group.set_current_key(AutomationLevel.AUTO_ALL, emit=True)
        assert page.auto_group.current_key() == AutomationLevel.AUTO_ALL
    finally:
        page.deleteLater()


def test_disabled_primary_is_visually_distinct():
    """비활성 primary 가 꽉 찬 채로 남으면 '누를 수 있어 보이는 못 누르는 버튼'이 된다.

    속성 선택자가 일반 :disabled 보다 특이도가 높아 전용 규칙이 필요하다."""
    from pathlib import Path as _P
    from aoi_verification.app.ui import theme
    qss = (_P(__file__).resolve().parents[2] / "aoi_verification" / "app" / "ui"
           / "style.qss").read_text(encoding="utf-8")
    assert 'QPushButton[role="primary"]:disabled' in qss
    out = theme.render_qss(qss)
    assert "$" not in out


def test_no_horizontal_scroll_at_800x600(qapp):
    from PyQt6.QtWidgets import QScrollArea
    page = sp.SetupPage()
    try:
        page.resize(800, 600)
        page.show()
        for _ in range(8):
            qapp.processEvents()
        scroll = page.findChild(QScrollArea)
        assert scroll is not None
        assert scroll.horizontalScrollBar().maximum() == 0
    finally:
        page.deleteLater()


# ※ `capture_draft`/`restore_draft`/`_recreate_pages` 를 쓰던 테스트 3개는 없앴다 —
#    페이지를 다시 만드는 전환(색 모드)이 사라져 입력값을 옮겨 심을 일이 없다.
def test_switch_does_not_toggle_on_press_alone(qapp):
    """★ press 즉시 토글하면 터치 패널의 스크롤 제스처가 판정 엔진을 바꾼다."""
    from PyQt6.QtCore import QPointF, Qt as _Qt
    from PyQt6.QtGui import QMouseEvent

    from aoi_verification.app.ui.widgets.switch_row import SwitchRow
    row = SwitchRow("구형 모드", checked=False)
    try:
        row.resize(300, 40)
        sw = row.switch
        center = QPointF(sw.width() / 2, sw.height() / 2)
        press = QMouseEvent(QMouseEvent.Type.MouseButtonPress, center,
                            _Qt.MouseButton.LeftButton, _Qt.MouseButton.LeftButton,
                            _Qt.KeyboardModifier.NoModifier)
        sw.mousePressEvent(press)
        assert sw.is_on() is False, "press 만으로 토글됐다"

        # 위젯 **밖**에서 release → 취소(드래그로 빠져나간 경우)
        outside = QPointF(sw.width() + 40, sw.height() + 40)
        rel_out = QMouseEvent(QMouseEvent.Type.MouseButtonRelease, outside,
                              _Qt.MouseButton.LeftButton, _Qt.MouseButton.LeftButton,
                              _Qt.KeyboardModifier.NoModifier)
        sw.mouseReleaseEvent(rel_out)
        assert sw.is_on() is False, "밖에서 release 했는데 토글됐다"

        # 안에서 press→release → 실행
        sw.mousePressEvent(press)
        rel_in = QMouseEvent(QMouseEvent.Type.MouseButtonRelease, center,
                             _Qt.MouseButton.LeftButton, _Qt.MouseButton.LeftButton,
                             _Qt.KeyboardModifier.NoModifier)
        sw.mouseReleaseEvent(rel_in)
        assert sw.is_on() is True, "정상 클릭이 토글되지 않았다"
    finally:
        row.deleteLater()


def test_switch_hot_zone_is_not_the_whole_row(qapp):
    """넓은 카드 안에서 행 전체가 핫존이면 보이지 않는 1300px 클릭영역이 생긴다."""
    from aoi_verification.app.ui.widgets.switch_row import SwitchRow
    row = SwitchRow("유사도 엔진(구형) 사용",
                    description="끄면 좌표 매칭을 씁니다 — 권장 기본값.")
    try:
        row.resize(1300, 60)
        row.show()
        for _ in range(8):
            qapp.processEvents()
        # 제목은 자기 글자 폭만 차지해야 한다(여백까지 늘어나면 다시 넓은 핫존).
        assert row._title.width() < row.width() * 0.5, \
            f"제목 폭 {row._title.width()} / 행 폭 {row.width()}"
        # 행 자신은 mousePressEvent 를 재정의하지 않는다(빈 여백 클릭 = 무반응).
        assert "mousePressEvent" not in SwitchRow.__dict__
    finally:
        row.deleteLater()
