"""Surface.flt 파서 + geometry 리졸버 — 합성 스키마로 로직 검증.

실제 바이트 오프셋 스키마(Surface.flt.md)는 저장소에 없으므로, 테스트는 모듈의
스키마 상수를 합성 레이아웃으로 monkeypatch 해 파서/리졸버 로직을 검증한다.
(스키마가 채워지면 실데이터로 추가 검증 가능 — 로직 자체는 동일.)

무거운 의존성(PyQt6/openpyxl/cv2) 불필요 — 순수 stdlib 로직.
"""

import struct
from pathlib import Path

from aoi_verification.app.coords import (abs_coord, camtek_ini, geometry,
                                         pixel_size, recipe_name, surface_flt,
                                         zone_name)


# 합성 레코드 레이아웃: 32바이트. geometry 는 float32, zone/recipe 는 uint8.
_SYN_FIELDS = {
    "actual_x":       (0, "f"),
    "actual_y":       (4, "f"),
    "area":           (8, "f"),
    "blob_breadth":   (12, "f"),
    "blob_feret_max": (16, "f"),
    "contrast":       (20, "f"),
    "zone":           (24, "B"),
    "recipe":         (25, "B"),
}
_SYN_SIZE = 32
_SYN_HEADER = 0
_INT_FMTS = ("B", "b", "h", "H", "i", "I")


def _install_schema(monkeypatch):
    """surface_flt 에 합성 스키마를 설치(_SCHEMA_READY=True)."""
    monkeypatch.setattr(surface_flt, "_FIELDS", dict(_SYN_FIELDS))
    monkeypatch.setattr(surface_flt, "_RECORD_SIZE", _SYN_SIZE)
    monkeypatch.setattr(surface_flt, "_HEADER_BYTES", _SYN_HEADER)
    monkeypatch.setattr(surface_flt, "_BYTE_ORDER", "<")
    monkeypatch.setattr(surface_flt, "_SCHEMA_READY", True)
    surface_flt.load_folder.cache_clear()
    camtek_ini.load_abs_folder.cache_clear()


def _pack_record(**vals) -> bytes:
    buf = bytearray(_SYN_SIZE)
    for name, (off, fmt) in _SYN_FIELDS.items():
        v = vals.get(name, 0)
        v = int(v) if fmt in _INT_FMTS else float(v)
        struct.pack_into("<" + fmt, buf, _SYN_HEADER + off, v)
    return bytes(buf)


def _write_flt(folder: Path, *records: bytes) -> None:
    (folder / "Surface.flt").write_bytes(b"".join(records))


# ── 파서 ────────────────────────────────────────────────────────────────
def test_parse_two_records(monkeypatch, tmp_path):
    _install_schema(monkeypatch)
    _write_flt(
        tmp_path,
        _pack_record(actual_x=100.0, actual_y=200.0, area=55.0,
                     blob_breadth=2.0, blob_feret_max=11.0, contrast=108.0),
        _pack_record(actual_x=300.0, actual_y=400.0, area=108.0,
                     blob_breadth=5.0, blob_feret_max=16.0, contrast=64.0),
    )
    recs = surface_flt.load_folder(tmp_path)
    assert len(recs) == 2
    assert recs[0].actual_x == 100.0 and recs[0].area == 55.0
    assert recs[1].contrast == 64.0


def test_missing_file_returns_empty(monkeypatch, tmp_path):
    _install_schema(monkeypatch)
    assert surface_flt.load_folder(tmp_path) == ()
    assert surface_flt.has_flt(tmp_path) is False


def test_truncated_bytes_no_raise(monkeypatch, tmp_path):
    _install_schema(monkeypatch)
    # 레코드 크기보다 짧은 꼬리는 조용히 버린다(raise 없음).
    (tmp_path / "Surface.flt").write_bytes(
        _pack_record(actual_x=1, actual_y=2, area=3, blob_breadth=4,
                     blob_feret_max=5, contrast=6) + b"\x00\x07")
    recs = surface_flt.load_folder(tmp_path)
    assert len(recs) == 1


def test_schema_live_by_default():
    """확정 스키마가 채워져 기본 활성(_SCHEMA_READY=True)."""
    assert surface_flt._SCHEMA_READY is True


def test_disabled_fallback_when_schema_off(monkeypatch, tmp_path):
    """스키마를 끄면(_SCHEMA_READY=False) 파일이 있어도 빈 결과(안전 폴백)."""
    monkeypatch.setattr(surface_flt, "_SCHEMA_READY", False)
    (tmp_path / "Surface.flt").write_bytes(b"\x00" * 304)
    surface_flt.load_folder.cache_clear()
    assert surface_flt.load_folder(tmp_path) == ()


# ── geometry 리졸버 (status 구분) ─────────────────────────────────────────
def _write_ini(folder: Path, stem: str, x: float, y: float) -> Path:
    (folder / "ColorImageGrabingInfo.ini").write_text(
        f"[{stem}.jpeg]\nX={x}\nY={y}\nCol=3\nRow=5\n", encoding="utf-8")
    img = folder / f"{stem}.jpeg"
    img.write_bytes(b"")  # 존재만 하면 됨(파서는 경로만 사용).
    return img


def test_geometry_ok(monkeypatch, tmp_path):
    _install_schema(monkeypatch)
    _write_flt(tmp_path, _pack_record(
        actual_x=147203.82, actual_y=243724.57, area=55.0,
        blob_breadth=2.1823, blob_feret_max=11.3868, contrast=108.18,
        zone=1, recipe=2))
    img = _write_ini(tmp_path, "147206.243725.c.2104939970.2",
                     147203.82, 243724.57)
    res = geometry.resolve(img)
    assert res.status == "ok"
    g = res.geometry
    # 픽셀크기 파일이 없으면 0.77 폴백.
    assert abs(g.pixel_um - 0.77) < 1e-9
    assert round(g.area_um2, 1) == round(55.0 * 0.77 * 0.77, 1)
    assert round(g.width_um, 3) == round(2.1823 * 0.77, 3)
    assert round(g.length_um, 3) == round(11.3868 * 0.77, 3)
    assert round(g.contrast) == 108
    assert g.zone == 1 and g.recipe == 2


def test_geometry_dynamic_pixel_size(monkeypatch, tmp_path):
    """결과 폴더에 Params_WaferInfo.ini 가 있으면 그 RefPixelSizeX 로 환산(0.77 아님)."""
    _install_schema(monkeypatch)
    pixel_size.scan_pixel_size_xy.cache_clear()
    _write_flt(tmp_path, _pack_record(
        actual_x=100.0, actual_y=200.0, area=55.0,
        blob_breadth=2.0, blob_feret_max=11.0, contrast=5.0, zone=1, recipe=2))
    (tmp_path / "Params_WaferInfo.ini").write_text(
        "[Wafer]\nRefPixelSizeX=0.8452004\nRefPixelSizeY=0.8452004\n", encoding="utf-8")
    img = _write_ini(tmp_path, "x.100.200", 100.0, 200.0)
    g = geometry.resolve(img).geometry
    assert abs(g.pixel_um - 0.8452004) < 1e-9
    assert abs(g.width_um - 2.0 * 0.8452004) < 1e-6
    assert abs(g.area_um2 - 55.0 * 0.8452004 ** 2) < 1e-4


def test_zone_name_dynamic(monkeypatch, tmp_path):
    """결과 폴더 recipe 파일의 ZoneName/ZoneID 로 zone 이름을 읽는다(자재별)."""
    _install_schema(monkeypatch)
    zone_name.zone_map.cache_clear()
    pixel_size.scan_pixel_size_xy.cache_clear()
    _write_flt(tmp_path, _pack_record(
        actual_x=100.0, actual_y=200.0, area=10.0, blob_breadth=1.0,
        blob_feret_max=2.0, contrast=5.0, zone=1, recipe=2))
    (tmp_path / "ProductInfo.ini").write_text(
        "[Zone0]\nZoneName=PI_Opening\nZoneID=1\n"
        "[Zone1]\nZoneName=Scan Area\nZoneID=63\n", encoding="utf-8")
    img = _write_ini(tmp_path, "x.100.200", 100.0, 200.0)
    g = geometry.resolve(img).geometry
    assert g.zone == 1 and g.zone_name == "PI_Opening"


def test_recipe_name_dynamic(monkeypatch, tmp_path):
    """결과 폴더 recipe 파일의 RecipeName/RecipeNumber 로 recipe 이름을 읽는다(자재별)."""
    _install_schema(monkeypatch)
    recipe_name.recipe_map.cache_clear()
    pixel_size.scan_pixel_size_xy.cache_clear()
    _write_flt(tmp_path, _pack_record(
        actual_x=100.0, actual_y=200.0, area=10.0, blob_breadth=1.0,
        blob_feret_max=2.0, contrast=5.0, zone=1, recipe=2))
    (tmp_path / "ProductInfo.ini").write_text(
        "[R0]\nRecipeName=PI_Bubble\nRecipeNumber=1\n"
        "[R1]\nRecipeName=PI\nRecipeNumber=2\n", encoding="utf-8")
    img = _write_ini(tmp_path, "x.100.200", 100.0, 200.0)
    g = geometry.resolve(img).geometry
    assert g.recipe == 2 and g.recipe_name == "PI"


def test_recipe_name_from_recipesinfo_sections(tmp_path):
    """RecipesInfo.ini 의 [Recipe-<N>] Name= (실측 주 형식)."""
    recipe_name.recipe_map.cache_clear()
    (tmp_path / "RecipesInfo.ini").write_text(
        "[Recipe-1]\nName=PI_Bubble\nScan2DPixelSize=0.7708\n"
        "[Recipe-2]\nName=PI\n[Recipes]\nCount=2\n", encoding="utf-8")
    assert recipe_name.name_for(tmp_path, 1) == "PI_Bubble"
    assert recipe_name.name_for(tmp_path, 2) == "PI"
    assert recipe_name.name_for(tmp_path, 9) is None


def test_zone_name_from_zones_subfolder(tmp_path):
    """Zones\\<name>.ini 서브폴더의 [General] ZoneName/ZoneID (실측 주 형식).

    ZoneID 가 Surface.flt 코드와 일치한다(Scan Area=63 등)."""
    zone_name.zone_map.cache_clear()
    zdir = tmp_path / "Zones"
    zdir.mkdir()
    (zdir / "RDL.ini").write_text(
        "[General]\nZoneName=RDL\nZoneID=2\nTypeName=Surface\n", encoding="utf-8")
    (zdir / "Scan Area.ini").write_text(
        "[General]\nZoneName=Scan Area\nZoneID=63\n", encoding="utf-8")
    assert zone_name.name_for(tmp_path, 2) == "RDL"
    assert zone_name.name_for(tmp_path, 63) == "Scan Area"
    assert zone_name.name_for(tmp_path, 99) is None


def test_recipe_name_scans_all_ini(tmp_path):
    """대표 ini 에 없으면 폴더 안 임의 *.ini 까지 확대 검색('(매핑없음)' 대비)."""
    recipe_name.recipe_map.cache_clear()
    # 대표 파일(ProductInfo/RecipesInfo)이 아닌 다른 이름의 ini 에 매핑이 있다.
    (tmp_path / "Recipe_Custom.ini").write_text(
        "[A]\nRecipeName=PI\nRecipeNumber=2\n", encoding="utf-8")
    assert recipe_name.name_for(tmp_path, 2) == "PI"
    assert recipe_name.name_for(tmp_path, 99) is None


def test_zone_name_scans_all_ini(tmp_path):
    """zone 도 대표 ini 에 없으면 임의 *.ini 까지 확대('(매핑없음)' 대비)."""
    zone_name.zone_map.cache_clear()
    (tmp_path / "Zones_Custom.ini").write_text(
        "[A]\nZoneName=RDL\nZoneID=2\n", encoding="utf-8")
    assert zone_name.name_for(tmp_path, 2) == "RDL"


def test_geometry_anisotropic_area(monkeypatch, tmp_path):
    """면적은 px_x × px_y(이방성)로 환산 — X≠Y 면 px² 와 다른 값이 나온다."""
    _install_schema(monkeypatch)
    pixel_size.scan_pixel_size_xy.cache_clear()
    _write_flt(tmp_path, _pack_record(
        actual_x=100.0, actual_y=200.0, area=250.0,
        blob_breadth=2.0, blob_feret_max=11.0, contrast=5.0, zone=1, recipe=2))
    (tmp_path / "Params_WaferInfo.ini").write_text(
        "[Wafer]\nRefPixelSizeX=0.7696441\nRefPixelSizeY=0.769460\n",
        encoding="utf-8")
    img = _write_ini(tmp_path, "x.100.200", 100.0, 200.0)
    g = geometry.resolve(img).geometry
    # 선형(width/length)·pixel_um 은 px_x 를 쓴다.
    assert abs(g.pixel_um - 0.7696441) < 1e-9
    assert abs(g.width_um - 2.0 * 0.7696441) < 1e-6
    # 면적은 px_x × px_y — px_x² 보다 작다(px_y < px_x).
    assert abs(g.area_um2 - 250.0 * 0.7696441 * 0.769460) < 1e-4
    assert g.area_um2 < 250.0 * 0.7696441 ** 2


def test_zone_name_map_and_missing(tmp_path):
    zone_name.zone_map.cache_clear()
    (tmp_path / "RecipesInfo.ini").write_text(
        "[A]\nZoneName=VIA\nZoneID=1\n[B]\nZoneName=Scan Area\nZoneID=63\n",
        encoding="utf-8")
    assert zone_name.name_for(tmp_path, 1) == "VIA"      # 자재별로 다를 수 있음
    assert zone_name.name_for(tmp_path, 63) == "Scan Area"
    assert zone_name.name_for(tmp_path, 999) is None
    zone_name.zone_map.cache_clear()
    assert zone_name.name_for(tmp_path / "none", 1) is None


def test_pixel_size_priority(tmp_path):
    """우선순위: Params_WaferInfo.ini(RefPixelSizeX) > ProductInfo.ini(Scan2DPixelSize)."""
    pixel_size.scan_pixel_size_xy.cache_clear()
    (tmp_path / "ProductInfo.ini").write_text("Scan2DPixelSize=0.7708\n", encoding="utf-8")
    assert abs(pixel_size.scan_pixel_size(tmp_path) - 0.7708) < 1e-9
    pixel_size.scan_pixel_size_xy.cache_clear()
    (tmp_path / "Params_WaferInfo.ini").write_text("RefPixelSizeX=0.7707764\n", encoding="utf-8")
    assert abs(pixel_size.scan_pixel_size(tmp_path) - 0.7707764) < 1e-9  # 우선
    pixel_size.scan_pixel_size_xy.cache_clear()
    assert pixel_size.scan_pixel_size(tmp_path / "none") is None  # 없으면 None


def test_geometry_no_flt_marker(monkeypatch, tmp_path):
    """Surface.flt 자체가 없으면 status='no_flt' (미지원 자재)."""
    _install_schema(monkeypatch)
    img = _write_ini(tmp_path, "abc.1.2.3", 100.0, 200.0)
    res = geometry.resolve(img)
    assert res.status == "no_flt" and res.geometry is None


def test_geometry_no_data_when_coord_far(monkeypatch, tmp_path):
    """flt 는 있으나 좌표가 tol 밖이면 status='no_data'."""
    _install_schema(monkeypatch)
    _write_flt(tmp_path, _pack_record(
        actual_x=0.0, actual_y=0.0, area=10, blob_breadth=1,
        blob_feret_max=2, contrast=5))
    img = _write_ini(tmp_path, "far.9.9.9", 99999.0, 99999.0)
    res = geometry.resolve(img)
    assert res.status == "no_data" and res.geometry is None


def test_geometry_disabled_when_schema_off(monkeypatch, tmp_path):
    """스키마를 끄면 status='disabled' — 엑셀이 기존과 동일하게 렌더."""
    monkeypatch.setattr(surface_flt, "_SCHEMA_READY", False)
    surface_flt.load_folder.cache_clear()
    img = tmp_path / "x.1.2.3.jpeg"
    img.write_bytes(b"")
    res = geometry.resolve(img)
    assert res.status == "disabled"


# ── 실데이터 회귀 — 예시에서 추출한 실제 152byte record(확정 오프셋 가드) ────
# (hex, area, blob_breadth, blob_feret_max, contrast, actual_x, actual_y, zone, recipe)
_REAL_RECORDS = [
    ("00001d0000000020906dab41602b134138fb1269788e0e41906dab41602b134138fb1269788e0e41010000006900000000000000000000000000000000010200000000000000144000000000000018400000000000003840000000e089dc09400000008059b21d40000000c0ff8919400000000000e0504000000000000014400000000000000000000000a0aaea5e400000000000000000",
     24.0, 3.232685, 6.384765, 123.666664, 314072.064131, 250319.051306, 1, 2),
    ("1d00000000040000a6756ba85096134148d30a475e9b0f41a6756ba85096134148d30a475e9b0f41ffffffff0f0000083613000000a0404400a01344003f0200000000000000284000000000000024400000000000804740000000c00f3f0a4000000080d0a62c40000000c0d3ae2b400000000000803640000000c076f81440000000000000000000000000000000000000000000000000",
     47.0, 3.280792, 13.841459, 0.0, 320916.164472, 258923.784689, 63, 2),
]


def test_real_record_decodes(tmp_path):
    """실측 Surface.flt record 가 확정 오프셋으로 정확히 디코딩된다(스키마 가드).

    area/width/length/contrast/zone/recipe 6개 — 오프셋/타입/엔디안이 어긋나면 실패.
    """
    for hx, area, breadth, feret, contrast, ax, ay, zone, recipe in _REAL_RECORDS:
        raw = bytes.fromhex(hx)
        assert len(raw) == 152
        surface_flt.load_folder.cache_clear()
        (tmp_path / "Surface.flt").write_bytes(raw)
        recs = surface_flt.load_folder(tmp_path)
        assert len(recs) == 1
        r = recs[0]
        assert abs(r.actual_x - ax) < 1e-3
        assert abs(r.actual_y - ay) < 1e-3
        assert abs(r.area - area) < 1e-3
        assert abs(r.blob_breadth - breadth) < 1e-5
        assert abs(r.blob_feret_max - feret) < 1e-5
        assert abs(r.contrast - contrast) < 1e-4
        assert r.zone == zone and r.recipe == recipe


def test_dotted_filename_abs_coord(tmp_path):
    """INI 없이 점표기 파일명에서 절대 X.Y 추출."""
    camtek_ini.load_abs_folder.cache_clear()
    img = tmp_path / "147206.243725.c.2104939970.2.jpeg"
    img.write_bytes(b"")
    xy = abs_coord.absolute_xy(img)
    assert xy == (147206.0, 243725.0)


# ── 속도 개선의 회귀 가드 — 결과는 한 비트도 달라지면 안 된다 ──────────────
def test_fast_parse_matches_field_by_field(tmp_path):
    """실제 스키마(152바이트)로 무작위 레코드를 만들어 두 경로의 결과를 비교한다.

    한 번에 푸는 경로(`struct.iter_unpack`)가 필드별 경로와 **같은 값·같은 개수**를
    내야 한다(꼬리의 불완전 레코드는 둘 다 버린다)."""
    import random
    rnd = random.Random(7)
    data = bytes(rnd.getrandbits(8) for _ in range(surface_flt._RECORD_SIZE * 300 + 17))
    p = tmp_path / "Surface.flt"
    p.write_bytes(data)
    fast = surface_flt._parse_flt(p)
    slow = surface_flt._parse_flt_by_field(data)
    assert len(fast) == len(slow) == 300
    # NaN 은 == 가 거짓이라 바이트 표현으로 비교한다.
    assert [tuple(map(repr, r)) for r in fast] == [tuple(map(repr, r)) for r in slow]


def test_fast_parse_follows_patched_schema(monkeypatch, tmp_path):
    """테스트가 끼워 넣는 합성 스키마에서도 같은 결과(스키마를 매번 읽는다)."""
    _install_schema(monkeypatch)
    recs = [_pack_record(actual_x=i, actual_y=-i, area=i * 2, blob_breadth=1,
                         blob_feret_max=2, contrast=3, zone=i % 5, recipe=i % 3)
            for i in range(50)]
    _write_flt(tmp_path, *recs)
    data = (tmp_path / "Surface.flt").read_bytes()
    assert (surface_flt._parse_flt(tmp_path / "Surface.flt")
            == surface_flt._parse_flt_by_field(data))


def _brute_nearest(records, xy, tol):
    """색인 도입 전의 원래 루프 그대로 — 비교 기준."""
    import math
    x, y = xy
    best, best_d = None, tol
    for rec in records:
        dx = rec.actual_x - x
        if dx > best_d or dx < -best_d:
            continue
        d = math.hypot(dx, rec.actual_y - y)
        if d <= best_d:
            best_d, best = d, rec
    return best


def test_indexed_nearest_matches_brute_force():
    """색인 탐색이 전수 탐색과 **같은 레코드**를 고른다 — 동점·경계·NaN 포함."""
    import random
    rnd = random.Random(11)
    R = surface_flt.RawRecord
    recs = []
    for i in range(2000):
        x = rnd.choice([rnd.uniform(0, 500), float(rnd.randint(0, 50))])
        y = rnd.choice([rnd.uniform(0, 500), float(rnd.randint(0, 50))])
        recs.append(R(x, y, i, 0, 0, 0, 0, 0))
    recs += [R(10.0, 10.0, 9001, 0, 0, 0, 0, 0),      # 완전 동점 — 뒤가 이긴다
             R(10.0, 10.0, 9002, 0, 0, 0, 0, 0),
             R(float("nan"), 10.0, 9003, 0, 0, 0, 0, 0),
             R(15.0, 10.0, 9004, 0, 0, 0, 0, 0)]      # 정확히 tol 거리
    recs = tuple(recs)
    probes = [(10.0, 10.0), (20.0, 10.0), (float("nan"), 1.0)]
    probes += [(rnd.uniform(-10, 510), rnd.uniform(-10, 510)) for _ in range(400)]
    probes += [(float(rnd.randint(0, 50)), float(rnd.randint(0, 50))) for _ in range(200)]
    for xy in probes:
        assert geometry._nearest(recs, xy, 5.0) is _brute_nearest(recs, xy, 5.0), xy
    assert geometry._nearest(recs, (10.0, 10.0), 5.0).area == 9002
    assert geometry._nearest((), (1.0, 1.0), 5.0) is None
