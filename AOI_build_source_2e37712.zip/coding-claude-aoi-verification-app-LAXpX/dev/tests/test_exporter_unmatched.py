"""Excel exporter — 매칭 + 미매칭 reference 통합 출력 검증."""

import os
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PyQt6.QtWidgets")
pytest.importorskip("openpyxl")
pytest.importorskip("PIL.Image")

from PIL import Image                                          # noqa: E402
from PyQt6.QtWidgets import QApplication                       # noqa: E402

from aoi_verification.app.models.result import (               # noqa: E402
    FinalResult, MatchResult, MissEntry,
)
from aoi_verification.app.workers.exporter import ExcelExporter  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _make_image(folder: Path, name: str) -> Path:
    p = folder / name
    Image.new("RGB", (400, 300), color=(80, 120, 200)).save(str(p), "JPEG")
    return p


def test_export_writes_matches_and_unmatched(qapp, isolated_cache, tmp_path):
    """매칭 + 미매칭이 같이 들어가면 결과 워크북에 두 종류 모두 나타난다."""
    src = tmp_path / "src"
    src.mkdir()
    a_ref = _make_image(src, "a_ref.jpeg")
    a_val = _make_image(src, "a_val.jpeg")
    b_ref = _make_image(src, "b_ref.jpeg")  # 미매칭

    result = FinalResult(
        mode="single",
        ref_machine="1호기",
        val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=a_ref, val_path=a_val,
                              score=0.9)],
        unmatched_refs=[MissEntry(slot="S1", side="ref", path=b_ref,
                                   note="미매칭")],
    )
    dst = tmp_path / "out.xlsx"
    # 양식 자동 감지를 피하려고 일부러 존재하지 않는 템플릿 경로를 명시 지정.
    no_tpl = tmp_path / "no_template.xlsx"
    exp = ExcelExporter(result, dst_path=dst, template_path=no_tpl)
    exp.run()  # QThread.run() 을 동기 실행
    assert dst.exists()

    from aoi_verification.app import i18n
    from openpyxl import load_workbook
    from openpyxl.cell.rich_text import CellRichText
    wb = load_workbook(str(dst), rich_text=True)
    # 요약 시트(파일명 stem)를 이름으로 직접 읽는다 — .active 는 openpyxl 버전에
    # 따라 미매칭 시트를 가리킬 수 있어 의존하지 않는다.
    ws = wb["out"]
    # 헤더는 row 1~2, 데이터는 row 3 부터. 정렬: a_ref(매칭)=row3, b_ref(미매칭)=row4.
    # ★ 매치 행의 C·D 는 사진 **아래에** 캡션(파일명 + 정보)을 함께 갖는다(사용자 요청).
    assert "a_ref.jpeg" in str(ws["C3"].value)
    assert "a_val.jpeg" in str(ws["D3"].value)
    d4 = ws["D4"].value
    # geometry 기능 활성 + Surface.flt 없음 → 파일명 + '미지원 자재' 마커(rich-text).
    assert "b_ref.jpeg" in str(d4)
    assert i18n.KO.GEOM_NOT_SUPPORTED in str(d4)
    # ★ 파일명 블록은 **회색 8pt** 다 — 예전의 빨강 굵은 글씨가 아니다(28안 ②).
    #   같은 셀 안에서 파일명(굵은 빨강)과 그 아래 geometry·좌표(회색 8pt)가
    #   서로 다른 등급이라 시선이 갈렸다.  '미매칭' 이라는 구분은 이제 **행 전체
    #   틴트**(UNMATCHED_FILL)가 담당하므로, 글씨가 혼자 소리칠 이유가 없다 —
    #   덤으로 흑백 인쇄에서도 구분이 살아남는다(빨강은 흑백에서 사라진다).
    #   ★ 색은 **검정**이다 — 시안은 회색(#808080)이었지만 8pt 회색이 인쇄물에서
    #   실제로 읽히지 않아 사용자가 되돌렸다.  등급은 크기로만 낮춘다.
    assert isinstance(d4, CellRichText)
    assert "000000" in str(d4[0].font.color.rgb).upper(), (
        "파일명이 검정이 아니다 — 8pt 회색은 인쇄물에서 읽기 어려웠다(사용자 결정)")
    assert float(d4[0].font.sz) == 8.0, "파일명이 8pt 가 아니다"
    # 구분을 넘겨받은 쪽 — 미매칭 행은 A~D 가 통째로 물든다.
    for col in ("A", "B", "C", "D"):
        assert str(ws[f"{col}4"].fill.fgColor.rgb).upper() == "FFFDF1EA", (
            f"{col}4 미매칭 틴트가 없다")
    # 매칭 행은 줄무늬 그대로 — 둘이 같아지면 구분이 사라진다.
    assert str(ws["A3"].fill.fgColor.rgb).upper() != "FFFDF1EA"

    # 코멘트 ‘미매칭’ 확인
    assert ws["D4"].comment is not None
    assert "미매칭" in str(ws["D4"].comment.text)

    # AOI-N 헤더가 row 2 에 들어갔는지 (#3).
    assert ws["C2"].value == "AOI-1"
    assert ws["D2"].value == "AOI-2"


def test_export_no_unmatched_unaffected(qapp, isolated_cache, tmp_path):
    """unmatched_refs 가 비어있으면 기존 동작과 동일하게 매칭만 출력."""
    src = tmp_path / "src"
    src.mkdir()
    ref = _make_image(src, "ref.jpeg")
    val = _make_image(src, "val.jpeg")

    result = FinalResult(
        mode="single",
        ref_machine="1호기",
        val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=ref, val_path=val,
                              score=0.9)],
    )
    dst = tmp_path / "out2.xlsx"
    no_tpl = tmp_path / "no_template.xlsx"
    ExcelExporter(result, dst_path=dst, template_path=no_tpl).run()
    assert dst.exists()

    from openpyxl import load_workbook
    ws = load_workbook(str(dst)).active
    # 헤더 2 줄 + 데이터 row 3 부터. 행 3 = 매칭, 행 4 는 데이터 없음.
    assert ws["B3"].value == "S1"
    assert "val.jpeg" in str(ws["D3"].value)   # 사진 아래 캡션(파일명)
    assert ws["B4"].value is None


def test_export_has_no_full_template_sheet(qapp, isolated_cache, tmp_path):
    """전체 양식(E~H 수기 영역) 시트는 만들지 않는다 — 옵션 삭제(사용자 요청 2026-10-25)."""
    src = tmp_path / "src"
    src.mkdir()
    ref = _make_image(src, "ref.jpeg")
    val = _make_image(src, "val.jpeg")
    result = FinalResult(
        mode="single", ref_machine="1호기", val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=ref, val_path=val, score=0.9)],
    )
    from aoi_verification.app.utils import paths
    from openpyxl import load_workbook

    # 요약 시트만, '전체 양식' 없음.
    dst = tmp_path / "결과_AOI-1_vs_AOI-2.xlsx"
    ExcelExporter(result, dst_path=dst,
                  template_path=paths.template_path()).run()
    wb = load_workbook(str(dst))
    assert wb.sheetnames[0] == "결과_AOI-1_vs_AOI-2"
    assert "전체 양식" not in wb.sheetnames
    summary = wb["결과_AOI-1_vs_AOI-2"]
    # 요약 시트는 A~D 만 — E~H 헤더 없음 + 데이터 채워짐.
    assert summary["A1"].value == "No" and summary["C1"].value == "Scan Defect"
    assert summary["E1"].value is None and summary["G1"].value is None
    assert summary["B3"].value == "S1"
    # 옵션 인자 자체가 없어졌다 — 다시 켤 길이 남지 않게.
    with pytest.raises(TypeError):
        ExcelExporter(result, dst_path=dst, include_full_template=True)


def test_export_unmatched_sheet(qapp, isolated_cache, tmp_path):
    """미매칭이 있으면 '미매칭 사진' 시트가 추가된다(이미지 포함, #3)."""
    src = tmp_path / "src"
    src.mkdir()
    ref = _make_image(src, "ref.jpeg")
    val = _make_image(src, "val.jpeg")
    miss = _make_image(src, "miss.jpeg")
    result = FinalResult(
        mode="single", ref_machine="1호기", val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=ref, val_path=val, score=0.9)],
        unmatched_refs=[MissEntry(slot="S2", side="ref", path=miss, note="미매칭")],
    )
    from aoi_verification.app import i18n
    from openpyxl import load_workbook
    no_tpl = tmp_path / "no_template.xlsx"
    dst = tmp_path / "out.xlsx"
    ExcelExporter(result, dst_path=dst, template_path=no_tpl).run()
    wb = load_workbook(str(dst), rich_text=True)
    assert i18n.KO.SHEET_UNMATCHED in wb.sheetnames
    um = wb[i18n.KO.SHEET_UNMATCHED]
    # 미매칭 시트엔 미매칭 행만 — 첫 데이터 행 slot=S2, D열에 파일명(+미지원 마커).
    assert um["B3"].value == "S2"
    assert "miss.jpeg" in str(um["D3"].value)
    assert i18n.KO.GEOM_NOT_SUPPORTED in str(um["D3"].value)


def _install_flt_schema(monkeypatch):
    """exporter 테스트용 — surface_flt 에 합성 스키마(32B) 설치(zone/recipe 포함)."""
    from aoi_verification.app.coords import surface_flt, camtek_ini
    fields = {"actual_x": (0, "f"), "actual_y": (4, "f"), "area": (8, "f"),
              "blob_breadth": (12, "f"), "blob_feret_max": (16, "f"),
              "contrast": (20, "f"), "zone": (24, "B"), "recipe": (25, "B")}
    monkeypatch.setattr(surface_flt, "_FIELDS", dict(fields))
    monkeypatch.setattr(surface_flt, "_RECORD_SIZE", 32)
    monkeypatch.setattr(surface_flt, "_HEADER_BYTES", 0)
    monkeypatch.setattr(surface_flt, "_SCHEMA_READY", True)
    surface_flt.load_folder.cache_clear()
    camtek_ini.load_abs_folder.cache_clear()


def _write_flt_record(folder: Path, x, y, area, breadth, feret, contrast,
                      zone=1, recipe=2):
    import struct
    buf = bytearray(32)
    for off, v in ((0, x), (4, y), (8, area), (12, breadth),
                   (16, feret), (20, contrast)):
        struct.pack_into("<f", buf, off, float(v))
    struct.pack_into("<B", buf, 24, int(zone))
    struct.pack_into("<B", buf, 25, int(recipe))
    (folder / "Surface.flt").write_bytes(bytes(buf))


def test_unmatched_geometry_rendered(qapp, isolated_cache, tmp_path, monkeypatch):
    """Surface.flt + 좌표 일치 → 미매칭 D셀에 geometry(area/contrast) 표기."""
    _install_flt_schema(monkeypatch)
    src = tmp_path / "src"
    src.mkdir()
    ref = _make_image(src, "a_ref.jpeg")
    val = _make_image(src, "a_val.jpeg")
    miss = _make_image(src, "z_miss.jpeg")
    _write_flt_record(src, 112743.1, 226527.0, 55.0, 2.0, 11.0, 108.0,
                      zone=1, recipe=2)
    (src / "ColorImageGrabingInfo.ini").write_text(
        "[z_miss.jpeg]\nX=112743.1\nY=226527.0\nCol=3\nRow=5\n",
        encoding="utf-8")
    # zone/recipe 이름 매핑(자재별)을 결과 폴더 ini 에서 읽어 표기하는지 검증.
    (src / "ProductInfo.ini").write_text(
        "[Z]\nZoneName=PI_Opening\nZoneID=1\n"
        "[R]\nRecipeName=PI\nRecipeNumber=2\n", encoding="utf-8")

    result = FinalResult(
        mode="single", ref_machine="1호기", val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=ref, val_path=val, score=0.9)],
        unmatched_refs=[MissEntry(slot="S1", side="ref", path=miss, note="미매칭")],
    )
    dst = tmp_path / "out.xlsx"
    no_tpl = tmp_path / "no_template.xlsx"
    ExcelExporter(result, dst_path=dst, template_path=no_tpl).run()

    from aoi_verification.app import i18n
    from openpyxl import load_workbook
    # 미매칭 사진 시트에는 미매칭 행만 — z_miss 가 첫 데이터 행(row3).
    ws = load_workbook(str(dst), rich_text=True)[i18n.KO.SHEET_UNMATCHED]
    d3 = str(ws["D3"].value)
    assert "z_miss.jpeg" in d3
    assert "area" in d3 and "contrast" in d3
    assert "zone" in d3 and "recipe" in d3
    # zone/recipe 는 이름만 표기(코드 숫자 없이).
    assert "recipe PI / zone PI_Opening" in d3
    assert "recipe 2" not in d3 and "zone 1" not in d3
    # 매칭단계 메커니즘으로 col/row/x/y 도 함께 표기(Col=3,Row=5 → col1/row2).
    assert "col 1 / row 2" in d3
    assert "x " in d3 and "y " in d3
    # contrast 108 (비0) → 값이 그대로, '—' 아님.
    assert "108" in d3 and "contrast —" not in d3
    # 표기 순서: recipe/zone → area → width → length → contrast → col/row → x/y.
    order = ["recipe", "\narea", "\nwidth", "\nlength", "contrast",
             "\ncol ", "\nx "]
    idx = [d3.index(tok) for tok in order]
    assert idx == sorted(idx), f"표기 순서 어긋남: {idx}"
    # px 줄은 더 이상 표기하지 않는다.
    assert "px " not in d3 and "㎛/px" not in d3


def test_unmatched_geometry_contrast_zero_dash(qapp, isolated_cache, tmp_path,
                                               monkeypatch):
    """contrast=0(대부분 자재) → 'contrast —' 로 표기(0.00 아님)."""
    _install_flt_schema(monkeypatch)
    src = tmp_path / "src"
    src.mkdir()
    ref = _make_image(src, "a_ref.jpeg")
    val = _make_image(src, "a_val.jpeg")
    miss = _make_image(src, "z_miss.jpeg")
    _write_flt_record(src, 112743.1, 226527.0, 55.0, 2.0, 11.0, 0.0, zone=63)
    (src / "ColorImageGrabingInfo.ini").write_text(
        "[z_miss.jpeg]\nX=112743.1\nY=226527.0\nCol=3\nRow=5\n",
        encoding="utf-8")
    result = FinalResult(
        mode="single", ref_machine="1호기", val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=ref, val_path=val, score=0.9)],
        unmatched_refs=[MissEntry(slot="S1", side="ref", path=miss, note="미매칭")],
    )
    dst = tmp_path / "out.xlsx"
    ExcelExporter(result, dst_path=dst,
                  template_path=tmp_path / "no_template.xlsx").run()
    from aoi_verification.app import i18n
    from openpyxl import load_workbook
    d3 = str(load_workbook(str(dst), rich_text=True)[i18n.KO.SHEET_UNMATCHED]["D3"].value)
    assert "contrast —" in d3 and "contrast 0.00" not in d3


def test_unmatched_no_flt_marker(qapp, isolated_cache, tmp_path, monkeypatch):
    """스키마는 켜졌지만 Surface.flt 가 없으면 '미지원 자재' 마커가 붙는다."""
    from aoi_verification.app import i18n
    _install_flt_schema(monkeypatch)
    src = tmp_path / "src"
    src.mkdir()
    ref = _make_image(src, "a_ref.jpeg")
    val = _make_image(src, "a_val.jpeg")
    miss = _make_image(src, "z_miss.jpeg")  # Surface.flt 없음

    result = FinalResult(
        mode="single", ref_machine="1호기", val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=ref, val_path=val, score=0.9)],
        unmatched_refs=[MissEntry(slot="S1", side="ref", path=miss, note="미매칭")],
    )
    dst = tmp_path / "out.xlsx"
    no_tpl = tmp_path / "no_template.xlsx"
    ExcelExporter(result, dst_path=dst, template_path=no_tpl).run()

    from openpyxl import load_workbook
    ws = load_workbook(str(dst), rich_text=True)[i18n.KO.SHEET_UNMATCHED]
    d3 = str(ws["D3"].value)
    assert "z_miss.jpeg" in d3
    assert i18n.KO.GEOM_NOT_SUPPORTED in d3


def test_unmatched_coords_without_flt(qapp, isolated_cache, tmp_path, monkeypatch):
    """Surface.flt 가 없어도(미지원 자재) col/row/x/y 는 매칭단계 메커니즘으로 표기."""
    from aoi_verification.app import i18n
    _install_flt_schema(monkeypatch)
    src = tmp_path / "src"
    src.mkdir()
    ref = _make_image(src, "a_ref.jpeg")
    val = _make_image(src, "a_val.jpeg")
    miss = _make_image(src, "z_miss.jpeg")  # Surface.flt 없음 → 미지원 자재
    # INI 는 있으니 좌표는 나온다(Col=4,Row=4 → col2/row3).
    (src / "ColorImageGrabingInfo.ini").write_text(
        "[z_miss.jpeg]\nX=150000\nY=220000\nCol=4\nRow=4\n", encoding="utf-8")

    result = FinalResult(
        mode="single", ref_machine="1호기", val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=ref, val_path=val, score=0.9)],
        unmatched_refs=[MissEntry(slot="S1", side="ref", path=miss, note="미매칭")],
    )
    dst = tmp_path / "out.xlsx"
    ExcelExporter(result, dst_path=dst,
                  template_path=tmp_path / "no_template.xlsx").run()

    from openpyxl import load_workbook
    ws = load_workbook(str(dst), rich_text=True)[i18n.KO.SHEET_UNMATCHED]
    d3 = str(ws["D3"].value)
    assert "z_miss.jpeg" in d3
    # Surface.flt 없음 마커 + 좌표가 함께.
    assert i18n.KO.GEOM_NOT_SUPPORTED in d3
    assert "col 2 / row 3" in d3
    assert "x " in d3 and "y " in d3


def test_matched_rows_carry_the_same_info_as_unmatched(qapp, isolated_cache,
                                                       tmp_path, monkeypatch):
    """★ 매치 행의 두 사진 칸에도 미매칭 행과 **같은 정보**가 셀 값으로 들어간다.

    "엑셀 양식에 매칭된 사진들도 사진 뒤에 미매칭 된것들처럼 적는 정보들 모두 적어줘"
    — 그리고 "정보들이 사진에 가려지도록 … 평소에는 가려져 있다가 필요할 때 사진을
    치워버리고 해당 정보를 보고자 합니다."  그래서 사진은 예전처럼 셀을 덮고 행 높이는
    양식 그대로이며, 값은 사진마다 그 사진의 것이다(기준·검증 장비가 각자 잰 값)."""
    from aoi_verification.app.coords import single_info
    from aoi_verification.app.workers import exporter as ex
    from openpyxl import load_workbook

    _install_flt_schema(monkeypatch)
    ref_dir, val_dir = tmp_path / "ref", tmp_path / "val"
    ref_dir.mkdir(); val_dir.mkdir()
    ref = _make_image(ref_dir, "a_ref.jpeg")
    val = _make_image(val_dir, "a_val.jpeg")
    _write_flt_record(ref_dir, 112743.1, 226527.0, 55.0, 2.0, 11.0, 108.0,
                      zone=1, recipe=2)
    (ref_dir / "ColorImageGrabingInfo.ini").write_text(
        "[a_ref.jpeg]\nX=112743.1\nY=226527.0\nCol=3\nRow=5\n", encoding="utf-8")
    _write_flt_record(val_dir, 150000.0, 220000.0, 77.0, 3.0, 13.0, 0.0,
                      zone=1, recipe=2)
    (val_dir / "ColorImageGrabingInfo.ini").write_text(
        "[a_val.jpeg]\nX=150000\nY=220000\nCol=4\nRow=4\n", encoding="utf-8")

    result = FinalResult(
        mode="single", ref_machine="1호기", val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=ref, val_path=val, score=0.9)],
    )
    dst = tmp_path / "out.xlsx"
    ExcelExporter(result, dst_path=dst,
                  template_path=tmp_path / "no_template.xlsx").run()
    ws = load_workbook(str(dst), rich_text=True)["out"]

    c3, d3 = str(ws["C3"].value), str(ws["D3"].value)
    for cell_text, path in ((c3, ref), (d3, val)):
        assert path.name in cell_text
        for line in single_info.defect_lines(path):
            assert line in cell_text, f"{path.name} 캡션에 {line!r} 가 없다"
    assert "col 1 / row 2" in c3 and "col 2 / row 3" in d3, "좌표가 사진별이 아니다"
    area_ref = next(l for l in single_info.defect_lines(ref) if l.startswith("area"))
    area_val = next(l for l in single_info.defect_lines(val) if l.startswith("area"))
    assert area_ref != area_val, "표본이 계측을 구분하지 못한다"
    assert area_ref in c3 and area_val in d3, "계측이 사진별이 아니다"
    assert area_val not in c3 and area_ref not in d3, "두 사진의 계측이 뒤섞였다"
    # 미매칭 칸과 같은 서식 — 사진을 치우면 같은 모양으로 드러난다.
    assert float(ws["C3"].value[0].font.sz) == 8.0
    assert ws["C3"].alignment.horizontal == "center"
    # ★ 사진은 그대로 셀을 덮고, 행 높이도 양식 그대로다 — 정보는 평소에 **가려진다**.
    assert len(ws._images) == 2
    assert ws.row_dimensions[3].height == ex.ROW_HEIGHT_PT, \
        "행이 커졌다 — 캡션이 사진 밖으로 드러난다(사용자는 가려지길 원했다)"
    anchor = ws._images[0].anchor._from
    assert (anchor.col, anchor.row) == (2, 2), "사진이 C3 칸을 덮지 않는다"


def test_unmatched_row_is_unchanged(qapp, isolated_cache, tmp_path):
    """미매칭 행은 예전 그대로다(D열 텍스트, 기준 사진 칸은 사진만)."""
    from aoi_verification.app.workers import exporter as ex
    from openpyxl import load_workbook

    src = tmp_path / "src"
    src.mkdir()
    ref = _make_image(src, "a_ref.jpeg")
    val = _make_image(src, "a_val.jpeg")
    miss = _make_image(src, "z_miss.jpeg")
    result = FinalResult(
        mode="single", ref_machine="1호기", val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=ref, val_path=val, score=0.9)],
        unmatched_refs=[MissEntry(slot="S1", side="ref", path=miss, note="미매칭")],
    )
    dst = tmp_path / "out.xlsx"
    ExcelExporter(result, dst_path=dst,
                  template_path=tmp_path / "no_template.xlsx").run()
    ws = load_workbook(str(dst))["out"]
    assert ws.row_dimensions[3].height == ex.ROW_HEIGHT_PT
    assert ws.row_dimensions[4].height == ex.ROW_HEIGHT_PT
    assert ws["C4"].value is None, "미매칭 행의 기준 사진 칸에 캡션이 생겼다"


def _embedded_media_sizes(xlsx_path: Path) -> list:
    """저장된 xlsx 안 xl/media/* 이미지들의 (w,h) 픽셀 크기 목록."""
    import io as _io
    import zipfile as _zip
    from PIL import Image as _Image
    sizes = []
    with _zip.ZipFile(str(xlsx_path)) as z:
        for name in z.namelist():
            if name.startswith("xl/media/"):
                with _Image.open(_io.BytesIO(z.read(name))) as im:
                    sizes.append(im.size)
    return sizes


def test_export_original_quality_embeds_full_resolution(qapp, isolated_cache,
                                                        tmp_path):
    """원본 화질 옵션: 저장된 미디어가 원본 해상도(축소 안 됨)여야 한다(#원본화질)."""
    src = tmp_path / "src"
    src.mkdir()
    # MID_PX(800)보다 큰 원본 — 중간 캐시는 800px 로 줄지만 원본은 그대로.
    big = src / "big_ref.jpeg"
    Image.new("RGB", (1600, 1200), color=(50, 90, 160)).save(str(big), "JPEG")
    val = src / "big_val.jpeg"
    Image.new("RGB", (1600, 1200), color=(60, 100, 170)).save(str(val), "JPEG")

    result = FinalResult(
        mode="single", ref_machine="1호기", val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=big, val_path=val, score=0.9)],
    )
    no_tpl = tmp_path / "no_template.xlsx"

    # 기본(off) — 중간 화질 캐시(800px 로 다운스케일) 가 임베드된다.
    dst_mid = tmp_path / "mid.xlsx"
    ExcelExporter(result, dst_path=dst_mid, template_path=no_tpl).run()
    mid_sizes = _embedded_media_sizes(dst_mid)
    assert mid_sizes, "이미지가 임베드되어야 한다"
    assert all(max(w, h) <= 800 for (w, h) in mid_sizes), (
        f"기본은 중간 화질(≤800px)이어야: {mid_sizes}")

    # 옵션 on — 원본(1600px) 그대로 임베드된다.
    dst_orig = tmp_path / "orig.xlsx"
    ExcelExporter(result, dst_path=dst_orig, template_path=no_tpl,
                  original_quality=True).run()
    orig_sizes = _embedded_media_sizes(dst_orig)
    assert orig_sizes, "이미지가 임베드되어야 한다"
    assert any(max(w, h) == 1600 for (w, h) in orig_sizes), (
        f"원본 화질은 원본 해상도(1600px)여야: {orig_sizes}")


def test_unmatched_original_quality_embeds_only_unmatched_full_res(
        qapp, isolated_cache, tmp_path):
    """'미매칭 사진만 원본 화질' 옵션: 미매칭만 원본, 매칭 사진은 중간 화질 유지.

    소스 해상도를 다르게 두어(매칭 1600 · 미매칭 1400) 저장된 미디어에서
    어느 쪽이 원본으로 들어갔는지 구분한다 — 둘 다 MID_PX(800)보다 크다.
    """
    src = tmp_path / "src"
    src.mkdir()
    ref = src / "m_ref.jpeg"
    Image.new("RGB", (1600, 1200), color=(50, 90, 160)).save(str(ref), "JPEG")
    val = src / "m_val.jpeg"
    Image.new("RGB", (1600, 1200), color=(60, 100, 170)).save(str(val), "JPEG")
    miss = src / "u_miss.jpeg"
    Image.new("RGB", (1400, 1050), color=(160, 60, 60)).save(str(miss), "JPEG")

    result = FinalResult(
        mode="single", ref_machine="1호기", val_machine="2호기",
        matches=[MatchResult(slot="S1", ref_path=ref, val_path=val, score=0.9)],
        unmatched_refs=[MissEntry(slot="S1", side="ref", path=miss,
                                  note="미매칭")],
    )
    no_tpl = tmp_path / "no_template.xlsx"
    dst = tmp_path / "out.xlsx"
    ExcelExporter(result, dst_path=dst, template_path=no_tpl,
                  unmatched_original_quality=True).run()
    sizes = _embedded_media_sizes(dst)
    assert sizes, "이미지가 임베드되어야 한다"
    # 미매칭은 원본 그대로(1400px) — 미매칭 시트·요약 시트 양쪽에 들어간다.
    assert any(max(w, h) == 1400 for (w, h) in sizes), (
        f"미매칭 사진이 원본 해상도(1400px)여야: {sizes}")
    # 매칭 사진은 여전히 중간 화질(≤800px) — 원본(1600px)이 나오면 안 된다.
    assert all(max(w, h) <= 800 for (w, h) in sizes
               if max(w, h) != 1400), (
        f"매칭 사진은 중간 화질(≤800px)이어야: {sizes}")


def test_machine_label_rule():
    """호기 라벨 규칙: 숫자/N호기 → AOI-N, 그 외 문자 포함 → AOI(원본)."""
    from aoi_verification.app.workers.exporter import _machine_label
    # 순수 숫자 / N호기 → AOI-N
    assert _machine_label("2") == "AOI-2"
    assert _machine_label("2호기") == "AOI-2"
    assert _machine_label("1호기") == "AOI-1"
    assert _machine_label(" 7 호기 ") == "AOI-7"
    assert _machine_label("10") == "AOI-10"
    # 다른 문자 포함 → AOI(원본값)
    assert _machine_label("K-2") == "AOI(K-2)"
    assert _machine_label("K-6") == "AOI(K-6)"
    assert _machine_label("AOI-3") == "AOI(AOI-3)"
    # 빈 입력 → ""
    assert _machine_label("") == ""
    assert _machine_label("   ") == ""
    assert _machine_label(None) == ""
