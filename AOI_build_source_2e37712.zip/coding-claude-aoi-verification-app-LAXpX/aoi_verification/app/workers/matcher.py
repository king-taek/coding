"""기준 사진 1장 vs 같은 슬롯의 검증 후보 N장 — 유사도 정렬 워커.

``val_features`` 가 주어지면 디스크에서 ``Feature`` 를 다시 읽지 않고 사용한다
(slot_features.SlotFeatureCache 와 함께 쓰면 같은 슬롯의 reference 들끼리
val side 특징을 공유해 큰 폭으로 속도가 빨라진다).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping, Optional

from PyQt6.QtCore import QObject, QThread, pyqtSignal

from ..config import CONFIG
from ..models.slot import ImageItem
from ..similarity import pipeline as sim


_LOG = logging.getLogger("aoi.match")


@dataclass
class Candidate:
    item: ImageItem
    score: float


class ClassicalResult(list):
    """``score_ref_classical`` 의 반환 — 평범한 ``list[Candidate]`` 이면서 채점에 **실패한**
    후보 경로를 ``failed`` 로 들고 있다(호출자가 실패 건수를 셀 수 있게).  기존 호출자는
    list 로만 쓰므로 호환된다."""

    def __init__(self, *args) -> None:
        super().__init__(*args)
        self.failed: list[Path] = []


def score_ref_classical(ref_item: ImageItem,
                        val_items: list[ImageItem],
                        *,
                        threshold: float,
                        cfg=None,
                        val_features: Optional[Mapping[Path, sim.Feature]] = None,
                        components: Optional[set] = None,
                        progress_cb=None,
                        stop_cb=None) -> list[Candidate]:
    """기준 1장 vs 후보 N장을 고전 파이프라인(pHash+ORB+SSIM)으로 채점.

    ``MatcherWorker`` 와 고효율 모드 CPU 유닛이 공유하는 순수 함수 (Qt 비의존).
    점수는 ``sim.score`` 가 이미 [0,1] 로 돌려준다.  ``val_features`` 가 주어지면
    재추출을 생략한다.  ``progress_cb(idx,total)`` / ``stop_cb()->bool`` 은 옵션.
    채점이 예외로 실패한 후보는 0점으로 둔갑시키지 않고 **제외**하며, 반환 리스트의
    ``failed`` 속성(경로 목록)에 남긴다.

    ``components`` (예: ``{"phash","ssim"}``) 가 주어지면 그 항만으로 채점한다 —
    비싼 ORB 를 빼서 CPU 재채점을 빠르게 하는 고속 변형용.  ORB 를 안 쓰면 특징
    추출에서도 ORB 검출을 생략(``need_orb=False``)해 추출 비용까지 줄인다."""
    need_orb = components is None or ("orb" in components)
    # 중앙-가중 ORB — cfg.orb_center_weight>0 이면 defect(중앙) 근접 매치에 가중(단일 패스).
    center_strength = (float(getattr(cfg, "orb_center_weight", 0.0) or 0.0)
                       if cfg is not None else 0.0)
    ref_feat = sim.extract(ref_item.path, cfg=cfg, side="ref", need_orb=need_orb)
    vfmap: dict[Path, sim.Feature] = dict(val_features or {})
    total = len(val_items)
    out = ClassicalResult()
    for idx, vi in enumerate(val_items, start=1):
        if stop_cb is not None and stop_cb():
            break
        try:
            vf = vfmap.get(vi.path)
            if vf is None:
                vf = sim.extract(vi.path, cfg=cfg, side="val", need_orb=need_orb)
                vfmap[vi.path] = vf
            s = sim.score(ref_feat, vf, components=components,
                          center_strength=center_strength)
        except Exception:
            # 예전엔 s=0.0 으로 바꿔 삼켰다 — threshold=0.0(좌표 폴백·고효율 재채점)이면
            # 그 후보가 **진짜 0% 후보**로 결과에 실렸다.  실패는 점수가 아니므로 후보에서
            # 빼고(경고로 남기고) ``failed`` 에 기록한다.
            _LOG.warning("고전 채점 실패 — 이 후보는 건너뜁니다: %s ↔ %s",
                         ref_item.path, vi.path, exc_info=True)
            out.failed.append(vi.path)
            if progress_cb is not None:
                progress_cb(idx, total)
            continue
        if s >= threshold:
            out.append(Candidate(item=vi, score=s))
        if progress_cb is not None:
            progress_cb(idx, total)
    out.sort(key=lambda c: c.score, reverse=True)
    if out.failed:
        _LOG.warning("고전 채점 실패 %d/%d건 (기준 %s)",
                     len(out.failed), total, ref_item.path)
    return out


class MatcherSignals(QObject):
    done = pyqtSignal(list)            # list[Candidate]
    progress = pyqtSignal(int, int)
    failed = pyqtSignal(str)


class MatcherWorker(QThread):
    """단일 기준 이미지에 대해 후보들의 score 를 계산해 정렬해 돌려준다.

    ``slot_cache`` 가 주어지면 워커 thread 가 해당 슬롯의 모든 val Feature 를
    한 번 빌드해 캐시에 저장한다. 같은 슬롯의 다음 reference 부터는 캐시
    히트로 디스크 재로드가 사라진다.
    """

    def __init__(self,
                 ref_item: ImageItem,
                 val_items: Iterable[ImageItem],
                 threshold: Optional[float] = None,
                 *,
                 val_features: Optional[Mapping[Path, sim.Feature]] = None,
                 slot_cache: Optional[object] = None,
                 cfg=None,
                 parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._ref = ref_item
        self._vals: list[ImageItem] = list(val_items)
        self._threshold = threshold if threshold is not None else CONFIG.default_threshold
        # 호출자가 미리 빌드한 val Feature 캐시 (Optional). 누락된 path 는 폴백으로 sim.extract.
        self._val_features: dict[Path, sim.Feature] = dict(val_features or {})
        self._slot_cache = slot_cache
        self._cfg = cfg                 # 강화/KLA 전처리 설정
        self.signals = MatcherSignals()
        self._stop = False

    def stop(self) -> None:
        self._stop = True

    def run(self) -> None:        # type: ignore[override]
        # 슬롯 캐시에 미적재면 워커 thread 에서 한 번 빌드 (GUI 미블록).
        if self._slot_cache is not None and not self._val_features:
            try:
                self._val_features = self._slot_cache.build(
                    self._ref.slot, self._vals, cfg=self._cfg,
                )
            except Exception:
                self._val_features = {}

        try:
            out = score_ref_classical(
                self._ref, self._vals,
                threshold=self._threshold, cfg=self._cfg,
                val_features=self._val_features,
                progress_cb=lambda idx, total: self.signals.progress.emit(idx, total),
                stop_cb=lambda: self._stop,
            )
        except Exception as exc:
            self.signals.failed.emit(str(exc))
            return
        self.signals.done.emit(out)
