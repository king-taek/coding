"""썸네일 + 중간 이미지 사전 생성 워커.

원본 폴더 스캔이 끝난 직후 호출되어 모든 이미지의 캐시를 미리 만든다.

설계: ``ThumbnailPool(QObject)`` — 다중 worker QThread 가 공유 heapq 에서 작업을
꺼내 처리하는 우선순위 풀.  사용자가 보고 있는 슬롯의 작업을 우선 처리해서
'첫 슬롯 준비되는 즉시 Stage 1 진입' 을 가능하게 한다.

※ 한때 ``ThumbnailWorker(QThread)`` 라는 단일 스레드 '호환용' 클래스가 함께 있었으나,
  그 호환 대상이던 호출자가 모두 풀로 옮겨 간 뒤로 **생성되는 곳이 0곳**이라 제거했다.
"""

from __future__ import annotations

import heapq
import os
import threading
from dataclasses import dataclass, field
from typing import Iterable, Optional

from PyQt6.QtCore import QObject, QThread, pyqtSignal

from .. import config
from ..models.slot import ImageItem
from ..utils import image_io


# ---------------------------------------------------------------------------
# Priority classes (lower = sooner)
# ---------------------------------------------------------------------------
PRIORITY_CENTER = 0           # 현재 활성 슬롯의 ‘결정 중인 사진’ 본인
PRIORITY_ACTIVE_SLOT = 1      # 현재 활성 슬롯의 다른 사진들
PRIORITY_NEXT_SLOT = 2        # 다음 슬롯 (look-ahead)
PRIORITY_BACKGROUND = 3       # 그 외 모든 백그라운드 채우기


class ThumbnailerSignals(QObject):
    progress = pyqtSignal(int, int, str)   # done, total, current path
    finished = pyqtSignal()
    failed = pyqtSignal(str)               # error message
    item_ready = pyqtSignal(object)        # ImageItem (캐시 완료)


# ---------------------------------------------------------------------------
# 우선순위 큐 + 멀티 워커 풀
# ---------------------------------------------------------------------------
@dataclass(order=True)
class _Job:
    """heapq 비교용 키: (priority, seq) 만 사용. 나머지는 비교에서 제외."""

    priority: int
    seq: int
    slot: str = field(compare=False)
    item: ImageItem = field(compare=False)
    also_mid: bool = field(compare=False, default=True)


class ThumbnailPool(QObject):
    """우선순위 큐 + 멀티 워커 스레드 풀.

    ``enqueue`` 로 작업을 적재하고 ``start`` 로 워커를 띄운다. 활성 슬롯이
    바뀔 때 ``reprioritize_slot(slot_name, PRIORITY_ACTIVE_SLOT)`` 으로
    재정렬해 사용자가 보는 슬롯의 작업을 먼저 끝낸다.
    """

    def __init__(self,
                 *,
                 tier: Optional[config.SizingTier] = None,
                 also_mid: bool = True,
                 num_workers: Optional[int] = None,
                 low_priority: bool = False,
                 parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.signals = ThumbnailerSignals()
        self._tier = tier
        self._also_mid = bool(also_mid)
        cpu = os.cpu_count() or 2
        self._num_workers = int(num_workers) if num_workers else max(2, cpu - 1)
        # 뒤에서 천천히 만드는 풀(교차검증 2차 대비 등) — OS 스레드 우선순위를 최저로
        # 두어 화면·매칭이 CPU 를 원하면 그쪽이 먼저 가게 한다.
        self._low_priority = bool(low_priority)

        self._heap: list[_Job] = []
        self._lock = threading.Lock()
        self._seq = 0
        self._stop = False
        self._workers: list[_PoolWorker] = []
        # 아직 일을 꺼낼 수 있는 워커 수 — 워커는 큐가 비면 끝나므로, 끝난 뒤 다시
        # ``enqueue`` 한 일을 놓치지 않도록 ``start`` 가 이 수만큼 모자란 워커를 새로
        # 띄운다.  '큐가 비었다 → 끝낸다' 판단과 같은 lock 아래서 줄여 경합이 없다.
        self._alive = 0
        self._total = 0
        self._done = 0
        # finished 시그널이 race condition 으로 두 번 emit / 한 번도 안 됨을 막기
        # 위한 단발 플래그.  _on_worker_progress 가 lock 아래서 set.
        self._finished_emitted = False

    # ------------------------------------------------------------------
    def enqueue(self, items: Iterable[ImageItem], *,
                priority: int = PRIORITY_BACKGROUND) -> None:
        added = 0
        with self._lock:
            for it in items:
                self._seq += 1
                heapq.heappush(self._heap, _Job(
                    priority=priority,
                    seq=self._seq,
                    slot=it.slot,
                    item=it,
                    also_mid=self._also_mid,
                ))
                added += 1
            self._total += added

    def reprioritize_slot(self, slot_name: str, new_priority: int) -> None:
        """해당 슬롯에 속한 대기 중 작업의 우선순위를 낮춰(앞으로) 재삽입."""
        with self._lock:
            kept: list[_Job] = []
            moved: list[_Job] = []
            for j in self._heap:
                if j.slot == slot_name and j.priority > new_priority:
                    self._seq += 1
                    moved.append(_Job(
                        priority=new_priority,
                        seq=self._seq,
                        slot=j.slot,
                        item=j.item,
                        also_mid=j.also_mid,
                    ))
                else:
                    kept.append(j)
            self._heap = kept + moved
            heapq.heapify(self._heap)

    def pending(self) -> int:
        with self._lock:
            return len(self._heap)

    def total(self) -> int:
        return self._total

    # ------------------------------------------------------------------
    def start(self) -> None:
        """워커를 띄운다 — 이미 끝난 워커가 있으면 그만큼 다시 띄운다(재시작 가능).

        좌표 매칭의 후보 썸네일처럼 일이 나중에 조금씩 들어오는 풀은
        ``enqueue`` → ``start`` 를 여러 번 부른다."""
        with self._lock:
            if self._stop:
                return
            need = self._num_workers - self._alive
            self._alive += max(0, need)
        # 끝난 워커는 놓아준다 — 후보 풀은 슬롯마다 다시 띄우므로 쌓이면 `wait` 가 길어진다.
        self._workers = [w for w in self._workers if not w.isFinished()]
        for _ in range(need):
            w = _PoolWorker(self)
            if self._low_priority:
                w.start(QThread.Priority.LowestPriority)
            else:
                w.start()
            self._workers.append(w)

    def is_done(self) -> bool:
        """적재한 일을 전부 끝냈는가(빈 풀이면 참)."""
        with self._lock:
            return self._done >= self._total

    def stop(self) -> None:
        self._stop = True

    def wait(self, msec: int = 0) -> None:
        """★ `msec` 는 **총액**이다 — 워커마다 주면 안 된다.

        예전엔 워커 수만큼 곱해져서, 12코어 PC 에서 `wait(1000)` 이 최대 11초가 됐다
        (느린 NAS 디코드에 워커들이 붙잡혀 있으면 실제로 그만큼 창이 안 닫혔다)."""
        import time
        deadline = time.monotonic() + max(0, int(msec)) / 1000.0
        for w in self._workers:
            remain = int(max(0.0, deadline - time.monotonic()) * 1000)
            w.wait(remain)

    # ------------------------------------------------------------------
    # 내부 사용 — 워커가 한 작업을 끝낼 때마다 호출
    # ------------------------------------------------------------------
    def _on_worker_progress(self, item: ImageItem, ok: bool, err: str) -> None:
        # 멀티 워커가 동시에 호출 — _done 증가와 ‘마지막 작업이냐’ 판단을 lock
        # 으로 묶지 않으면 race condition 으로 finished 가 한 번도 emit 되지
        # 않거나 두 번 emit 될 수 있다.
        with self._lock:
            self._done += 1
            done = self._done
            total = self._total
            is_finished = (done >= total and not self._finished_emitted)
            if is_finished:
                self._finished_emitted = True
        if not ok:
            self.signals.failed.emit(f"{item.path}: {err}")
        else:
            self.signals.item_ready.emit(item)
        self.signals.progress.emit(done, total, str(item.path))
        if is_finished:
            self.signals.finished.emit()


class _PoolWorker(QThread):
    """heap 에서 작업을 꺼내 처리하는 단일 워커 스레드."""

    def __init__(self, pool: ThumbnailPool) -> None:
        super().__init__()
        self._pool = pool

    def run(self) -> None:  # type: ignore[override]
        while True:
            with self._pool._lock:
                if self._pool._stop or not self._pool._heap:
                    self._pool._alive -= 1
                    return
                job = heapq.heappop(self._pool._heap)
            ok = True
            err = ""
            try:
                image_io.get_thumb_path(job.item.path, tier=self._pool._tier)
                if job.also_mid:
                    image_io.get_mid_path(job.item.path, tier=self._pool._tier)
            except Exception as exc:
                ok = False
                err = str(exc)
            self._pool._on_worker_progress(job.item, ok, err)
