"""고효율 모드 — GPU 임베딩 recall + CPU 고전 재채점의 **fusion-zscore** 매칭.

검증(2 웨이퍼·4회 벤치마크) 결과 채택된 결정 규칙:
  1) GPU(MobileNetV3, OpenVINO) 임베딩으로 슬롯 val 후보를 코사인 랭킹(recall).
  2) 상위 K(=40) 후보를 CPU 고전(pHash+ORB+SSIM, ``score_ref_classical``)으로 채점.
  3) ref별 **z-점수 융합** ``z(코사인)+z(고전)`` 으로 최종 순위(단일 신호 약점 보완).

GPU/OpenVINO 가 없으면 CPU 고전 단독으로 폴백한다(절대 크래시 없음).

결과는 ``results[(slot, ref_path)] = [(val_path, score), ...]`` (내림차순) 으로
저장되어 ``match_page`` 가 무수정 소비한다.
"""

from __future__ import annotations

import logging
import os
import queue
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PyQt6.QtCore import QObject, QThread, pyqtSignal

from ..learning import embedder_openvino as _ov
from ..models.slot import ImageItem
from ..similarity import embedding_index as _ann
from ..similarity import pipeline as _pipeline
from .matcher import score_ref_classical

_LOG = logging.getLogger("aoi.match")


def _rerank_workers() -> int:
    """CPU 재채점 병렬 워커 수 — 코어 수 기반.  유휴 코어를 줄이기 위해 상한을 32
    로(과거 12) 올린다(#3).  cv2 내부 스레드는 ``cv2.setNumThreads(1)`` 로 막혀 있어
    외부 풀과 과도구독되지 않는다."""
    return max(2, min(32, os.cpu_count() or 4))

# 고정 하이퍼파라미터(벤치마크에서 확정 — 데이터에 맞춰 튜닝하지 않음).
FUSION_TOPK = 40          # CPU 고전 재채점 최소 후보 수(실제론 후보의 절반 vs 40 중 큰 값)
GPU_BATCH = 16            # GPU 정적 배치(=batch=1 이면 처리량 폭락 → 멈춤)


def _cos_to_unit(cos: float) -> float:
    """코사인 유사도 [-1,1] → [0,1] (순서 보존)."""
    return max(0.0, min(1.0, (float(cos) + 1.0) / 2.0))


# ---------------------------------------------------------------------------
# fusion-zscore 순수 함수 (헤드리스 테스트 대상)
# ---------------------------------------------------------------------------
def _zscores(xs: List[float]) -> List[float]:
    """평균 0·표준편차 1 정규화.  길이<2 또는 std≈0 이면 전부 0(=신호 무시)."""
    n = len(xs)
    if n < 2:
        return [0.0] * n
    m = sum(xs) / n
    sd = (sum((x - m) ** 2 for x in xs) / n) ** 0.5
    if sd < 1e-9:
        return [0.0] * n
    return [(x - m) / sd for x in xs]


def zfuse(emb: List[float], cls: List[float]) -> List[float]:
    """z(임베딩 코사인) + z(고전 점수).  스케일이 다른 두 신호를 동등 융합."""
    ze, zc = _zscores(emb), _zscores(cls)
    return [a + b for a, b in zip(ze, zc)]


def map_score(fused: List[float]) -> List[float]:
    """ref별 융합 점수를 [0.80, 0.98] 밴드로 min-max 매핑(순위 보존 + 최상위가
    임계치 통과 — 현 임베딩 모드의 (cos+1)/2≈0.85~0.95 와 동일 성격)."""
    if not fused:
        return []
    lo, hi = min(fused), max(fused)
    span = hi - lo
    if span < 1e-9:
        return [0.98] * len(fused)
    return [0.80 + 0.18 * (f - lo) / span for f in fused]


DEFAULT_ACCEL_CONCURRENCY = 32


def accel_concurrency(cfg) -> int:
    """동시 추론 수(in-flight) 상한.  사용자 설정이 없으면 기본 32.  최소 1."""
    try:
        return max(1, int(getattr(cfg, "accel_concurrency", None)))
    except (TypeError, ValueError):
        return DEFAULT_ACCEL_CONCURRENCY


def dynamic_concurrency(n_items: int, batch: int, cap: int = DEFAULT_ACCEL_CONCURRENCY) -> int:
    """워크로드에 맞춰 동시 in-flight 추론 수를 **자동 산정**(사용자 설정 없음).

    실제 필요한 추론 요청 수(≈ceil(n/batch))만큼만 띄우되 [8, cap(기본 32)] 로
    클램프 — 후보가 적으면 줄이고 많으면 상한까지.  추론 결과는 동시수와 무관."""
    if n_items <= 0:
        return min(cap, 8)
    reqs = -(-int(n_items) // max(1, int(batch)))     # ceil division
    return max(8, min(int(cap), reqs)) if cap >= 8 else max(1, min(int(cap), reqs))


def describe_active_units(cfg=None) -> str:
    """상태바용 라벨 — CPU + (가용이고 설정에서 켠) GPU."""
    from .. import i18n
    use_gpu = bool(getattr(cfg, "use_gpu", True))
    avail = [d for d in _ov.available_units() if d == "GPU" and use_gpu]
    units = ["CPU"] + avail
    return i18n.KO.ACCEL_UNITS_FMT.format(units="+".join(units))


def has_accel_units() -> bool:
    """효율 모드용 가속(GPU)이 있는지."""
    return "GPU" in _ov.available_units()


def warmup(cfg=None) -> bool:
    """고효율 모드가 쓸 백엔드(MobileNetV3, GPU, batch16)를 **미리 컴파일 + 더미
    추론 1회** 수행해, 첫 슬롯에서 한꺼번에 걸리던 GPU 커널 JIT 컴파일 지연을
    앱 시작 시점으로 옮긴다(#3).  가속 장치가 없으면 아무것도 안 하고 False.

    실패해도 조용히 무시(워밍업은 최적화일 뿐 정확성과 무관).  앱 시작 시
    백그라운드 스레드에서 호출하면 UI 를 막지 않는다."""
    backend = _select_backend(cfg)
    if backend is None:
        return False
    mk, dev, batch = backend
    try:
        import numpy as np
        pack = _ov.compile_model_on(mk, dev, batch)
        if pack is None:
            return False
        compiled, _name = pack
        _ov.mark_unit_active(dev)
        px = _ov._INPUT_PX
        dummy = [(("__warmup__",),
                  np.zeros((batch, 3, px, px), dtype=np.float32))]
        _ov._infer_raw(compiled, dummy, 1)
        return True
    except Exception:
        return False


def _select_backend(cfg):
    """효율 모드 임베딩 백엔드 선택 — **CPU+GPU만**.  GPU 가용·컴파일 OK 면
    (MobileNetV3, "GPU", batch=16), 아니면 None(=CPU 고전 단독 폴백)."""
    if bool(getattr(cfg, "use_gpu", True)) and "GPU" in _ov.available_units():
        if _ov.compile_model_on(_ov.MODEL_MOBILENET_V3, "GPU", GPU_BATCH) is not None:
            return (_ov.MODEL_MOBILENET_V3, "GPU", GPU_BATCH)
    return None


# ---------------------------------------------------------------------------
# 스케줄러 — 슬롯 순차 fusion 파이프라인 (SlotPrecomputeWorker 와 동일 시그널 계약)
# ---------------------------------------------------------------------------
class _SchedSignals(QObject):
    progress = pyqtSignal(int, int)            # done_pairs, total_pairs
    slot_finished = pyqtSignal(str, int, int)  # slot, done_slots(1-base), total_slots
    phase = pyqtSignal(str)
    finished = pyqtSignal()
    failed = pyqtSignal(str)


class EfficiencyScheduler(QThread):
    """슬롯 순차로 GPU 임베딩(recall) → CPU 고전 재채점 → z-융합 → ``results`` 저장."""

    def __init__(self,
                 tasks: List[Tuple[str, List[ImageItem], List[ImageItem]]],
                 *,
                 cfg=None,
                 threshold: float = 0.0,
                 auto: bool = False,
                 results: Optional[dict] = None,
                 parent: Optional[QObject] = None) -> None:
        super().__init__(parent)
        self._tasks = [(s, list(r), list(v)) for s, r, v in tasks]
        self._cfg = cfg
        self._threshold = float(threshold)
        self._auto = bool(auto)
        self._results = results if results is not None else {}
        self._stop = threading.Event()
        self.signals = _SchedSignals()

    def stop(self) -> None:
        self._stop.set()

    def run(self) -> None:        # type: ignore[override]
        try:
            self._run()
        except Exception as exc:                # pragma: no cover - 방어
            self.signals.failed.emit(str(exc))

    # -- fusion 한 ref 처리 -------------------------------------------------
    def _fuse_ref(self, ref, vals, built, ref_emb, by_path, vfmap=None) -> Optional[list]:
        """임베딩 성공 시 fusion 결과 [(val_path, score), …] 내림차순, 실패 시 None.

        ``vfmap`` (슬롯 val Feature 캐시) 가 주어지면 고전 재채점에서 재추출 생략."""
        if built is None:
            return None
        remb = ref_emb.get(Path(ref.path))
        if remb is None:
            return None
        index, val_paths = built
        hits = index.query(remb, len(val_paths))     # [(label, cos)] 내림차순
        ordered = [(val_paths[lab], float(cos)) for lab, cos in hits
                   if 0 <= lab < len(val_paths)]
        if not ordered:
            return None
        # CPU 재검증 범위 = 후보의 **최소 절반**, 단 최소 FUSION_TOPK(40) 이상.
        # (후보가 80장↑이면 절반, 80장 미만이면 40장(또는 후보 전부)을 재검증.)
        topk = max(FUSION_TOPK, (len(ordered) + 1) // 2)
        top = ordered[:topk]
        items = [by_path.get(Path(vp)) for vp, _ in top]
        valid = [it for it in items if it is not None]
        # 재채점 항 선택 — 고효율 모드는 rr_orb_center50(ORB 단독+중앙가중)을 위해
        # cfg.rerank_components={"orb"} 를 쓴다.  None 이면 전체(pHash+ORB+SSIM).
        comps = getattr(self._cfg, "rerank_components", None)
        comps = set(comps) if comps else None
        cls_cands = (score_ref_classical(ref, valid, threshold=0.0, cfg=self._cfg,
                                         val_features=vfmap, components=comps,
                                         stop_cb=self._stop.is_set)
                     if valid else [])
        cls_map = {c.item.path: float(c.score) for c in cls_cands}
        emb_scores = [cos for _, cos in top]
        cls_scores = []
        for vp, _ in top:
            it = by_path.get(Path(vp))
            cls_scores.append(cls_map.get(it.path, 0.0) if it is not None else 0.0)
        mapped = map_score(zfuse(emb_scores, cls_scores))
        head = sorted(zip([vp for vp, _ in top], mapped), key=lambda x: -x[1])
        tail = [(vp, _cos_to_unit(cos)) for vp, cos in ordered[topk:]]
        out = list(head) + tail
        out.sort(key=lambda x: -x[1])
        # 임베딩이 **없는** val(디코드 실패 등)은 인덱스에 들어가지 못해 위 점수 어디에도
        # 없다 — 예전엔 결과에서 조용히 사라졌다.  고전 점수만으로라도 채점해 덧붙인다
        # (점수 척도·융합식은 건드리지 않는다: 사진을 잃지 않는 것까지만).
        # 실패가 없으면 missing 이 비어 위 결과가 그대로다.
        embedded = {Path(p) for p in val_paths}
        missing = [v for v in vals if Path(v.path) not in embedded]
        if missing:
            extra = score_ref_classical(ref, missing, threshold=0.0, cfg=self._cfg,
                                        val_features=vfmap, components=comps,
                                        stop_cb=self._stop.is_set)
            _LOG.warning("임베딩 없는 후보 %d장은 고전 점수로만 채점 (기준 %s, 채점 실패 %d)",
                         len(missing), ref.path, len(extra.failed))
            out.extend((c.item.path, float(c.score)) for c in extra)
            out.sort(key=lambda x: -x[1])        # 안정 정렬 — 기존 항목끼리 순서 유지
        return out

    def _on_embed_image(self, n: int) -> None:
        """device_embed 가 사진 n장을 처리할 때마다 호출 — per-image 진행률(#3).

        슬롯 단위가 아니라 **사진 단위**로 카운트가 올라가, 느린 NAS 에서도 '후보
        생성' 진행률이 0 에 머물지 않는다."""
        with self._plock:
            self._embed_done += int(n)
        self._emit_progress()

    def _embed_slot(self, backend, refs, vals):
        """슬롯 val+ref 임베딩(GPU) → (built_index, ref_emb).  동시추론수는 자동 산정.

        device_embed 에 per-image 콜백을 전달해 사진이 임베딩되는 즉시 진행률을 올린다."""
        mk, dev, batch = backend
        cap = accel_concurrency(self._cfg)
        cb = self._on_embed_image
        val_emb = _ov.device_embed(
            [Path(v.path) for v in vals], model_kind=mk, device=dev, cfg=self._cfg,
            jobs=dynamic_concurrency(len(vals), batch, cap), batch=batch,
            progress_cb=cb)
        built = _ann.build_from(val_emb) if val_emb else None
        n_val_fail = len(vals) - len(val_emb or {})
        if n_val_fail > 0:
            _LOG.warning("슬롯 %s: 검증 임베딩 실패 %d/%d장 (전부 실패면 고전 점수로 폴백)",
                         vals[0].slot if vals else "?", n_val_fail, len(vals))
        ref_emb: Dict = {}
        if built is not None:
            ref_emb = _ov.device_embed(
                [Path(r.path) for r in refs], model_kind=mk, device=dev, cfg=self._cfg,
                jobs=dynamic_concurrency(len(refs), batch, cap), batch=batch,
                progress_cb=cb)
            n_ref_fail = len(refs) - len(ref_emb)
            if n_ref_fail > 0:
                _LOG.warning("슬롯 %s: 기준 임베딩 실패 %d/%d장 (해당 기준은 고전 점수로 폴백)",
                             refs[0].slot if refs else "?", n_ref_fail, len(refs))
        return built, ref_emb

    def _emit_progress(self) -> None:
        """현재 단계의 실제 처리 갯수를 emit — 재채점이 시작됐으면 유사도 계산
        갯수(쌍), 그 전이면 임베딩(후보 생성) 갯수(장).  LoadingOverlay 가 done/total
        갯수로 표시하고, phase 시그널이 단계 라벨을 바꾼다."""
        with self._plock:
            if self._scoring_started or self._total_embed <= 0:
                done, total = self._score_done, self._total_score
            else:
                done, total = self._embed_done, self._total_embed
        if total > 0:
            self.signals.progress.emit(int(done), int(total))

    def _slot_val_features(self, vals) -> dict:
        """슬롯 val 의 고전 Feature 를 **1회만** 병렬 추출(읽기 전용 캐시).  모든 ref
        가 공유 → ref마다 같은 val 을 재추출하던 중복 제거(결과 동일).

        CPU-단독 폴백(``_emit_feat``)에선 추출 진행률도 emit 해 '특징 분석' 단계에서
        진행 바가 0에 멈춘 것처럼 보이지 않게 한다(#2)."""
        def _ex(v):
            try:
                return v.path, _pipeline.extract(v.path, cfg=self._cfg, side="val")
            except Exception:
                _LOG.warning("특징 추출 실패 — 재추출 시도 후에도 실패하면 이 후보는 채점에서 빠집니다: %s",
                             v.path, exc_info=True)
                return v.path, None
        out: dict = {}
        futs = [self._pool.submit(_ex, v) for v in vals]
        for fut in as_completed(futs):
            path, feat = fut.result()
            if feat is not None:
                out[path] = feat
            if getattr(self, "_emit_feat", False):
                with self._plock:
                    self._feat_done += 1
                    fd, ft = self._feat_done, self._total_feat
                if ft > 0:
                    self.signals.progress.emit(int(fd), int(ft))
        return out

    def _rerank_one(self, r, vals, built, ref_emb, by_path, vfmap):
        """ref 1장 재채점(직렬 버전과 동일 결과) — 풀 워커에서 병렬 실행."""
        try:
            cands = self._fuse_ref(r, vals, built, ref_emb, by_path, vfmap)
        except Exception:
            _LOG.warning("융합 재채점 실패 — 고전 점수로 폴백: %s", r.path, exc_info=True)
            cands = None
        if cands is None:                            # 고전 폴백(임베딩 실패/미가용)
            cc = score_ref_classical(r, vals, threshold=self._threshold,
                                     cfg=self._cfg, val_features=vfmap,
                                     stop_cb=self._stop.is_set)
            cands = [(c.item.path, float(c.score)) for c in cc]
        return cands

    def _consume_slot(self, slot, refs, vals, built, ref_emb) -> None:
        """슬롯 val 특징 1회 캐시 + ref들을 멀티코어로 병렬 재채점(결과는 직렬과 동일)."""
        if not refs:
            self._finished_slots += 1
            self.signals.slot_finished.emit(slot, self._finished_slots, self._total_slots)
            return
        vfmap = self._slot_val_features(vals)        # ② 1회 병렬 추출(공유)
        by_path = {Path(v.path): v for v in vals}
        # ① ref별 재채점을 코어 수만큼 동시 실행 — 채점은 ref끼리 독립이라 결과 동일.
        futs = {self._pool.submit(self._rerank_one, r, vals, built, ref_emb, by_path,
                                  vfmap): r for r in refs}
        for fut in as_completed(futs):
            r = futs[fut]
            try:
                cands = fut.result()
            except Exception:
                _LOG.warning("재채점 실패 — 이 기준은 빈 결과: 슬롯 %s %s",
                             slot, r.path, exc_info=True)
                cands = []
            self._results[(slot, Path(r.path))] = cands
            with self._plock:
                self._score_done += len(vals)
                first = not self._scoring_started
                self._scoring_started = True
            if first:
                self._emit_feat = False            # 특징 분석 단계 종료 → 점수 진행률로
                self.signals.phase.emit(self._PHASE_SCORING)   # '유사도 계산' 라벨
            self._emit_progress()
            if self._stop.is_set():
                break
        self._finished_slots += 1
        self.signals.slot_finished.emit(slot, self._finished_slots, self._total_slots)

    def _run(self) -> None:
        from .. import i18n
        tasks = self._tasks
        self._total_score = sum(len(refs) * len(vals) for _, refs, vals in tasks)
        slot_order: List[str] = []
        for s, _r, _v in tasks:
            if s not in slot_order:
                slot_order.append(s)
        if self._total_score == 0:
            self.signals.finished.emit()
            return

        backend = _select_backend(self._cfg)         # (model_kind, device, batch) | None
        self._plock = threading.Lock()
        self._embed_done = 0
        self._score_done = 0
        self._scoring_started = False
        self._finished_slots = 0
        self._total_slots = len(slot_order)
        self._total_embed = (sum(len(refs) + len(vals) for _, refs, vals in tasks)
                             if backend is not None else 0)
        # CPU-단독 폴백에선 GPU 임베딩 진행률이 없으므로, val 특징 추출(특징 분석)
        # 단계의 진행률을 대신 표시한다(#2).  GPU 경로는 임베딩 진행률이 있어 불필요.
        self._total_feat = sum(len(vals) for _, _refs, vals in tasks)
        self._feat_done = 0
        self._emit_feat = backend is None
        self._PHASE_SCORING = i18n.KO.PHASE_SCORING
        # ① 재채점 멀티코어 풀 — val 특징 추출 + ref별 재채점을 병렬로(결과 동일).
        self._pool = ThreadPoolExecutor(max_workers=_rerank_workers())
        try:
            if backend is None:
                # GPU 미가용 — 겹칠 임베딩 작업이 없어 CPU 고전 단독(슬롯별 병렬 재채점).
                # '유사도 계산' 라벨을 미리 띄우지 말고, 먼저 '특징 분석' 으로 시작해
                # val 특징 추출 진행률을 보여준다(#2).  재채점 시작 시 SCORING 으로 전환.
                self.signals.phase.emit(i18n.KO.PHASE_FEATURE)
                for slot, refs, vals in tasks:
                    if self._stop.is_set():
                        break
                    self._consume_slot(slot, refs, vals, None, {})
            else:
                # GPU 임베딩(생산자 스레드) ∥ CPU 병렬 재채점(소비자) — 동시 가동.
                # 큐 maxsize=2 로 메모리 절제(최대 2개 슬롯 임베딩만 상주).
                self.signals.phase.emit(i18n.KO.PHASE_EMBED)   # '후보 생성(임베딩)' 먼저
                self._emit_progress()
                embed_q: "queue.Queue" = queue.Queue(maxsize=3)
                embed_seen = 0          # 지금까지 임베딩 대상이 된 사진 누계(예상치)

                # ★ 종료 신호는 **finally 에서** 넣는다.  예전엔 루프 정상 종료 뒤에만
                #   넣어서, `_embed_slot` **바깥**(진행 보고·락 구간·put)에서 예외가 나면
                #   생산자가 센티널 없이 죽었다.  그러면 아래 소비자가 타임아웃 없는
                #   `get()` 에 영원히 갇혀 `finished`·`failed` **어느 것도 안 나오고**
                #   차단 오버레이가 영구히 남았다(`stop()` 으로도 못 깬다).
                #   규칙: 생산자는 **어떤 경로로 끝나든** 센티널을 정확히 한 번 넣는다.
                def producer() -> None:
                    nonlocal embed_seen
                    try:
                        for slot, refs, vals in tasks:
                            if self._stop.is_set():
                                break
                            # per-image 콜백(_on_embed_image)이 임베딩 중 _embed_done 을
                            # 실시간으로 올린다.  여기선 슬롯 경계에서 누락분(디코드 실패
                            # 등 콜백이 안 온 사진)만 보정해 100% 도달을 보장한다.
                            try:
                                built, ref_emb = (self._embed_slot(backend, refs, vals)
                                                  if vals else (None, {}))
                            except Exception:
                                # 슬롯 임베딩이 통째로 실패해도 실행은 계속(고전 폴백)하되,
                                # 왜 느려졌는지 알 수 있게 남긴다.
                                _LOG.warning("슬롯 %s 임베딩 실패 — 고전 점수로 폴백",
                                             slot, exc_info=True)
                                built, ref_emb = None, {}
                            embed_seen += len(refs) + len(vals)
                            with self._plock:
                                if self._embed_done < embed_seen:
                                    self._embed_done = embed_seen
                                pre_scoring = not self._scoring_started
                            if pre_scoring:                # 재채점 전엔 임베딩 라벨 유지
                                self.signals.phase.emit(i18n.KO.PHASE_EMBED)
                            self._emit_progress()
                            # ★ 타임아웃 없는 put 은 중지 때 새는 자리다.  소비자가
                            #   먼저 빠져나가면(중지 버튼) 큐가 가득 찬 채로 이 스레드가
                            #   영원히 걸려 그 슬롯의 임베딩을 세션 끝까지 붙잡고 있었다.
                            #   센티널 put(아래)과 **같은 규칙**을 본문에도 적용한다.
                            while not self._stop.is_set():
                                try:
                                    embed_q.put((slot, refs, vals, built, ref_emb),
                                                timeout=0.2)
                                    break
                                except queue.Full:
                                    continue
                    finally:
                        # 종료 신호(예외 경로 포함).  큐가 가득 찬 채 소비자가 이미
                        # 떠났으면(중지) 무한 대기가 되므로 시간을 건다.
                        try:
                            embed_q.put(None, timeout=1.0)
                        except Exception:
                            pass

                pt = threading.Thread(target=producer, daemon=True)
                pt.start()
                while not self._stop.is_set():
                    # ★ 타임아웃을 둔다 — 무한 대기면 중지 버튼도 소비자를 못 깨운다.
                    try:
                        item = embed_q.get(timeout=0.2)
                    except queue.Empty:
                        if not pt.is_alive():
                            break          # 생산자가 죽었는데 센티널도 없다 → 탈출
                        continue
                    if item is None:
                        break
                    slot, refs, vals, built, ref_emb = item
                    self._consume_slot(slot, refs, vals, built, ref_emb)
                pt.join(timeout=1.0)
        finally:
            self._pool.shutdown(wait=not self._stop.is_set())
        self.signals.finished.emit()
