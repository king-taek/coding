"""Slot / ImageItem 데이터 클래스 및 폴더 스캔 헬퍼."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .. import config


@dataclass(frozen=True)
class ImageItem:
    """한 장의 원본 이미지."""
    slot: str
    path: Path
    side: str  # "ref" or "val"

    @property
    def filename(self) -> str:
        return self.path.name

    @property
    def key(self) -> str:
        return f"{self.side}::{self.slot}::{self.path.name}"


@dataclass
class Slot:
    """한 슬롯에 대응하는 기준/검증 이미지 목록.

    ``ref_dir``/``val_dir`` 는 원본 폴더 경로다 — **사진이 한 장도 없는 폴더**는 이미지
    경로에서 폴더를 역산할 수 없으므로, KLA 정보파일에서 WaferID 를 읽으려면 이 경로가 필요하다.
    """
    name: str
    ref_images: list[ImageItem] = field(default_factory=list)
    val_images: list[ImageItem] = field(default_factory=list)
    ref_dir: Path | None = None
    val_dir: Path | None = None

    @property
    def has_both(self) -> bool:
        return bool(self.ref_images) and bool(self.val_images)


@dataclass
class ScanResult:
    """루트 폴더 스캔 결과 + 한쪽에만 존재하는 Slot 목록."""
    slots: dict[str, Slot]
    ref_only: list[str]
    val_only: list[str]

    @property
    def common_slot_names(self) -> list[str]:
        return sorted(name for name, s in self.slots.items() if s.has_both)


# ---------------------------------------------------------------------------
# Scanning
# ---------------------------------------------------------------------------
# 결함 사진이 아닌 웨이퍼 전경(매크로) 카메라 사진 — 슬롯마다 1장씩 들어 있고
# ColorImageGrabingInfo.ini 에 항목이 없어 좌표를 만들 수 없다.
# 예: ``CognexInSight17xx_Bottom_OnPal_Station1_Slot21.jpg``
_NON_DEFECT_PREFIXES = ("cognexinsight",)


def is_ignored_name(name: str) -> bool:
    """무시 대상 파일명인가 (썸네일 생성·매칭·엑셀 등 모든 단계에서 처음부터 배제).

    둘을 거른다:

    · **결함 사진이 아닌 웨이퍼 전경 사진**(:data:`_NON_DEFECT_PREFIXES`) —
      좌표가 없어 매칭에 쓸 수 없다.
    · 이름에 점으로 구분된 ``t`` 토큰이 있는 사진(:func:`has_t_token`,
      예 ``-86955.68631.t.1.jpg``) — **항상 뺀다**(사용자 요청).

    ⚠ ``.t.`` 자리는 네 번 바뀌었다: '항상 뺀다' → '항상 넣는다'(`0b676d1`) →
    '세션마다 묻는다'(`79cc7f4`, 예시 사진을 보여 주는 팝업) → **'항상 뺀다'**(지금).
    묻는 팝업은 검증을 시작할 때마다 클릭을 하나 더 요구했고, 사용자가 '늘 뺀다' 로
    결정했다.  다시 바꾸려면 여기 한 곳만 고치면 된다 — 열거가 유일한 소스라
    썸네일·매칭·엑셀·슬롯별 장수(`count_images`)가 전부 따라온다.
    """
    return (name.lower().startswith(_NON_DEFECT_PREFIXES)
            or has_t_token(name))


def has_t_token(name: str) -> bool:
    """점으로 구분된 ``t`` 토큰을 가진 이름인가.

    예: ``-86955.68631.t.1.jpg`` → 확장자를 한 단계 뗀 stem ``-86955.68631.t.1`` 을
    ``.`` 으로 나눈 토큰 ``[-86955, 68631, t, 1]`` 에 정확히 ``t`` 가 있다.
    같은 자리에 ``c`` 가 오는 사진(실물 다수: ``272646.165679.c.1000203959.2.jpeg``)은
    해당하지 않는다.

    ⚠ **부분 문자열 검사가 아니다.**  ``t`` 하나짜리 토큰만 본다 — 이름 어딘가에
    ``t`` 가 들어 있다고 걸리면 멀쩡한 사진이 통째로 빠진다(``test.jpg`` 가 그렇다).

    :func:`is_ignored_name` 이 열거에서 쓴다 — 걸린 사진은 어느 단계에도 오지 않는다."""
    stem = name.rsplit(".", 1)[0]        # 확장자 한 단계 제거
    return "t" in stem.split(".")


def _list_images(folder: Path) -> list[Path]:
    """폴더 내 이미지 파일 목록.

    ``os.scandir`` 의 캐시된 ``DirEntry.is_file()`` 를 써서 파일당 별도
    ``stat()`` 시스템콜을 피한다 — 폴더에 수만 장이 있어도 빠르게 열거 (#3).

    웨이퍼 전경 사진과 ``.t.`` 사진은 ``is_ignored_name`` 으로 처음부터 건너뛴다 —
    열거가 유일한 소스라 썸네일도 만들어지지 않는다.
    """
    if not folder.exists() or not folder.is_dir():
        return []
    out: list[Path] = []
    try:
        with os.scandir(folder) as it:
            for entry in it:
                try:
                    if (entry.is_file()
                            and config.CONFIG.is_image(entry.name)
                            and not is_ignored_name(entry.name)):
                        out.append(Path(entry.path))
                except OSError:
                    continue
    except OSError:
        return []
    out.sort(key=lambda p: p.name.lower())
    return out


def count_images(folder: Path) -> int:
    """폴더의 결함 사진 수 — **앱이 실제로 처리하는 수와 같다.**

    슬롯 선택 팝업이 'slot별로 몇 장인지' 를 보여주는 데 쓴다(사용자 요청).
    :func:`_list_images` 를 그대로 쓰므로 웨이퍼 전경 사진(:data:`_NON_DEFECT_PREFIXES`)
    은 빠진다 — 화면의 숫자와 검증이 실제로 도는 장수가 어긋나면 안 된다.

    ⚠ 이 함수는 폴더를 통째로 열거한다.  NAS 에서는 왕복이므로 **UI 스레드에서
    부르지 마라**(호출부는 워커에서 부른다: `widgets/slot_select_dialog._SlotCountScan`).
    """
    return len(_list_images(Path(folder)))


def list_slot_dirs(root: Path) -> dict[str, Path]:
    """root/*/ 들 중 폴더만 골라 슬롯명 → 경로 매핑 (공개 래퍼).

    Setup 단계의 '일부 슬롯만 진행' 옵션이 폴더를 스캔하기 위해 사용한다.
    """
    return _enum_slot_dirs(Path(root))


def _enum_slot_dirs(root: Path) -> dict[str, Path]:
    """root/*/ 들 중 폴더만 골라 슬롯명 → 경로 매핑."""
    if not root.exists():
        return {}
    out: dict[str, Path] = {}
    try:
        with os.scandir(root) as it:
            for entry in it:
                try:
                    if entry.is_dir():
                        out[entry.name] = Path(entry.path)
                except OSError:
                    continue
    except OSError:
        return {}
    return out


def scan(ref_root: Path, val_root: Path, progress=None,
         only=None) -> ScanResult:
    """기준/검증 두 최상위 폴더를 스캔하여 Slot 매핑을 만든다.

    ``progress(done, total)`` 콜백이 주어지면 폴더(slot) 하나를 열거할 때마다 호출해,
    NAS 처럼 느린 원격에서 폴더가 많아도 진행 개수를 실시간 표시할 수 있다.

    ``only`` 에 슬롯명 집합을 주면 **그 폴더들만 연다**('일부 슬롯만 진행').
    최상위 두 폴더의 목록(왕복 2회)은 어차피 봐야 하지만, 사진 열거는 슬롯마다
    왕복이라 — 예전에는 전부 훑고 나서 결과를 줄였고, 25슬롯 중 3개만 고른 사용자도
    25개를 기다렸다.  결과의 ``slots``·``ref_only``·``val_only`` 는 전부 이 목록에서
    나오므로, 여기서 줄이면 다운스트림이 따로 거를 것이 없다.  ``None`` 이면 전체."""
    ref_dirs = _enum_slot_dirs(Path(ref_root))
    val_dirs = _enum_slot_dirs(Path(val_root))

    all_names = sorted(set(ref_dirs.keys()) | set(val_dirs.keys()))
    if only is not None:
        wanted = set(only) | _kla_partners(set(only), ref_dirs, val_dirs)
        all_names = [n for n in all_names if n in wanted]
    total = len(all_names)
    slots: dict[str, Slot] = {}
    ref_only: list[str] = []
    val_only: list[str] = []

    for idx, name in enumerate(all_names, start=1):
        ref_d = ref_dirs.get(name)
        val_d = val_dirs.get(name)
        ref_imgs: list[ImageItem] = []
        val_imgs: list[ImageItem] = []
        if ref_d:
            ref_imgs = [ImageItem(name, p, "ref") for p in _list_images(ref_d)]
        if val_d:
            val_imgs = [ImageItem(name, p, "val") for p in _list_images(val_d)]
        if ref_d and not val_d:
            ref_only.append(name)
        elif val_d and not ref_d:
            val_only.append(name)
        slots[name] = Slot(name=name, ref_images=ref_imgs, val_images=val_imgs,
                           ref_dir=ref_d, val_dir=val_d)
        if progress is not None:
            try:
                progress(idx, total)
            except Exception:
                pass

    return ScanResult(slots=slots, ref_only=ref_only, val_only=val_only)


def _kla_partners(wanted: set, ref_dirs: dict, val_dirs: dict) -> set:
    """'일부 슬롯만' 으로 고른 슬롯의 **상대 장비 폴더**를 WaferID 로 찾는다.

    KLA 폴더명은 검사 시각(``2026-08-02-23-09_4``)이고 상대 장비 폴더명은 WaferID 라,
    이름으로만 거르면 고른 웨이퍼의 짝 폴더가 스캔에서 빠진다 — 그러면 KLA 해석이
    짝을 찾을 수 없어 '기준/검증 전용' 이 되고 매칭이 통째로 사라졌다.

    이름으로 짝이 다 맞으면(일반 Camtek↔Camtek) **아무것도 읽지 않는다**.  짝이 없는
    슬롯이 있을 때만 고른 폴더의 WaferID 와, 반대쪽 폴더들의 WaferID(정보파일 헤더)를
    읽어 같은 웨이퍼를 더한다(스캔 워커 안에서 돈다).  반환은 더할 폴더명들이다."""
    from ..coords import kla_info

    def norm(v) -> str:
        return str(v).strip().upper()

    lonely = [n for n in wanted
              if (n in ref_dirs) != (n in val_dirs)]
    if not lonely:
        return set()
    keys = {norm(n) for n in lonely}
    for n in lonely:
        d = ref_dirs.get(n) or val_dirs.get(n)
        wid = kla_info.read_wafer_id(d) if d is not None else None
        if wid:
            keys.add(norm(wid))
    extra: set = set()
    others = {id(d): d for d in (val_dirs if n in ref_dirs else ref_dirs
                                 for n in lonely)}
    for other in others.values():
        for name, d in other.items():
            if name in wanted or name in extra:
                continue
            if norm(name) in keys:
                extra.add(name)
                continue
            wid = kla_info.read_wafer_id(d)
            if wid and norm(wid) in keys:
                extra.add(name)
    return extra


def scan_one_side(root: Path, progress=None, only=None) -> ScanResult:
    """Defect 추출용 — **한쪽 폴더만** 훑는다.  사진은 전부 ``ref_images`` 에 담긴다.

    폴더 종류는 자동으로 가린다:

    · 폴더 **바로 안에 결함 사진이 있으면** wafer 폴더 하나 → 슬롯 1개(이름 = 폴더명).
      단 사진·``.001`` 을 가진 하위 폴더가 2개 이상이면 LOT 폴더다(:func:`_looks_like_lot`).
      이때 ``only`` 는 무시한다 — 하위 폴더(`_recipe_files…` 등)는 슬롯이 아니다.
    · 아니면 LOT 폴더 → 하위 폴더 하나가 슬롯 하나(:func:`scan` 과 같은 규칙).

    ⚠ 판정 기준을 '하위 폴더가 있는가' 로 바꾸지 마라.  Camtek wafer 폴더에는
    `_recipe_files_…`·`_wafer2table_…` 같은 하위 폴더가 함께 있다(docs 좌표 예시).
    ``ref_only``/``val_only`` 는 비워 둔다 — 짝지을 상대가 없다."""
    return _scan_dirs(_one_side_dirs(Path(root), only), progress)


def _has_slot_content(folder: Path) -> bool:
    """하위 폴더가 슬롯다운가 — 결함 사진 또는 KLA 정보파일(``.001``)이 바로 안에 있다."""
    try:
        with os.scandir(folder) as it:
            for e in it:
                if e.name.lower().endswith(".001"):
                    return True
                if (config.CONFIG.is_image(e.name) and not is_ignored_name(e.name)
                        and e.is_file()):
                    return True
    except OSError:
        return False
    return False


def _looks_like_lot(dirs: dict[str, Path]) -> bool:
    """바로 안에 사진이 있는 폴더가 그래도 LOT 폴더인가 — 슬롯다운 하위 폴더가 2개 이상이면 그렇다.

    KLA LOT 폴더 바로 안에 안내 사진(``REPORT.JPG`` 등)이 있으면 하위 폴더 25개가 통째로
    무시되고 슬롯이 1개로 나왔다(실측 2026-11-02).  Camtek wafer 폴더의 ``_recipe_files…``
    는 사진도 ``.001`` 도 없어 여기 걸리지 않는다.  2개째를 찾으면 바로 멈춘다(NAS 왕복)."""
    found = 0
    for d in dirs.values():
        if _has_slot_content(d):
            found += 1
            if found >= 2:
                return True
    return False


def _one_side_dirs(root: Path, only=None) -> dict[str, Path]:
    """{슬롯명 → 폴더} — wafer 폴더면 자기 자신 하나, LOT 폴더면 하위 폴더들."""
    dirs = _enum_slot_dirs(root)
    if _list_images(root) and not _looks_like_lot(dirs):
        return {root.name: root}
    if only is not None:
        wanted = set(only)
        dirs = {n: d for n, d in dirs.items() if n in wanted}
    return dirs


def extract_slot_dirs(root) -> dict[str, Path]:
    """Defect 추출에서 그 폴더의 슬롯들 — 스캔과 **같은 규칙**(wafer 폴더면 자기 하나).

    설정 화면의 LOT 별 [슬롯 선택] 이 쓴다(그래야 고를 수 있는 슬롯과 실제로 훑는
    슬롯이 같다).  폴더를 여는 일이라 NAS 에서는 왕복이 있다."""
    return _one_side_dirs(Path(root))


def _scan_dirs(dirs: dict[str, Path], progress=None) -> ScanResult:
    names = sorted(dirs)
    slots: dict[str, Slot] = {}
    for idx, name in enumerate(names, start=1):
        d = dirs[name]
        slots[name] = Slot(name=name,
                           ref_images=[ImageItem(name, p, "ref")
                                       for p in _list_images(d)],
                           ref_dir=d)
        if progress is not None:
            try:
                progress(idx, len(names))
            except Exception:
                pass
    return ScanResult(slots=slots, ref_only=[], val_only=[])


# 여러 LOT 를 한 번에 추출할 때 slot명 앞에 붙는 LOT 이름의 구분자.
# ★ '/' 는 폴더명·WaferID 에 올 수 없는 글자라 구분이 모호해지지 않는다.
LOT_SEP = "/"


def lot_of(slot_name: str) -> str:
    """``"LOT/slot"`` → ``"LOT"``.  LOT 가 하나뿐이라 접두가 없으면 ``""``."""
    return slot_name.split(LOT_SEP, 1)[0] if LOT_SEP in slot_name else ""


def slot_label(slot_name: str) -> str:
    """``"LOT/slot"`` → ``"slot"`` (엑셀 B열 표기 — LOT 는 시트 이름이 말한다)."""
    return slot_name.split(LOT_SEP, 1)[1] if LOT_SEP in slot_name else slot_name


def scan_lots(roots, progress=None, only=None) -> ScanResult:
    """Defect 추출 — 폴더 **여러 개**(LOT·wafer 섞여도 된다)를 한 번에 훑는다.

    하나면 :func:`scan_one_side` 그대로(slot명 접두 없음 — 예전과 같다).  둘 이상이면
    slot명을 ``"LOT/slot"`` 으로 만든다 — 서로 다른 LOT 에 같은 이름의 슬롯이 흔해서
    접두 없이는 사진이 섞인다.  LOT 이름은 폴더명이고, 같은 이름의 폴더가 둘이면
    ``이름 (2)`` 로 가른다.

    ``only`` 는 LOT 별 '일부 슬롯' — ``roots`` 와 같은 순서의 목록(각 원소는 슬롯명
    집합, ``None`` = 전체).  LOT 하나에는 집합 하나를 그대로 줘도 된다."""
    roots = [Path(r) for r in roots]
    if only is None or isinstance(only, (set, frozenset)):
        only = [only] + [None] * (len(roots) - 1)
    if len(roots) == 1:
        return scan_one_side(roots[0], progress=progress, only=only[0])
    dirs: dict[str, Path] = {}
    used: set = set()
    for k, root in enumerate(roots):
        lot, n = root.name or str(root), 2
        while lot in used:
            lot = f"{root.name} ({n})"
            n += 1
        used.add(lot)
        for name, d in _one_side_dirs(root, only[k]).items():
            dirs[f"{lot}{LOT_SEP}{name}"] = d
    return _scan_dirs(dirs, progress)


def rename_slots_by_wafer_id(sr: ScanResult, wid_by_folder: dict) -> dict[str, str]:
    """KLA 폴더(슬롯)를 WaferID 이름으로 바꾼다 — Defect 추출용(짝이 없는 한쪽 스캔).

    ``wid_by_folder`` : {폴더(슬롯)명 → WaferID}.  반환은 {새 slot명 → KLA 폴더명}
    (엑셀 B열 회색 표기, :attr:`FinalResult.kla_folders`).

    slot명 표기는 매칭의 :func:`merge_unmatched_by_wafer_id` 와 같다(대문자 정규화).
    새 이름이 **다른 슬롯과 겹치면 바꾸지 않는다** — 겹친 채 바꾸면 한쪽 사진이
    덮여 웨이퍼가 조용히 사라진다(같은 함수의 충돌 규칙과 같은 이유).
    ``sr`` 를 직접 수정한다."""
    kla: dict[str, str] = {}
    for folder, wid in sorted((wid_by_folder or {}).items()):
        if not wid or folder not in sr.slots:
            continue
        # 여러 LOT 면 LOT 접두는 그대로 두고 slot 부분만 WaferID 로 바꾼다.
        lot = lot_of(folder)
        new = f"{lot}{LOT_SEP}{_norm_key(wid)}" if lot else _norm_key(wid)
        if new != folder and new in sr.slots:
            continue
        slot = sr.slots.pop(folder)
        slot.name = new
        slot.ref_images = [ImageItem(slot=new, path=it.path, side="ref")
                           for it in slot.ref_images]
        sr.slots[new] = slot
        kla[new] = slot_label(folder)
    return kla


def drop_empty_unmatched(sr: ScanResult) -> None:
    """한쪽 전용(ref_only/val_only) 중 **사진이 한 장도 없는 폴더**를 목록에서 제거.

    매칭할 사진 자체가 없으므로 OCR/수동 매핑 대상에서 그냥 제외한다(사용자 요청).
    ``ScanResult`` 를 직접 수정한다.
    """
    sr.ref_only = [n for n in sr.ref_only
                   if n in sr.slots and sr.slots[n].ref_images]
    sr.val_only = [n for n in sr.val_only
                   if n in sr.slots and sr.slots[n].val_images]


def push_one_sided_to_unmatched(sr: ScanResult) -> None:
    """사진이 **한쪽에만** 있는 슬롯을 ``ref_only``/``val_only`` 로 옮겨 결과에 남긴다.

    KLA 정보파일로 짝은 찾았지만 한쪽 폴더에 사진이 0장이면 ``has_both`` 가 False 라
    ``common_slot_names`` 에도, ``ref_only``/``val_only`` 에도 없어 **결과에서 통째로
    사라진다**.  이를 ‘기준 전용/검증 전용’ 으로 되돌려 (병합된) slot명으로 보고되게 한다.

    양쪽 다 사진이 없는 슬롯은 검증할 것이 없으므로 그대로 둔다.
    ``ScanResult`` 를 직접 수정한다.
    """
    known = set(sr.ref_only) | set(sr.val_only)
    for name, slot in sr.slots.items():
        if name in known or slot.has_both:
            continue
        if slot.ref_images:
            sr.ref_only.append(name)
        elif slot.val_images:
            sr.val_only.append(name)


def _norm_key(s) -> str:
    return str(s).strip().upper()


def kla_folder_slot_no(name: str) -> Optional[str]:
    """KLA 실행 폴더명(``2026-09-24-15-51_1``) 끝의 카세트 슬롯 번호.  없으면 None."""
    import re
    m = re.search(r"_(\d+)$", str(name))
    return str(int(m.group(1))) if m else None


def wafer_ids_from_broken_info(kla_dirs: dict, other_dirs: dict,
                               known: dict) -> tuple[dict, list]:
    """정보파일이 비어 WaferID 를 못 읽은 KLA 폴더를 **이름 + 슬롯 번호**로 짝짓는다.

    ``kla_dirs``/``other_dirs`` 는 {폴더명 → 경로}(짝 없는 쪽만), ``known`` 은 이미 헤더로
    읽은 {폴더명 → WaferID}.  두 근거가 **모두** 맞을 때만 채택한다(사용자 결정
    2026-10-25): ① 정보파일 이름의 WaferID 와 같은 이름의 상대(Camtek) 폴더가 있고,
    ② KLA 폴더명 끝 슬롯 번호 = 그 폴더 ``WaferInfo.ini`` 의 ``ActiveSlot``.
    반환 ``({KLA폴더명 → WaferID}, [(KLA폴더명, 이름의 WaferID 또는 None, 짝지었나)])`` —
    두 번째는 정보파일이 깨진 폴더 전부라 화면 경고에 쓴다.  깨진 ``.001`` 에는 결함
    좌표도 없다 — 짝을 지어도 그 슬롯은 좌표 매칭이 되지 않는다."""
    from ..coords import kla_info
    from .lot_info import read_active_slot
    others = {_norm_key(n): d for n, d in other_dirs.items()}
    ids: dict = {}
    broken: list = []
    for name, d in kla_dirs.items():
        if name in known or d is None:
            continue
        wid = kla_info.wafer_id_from_info_name(d)
        if wid is None:
            continue                        # .001 자체가 없음 — KLA 폴더가 아니거나 OCR 대상
        od = others.get(_norm_key(wid))
        ok = (od is not None and kla_folder_slot_no(name) is not None
              and read_active_slot(od) == kla_folder_slot_no(name))
        if ok:
            ids[name] = wid
        broken.append((name, wid, ok))
    return ids, broken


def merge_unmatched_by_wafer_id(sr: ScanResult, wid_by_ref: dict,
                                wid_by_val: dict) -> list[tuple[str, str]]:
    """``ref_only``/``val_only`` 를 ‘폴더명 또는 WaferID’ 키 교집합으로 병합.

    각 폴더 키 = {폴더명, (있으면) WaferID}.  ref·val 키가 겹치면 같은 slot.
    병합 **slot명 = 교집합 키(WaferID 우선)** — KLA 가 기준/검증 어느 쪽이든 깔끔한
    WaferID 가 slot명이 된다(KLA 의 임의 폴더명이 slot명이 되는 것 방지).
    ``sr`` 를 직접 수정하고 짝지은 ``(ref, val)`` 목록 반환.  ``wid_by_*`` : {폴더명 → WaferID}."""
    wid_by_ref = wid_by_ref or {}
    wid_by_val = wid_by_val or {}

    def keyset(name, wid):
        ks = {_norm_key(name)}
        if wid:
            ks.add(_norm_key(wid))
        return ks

    val_keys = {v: keyset(v, wid_by_val.get(v)) for v in sr.val_only}
    paired: list[tuple[str, str]] = []
    used_val: set = set()
    for ref_name in list(sr.ref_only):
        rk = keyset(ref_name, wid_by_ref.get(ref_name))
        match_val = None
        slot_name = None
        for val_name in list(sr.val_only):
            if val_name in used_val:
                continue
            inter = rk & val_keys.get(val_name, set())
            if not inter:
                continue
            match_val = val_name
            # slot명 = 교집합 키 중 WaferID 우선(없으면 임의의 교집합 키).
            wids = {_norm_key(w) for w in
                    (wid_by_ref.get(ref_name), wid_by_val.get(val_name)) if w}
            pref = inter & wids
            slot_name = sorted(pref)[0] if pref else sorted(inter)[0]
            break
        if match_val is None:
            continue
        ref_slot = sr.slots.get(ref_name)
        vs = sr.slots.get(match_val)
        if ref_slot is None or vs is None:
            continue
        # slot명이 **무관한 기존 슬롯**과 겹치면 병합하지 않는다 — 겹친 채로 진행하면
        # 그 슬롯의 사진을 덮어써 웨이퍼가 조용히 사라진다.  두 폴더는 ref_only/val_only
        # 에 남아 수동 매핑으로 넘어간다(정확도 우선).
        existing = sr.slots.get(slot_name)
        if existing is not None and slot_name not in (ref_name, match_val):
            continue
        merged = existing or Slot(name=slot_name)
        merged.ref_images = [ImageItem(slot=slot_name, path=it.path, side="ref")
                             for it in ref_slot.ref_images]
        merged.val_images = [ImageItem(slot=slot_name, path=it.path, side="val")
                             for it in vs.val_images]
        # 원본 폴더 경로를 옮겨 둔다 — 사진 0장 폴더의 정보파일을 나중에도 찾을 수 있게.
        merged.ref_dir = ref_slot.ref_dir
        merged.val_dir = vs.val_dir
        if ref_name != slot_name:
            sr.slots.pop(ref_name, None)
        if match_val != slot_name:
            sr.slots.pop(match_val, None)
        sr.slots[slot_name] = merged
        used_val.add(match_val)
        for n in (ref_name, match_val, slot_name):
            if n in sr.ref_only:
                sr.ref_only.remove(n)
            if n in sr.val_only:
                sr.val_only.remove(n)
        paired.append((ref_name, match_val))
    return paired
