"""모든 사용자 노출 문자열(한국어)을 한 곳에 모아둔 모듈.

UI/로그/툴팁/오류 메시지 모두 이 모듈을 통해 참조합니다.
번역이나 일괄 수정 시 이 파일만 보면 됩니다.
"""

# ── 앱/메타 ────────────────────────────────────────────────────────────────
APP_TITLE = "AOI 레시피 검증"
# 개발자 크레딧 — 주요 화면/상태바 공통 표시.
CREDIT = "Developed by 임현택"

# ── 시작 스플래시(로고 + 로딩) ────────────────────────────────────────────
SPLASH_MODULES = "구성 요소를 불러오는 중…"
SPLASH_PAGES = "화면을 준비하는 중…"
SPLASH_UPDATE_CHECK = "업데이트를 확인하는 중…"
SPLASH_READY = "준비 완료"

# ── OpenVINO 자동 설치 안내 ───────────────────────────────────────────────
OPENVINO_OFFER_TITLE = "Intel GPU 가속 활성화"
OPENVINO_OFFER_BODY = (
    "Intel CPU 가 감지되었습니다.\n"
    "OpenVINO 를 설치하면 고효율 모드의 후보 생성이 Intel GPU (Iris Xe / Arc) 로 "
    "빨라집니다. 좌표·기본 모드에는 영향이 없습니다.\n\n"
    "지금 설치할까요? (약 200 MB)"
)
OPENVINO_OFFER_BTN_INSTALL = "지금 설치"
OPENVINO_OFFER_BTN_LATER = "다음에"
OPENVINO_OFFER_BTN_NEVER = "다시 보지 않기"
OPENVINO_INSTALL_PROGRESS = "OpenVINO 설치 중…"
OPENVINO_INSTALL_DONE = (
    "OpenVINO 설치 완료!\n프로그램을 다시 시작하면 고효율 모드에서 Intel GPU 가속을 쓸 수 있습니다."
)
OPENVINO_INSTALL_FAILED_FMT = (
    "OpenVINO 설치에 실패했습니다 — {error}\n\n"
    "수동으로 시도해보세요:  pip install openvino"
)

# ── 공통 버튼/액션 ─────────────────────────────────────────────────────────
BTN_OK = "확인"
BTN_CANCEL = "취소"
# 진행 중인 작업을 멈추는 버튼(로딩 오버레이) — '취소' 와 뜻이 다르다.
BTN_STOP = "중지"

# ── 로딩 오버레이(타이틀블록) ─────────────────────────────────────────────
# 단계 서수 — 다단계 여정에서 '전체의 어디쯤' 을 말한다.  단계 정보를 주지 않은
# 호출부에서는 이 줄 자체가 보이지 않는다(하위 호환: 문구 하나만 뜬다).
LOADING_STAGE_FMT = "단계 {idx:02d} / {total:02d}"
LOADING_COUNT_FMT = "진행 {done} / {total}"
LOADING_ETA_FMT = "남은 시간 약 {text}"
# 표본이 모자라거나(<5) 총량을 모르는 단계 — 없는 정보를 지어내지 않는다.
LOADING_ETA_UNKNOWN = "—"
DURATION_SEC_FMT = "{s}초"
DURATION_MIN_FMT = "{m}분 {s}초"
DURATION_HOUR_FMT = "{h}시간 {m}분"
# ※ BTN_BACK_TO_SETUP("← 설정으로")은 지웠다 — 화면마다 다른 뜻을 갖던 뒤로가기
#   버튼을 없애고 창 상단 여정 레일이 복귀를 통일해서 맡는다(구조개편 1안-A).
#   레일의 문구는 JOURNEY_RAIL_* 다.
BTN_START = "검증 시작"
# 시작 직후 — 무거운 구성 요소(영상 처리·가속)를 백그라운드에서 불러오는 동안의 표기.
# 창은 먼저 뜨고, 준비가 끝나면 원래 이름(BTN_START)으로 돌아오며 활성화된다.
BTN_START_PREPARING = "준비 중…"
BTN_BROWSE = "폴더 선택…"
BTN_VERIFY = "검증"
BTN_EXCLUDE = "제외"
BTN_UNDO = "되돌리기(Z)"
# 단축키를 라벨에 적는다 — 선별 화면은 "되돌리기(Z)" 라 여기서 Z 를 눌러 보게 된다.
#   매칭 화면은 Z 가 선별 화면과 충돌해 Ctrl+Z 만 받는다(match_page 주석).
BTN_MATCH_UNDO = "되돌리기(Ctrl+Z)"
# ★ 예전 문구는 "직전 매칭/매칭없음 결정을 취소합니다" 였다.  그 '매칭없음' 을 만들던
#   [매칭 없음] 버튼과 `N` 단축키는 제거됐으므로(2단계는 언제나 자동 — 그 사이 눌리면
#   처리 중이던 사진이 조용히 미탐으로 확정됐다), 사람이 만들 수 없는 결정 종류를
#   되돌리기 툴팁이 계속 약속하고 있었다.  남은 결정은 '매치' 하나다.
MATCH_UNDO_TOOLTIP = "직전 매치 결정을 취소합니다 (Ctrl+Z)"
# ⚠ 도달 불가 — SKIPPED_SECTION_DEFER_FMT 주석 참조(보류 풀이 항상 비어 버튼이 숨는다).
BTN_RETRY_SKIP = "보류 재시도"
BTN_SELECT_MODE = "선택 모드"
# Stage 1 좌측 패널 — 사진을 여러 장 고르면 헤더에 나타나는 일괄 액션.
# ★ 예전엔 클릭 선택이 아무 데도 연결되지 않아 '테두리만 생기고 할 수 있는 게 없는'
#   죽은 기능이었다.  라벨에 개수를 넣어 무엇에 적용되는지 분명히 한다.
BTN_INLINE_VERIFY_FMT = "선택 {n}장 검증"
BTN_INLINE_EXCLUDE_FMT = "선택 {n}장 제외"

# ── 다중 선택 다이얼로그 (Stage 1 선택 모드) ─────────────────────────────
BULK_SELECT_TITLE_FMT = "{panel} — 다중 선택"
BULK_SELECT_HINT = (
    "사진을 클릭하거나 빈 곳에서 드래그해 여러 장을 선택/해제하세요. "
    "선택된 사진들에 아래 액션이 적용됩니다."
)
BULK_SELECT_SUMMARY_FMT = "선택됨: {n}장"
# ★ 페이지네이션 중에는 선택이 페이지를 넘어 유지되므로, 이 페이지에 보이는 것보다
#   훨씬 많은 사진이 함께 처리될 수 있다.  실행 직전에 그 간극을 화면이 말한다.
BULK_SELECT_SUMMARY_OFFPAGE_FMT = "선택됨: {n}장 (이 페이지 밖 {m}장 포함)"
BULK_SELECT_EMPTY = "표시할 사진이 없습니다."
BULK_SELECT_ALL = "전체 선택"
BULK_DESELECT_ALL = "선택 해제"
# 사진 크기 슬라이더 / 페이지네이션 / 우클릭 확대 (대량 표시 대응)
BULK_SIZE_LABEL = "사진 크기"
BULK_PAGE_PREV = "◀ 이전"
BULK_PAGE_NEXT = "다음 ▶"
BULK_PAGE_LABEL_FMT = "페이지 {page} / {total}"
BULK_TILE_ZOOM_TOOLTIP = "우클릭하여 크게 보기"
BTN_MOVE_TO_EXCLUDE = "제외로 이동"
BTN_MOVE_TO_TARGET = "검증 대상으로 이동"
BTN_BACK_TO_CENTER = "중앙으로 복귀(재결정)"
BTN_BATCH_EXCLUDE = "선택 항목 검증 제외"
BTN_BATCH_VERIFY = "선택 항목 검증 대상 지정"
BTN_VIEW_EXCLUDED_FMT = "검증 제외 사진 보기 ({n})"
# Stage 1 ‘선택 종료’ — 미결정 사진 모두 제외 처리 후 다음 단계로.
BTN_END_SELECTION = "선택 종료"
# Stage 1 에서 설정 화면으로 돌아갈 때 — 이미 내린 결정이 사라지므로 한 번 묻는다.
MATCH_CANCEL_CONFIRM_TITLE = "매칭 중단"
# ★ 중단은 '잠깐 멈춤' 이 아니다 — 정확도 사고를 막기 위해 계산 결과를 전부 버린다
#   (남기면 설정을 바꿔 다시 돌려도 1회차 결과가 재사용된다).  그 사실을 말해 준다.
MATCH_CANCEL_CONFIRM_FMT = (
    "진행 중인 매칭을 중단할까요?  ({done} / {total} 까지 진행)\n\n"
    "지금까지 계산한 결과는 저장되지 않고, 다시 시작하면 처음부터 계산합니다."
)
SELECT_BACK_CONFIRM_TITLE = "설정으로 돌아가기"
SELECT_BACK_CONFIRM_FMT = (
    "지금까지 결정한 {n}장이 사라지고 설정 화면으로 돌아갑니다.\n"
    "계속할까요?"
)
END_SELECTION_CONFIRM_TITLE = "선택 종료"
END_SELECTION_CONFIRM_FMT = (
    "남은 {n}장의 미결정 사진을 모두 ‘검증 제외 사진’ 으로 보내고 "
    "다음 단계로 진행할까요?"
)
BULK_SELECT_EXCLUDED_TITLE = "검증 제외 사진"

BTN_EXPORT_EXCEL = "엑셀로 저장"
BTN_OPEN_SAVED_FILE = "파일 열기"
BTN_OPEN_SAVED_FOLDER = "폴더 열기"
BTN_RETRY_SAVE = "다시 시도"
BTN_NEW_SESSION = "새 검증 시작"
NEW_SESSION_CONFIRM_TITLE = "새 검증 시작"
NEW_SESSION_CONFIRM_BODY = (
    "아직 엑셀로 저장하지 않았습니다.  지금 새 검증을 시작하면 이번 결과가 사라집니다.\n"
    "계속할까요?"
)
# 결과 화면 → 전용 검토 화면으로 되돌아가기(검토 결과는 그대로 보존된다).
BTN_BACK_TO_REVIEW = "← 검토 화면으로"


# ── 셋업 페이지 ────────────────────────────────────────────────────────────
# 이전 값 "AOI Recipe Verificator" 는 (a) 오타(verificator → verifier) 이고
# (b) 나머지가 전부 한국어인 화면에 영어만 남아 있었다.
SETUP_TITLE = "AOI 레시피 검증"
SETUP_REF_GROUP = "기준 장비"
SETUP_VAL_GROUP = "검증 장비"
# 기준 1 ↔ 검증 여러 장비(`models/multi_val.py`).
MULTI_VAL_ADD_FMT = "+ 검증 장비 추가 ({n}/{max})"
MULTI_VAL_REMOVE = "이 검증 장비 빼기"
MULTI_VAL_ROW_FMT = "검증 {n}"
MULTI_VAL_MACHINE_PLACEHOLDER = "예) AOI-5"
MULTI_VAL_DEFAULT_MACHINE_FMT = "검증호기{n}"
MULTI_VAL_NO_CANDIDATE_FMT = "{machine} · 이 기준 사진의 후보를 찾지 못했습니다"
MULTI_VAL_LEG_FMT = "검증 장비 {n}/{total} ({machine}) — {msg}"
MULTI_VAL_RESULT_PICK = "검증 장비:"
MULTI_VAL_SUMMARY_SHEET = "장비별 요약"
MULTI_VAL_SUMMARY_COL_SLOT = "슬롯"
MULTI_VAL_SUMMARY_COL_REF_FMT = "기준 사진 ({machine})"
MULTI_VAL_STATUS_FOUND = "찾음"
MULTI_VAL_STATUS_MISSED = "놓침"
MULTI_VAL_STATUS_NO_SLOT = "비교 못 함(짝 슬롯 없음)"
MULTI_VAL_DUPLICATE_FMT = "같은 폴더가 두 번 들어 있습니다:\n{path}"
SETUP_FOLDER_LABEL = "최상위 폴더"
SETUP_MACHINE_LABEL = "호기 번호"
SETUP_THRESHOLD_LABEL = "유사도 임계치"
SETUP_FOLDER_PLACEHOLDER = "폴더를 선택해 주세요"
SETUP_MACHINE_PLACEHOLDER = "호기"

# ── 검증 단계 헤더 ─────────────────────────────────────────────────────────
# ★ 레일 이름을 그대로 쓴다 — "Stage 1" 은 레일의 ② 와 번호가 어긋났고(설정이 ①),
#   "(v2)" 는 사용자가 알 필요 없는 내부 판 번호였다.
STAGE1_TITLE = "후보 선별"
STAGE2_TITLE = "매칭 · 유사도 기반"
STAGE2_TITLE_COORD = "매칭 · 좌표 기반"
STAGE2_COORD_OFFSET_FMT = "  ·  보정 가로 {dx:+.0f} · 세로 {dy:+.0f} µm"
RESULT_TITLE = "결과"
# 결과 요약 — 핵심 수치는 타일로, 나머지는 문장으로.
RESULT_MACHINES_FMT = "기준 장비: {ref}    검증 장비: {val}"
# 입력한 폴더 주소 — 숫자 타일 아래, 기준·검증 한 줄씩.
RESULT_REF_ROOT_FMT = "기준  {path}"
RESULT_VAL_ROOT_FMT = "검증  {path}"
RESULT_SLOT_ONLY_REF_FMT = "슬롯 불일치  ·  기준 전용: {names}"
RESULT_SLOT_ONLY_VAL_FMT = "슬롯 불일치  ·  검증 전용: {names}"
VALUE_NONE = "없음"
# ★ '매치 성공' 이다(‘매칭 성공’ 아님) — 형제 타일이 '매치 없음'·'매치 실패' 라
#   같은 한 건을 세는 자리에서 낱말이 갈리면 다른 것을 세는 것처럼 읽힌다.
#   낱말 규약: **매칭 = 과정/기능**(설정·중단·엔진), **매치 = 결과 한 건**(검토·확정·성공).
STAT_MATCHED = "매치 성공"
STAT_OVER_TOLERANCE = "허용 초과"
STAT_NO_MATCH = "매치 없음"
STAT_SLOT_MISMATCH = "슬롯 불일치"
# 교차검증(양방향) — '매치 없음' 을 어느 장비에만 있었는지로 나눈다.
STAT_ONLY_REF = "기준에만 있음"
STAT_ONLY_VAL = "검증에만 있음"
MATCH_REVIEW_TITLE = "매치 검토"

# ★ 패널 제목에 괄호 부연을 넣지 않는다.  이 제목은 `role=paneTitle` QLabel 이고
#   wordWrap 도 elide 도 없어 **말줄임표 없이 하드 클립**된다 — 실측(1024 폭)에서
#   "검증 대상 (검증하기로 한 사진들)" 은 189px 이 필요한데 자리는 135px 이라
#   "검증 대상 (검증하기로 " 까지만 보였다(1280 에서도 여유 0~1px).  부연은 툴팁으로
#   내리고 제목은 짧게 둔다.  회귀 가드: `dev/tests/test_pane_title_fits.py`.
PANEL_LEFT_CANDIDATES = "검증 후보"
PANEL_LEFT_CANDIDATES_TOOLTIP = "아직 검증/제외를 결정하지 않은 남은 사진들"
PANEL_CENTER_DECIDE = "검증 결정할 사진"
PANEL_RIGHT_TARGETS = "검증 대상"
PANEL_RIGHT_TARGETS_TOOLTIP = "검증하기로 결정한 사진들"
# 우측 패널이 비었을 때의 안내 — 처음 쓰는 사람이 이 칸의 용도를 알 수 있게.
PANEL_RIGHT_EMPTY = "→ 또는 [✓ 검증] 으로 보낸 사진이 여기에 쌓입니다."

PANEL_MATCH_REF = "기준 사진"
PANEL_MATCH_CANDIDATES = "검증 장비 후보"
# 교차검증 두 번째 방향(검증 → 기준) — 큐가 검증 사진, 후보가 기준 사진이다.
PANEL_MATCH_REF_REVERSE = "검증 사진"
PANEL_MATCH_CANDIDATES_REVERSE = "기준 장비 후보"
# 선별·매칭·검토 화면 표제 뒤에 붙는다 — 지금 두 번째 방향이라는 것을 표제가 말한다.
CROSS_REVERSE_SUFFIX = " · 2차: 검증 → 기준"
# 교차검증 첫 방향 — 2차 화면에만 방향이 적히면 1차 화면은 '어느 방향인가' 가 비어 보인다.
CROSS_FORWARD_SUFFIX = " · 1차: 기준 → 검증"

# Stage 2 의 '매치 없음' 사진 팝업
# ★ 이 팝업의 이름에서 '보류' 를 뺐다.  버튼은 오래 "보류된 사진 보기 (n)" 이었지만
#   n = 보류(defer) + 매치 없음(no_match) 합계이고, **보류를 만드는 경로가 없다**
#   (`match_page._skip_current` 의 프로덕션 호출부 0건 — 아래 SKIPPED_SECTION_DEFER_FMT
#   주석 참조).  즉 내용물은 항상 '매치 없음' 뿐인데 이름은 비어 있는 절반만 불렀다.
BTN_VIEW_SKIPPED_FMT = "매치 없음 사진 보기 ({n})"
SKIPPED_DIALOG_TITLE = "매치 없음 사진"
# ⚠ 아래 두 문구는 **지금 화면에 뜨지 않는다** — '잠시 보류' 절은 defer 가 1건 이상일
#   때만 그려지는데 그 풀을 채우는 `_skip_current` 를 부르는 프로덕션 코드가 없다.
#   기능(코드·테스트)은 그대로 두고 문구만 남긴다: 지우면 보류를 되살릴 때 다시
#   만들어야 하고, 남겨 두어도 숨어 있어 해가 없다.  되살린다면 위 버튼 이름도
#   함께 '보류' 를 되돌려야 한다.
SKIPPED_SECTION_DEFER_FMT = "잠시 보류 ({n}장)"
SKIPPED_SECTION_NO_MATCH_FMT = "매치 없음 확정 ({n}장)"
SKIPPED_DIALOG_EMPTY = "매치 없음 사진이 없습니다."

# 매치 실패 사진 검토 다이얼로그 (#8)
BTN_REVIEW_UNMATCHED = "매치 없음 사진 검토"
UNMATCHED_REVIEW_TITLE = "매치 없음 사진 검토 — {n}장"
UNMATCHED_REVIEW_PROGRESS_FMT = "{idx} / {total} — {slot}"
UNMATCHED_REVIEW_HINT = (
    "매치 없음인 기준 사진을 하나씩 검토합니다. 같은 슬롯의 검증 장비 후보를"
    " 보여줍니다. 맞는 사진을 클릭해 선택(파란 테두리)한 뒤"
    " [매치 확정] 을 누르세요. 후보를 우클릭하면 크게 비교할 수 있습니다."
)
# 좌표로 매칭한 세션에서 이 화면만 유사도로 줄을 세운다는 사실을 알린다 (U-18).
#   좌표 모드로 검증했는데 후보 순서가 좌표와 무관해 보여 혼란을 준 지점이다.
UNMATCHED_REVIEW_COORD_NOTE = (
    "이 검증은 좌표 기준으로 매칭했지만, 이 화면의 후보 순서는 좌표 거리가 아니라"
    " 사진 유사도입니다. 좌표로 짝을 찾지 못한 사진들이라 유사도로 다시 줄을 세웁니다."
)
UNMATCHED_REVIEW_NO_CANDIDATES = "이 슬롯에는 검증 장비 후보가 없습니다."
UNMATCHED_REVIEW_DONE_FMT = "{n} 건의 신규 매칭을 확정했습니다."
UNMATCHED_REVIEW_EMPTY = "검토할 매치 실패 사진이 없습니다."
UNMATCHED_CONFIRM_ON_CLOSE = (
    "선택(파란 테두리)했지만 아직 확정하지 않은 후보가 있습니다.\n"
    "선택한 대로 매칭하시겠습니까?"
)
BTN_UNMATCHED_CONFIRM = "매치 확정"
BTN_UNMATCHED_SELECT_THIS = "이 후보로 선택"
BTN_UNMATCHED_NEXT = "다음 사진"
BTN_UNMATCHED_PREV = "← 이전"
BTN_UNMATCHED_CLOSE = "검토 종료"

# ‘매칭 취소’ 결합 (#14) — 실패 검토가 `MissEntry.note` 에서 이 표시를 보고 해당
# 항목을 목록 뒤로 모은다(`unmatched_review_dialog._is_cancelled`).
#
# ⚠ **지금 이 표시를 note 에 남기는 생산자는 없다.**  예전 주석은 "결과 검토
#    (`result_page`)가 남긴다" 고 적었지만 `result_page._on_review_matches` 는 저장소에
#    존재하지 않고, note 를 쓰는 곳은 `main_window`(NOTE_UNMATCHED)와
#    `match_review_page`(NOTE_UNMATCHED_BY_USER) 둘뿐이라 둘 다 이 표식을 담지 않는다.
#    따라서 `_is_cancelled` 는 항상 False 이고 UNMATCHED_CANCELLED_SEPARATOR 도 그려지지
#    않는다 — 소비자 쪽 코드만 살아 있는 **휴면 경로**다.
#    남겨 두는 이유: 소비자(정렬·구분선)는 이미 있고 테스트도 있으므로, 생산자가
#    돌아오면 문자열 하나로 다시 이어진다.  지우면 그 결합을 다시 만들어야 한다.
#    이 사실은 `dev/tests/test_unmatched_cancelled_order.py` 가 못 박는다 —
#    생산자를 추가하면 그 테스트가 실패하며 이 주석을 고치라고 알려 준다.
CANCELLED_NOTE_MARK = "매칭 취소"
CANCELLED_NOTE = f"{CANCELLED_NOTE_MARK} (검토에서 삭제)"
UNMATCHED_CANCELLED_SEPARATOR = f"── {CANCELLED_NOTE_MARK} 목록 ──"

# ── 줌-뷰 윈도우 ───────────────────────────────────────────────────────────
ZOOM_TITLE_TARGETS = "검증 대상인 사진들 — {slot}"
ZOOM_TITLE_EXCLUDED = "검증하지 않을 사진 — {slot}"
ZOOM_TITLE_CANDIDATES = "검증 후보 사진들 — {slot}"
ZOOM_BTN_EXCLUDE = "검증에서 제외"
ZOOM_BTN_TO_TARGET = "검증 대상으로 변경"
ZOOM_BTN_TO_CENTER = "재결정으로 복귀"
# ★ 같은 동작(이 후보를 매치로 확정)을 하는 버튼이 세 화면에 있다 — 확대 보기
#   (BTN_CONFIRM_AS_MATCH) · 좌우 비교(BTN_MATCH_THIS) · 줌 윈도우(여기).  한때
#   '매치' / '이 후보로 매치' / '이 사진으로 매칭' 세 이름이었다.  **한 이름으로 둔다.**
ZOOM_BTN_PICK_MATCH = "이 후보로 매치"

# ── 단축키 ────────────────────────────────────────────────────────────────
SHORTCUT_TOOLTIP = (
    "단축키:  → = 검증   /   ← = 제외   /   Z = 되돌리기"
)

# ── 사진 크기 슬라이더 ────────────────────────────────────────────────────
IMAGE_SIZE_LABEL = "사진 크기"
SLOT_LABEL_FMT = "슬롯: {slot}"
# 후보 패널 '슬롯 고르기' — 사진이 많아 지금 슬롯만 보일 때 다른 슬롯으로 넘어간다.
SLOT_JUMP_LABEL = "다른 슬롯으로 이동"
SLOT_JUMP_TOOLTIP = "사진이 많아 슬롯 하나씩 보여 줍니다 — 여기서 다른 슬롯으로 바로 넘어갈 수 있습니다"
SLOT_JUMP_ITEM_FMT = "{slot} · {n}장"
SLOT_JUMP_ITEM_NO_FMT = "#{no} · {slot} · {n}장"

# ── 유사도 엔진 모드 + 중앙 전처리 ────────────────────────────────────────
# 구형(유사도) 모드 — 명시적 스위치.  '펼치기 = 켜기' 였던 옛 동작을 없앴다.
LEGACY_SWITCH_TITLE = "유사도 엔진(구형) 사용"
LEGACY_MODE_HINT = "좌표 데이터가 없는 예전 자료에 쓰는 대체 경로입니다."
# 지금 어떤 파라미터가 유효한지 문장으로 알려준다(비활성 컨트롤의 이유).
ENGINE_ACTIVE_LEGACY_FMT = "구형 {sub} 모드 사용 중 — 유사도 임계치가 판정 기준입니다."
# 문장 안에 넣을 짧은 이름(타일 라벨의 괄호까지 넣으면 괄호가 겹친다).
ENGINE_MODE_BASIC_SHORT = "기본"
ENGINE_MODE_EFFICIENCY_SHORT = "고효율"
# ── 상단 모드 배지 — "지금 무슨 모드야?"를 스크롤 없이 2초 안에 ───────────────────
# 채점자 5인이 전부 같은 지적을 했다: 판정 기준 문장이 엔진 카드 안(A안은 화면 밖,
# C안은 접힘 아래)에 있어, 무슨 엔진·무슨 수치로 도는지 알려면 찾아 내려가야 했다.
# 배지는 **판정 기준 값까지** 담는다 — 모드 이름만으로는 오조작을 못 막는다.
MODE_BADGE_CAPTION = "판정 기준"
# ★ (이름, 수치) 로 나눈다 — 이름은 한국어(본문 서체), 수치만 모노.  한 라벨에 모노를
#   걸면 모노 서체에 한글 글리프가 없어 문장 안에서 서체가 갈린다.
#   배지·C안 요약이 **같은 함수**(`SetupPage.judgement_text`)에서 문장을 받는다.
JUDGE_NAME_COORD = "좌표 매칭 · 허용 오차"
JUDGE_VALUE_COORD_FMT = "{tol:.0f} µm"
JUDGE_NAME_LEGACY_FMT = "구형 {sub} · 유사도 임계치"
JUDGE_VALUE_LEGACY_FMT = "{th:.0f} %"
# ★ 배치에 종속된 안내를 하지 않는다 — "아래 '매칭 설정' 카드" 라고 쓰면 C안처럼
#   상세를 접어 두는 배치에서는 화면에 없는 것을 가리킨다.
MODE_BADGE_TOOLTIP = (
    "지금 이 설정으로 매칭합니다.  아래 방식 구역에서 바꿀 수 있습니다."
)
COORD_NO_DATA_MSG = (
    "좌표 정보가 없습니다.\n\n"
    "이미지 파일명 또는 폴더에 좌표 데이터(Camtek LIVE / INI / KLA .001)가\n"
    "없어 좌표 매칭을 진행할 수 없습니다.\n\n"
    "매칭 설정에서 ‘유사도 엔진(구형) 사용’ 을 켠 뒤 다시 시작하세요."
)
SCORE_DIST_FMT = "{dist:.0f} µm"
# ★ 낱말은 '허용 초과' 다 — 통계 타일(STAT_OVER_TOLERANCE)·판정 칩(CHIP_OVER)·
#   탤리(TALLY_OVER_FMT)가 전부 그렇게 부른다.  여기만 '허용범위 초과' 였다.
SCORE_DIST_OVER_FMT = "{dist:.0f} µm (허용 초과)"
# 구형(유사도) 엔진의 점수 표기 — 좌표 모드의 µm 거리에 대응.  같은 포맷이 네 곳
# (매치 검토 행·차순위 타일·매칭 목록·실패 검토)에 흩어져 갈라져 있었다.
SCORE_SIMILARITY_FMT = "{pct:.1f} %"
ENGINE_MODE_BASIC = "기본 모드"
ENGINE_MODE_EFFICIENCY = "고효율 모드 (사진이 많을 때 권장)"
COORD_TOLERANCE_LABEL = "허용 오차"
# 허용 오차 ± 버튼 — Qt 기본 스핀 버튼(잘린 막대·10px 타깃) 대체.
TOL_STEP_UP = "허용 오차 50 µm 늘리기"
TOL_STEP_DOWN = "허용 오차 50 µm 줄이기"
COORD_TOLERANCE_TOOLTIP = (
    "좌표 매칭 모드에서 두 defect 좌표의 최대 허용 거리 (µm).\n"
    "이 값 이하면 동일 defect 으로 간주합니다.\n"
    "기본값 200 µm 은 한 die 크기가 40 mm 안팎일 때 약 0.5% 수준입니다.\n"
    "die 가 작은 자재에서는 그에 맞춰 낮춰 주세요."
)
# 기준 폴더에서 읽어낸 die 크기 안내 — 허용 오차를 자재에 맞게 정하도록 돕는다.
# 값을 대신 바꾸지는 않는다(기존 결과가 조용히 달라지면 안 된다).
DIE_SIZE_DETECTED_FMT = "감지된 die: {x:,.0f} × {y:,.0f} µm  ({src})"
DIE_SIZE_SRC_KLA = "KLA .001 DiePitch"
# 폴더를 훑는 동안 보여 줄 문구.  ★ 빈 줄로 두지 않는다 — 이 스캔은 자재에 따라
# 1초를 넘고(슬롯 25 × 결함 3,000 실측 1.4초), 아무 표시도 없으면 '안내가 원래
# 없는 폴더' 와 구분되지 않는다.  진행을 모를 때도 멈춰 보이게 두지 않는다는
# 로딩바 규칙(CLAUDE.md)과 같은 취지다.
DIE_SIZE_CHECKING = "die 크기 확인 중…"
# ⚠ **Camtek INI 좌표가 있는데 die pitch 를 못 정한 경우에만** 띄운다.
# KLA 슬롯·LIVE 파일명 슬롯은 die 크기 없이도 좌표가 나오므로 경고 대상이 아니다.
# 매칭 자체는 절대 wafer 좌표로 정상 동작한다 — 못 하는 건 die 단위 표기뿐이다.
DIE_SIZE_NOT_FOUND = (
    "die 크기를 찾지 못해 **절대 wafer 좌표**로 매칭합니다 (매칭은 정상).\n"
    "die 내부 좌표·row 표기를 보려면 결과 폴더에 "
    "Params_WaferInfo.ini(DieStep_X/Y) 또는 ProductInfo.ini(XDieIndex/YDieIndex) 가 필요합니다."
)
ENGINE_EFFICIENCY_CPU_ONLY = (
    "가속 장치(Intel GPU)가 없어 CPU만으로 고효율 모드를 실행합니다."
)
ACCEL_UNITS_FMT = "가속: {units}"
SIZE_TIER_NOTICE_FMT = (
    "사진이 많아 썸네일 화질을 자동 조정했습니다 ({thumb}px / Q{q})"
)

# ── 상태 바: 메모리 / 진행 ────────────────────────────────────────────────
MEMORY_USAGE_FMT = "메모리 사용량: {mb} MB"
MEMORY_PRESSURE_TOAST = "메모리 사용량이 높아 캐시를 정리했습니다"

# ※ 상태 바의 CPU/GPU 사용량 문구(USAGE_*)와 'Intel GPU 가속' 디바이스 표시는 제거했다.
#   상태바는 사용자가 행동을 바꿀 수 있는 정보만 담는다 — 메모리 압박은 '슬롯을 나눠
#   돌리라'는 행동으로 이어지지만, GPU 가동 여부로 사용자가 할 수 있는 일은 없었다.

# ── Stage 2 더 크게 보기 ───────────────────────────────────────────────────
EXPAND_VIEW_TOOLTIP = "이 사진을 크게 보기 (←/→ 이전·다음, Enter 매치, Esc 돌아가기)"
# 확대 보기의 확정 버튼 — 좌우 비교(BTN_MATCH_THIS)·줌 윈도우(ZOOM_BTN_PICK_MATCH)와
# **같은 동작이므로 같은 이름**을 쓴다(예전엔 여기만 '매치' 였다).
BTN_CONFIRM_AS_MATCH = "이 후보로 매치"
BTN_BACK_TO_GRID = "돌아가기"            # 확대 보기 — 화살표 제거 (#2)
BTN_EXPAND_PREV = "◀ 이전"
BTN_EXPAND_NEXT = "다음 ▶"
EXPAND_POSITION_FMT = "{cur} / {total}"

# ── 양식 파일 / 저장 파일 명명 ─────────────────────────────────────────────
# 결과 엑셀 제목 — "장비Layer_자재검증(장비기준)" (사용자 요청).
#   예: `4F-AOI-03 TB500_RDL4_GFW 검증(AOI-24 기준).xlsx`
# {tag} = "자재_Layer_S/M"(못 읽은 칸은 빠진다).  자재는 제품 이름(TB500)이고 Camtek Job
# 이름·KLA 헤더에서, S/M(스트립 마크)은 슬롯 WaferInfo.ini `InputLot` 의 첫 하이픈 앞에서
# 추천한다(`models/lot_info.py`, 사용자 결정·요청 2026-10-30).  모두 못
# 읽으면 아래 폴백 이름을 쓴다 — 저장 창에서 사용자가 칸을 채워 다시 만들 수 있다.
RESULT_FILE_TITLE_FMT = "{val} {tag} 검증({ref} 기준).xlsx"
RESULT_FILE_TITLE_FALLBACK_FMT = "AOI {val} 검증 ({ref} 기준).xlsx"
# 교차검증은 양방향(기준→검증 + 검증→기준)이라 '어느 쪽 기준'이 없다 — 두 장비를 ↔ 로 묶는다.
#   예: `AOI-24 vs 4F-AOI-03 TB500_RDL4_GFW 교차검증.xlsx`
CROSS_FILE_TITLE_FMT = "{ref} vs {val} {tag} 교차검증.xlsx"
CROSS_FILE_TITLE_FALLBACK_FMT = "AOI {ref} vs {val} 교차검증.xlsx"
TEMPLATE_NOT_FOUND_TITLE = "양식 파일 없음"
TEMPLATE_NOT_FOUND_BODY = (
    "‘양식’ 폴더 안의 ‘양식.xlsx’ 를 찾을 수 없습니다.\n"
    "기본 양식으로 결과를 생성합니다.\n\n"
    "확인한 경로: {path}"
)
# 엑셀 저장 성공을 결과 화면에 남기는 표시 — 저장 시트를 닫은 뒤에도 '저장했는가' 를
# 화면이 답한다(재저장·미저장 이탈을 확인창으로만 알게 되던 문제).
RESULT_SAVED_AT_FMT = "저장 완료 {time}"

# ── 로딩/진행 ──────────────────────────────────────────────────────────────
# ★ 로딩 문구에 진행 수치({done}/{total})를 넣지 마라.  진행 수치는 웨이퍼 맵 **옆의
#   모노 라벨**(LoadingOverlay._count_label)이 전담한다 — 문구에도 넣으면 같은 숫자가
#   한 화면에 두 번 보인다("썸네일 생성 중 147 / 480" + "147 / 480").  단일 출처 규칙.
LOAD_THUMBNAIL = "썸네일 생성 중…"
# 교차검증 2차 선별에 들어가기 전 — 1차 동안 천천히 만들던 검증 사진 썸네일을 마저 만든다.
LOAD_THUMBNAIL_CROSS_B = "2차 선별용 썸네일 마무리 중…"
LOAD_STAGE_PREP = "다음 단계 준비 중…"
# ★ [검증 시작] 뒤의 세 단계.  단계가 바뀌면 진행바는 0 에서 다시 차는데(그 스냅은
#   올바른 동작이다), 여정 표시가 없으면 "다 됐다가 다시 0 이 됐다" 로 읽힌다.
#   바를 잇는 것이 답이 아니라, 화면이 '전체의 어디쯤' 을 말해야 한다 —
#   서수(`LOADING_STAGE_FMT`)와 이 스텝 행이 그 일을 한다.
#   ※ 문구 자체에는 서수를 붙이지 마라.  타이틀블록 캡션이 이미 말하므로 한 화면에
#     같은 사실이 두 번 적힌다.  세 단계는 LOAD_SCAN → LOAD_THUMBNAIL →
#     LOAD_STAGE_PREP 순으로 항상 함께 돈다(KLA 해석·수동 매핑은 그 사이에서
#     오버레이를 내리고 시트를 띄우므로 단계 수를 바꾸지 않는다).
LOAD_JOURNEY_STEPS = ("폴더 스캔", "썸네일", "매칭 준비")
# ※ 스텝 줄에는 수치를 적지 않는다(개선안 2a — 점 + 이름만).  현재 단계의 수치는
#   웨이퍼 맵 옆의 `LOADING_COUNT_FMT` 줄 하나가 말한다(단일 출처).
# 검토 화면 진입 — 행을 나눠 만드는 동안(수백 건이면 몇 초).
# 엑셀 저장 진행 — 어느 시트의 어느 슬롯인지 (구조개편 30안).
# ★ 저장이 오래 걸리는 이유는 시트를 두세 장 쓰기 때문이다(요약·미매칭에
#   사진을 각각 다시 임베드한다).  고정 문구 하나로는 그 사실이 전달되지 않아
#   '3분째 같은 문장' 이 됐다.  행 수치는 여기 넣지 않는다 — 진행 라벨의 몫이다.
EXPORT_PHASE_FMT = "엑셀로 저장 중 — {sheet} 시트 · {slot}"
LOAD_REVIEW_ROWS = "검토 목록 준비 중…"
LOAD_FEATURE = "검증 장비 특징 추출 중…"
LOAD_SCORING = "유사도 계산 중…"
LOAD_COORD = "좌표 매칭 중…"             # 좌표 모드는 유사도를 계산하지 않는다
PHASE_FEATURE = "이미지 특징 분석"
PHASE_SCORING = "유사도 계산"
PHASE_EMBED = "후보 생성 (GPU 임베딩)"      # 고효율 모드 1단계 — 유사도 계산 직전
PHASE_COORD = "좌표 매칭 중"                # 좌표 기반 매칭 v2
PHASE_COORD_PARSE = "좌표 파싱 중…"         # 좌표 매칭 1단계
# 수동 모드: 첫 슬롯만 기다리고 나머지는 백그라운드 (#streaming).
# 선행 단계(특징 분석/임베딩) 동안에도 '유사도 계산' 으로 오인되지 않도록 중립 문구.
LOAD_PRECOMPUTE_FIRST_SLOT = (
    "첫 슬롯 준비 중… 잠시만 기다려 주세요."
)
LOAD_PRECOMPUTE_WAIT_FMT = (
    "{slot} 슬롯 계산이 끝나기를 기다리는 중… 다음 슬롯은 백그라운드에서 준비됩니다"
)
PRECOMPUTE_BG_STATUS_FMT = "백그라운드 유사도 계산: {idx} / {total} 슬롯 완료"
PRECOMPUTE_BG_DONE = "유사도 계산 완료"

# ── 자동 업데이트 ─────────────────────────────────────────────────────────
UPDATE_AVAILABLE_TITLE = "업데이트 있음"
# '있음' 은 실제로 새 버전이 있을 때만 쓴다.  최신이거나 확인에 실패한 결과까지 같은
# 제목으로 띄우면 제목과 본문이 정반대 사실을 말한다(제목만 읽은 사용자는 오해한다).
UPDATE_CHECK_TITLE = "업데이트 확인"
UPDATE_DONE_TITLE = "업데이트 완료"
UPDATE_FAILED_TITLE = "업데이트 실패"
UPDATE_AVAILABLE_BODY = "새 버전이 있습니다. 지금 업데이트할까요?"
# 버튼은 동작 이름으로 — '예/아니오' 는 질문을 다시 읽어야 뜻이 정해진다.
UPDATE_BTN_NOW = "지금 업데이트"
UPDATE_BTN_LATER = "나중에"
UPDATE_UNKNOWN_CURRENT = "최신 버전을 받아 적용할까요?"
UPDATE_DOWNLOADING = "업데이트 다운로드 중…"
UPDATE_DONE_RESTART = "업데이트가 적용되었습니다.\n프로그램을 종료합니다. 다시 실행해 주세요."
# exe 배포본은 실행 중인 app 폴더를 바꿀 수 없어 새 버전을 받아두기만 하고, 다음 실행 때
# 런처가 교체한다.  '적용되었다' 고 하면 사실과 다르므로 문구를 나눈다.
UPDATE_DONE_RESTART_STAGED = (
    "새 버전을 받았습니다.\n프로그램을 종료합니다. 다시 실행하면 적용됩니다."
)
# 이번 업데이트로 필요한 패키지 목록(requirements.txt)이 바뀐 경우의 추가 안내.
# 자동 업데이트는 앱 소스만 바꾸고 **의존성은 다시 설치하지 않는다**(번들 런타임 보존).
UPDATE_DEPS_CHANGED = (
    "\n\n[중요] 이번 업데이트로 필요한 패키지 목록이 바뀌었습니다. 다음 실행 전에 "
    "의존성을 갱신해 주세요:\n"
    " · 포터블: 앱 폴더의 python\\python.exe -m pip install -r requirements.txt 실행"
    "(또는 최신 포터블 빌드 사용)\n"
    " · 개발/소스: git pull 후 scripts\\run_this_before.py 를 다시 실행"
)
# exe 배포본에서 새 패키지 **설치가 실패해** 적용을 포기한 경우.
# 코드만 바꾸면 앱이 안 켜지므로 구버전을 그대로 유지하고, 무엇을 받아야 하는지 알려준다.
UPDATE_NEEDS_NEW_BUNDLE = (
    "이번 업데이트에 필요한 패키지를 설치하지 못해 적용하지 않았습니다.\n"
    "지금 버전은 그대로 사용하실 수 있습니다.\n\n"
    "인터넷 연결을 확인한 뒤 다시 시도해 주세요.\n"
    "계속 실패하면 관리자에게 새 배포본 'AOI_Verify' 폴더 전체(zip)를 요청하세요.\n"
    "app 폴더만 바꾸면 앱이 실행되지 않습니다."
)
UPDATE_FAILED = "업데이트에 실패했습니다. 잠시 후 다시 시도해 주세요."
UPDATE_CHECKING = "업데이트 확인 중…"
UPDATE_LATEST = "최신 버전입니다."
UPDATE_UNKNOWN = "업데이트를 확인할 수 없습니다. 인터넷 연결을 확인해 주세요."
UPDATE_GIT_HINT = "개발(git) 환경입니다. 'git pull' 로 업데이트하세요."
# 첫 화면 '업데이트 확인' 버튼 라벨(좌상단 도움말 메뉴 대체).
MENU_CHECK_UPDATE = "업데이트 확인"
SETUP_SECTION_FOLDER = "1  폴더"
SETUP_SECTION_MODE = "2  방식"

# ── 개발자 모드 (메인 화면 Ctrl+Shift+D) ───────────────────────────────────
DEV_MODE_ON = "개발자 모드를 켰습니다."
DEV_MODE_OFF = "개발자 모드를 껐습니다. 자동 업데이트는 기본 브랜치를 따릅니다."
DEV_MODE_BUTTON = "개발자 모드"
DEV_MODE_TITLE = "개발자 모드 — 업데이트 대상"
DEV_MODE_BODY = (
    "업데이트를 받을 저장소와 브랜치를 고릅니다. 개발자 모드가 켜져 있는 동안에는 "
    "자동 업데이트도 이 브랜치를 따릅니다. 브랜치를 비우면 기본 브랜치를 따릅니다.\n"
    "개발자 모드를 끄면(Ctrl+Shift+D) 다음 업데이트부터 기본 브랜치로 돌아갑니다."
)
DEV_MODE_CURRENT_FMT = "지금 설치된 버전: {branch} @ {sha}  ({repo})"
DEV_MODE_CURRENT_UNKNOWN = "지금 설치된 버전: 알 수 없음"
DEV_MODE_REPO = "저장소 (소유자/이름)"
DEV_MODE_BRANCH = "브랜치"
DEV_MODE_BRANCH_DEFAULT_HINT = "비우면 기본 브랜치"
DEV_MODE_LOAD_BRANCHES = "브랜치 목록 불러오기"
DEV_MODE_LOADING_BRANCHES = "브랜치 목록을 불러오는 중…"
DEV_MODE_BRANCHES_LOADED_FMT = "브랜치 {n}개를 불러왔습니다."
DEV_MODE_BRANCHES_FAILED = "브랜치 목록을 불러오지 못했습니다. 이름을 직접 적어 주세요."
DEV_MODE_CHECK = "업데이트 확인"
DEV_MODE_INSTALL = "이 브랜치로 설치"
DEV_MODE_RESET = "기본으로 되돌리기"
DEV_MODE_CLOSE = "닫기"
DEV_MODE_OPEN_LOG = "로그 폴더 열기"
DEV_MODE_LOG_PATH_FMT = "app.log 위치: {path}"
DEV_MODE_CHECKING = "확인 중…"
DEV_MODE_RESULT_UPDATE_FMT = "새 버전이 있습니다: {sha}  {message}"
DEV_MODE_RESULT_LATEST_FMT = "이미 이 버전입니다: {sha}  ([이 브랜치로 설치] 로 다시 받을 수 있습니다)"
DEV_MODE_RESULT_UNKNOWN_FMT = "확인할 수 없습니다 — {error}"
DEV_MODE_INSTALL_ASK_FMT = "{repo} 의 {branch} 브랜치({sha})를 설치할까요?"
LOAD_AUTO_MATCH = "자동 매치 진행 중…"

# ── 자동 업데이트 진행 단계 (utils/updater.py → LoadingOverlay) ──────────────
# ★ 이 문구들은 `updater.download_and_apply(progress=…)` 이 단계마다 보고하는 phase 다.
#   `main_window._update_progress`(시그널) → `_on_update_progress` →
#   `LoadingOverlay.set_progress(done, total, message)` 로 **화면에 그대로 뜬다.**
#   예전엔 updater 안에 한글 리터럴로 박혀 있었고, 그래서 같은 오버레이의 첫 문구
#   (UPDATE_DOWNLOADING='업데이트 다운로드 중…')와 어긋난 채 '다운로드 중…' 으로
#   바뀌었다.  한 화면의 문구는 한 곳에서 정한다.
UPDATE_PHASE_DOWNLOAD = UPDATE_DOWNLOADING
UPDATE_PHASE_EXTRACT = "업데이트 압축 해제 중…"
UPDATE_PHASE_PREPARE = "업데이트 준비 중…"
UPDATE_PHASE_DEPS = "필요한 패키지 설치 중…"
UPDATE_PHASE_APPLY = "업데이트 적용 중…"
UPDATE_PHASE_DONE = "업데이트 완료"
# 사용자에게는 크게 두 단계로만 보인다 — 받는 일(다운로드) / 그 뒤 전부(설치: 압축 해제·
# 준비·패키지·적용).  `UPDATE_PHASE_DOWNLOAD` 만 1단계, 나머지 phase 는 2단계다.
UPDATE_JOURNEY_STEPS = ("다운로드", "설치")

# 업데이트 실패 사유 — `updater.last_error()` 에 담겨 main_window 가 CAUSE_PREFIX 뒤에
# 붙여 사용자에게 보여 준다(개발자용 로그가 아니다).
UPDATE_ERR_SSL_FMT = "SSL 인증서 오류 — {host} ({reason})"
UPDATE_ERR_TIMEOUT_FMT = "응답 시간 초과 — {host}"
UPDATE_ERR_CONNECT_FMT = "연결 실패 — {host} ({reason})"
UPDATE_ERR_HTTP_FMT = "HTTP {code} — {host}"
UPDATE_ERR_OTHER_FMT = "{kind} — {host} ({detail})"
UPDATE_ERR_GITHUB = "GitHub 연결 실패"
UPDATE_ERR_NO_SHA_API = "GitHub API 응답에 커밋 SHA 없음"
UPDATE_ERR_NO_SHA_ATOM = "github.com Atom 피드에서 커밋 SHA 를 찾지 못함"
UPDATE_ERR_MISSING_FILE_FMT = "필수 파일 누락: {rel}"
UPDATE_ERR_EMPTY_FILE_FMT = "파일이 비어 있음: {rel}"
UPDATE_ERR_STAT_FAIL_FMT = "파일 확인 실패: {rel} ({error})"
UPDATE_ERR_PIP_START_FMT = "패키지 설치를 시작하지 못했습니다 ({error})"
UPDATE_ERR_PIP_RC_FMT = "패키지 설치 실패 (pip 종료코드 {rc})"
UPDATE_ERR_VERIFY_FMT = "업데이트 준비 검증 실패 — {reason}"

# ── OpenVINO 설치 워커의 결과 사유 (learning/openvino_installer.py) ─────────
# OPENVINO_INSTALL_FAILED_FMT 의 {error} 로 그대로 사용자에게 보인다.
OPENVINO_ERR_PIP_START_FMT = "pip 실행 실패: {error}"
OPENVINO_ERR_CANCELLED = "사용자가 취소함"
OPENVINO_ERR_DURING_FMT = "설치 중 오류: {error}"
OPENVINO_ERR_PIP_RC_FMT = "pip 종료 코드 {rc}"
OPENVINO_INSTALL_OK = "설치 완료"

# ── 첫 실행 부트스트랩 콘솔 (utils/bootstrap.py) ───────────────────────────
# ★ 온라인/lite 배포의 **첫 실행 콘솔 창**에 그대로 찍히는 문구다 — 사용자가 읽는다.
#   이 모듈은 의존성 설치 **전에** 도는데, ko.py 는 표준 라이브러리조차 import 하지
#   않는 순수 상수 모듈이라 그 시점에도 안전하다(얼린 launcher 는 online.spec 의
#   hiddenimports 로 함께 담긴다).  ※ 예외 원문을 덧붙이는 자리는 {error} 로 받는다.
BOOT_DEPS_INSTALLING = "필요한 패키지를 설치합니다 — 처음 1회, 인터넷이 필요하고 몇 분 걸립니다."
BOOT_DEPS_FAILED = "패키지 설치에 실패했습니다. 인터넷·프록시 설정을 확인한 뒤 다시 실행하세요."
BOOT_DEPS_DONE = "설치가 끝났습니다."
BOOT_PY_DOWNLOADING = "파이썬 런타임을 내려받는 중… (처음 1회, 수십 MB)"
BOOT_PY_DOWNLOAD_FAILED_FMT = "파이썬 런타임 다운로드 실패: {error}"
BOOT_PY_TOO_SMALL_FMT = (
    "받은 파일이 너무 작습니다({n} bytes) — 회사 프록시가 차단 페이지를 돌려줬을 수 있습니다."
)
BOOT_PY_EXTRACTING = "파이썬 런타임을 푸는 중…"
BOOT_PY_EXTRACT_FAILED_FMT = "파이썬 런타임 압축 해제 실패: {error}"
BOOT_PY_NOT_FOUND = "파이썬 런타임을 풀었지만 실행 파일을 찾지 못했습니다."
BOOT_PY_UNAVAILABLE = "파이썬 런타임을 준비하지 못해 시작할 수 없습니다."
BOOT_APP_DOWNLOADING = "앱을 내려받는 중…"
BOOT_APP_DOWNLOAD_FAILED = "앱 다운로드 실패 — 인터넷 연결을 확인하세요."
BOOT_DEPS_INSTALLING_FIRST = "필요한 패키지를 설치하는 중… (처음 1회, 인터넷 필요)"
BOOT_DEPS_FAILED_SHORT = "패키지 설치 실패 — 인터넷/프록시 설정을 확인하세요."
BOOT_APP_STARTING = "앱을 시작합니다…"

# ── 자동화 수준 (#3 올인원 모드) ───────────────────────────────────────────
AUTOMATION_TITLE = "자동화 수준"
AUTOMATION_USER_SELECT = "사진 직접 선택 + 매치는 자동"
AUTOMATION_AUTO_ALL = "모든 사진 자동 — 후보 선별 건너뛰기"
# 세그먼트에 들어가는 짧은 라벨.  긴 설명은 위 두 문구가 툴팁으로 맡는다 —
# 34px 세그먼트에 문장을 넣으면 '작게'라는 의도가 폭으로 되돌아온다.
AUTOMATION_USER_SELECT_SHORT = "사진 직접 선택"
AUTOMATION_AUTO_ALL_SHORT = "모든 사진 자동"
# ── 매치 검토 페이지 ───────────────────────────────────────────────────────
BTN_MARK_NO_MATCH = "매치 없음 ✕"
BTN_RESTORE_MATCH = "되돌리기 ↩"
# ※ [다음 예외로] 탐색 버튼은 사용자 결정으로 제거했다 — 그 문구도 함께 지웠다.
BTN_FINISH_REVIEW = "검토 완료 ▶"
RUNNERUP_TOOLTIP = "클릭하면 이 사진으로 매치를 교체합니다."
# A2 밀집 리스트 — 상단 집계 바 / 판정 칩 / 컴팩트 토글 (#A2)
TALLY_OK_FMT = "일치 {n}"
TALLY_OVER_FMT = "허용 초과 {n}"
TALLY_NO_MATCH_FMT = "매치 없음 {n}"
TALLY_COORD_FAILED_FMT = "매치 실패 {n}"
# 네 낱말이 서로 어떻게 다른지 화면에서 설명한다 (U-13) — 이름만 봐서는
# '매치 없음' 과 '매치 실패' 가 같은 말로 읽힌다.
TALLY_TOOLTIP = (
    "일치 — 짝을 찾았고 허용 오차 안에 든 매치입니다.\n"
    "허용 초과 — 짝은 찾았지만 좌표 차이가 허용 오차를 넘었습니다.\n"
    # ★ 여기서 다섯째 낱말을 만들지 않는다.  예전엔 "직접 '매치 아님' 으로 되돌린" 이라
    #   적었는데 화면에 '매치 아님' 이라는 라벨은 없다(버튼은 BTN_MARK_NO_MATCH='매치
    #   없음 ✕', 칩은 CHIP_NO_MATCH='매치 없음').  네 낱말의 차이를 설명하는 툴팁이
    #   그 자리에서 없는 낱말을 새로 만들면 안 된다.
    "매치 없음 — 검토에서 직접 ‘매치 없음’ 으로 되돌린 것입니다.\n"
    "매치 실패 — 가장 가까운 후보조차 허용 오차의 3배를 넘어 짝으로 볼 수"
    " 없었습니다 (이 화면에서는 고칠 수 없습니다).\n"
    # 화면('매치 없음')과 엑셀('미매칭')의 낱말이 다른 유일한 자리 — 다리를 놓아 둔다.
    "※ 매치 없음·매치 실패는 결과 엑셀에서 ‘미매칭’ 으로 적힙니다."
)
BTN_FINISH_REVIEW_KEPT_FMT = "검토 완료 · 유지 {n}"   # ⏎ 제거 — Enter 단축키가 없어졌다
CHIP_OVER = "허용 초과"
CHIP_NO_MATCH = "매치 없음"
BTN_NO_MATCH_COMPACT = "×"
BTN_RESTORE_COMPACT = "↩"
REVIEW_EMPTY_HINT = (
    # ★ 화면의 버튼 이름과 같게 적는다 — 예전엔 [완료] 라고 안내했지만 실제 버튼은
    #   '검토 완료 · 유지 n' 이라, 있지도 않은 버튼을 찾게 만들었다.
    "자동 매치된 항목이 없습니다.  [검토 완료] 를 누르면 결과 화면으로 이동합니다."
)
# 교차검증 1차 검토 — 다음은 결과가 아니라 2차 선별이다(문구가 틀린 곳으로 안내하던 것).
REVIEW_EMPTY_HINT_CROSS_A = (
    "자동 매치된 항목이 없습니다.  [검토 완료] 를 누르면 2차 선별로 이동합니다."
)
# 검토 리스트 컬럼 헤더 — ★ 이미지 세 종류를 **각자 자기 사진 위**에 놓기 위해
# 하나였던 'COL_IMAGES = 기준 · 검증 · 후보' 를 셋으로 쪼갰다(한 라벨이면 어느 것도
# 자기 사진 위에 없다).  폭 정렬은 match_review_page._sync_header_widths 가 맞춘다.
COL_SLOT = "슬롯"
COL_REF = "기준"
COL_VAL = "검증"
COL_CANDIDATES = "후보"
COL_DISTANCE = "거리(µm)"
# 구형(유사도) 엔진에서는 같은 열이 거리가 아니라 유사도를 보여준다.
COL_SIMILARITY = "유사도(%)"
COL_VERDICT = "판정"
COMPARE_REF_CAPTION_FMT = "기준 — {name}"
COMPARE_VAL_CAPTION_FMT = "검증 — {name}"     # 교차검증 역방향
# 비교 뷰어 상단 조작 힌트.  확대/이동은 **마우스가 올라간 쪽 사진에만** 적용된다
# (사용자 결정) — 기준을 그대로 두고 후보만 파고들어 볼 수 있다.
COMPARE_HINT = "← → 후보 이동 · 휠 확대/축소 · 드래그 이동 (사진마다 따로)"
# 액션 버튼이 달려 열린 비교 뷰어 전용 — Enter 로 확정할 수 있다는 사실을 싣는다.
# Stage 2 확대 보기(match_expand_view)가 이미 ←/→ + Enter + Esc 문법을 쓰므로,
# 같은 목적의 이 화면만 키가 다르면 손이 마지막에만 마우스로 옮겨 간다.
COMPARE_HINT_ACTION = (
    "← → 후보 이동 · Enter 선택 · 휠 확대/축소 · 드래그 이동 (사진마다 따로)")
# 단일 풀스크린 뷰어 — 화면에 사진 말고는 아무 표시가 없어 확대가 되는 줄 모른다.
VIEWER_HINT = "휠 확대/축소 · 드래그 이동 · Ctrl+C 원본 복사 · Esc 닫기"
# Scan 범위 박스가 있는 뷰어 — 박스 밑 결함을 보려고 끄는 버튼.
VIEWER_CROP = "크롭하기"
VIEWER_CROP_CANCEL = "크롭 취소"
VIEWER_CROP_TIP = "드래그한 구역을 원본 화질 그대로 복사합니다"
VIEWER_CROP_HINT = "복사할 구역을 드래그하세요"
VIEWER_COPIED_FULL = "원본 복사됨"
VIEWER_COPIED_CROP = "구역 복사됨 ({w}×{h}px)"
VIEWER_BOX_OFF = "박스 끄기"
VIEWER_BOX_ON = "박스 켜기"
VIEWER_BOX_TIP = "Scan 범위 박스를 숨기거나 다시 보여줍니다 (B)"
# ※ 검토 화면의 키보드 상호작용(↑↓ 줄 이동 · R 매치 없음 · Enter 검토 완료)과 키캡 힌트
#   줄, '확인 필요만' 필터는 제거했다.  '매치 없음'은 행마다 있는 ✕ 토글, '검토 완료'는
#   상단 버튼이 한다.  Enter 가 검토 전체를 끝내던 것은 특히 위험했다.
# 카드 제목 옆 '?' 도움말 토글 (하드코딩 금지 — 사용자 노출 문자열은 여기 모은다)
HELP_TOGGLE_TOOLTIP = "설명 보기/숨기기"

# ※ 배치안 스위처(LAYOUT_*)와 C안 요약(SETUP_DETAIL_*·SUMMARY_*) 문구는 제거했다 —
#   사용자가 '순서형' 배치를 확정하면서 비교용 스위처와 미선택 2안이 함께 사라졌다.
#   지금 판정 기준을 말하는 것은 상단 모드 배지(judgement_text) 하나다.

# ── 여정 레일(창 상단 상시 진행 지도, 구조개편 1안-A) ─────────────────────────
# ★ 이름은 **화면 표제와 같은 말**이어야 한다 — 레일이 "후보 선별" 이라 하고 화면이
#   "Stage 1 — 후보 선별" 이라 하면 사용자가 둘을 맞춰 보는 데 한 박자를 쓴다.
#   레일은 짧은 쪽(단계 이름)만 적고, 긴 표제는 화면이 계속 담당한다.
JOURNEY_RAIL_STEPS = ("설정", "후보 선별", "매칭", "매치 검토", "결과")
# Defect 추출 — 매칭·검토·결과 화면이 없다(사용자 결정: 3단계로 줄이기).
EXTRACT_JOURNEY_RAIL_STEPS = ("설정", "후보 선별", "저장")
# 교차검증 — 선별·매칭·검토를 기준→검증(1차), 검증→기준(2차) 두 번 돈다.
CROSS_JOURNEY_RAIL_STEPS = ("설정", "1차 선별", "1차 매칭", "1차 검토",
                            "2차 선별", "2차 매칭", "2차 검토", "결과")
JOURNEY_RAIL_BACK_TOOLTIP_FMT = "{step} 단계로 돌아갑니다 — 이후 결정은 폐기됩니다."
# 검토 화면에서 설정으로 되돌아갈 때.  선별·매칭은 각 화면이 이미 자기 확인 문구를
# 갖고 있어 그대로 쓰고, 검토에는 그런 경로가 없었으므로 여기서 묻는다.
JOURNEY_BACK_TO_SETUP_TITLE = "설정으로 돌아갈까요?"
JOURNEY_BACK_TO_SETUP_BODY = (
    "지금까지의 매칭·검토 결과가 모두 사라지고 처음부터 다시 시작합니다.\n"
    "저장하지 않은 결과는 복구할 수 없습니다.")

# ※ '모션 줄이기' 토글은 제거했다 — 모션은 항상 켜진다(사용자 결정).
LOAD_SCAN = "폴더 스캔 중…"          # 여정 규칙은 LOAD_JOURNEY_STEPS 주석 참조
LOAD_EXPORT = "엑셀로 저장 중…"

# ── 경고/안내 모달 ─────────────────────────────────────────────────────────
WARN_SAME_PATH_TITLE = "경로 확인"
WARN_SAME_PATH_BODY = (
    "기준 장비와 검증 장비의 경로가 동일합니다.\n"
    "정말로 같은 폴더를 비교하시겠습니까?"
)
WARN_PATH_NOT_EXIST = "선택한 경로가 존재하지 않습니다:\n{path}"
WARN_NO_SLOTS = "두 폴더에 공통된 슬롯이 존재하지 않습니다."
# 폴더 스캔이 실패했을 때 (U-05) — 예전엔 로딩만 켜진 채 앱이 잠긴 것처럼 보였다.
WARN_SCAN_FAILED_FMT = (
    "폴더를 읽는 중 문제가 생겼습니다.\n"
    "폴더가 그대로 있는지, 접근 권한이 있는지 확인한 뒤 다시 시도해 주세요.\n\n"
    "{detail}"
)
WARN_NO_IMAGES = "선택된 슬롯에 이미지가 없습니다."
WARN_SLOT_MISMATCH_TITLE = "슬롯 불일치"
WARN_SLOT_MISMATCH_FMT = (
    "한쪽에만 존재하는 슬롯이 있습니다.\n"
    "사용자가 직접 슬롯 매핑을 정해주실 수 있습니다.\n\n"
    "기준 전용: {ref_only}\n검증 전용: {val_only}"
)
SLOT_MAP_TITLE = "슬롯 수동 매핑"
SLOT_MAP_HINT = (
    "남은 슬롯을 직접 짝지어 주세요. 양쪽에서 하나씩 골라 ‘묶기’, 다시 누르면 해제."
)
SLOT_MAP_REF_LABEL = "기준 (남은 슬롯)"
SLOT_MAP_VAL_LABEL = "검증 (남은 슬롯)"
SLOT_MAP_ADD = "묶기 ↔"
SLOT_MAP_REMOVE = "선택 해제"
SLOT_MAP_PAIRS_LABEL = "묶은 쌍"
# ※ SLOT_MAP_OPEN('매핑 다이얼로그 열기')은 제거했다 — 전 저장소 참조 0건.
#   확인창은 SLOT_MAP_ASK 문장 + 표준 예/아니오 버튼을 쓴다(U-23).
# 확인창 본문용 완결 문장 — 라벨에 " ?" 를 붙여 만들던 비문을 대체한다.
SLOT_MAP_ASK = "슬롯을 직접 짝지어 주시겠습니까?"

# ── 일부 슬롯만 진행 (Setup) ───────────────────────────────────────────────
SLOT_SELECT_BTN_TOOLTIP = (
    "기준 폴더의 슬롯 중 이번 검증에서 진행할 슬롯만 선택합니다.\n"
    "선택하지 않으면 모든 공통 슬롯을 진행합니다."
)
SLOT_SELECT_TITLE = "슬롯 선택"
# 다이얼로그 상단 — 지금 무엇이 진행되는지 **큰 글자로** 말한다(이전엔 '선택 3 / 24' 뿐).
SLOT_SELECT_COUNT_HEAD_FMT = "{total}개 중 {n}개 선택"
SLOT_SELECT_COUNT_HEAD_ALL = "모든 슬롯 선택 ({total}개)"
SLOT_SELECT_SEARCH_PLACEHOLDER = "슬롯 이름으로 찾기"
SLOT_SELECT_FILTER_HIT_FMT = "‘{q}’ 검색 결과 {n}개"
SLOT_SELECT_FILTER_NONE_FMT = "‘{q}’ 와 맞는 슬롯이 없습니다"
SLOT_SELECT_PICK_VISIBLE = "검색 결과 선택"
# 0개로 확인하면 호출부가 '전체 진행'으로 정규화한다 — 의도와 정반대라 막고 이유를 말한다.
SLOT_SELECT_NEED_ONE = "최소 한 개는 선택해야 합니다."
# ※ SLOT_SELECT_KEY_HINT 는 제거했다 — 타일 키보드 조작을 없앴으므로(사용자 결정)
#   안내할 키가 남지 않았다.  화면에 지키지 못할 약속을 적어 두지 않는다.
SLOT_SELECT_HINT = (
    "이번에 쓸 슬롯을 눌러 고르세요. 이름을 알면 위에서 바로 찾을 수 있습니다.\n"
    "고르지 않은 슬롯은 이번 작업에서 제외됩니다."
)
SLOT_SELECT_ALL = "전체 선택"
SLOT_SELECT_NONE = "전체 해제"
# 타일 둘째 줄 — 그 슬롯에 사진이 몇 장인지(사용자 요청: "slot별로 몇 개 있는지 보이게").
# ★ 세는 것은 **결함 사진 장수**다(`models.slot.count_images`) — 웨이퍼 전경 사진은
#   빠지므로 검증이 실제로 도는 장수와 같다.  좌표 항목 수가 아니다.
# ★ 폴더를 열거해야 알 수 있어 워커가 채운다.  채워지기 전에는 빈칸이 아니라
#   '확인 중…' 을 보여 준다(로딩바 계약과 같은 취지 — 모를 때도 멈춰 보이지 않게).
SLOT_SELECT_TILE_COUNT_FMT = "기준 {ref} · 검증 {val}"
SLOT_SELECT_TILE_COUNT_PENDING = "확인 중…"
SLOT_SELECT_TILE_COUNT_NONE = "—"      # 검증 폴더에 그 슬롯이 없다
# KLA 폴더 타일 이름 — 폴더명(검사 시각) 대신 정보파일의 WaferID·Slot 번호(사용자 요청).
SLOT_SELECT_KLA_FMT = "{wafer_id}  ·  슬롯 #{slot}"
SLOT_MAP_FOLDER_TIP_FMT = "폴더: {folder}"
# 진행 범위 타일 — 상태를 옆 라벨이 아니라 타일 자신이 말한다.
SCOPE_TITLE = "진행 범위"
SCOPE_ALL = "모든 슬롯"
SCOPE_SUBSET = "일부 슬롯만"
SCOPE_SUBSET_COUNT_FMT = "일부 슬롯 ({n}/{total})"
# 입력 유효성 — 왜 [검증 시작] 을 누를 수 없는지 눈에 보이게.
SETUP_INVALID_FOLDER = "폴더를 찾을 수 없습니다."
START_BLOCKED_HINT = "기준·검증 폴더를 먼저 지정하세요."
# 폴더 존재 확인이 아직 안 끝났을 때 — 네트워크 폴더는 응답이 느릴 수 있다 (P-15).
START_CHECKING_HINT = "폴더를 확인하는 중입니다…"
# 폴더는 다 골랐는데 아직 구성 요소를 불러오는 중일 때 — 곧 저절로 풀린다.
START_PREPARING_HINT = "구성 요소를 불러오는 중입니다. 잠시만 기다려 주세요."
# 그 불러오기가 실패한 경우(설치 손상 등) — 시작 버튼은 잠긴 채로 둔다.
BACKEND_LOAD_FAILED_FMT = (
    "영상 처리 구성 요소를 불러오지 못했습니다.\n"
    "프로그램을 다시 설치하거나 관리자에게 문의하세요.\n\n{err}")
# 후보 선별에서 검증 대상을 한 장도 고르지 않고 끝냈을 때(사용자 요청).
# ★ 막지 않고 **묻는다** — '전부 제외' 도 유효한 결정일 수 있다(그 폴더에 검증할
#   것이 없다는 결론).  다만 그대로 넘어가면 매칭할 사진이 0장이라 다음 화면이
#   통째로 비므로, 되돌릴 기회를 한 번 준다.
SELECT_NONE_CHOSEN_TITLE = "검증 대상이 없습니다"
SELECT_NONE_CHOSEN_BODY = (
    "검증 대상으로 고른 사진이 한 장도 없습니다.\n"
    "이대로 진행하면 매칭할 사진이 없어 결과가 비어 있습니다.\n\n"
    "설정 화면으로 돌아갈까요? (아니오 = 그대로 진행)"
)
SLOT_SELECT_NEED_REF = "먼저 기준 폴더를 선택하세요."

# 이전 결과 엑셀을 기준으로 쓰기 (기준 폴더 줄의 [엑셀로])
EXCEL_REF_BTN = "엑셀로"
EXCEL_REF_BTN_TIP = "이전 결과 엑셀의 기준 사진·좌표를 기준 폴더 대신 사용"
EXCEL_REF_PICK_CAPTION = "이전 결과 엑셀 선택"
EXCEL_REF_FILTER = "엑셀 (*.xlsx)"
EXCEL_REF_LOADING = "엑셀에서 기준 사진 꺼내는 중…"
EXCEL_REF_DONE_TIP_FMT = "{name}\n사진 {photos}장 · 슬롯 {groups}개 · 좌표 {coords}장"
EXCEL_REF_DONE_BTN = "엑셀 ✓"
EXCEL_REF_ERR_NOFILE = "엑셀 파일을 찾을 수 없습니다."
EXCEL_REF_ERR_OPEN = "엑셀을 열 수 없습니다. 다른 프로그램에서 열려 있거나 손상된 파일일 수 있습니다."
EXCEL_REF_ERR_NOPHOTO = "이 엑셀에서 기준 사진을 찾지 못했습니다. 앱이 저장한 결과 엑셀인지 확인하세요."
EXCEL_REF_PICK_SHEETS_TITLE = "기준으로 쓸 시트 선택"
EXCEL_REF_PICK_SHEETS_HINT = (
    "이 엑셀은 여러 시트(LOT)에 같은 이름의 슬롯이 있습니다. "
    "섞이지 않게, 한 LOT 에 해당하는 시트만 고르세요."
)
EXCEL_REF_SHEET_COUNT_FMT = "사진 {n}장"
EXCEL_REF_SHEET_SEARCH = "시트 이름으로 찾기"
EXCEL_REF_PARTIAL_FMT = "좌표가 없는 사진 {n}장은 이미지 유사도로만 비교합니다."
SLOT_SELECT_EMPTY = "기준 폴더에서 슬롯(하위 폴더)을 찾지 못했습니다."

# ── 기준 사진 재사용 (#6) ──────────────────────────────────────────────────
REF_REUSE_TITLE = "이전 기준 사진 재사용"
REF_REUSE_BODY_FMT = (
    "이 기준 폴더로 이전에 매치를 진행한 기록이 있습니다.\n"
    "그때 직접 고른 기준 사진 {n}장을 그대로 사용하시겠습니까?\n\n"
    "예 — 해당 사진들을 자동으로 ‘검증 대상’ 으로 옮긴 상태에서 시작합니다.\n"
    "아니오 — 처음부터 직접 고릅니다."
)
# KLA slot 해석 단계 — 로딩창에 현재 진행 단계(정보파일/OCR)를 실시간 표시.
LOAD_KLA_INFO = "KLA 슬롯 매칭 중 — 정보파일 분석…"
LOAD_KLA_OCR = "KLA WaferID 판독 (OCR) 중…"

# slot 매칭 실패 시 'KLA 가 어느 쪽?' 확인 — 호기가 K-n 이면 자동, 아니면 묻는다.
KLA_ASK_TITLE = "KLA 장비 확인"
# 팝업 최상단에 크게·색상으로 강조되는 핵심 질문(#2).
KLA_ASK_SIDE_HEADING = "KLA 장비가 어느 쪽인가요?"
KLA_ASK_SIDE_BODY = "KLA(WaferID) 장비 위치를 선택하세요. 없으면 ‘KLA 아님’."
KLA_SIDE_REF = "기준"
KLA_SIDE_VAL = "검증"
KLA_SIDE_BOTH = "둘다"
KLA_SIDE_NONE = "KLA 아님"

INFO_RESUME_TITLE = "이전 검증 설정 복원"
# ★ 문구를 사실대로 적는다.  '이어하기' 라고 했지만 실제로 복원되는 것은 폴더·호기·
#   임계치 같은 **입력값뿐**이고, 선별 결정은 처음부터 다시 한다.  다만 직접 고른
#   기준 사진은 기록해 두므로 선별 화면에서 '재사용할까요?' 로 되돌려 받을 수 있다.
INFO_RESUME_BODY = (
    "마치지 못한 검증이 있습니다.  이전 입력값(폴더·호기·판정 기준)을 복원해 "
    "처음부터 다시 시작할까요?\n\n"
    "선별은 다시 하게 되지만, 직접 고르셨던 기준 사진은 선별 화면에서 "
    "재사용할지 물어봅니다."
)
# ※ INFO_PHASE_TRANSITION_TITLE('단계 전환')·INFO_PHASE_A_TO_MATCH 는 제거했다 —
#   U-14 로 '선택지 없는 안내 모달' 을 없앨 때 문구만 남아 참조가 0건이었다
#   (`dev/tests/test_sheet_default_and_flow.py::test_phase_transition_modal_is_gone`).
# ⚠ 아래 문구는 **지금 화면에 뜨지 않는다** — 호출부 두 곳이 모두 `if not self._auto_mode:`
#   안이고, 자동화 수준 두 가지가 둘 다 `AutomationLevel.AUTO_MODES` 라 2단계는 언제나
#   자동이다.  수동 스트리밍 경로가 되살아날 때를 대비해 문구·경로를 남기되, 화면에
#   없는 영어 낱말('Skip')과 낱말 규약을 어긴 표기는 지금 고쳐 둔다.
INFO_NO_MATCH_FOUND = "조건에 맞는 검증 후보가 없습니다. 자동으로 ‘매치 없음’ 으로 처리됩니다."
INFO_NO_VAL_PHOTOS = "이 슬롯에 검증 사진이 없습니다. 자동으로 ‘매치 없음’ 으로 처리됩니다."
INFO_ALREADY_MATCHED_SECTION = "이미 매칭됨 (자동 제외)"

# ── 저장/엑셀 ──────────────────────────────────────────────────────────────
# 마지막 저장 직전에 뜨는 제목 확인창(사용자 요청).  여기서는 **이름만** 정한다 —
# 파일은 이 창에서 이름을 확정한 뒤에야 만들어진다(검증 시작 때 미리 만들지 않는다:
# 저장까지 안 간 세션마다 빈 xlsx 가 남았다).
SAVE_NAME_TITLE = "저장할 파일 이름"
SAVE_NAME_BODY = (
    "아래 이름으로 저장합니다. 필요하면 고쳐 주세요.\n"
    "규칙: 장비 자재_Layer_S/M 검증(기준 장비 기준)"
)
SAVE_NAME_CROSS_BODY = (
    "아래 이름으로 저장합니다. 필요하면 고쳐 주세요.\n"
    "규칙: 기준 장비 vs 검증 장비 자재_Layer_S/M 교차검증"
)
SAVE_NAME_FOLDER_FMT = "저장 폴더: {path}"
# 이름 아래 칸들 — 추천값이 들어 있고, 고친 뒤 버튼을 누르면 위 이름을 다시 만든다(사용자 요청 2026-10-30).
SAVE_NAME_FIELDS_HINT = "아래 값을 고친 뒤 ‘제목 자동 생성’을 누르면 위 이름이 바뀝니다. 비워 둔 값은 제목에서 빠집니다."
SAVE_NAME_AUTO = "제목 자동 생성"
SAVE_NAME_FIELD_VAL = "검증 장비"
SAVE_NAME_FIELD_REF = "기준 장비"
SAVE_NAME_FIELD_MACHINE = "장비"
SAVE_NAME_FIELD_LAYER = "Layer"
SAVE_NAME_FIELD_MATERIAL = "자재"
SAVE_NAME_FIELD_SM = "S/M"
SAVE_NAME_OK = "이 이름으로 저장"
SAVE_NAME_CANCEL = "취소"
SAVE_NAME_EMPTY = "이름을 비워 둘 수 없습니다."
SAVE_NAME_BAD_CHARS = "파일 이름에 쓸 수 없는 문자가 있습니다:  \\ / : * ? \" < > |"
SAVE_DIALOG_TITLE = "결과 엑셀 저장 위치 선택"
SAVE_FILENAME_FMT = "AOI검증결과_{ref}_vs_{val}_{ts}.xlsx"
SAVE_SUCCESS_FMT = "엑셀 저장 완료:\n{path}"
SAVE_FAIL_FMT = "엑셀 저장 실패:\n{error}"
# ★ 가장 흔한 실패는 결과 파일이 엑셀에서 열려 있는 경우다.  OS 원문만 보여 주면
#   무엇을 해야 할지 알 수 없으므로 **다음 행동을 먼저** 말한다.
SAVE_FAIL_LOCKED_FMT = (
    "결과 파일에 쓸 수 없습니다.\n\n"
    "그 파일이 엑셀에서 열려 있으면 닫은 뒤 다시 시도해 주세요.\n"
    "(다른 프로그램이 쓰고 있거나 폴더 권한이 없을 때도 같은 오류가 납니다.)\n\n"
    "원문: {error}"
)
# ⚠ **엑셀 표기만 예외로 'Slot' 을 남긴다.**  화면 문구는 전부 '슬롯' 으로 통일했지만
#   (STAT_SLOT_MISMATCH·WARN_SLOT_MISMATCH_*·SLOT_MAP_TITLE·SLOT_LABEL_FMT·
#   LOT_COUNTS_PREFIX·WARN_NO_SLOTS·WARN_NO_IMAGES·LOAD_KLA_INFO), 시트 이름·헤더는
#   현장 양식과 맞춰야 하므로 확인 전까지 건드리지 않는다(같은 이유로 `NOTE_UNMATCHED`
#   의 '미매칭' 도 남는다 — 다리는 TALLY_TOOLTIP 이 놓는다).
SLOT_MISMATCH_SHEET = "Slot 불일치 목록"
SHEET_UNMATCHED = "미매칭 사진"
# 미매칭 행 D열 — 결함 geometry(area/width/length/contrast) 표기.  Surface.flt 에서
# 환산해 파일명 아래 회색 글씨로 덧붙인다.  값을 못 얻을 때의 명시적 마커:
GEOM_NOT_SUPPORTED = "측정정보 미지원 자재"   # Surface.flt 자체가 없는 자재(예: KLA)
GEOM_NO_DATA = "측정정보 없음"               # Surface.flt 는 있으나 매칭 실패
# KLA 결함 — 변환값(Camtek 좌표계) 아래에 KLA 자체 원본 좌표(XREL/YREL)도 표기.
# ★ 줄바꿈은 붙이지 않는다 — 줄을 잇는 쪽(엑셀 exporter)이 "\n" 을 앞에 붙인다.
EXPORT_KLA_NATIVE_FMT = "KLA원본 x {x:.0f} / y {y:.0f} ㎛"
# 결과 화면 — 체크박스 셋이 무엇에 걸리는 옵션인지 밝히는 캡션.  셋 다 [엑셀로
# 저장]에만 걸리는데 캡션이 없어 '화면 보기 옵션' 으로 오독됐다.
EXPORT_OPTIONS_CAPTION = "엑셀 저장 옵션"
# ── 저장 목적지 미리보기 (구조개편 31안) ─────────────────────────────────────
# ★ 누르기 전에 '무엇이 어디에 생기는가' 를 말한다.  두 상태다 — 저장 전과,
#   한 번 저장한 뒤(같은 파일에 덮어쓴다).  두 번째 저장이 대화상자 없이 조용히
#   덮어쓰던 것이 이 화면에서 가장 놀라운 동작이었다.
# ★ 전체 경로는 툴팁이 갖는다 — 긴 UNC 경로가 버튼 줄을 밀어내면 정작 버튼이 밀린다.
SAVE_TARGET_FMT = "저장 파일명: {name}"
SAVE_TARGET_AGAIN_FMT = "다시 저장: 같은 파일에 덮어씀 · {path}"

# 결과 화면 — 미매칭 사진만 원본 화질로 임베드 옵션 (기본 해제).
EXPORT_UNMATCHED_ORIGINAL_LABEL = "미매칭 사진만 원본 화질로 넣기"
EXPORT_UNMATCHED_ORIGINAL_TOOLTIP = (
    "체크하면 미매칭 사진만 원본 화질 그대로 임베드합니다.\n"
    "매칭된 사진은 중간 화질 캐시를 그대로 써서 파일이 크게 늘지 않습니다.\n"
    "‘사진을 원본 화질로 넣기’ 를 켜면 이 옵션과 무관하게 모든 사진이 원본 화질입니다."
)
# 결과 화면 — 사진을 원본 화질로 임베드 옵션 (기본 해제).
EXPORT_ORIGINAL_QUALITY_LABEL = "사진을 원본 화질로 넣기"
EXPORT_ORIGINAL_QUALITY_TOOLTIP = (
    "체크하면 셀에 들어가는 사진을 줄이지 않고 원본 화질 그대로 임베드합니다.\n"
    "기본(해제)은 중간 화질 캐시를 사용해 더 빠르고 가벼운 파일이 됩니다.\n"
    "원본은 화질이 좋지만 파일 용량이 크게 늘고 저장이 느려질 수 있습니다."
)

# ── 단일 사진 정보 ─────────────────────────────────────────────────────────
# 사진 한 장에서 뽑은 결함 계측.  `coords.single_info` 가 유일한 생산자이고 두 화면이
# **같은 수치**를 쓴다 — 엑셀 미매칭 행(D열)은 `_FMT`(한 줄), 정보 화면은
# `_LABEL`/`_VALUE_FMT`(제도 시트 표의 2열).  셋은 한 자리에서 같은 값으로 채워진다.
DEFECT_RECIPE_ZONE_LABEL = "recipe / zone"
DEFECT_RECIPE_ZONE_VALUE_FMT = "{recipe} / {zone}"
DEFECT_RECIPE_ZONE_FMT = "recipe {recipe} / zone {zone}"
DEFECT_AREA_LABEL = "area"
DEFECT_AREA_VALUE_FMT = "{v:.2f} ㎛²"
DEFECT_WIDTH_LABEL = "width"
DEFECT_WIDTH_VALUE_FMT = "{v:.2f} ㎛"
DEFECT_LENGTH_LABEL = "length"
DEFECT_LENGTH_VALUE_FMT = "{v:.2f} ㎛"
DEFECT_CONTRAST_LABEL = "contrast"
DEFECT_CONTRAST_VALUE_FMT = "{v:.2f}"
# contrast 는 일부 자재(예: PI)만 측정 — 0 은 ‘측정 안 함’이라 0.00 대신 ‘—’.
DEFECT_CONTRAST_NONE_VALUE = "—"
DEFECT_COLROW_LABEL = "col / row"
DEFECT_COLROW_VALUE_FMT = "{col} / {row}"
DEFECT_COLROW_FMT = "col {col} / row {row}"
DEFECT_XY_LABEL = "x / y"
DEFECT_XY_VALUE_FMT = "{x:.0f} / {y:.0f} ㎛"
DEFECT_XY_FMT = "x {x:.0f} / y {y:.0f} ㎛"
DEFECT_KLA_NATIVE_LABEL = "KLA원본 x / y"
# die pitch 를 못 찾아 die 로 쪼개지 못한 경우(source="camtek_abs") — 있는 사실만 적는다.
# col 도 상수 오프셋이라 제품에 따라 틀리므로 숫자 대신 경고를 적는다(사용자 결정 2026-10-25).
DEFECT_COL_ONLY_LABEL = "col / row"
DEFECT_COL_UNKNOWN_VALUE = "⚠ 확인 불가"
DEFECT_COL_UNKNOWN_FMT = "⚠ col / row 확인 불가 — die 격자 정보를 못 읽음 (장비 화면으로 확인)"
# 번호가 틀렸을 수 있을 때만 붙는 경고 — 정상이면 아무것도 붙이지 않는다(사용자 결정 2026-10-25).
DEFECT_NUMBER_WARN_LABEL = "⚠ 번호"
DEFECT_NUMBER_WARN_NO_TABLE = "장비 번호표·die 목록이 없고 계산이 서로 달라 확실하지 않은 col / row — 장비 화면으로 확인"
DEFECT_NUMBER_WARN_KLA_GUESS = "KLA 파일에 웨이퍼 중심이 없어 추정한 col / row — 장비 화면으로 확인"
DEFECT_NUMBER_WARN_FMT = "⚠ {text}"
DEFECT_ABS_XY_LABEL = "wafer x / y"
DEFECT_ABS_XY_FMT = "wafer x {x:.0f} / y {y:.0f} ㎛"

# 화면 전용 라벨 — 파일 하나에서만 의미 있는 항목(엑셀에는 나가지 않는다).
IMAGE_INFO_LOADING = "사진 정보를 불러오는 중"
IMAGE_INFO_GROUP_FILE = "파일"
IMAGE_INFO_GROUP_DEFECT = "결함 계측"
IMAGE_INFO_COL_VALUE = "값"
IMAGE_INFO_ROW_FILE = "파일명"
IMAGE_INFO_ROW_FOLDER = "폴더"
IMAGE_INFO_ROW_WAFER_ID = "WaferID"
IMAGE_INFO_ROW_SOURCE = "좌표 출처"
IMAGE_INFO_ROW_ABS_XY = "절대 X / Y"
IMAGE_INFO_ROW_PIXEL = "픽셀 크기"
IMAGE_INFO_ABS_XY_FMT = "{x:.0f} / {y:.0f} ㎛"
IMAGE_INFO_PIXEL_FMT = "{v:.3f} ㎛/px"
# 판정 스탬프 — 측정정보 유무를 한눈에.  미지원/없음은 GEOM_* 를 그대로 쓴다.
IMAGE_INFO_STAMP_MEASURED = "측정정보 있음"
# DefectCoord.source 코드 → 사람이 읽는 이름.
IMAGE_INFO_SOURCE_NAMES = {
    "camtek_live": "Camtek LIVE 파일명",
    "camtek_ini": "Camtek 정보파일(INI)",
    "camtek_abs": "Camtek 정보파일(INI) — 절대 wafer 좌표",
    "kla": "KLA 정보파일",
}

# 다이얼로그.
IMAGE_INFO_BUTTON = "사진 정보 보기"
IMAGE_INFO_TITLE = "단일 사진 정보"
IMAGE_INFO_SUBTITLE = "결과 엑셀에 찍히는 것과 같은 좌표·계측값을 사진 한 장에서 바로 읽습니다"
IMAGE_INFO_PICK = "사진 선택"
IMAGE_INFO_PICK_ANOTHER = "다른 사진"
IMAGE_INFO_FILE_FILTER_FMT = "사진 파일 ({patterns})"
IMAGE_INFO_DROP_HERE = "여기에 놓으세요"
IMAGE_INFO_NO_FILE = (
    "사진을 이 창으로 끌어다 놓거나, ‘사진 선택’(Ctrl+O) 을 누르세요.\n\n"
    "계측값은 사진이 든 폴더의 정보파일에서 읽습니다 — "
    "ColorImageGrabingInfo.ini(Camtek) · KLA 정보파일 · Surface.flt.\n"
    "사진만 따로 복사한 폴더에서는 일부 항목이 나오지 않습니다."
)
IMAGE_INFO_EMPTY = (
    "이 사진에서 읽을 수 있는 결함 정보가 없습니다.\n"
    "폴더에 정보파일(ColorImageGrabingInfo.ini / KLA 정보파일 / Surface.flt)이 "
    "있는지 확인하세요."
)
IMAGE_INFO_COPY = "전체 복사"
# 업데이트 안내 — 업데이트 후 첫 실행 때 한 번(항목은 `i18n/whats_new.py`).
WHATS_NEW_TITLE = "업데이트 안내"
WHATS_NEW_KICKER_FMT = "UPDATE · {date}"
WHATS_NEW_OTHERS = "그 밖에 달라진 점"
WHATS_NEW_NOTICE = "주의"
WHATS_NEW_OK = "좋아요"
IMAGE_INFO_COPIED = "복사했습니다"

# ── Scan 이미지 (Color 결함 위치를 같은 폴더 Scan 사진에서 300㎛ 로 잘라 보임) ──
# Scan 이 없는 사진에서는 칸 자체를 만들지 않는다(사용자 결정) — '없음' 문구는 화면에 없다.
SCAN_IMAGE_TITLE = "Scan image"
SCAN_IMAGE_LOADING = "Scan 이미지 불러오는 중"
# 불러오는 동안 문구 아래에서 도는 점 — 폭이 같은 프레임이라 글자가 흔들리지 않는다.
SCAN_IMAGE_LOADING_DOTS = ("●  ○  ○", "○  ●  ○", "○  ○  ●", "○  ●  ○")
SCAN_IMAGE_UNREADABLE = "Scan 이미지를 읽을 수 없음"
SCAN_IMAGE_OPEN_TIP = "누르면 전체 Scan 이미지에서 이 범위를 보여줍니다"
# 엑셀 — Scan 열 머리(2행)와, Scan 열이 생긴 시트에서 그 행만 Scan 이 없을 때의 칸 문구.
SCAN_EXCEL_HEADER_FMT = "{machine} Scan"
SCAN_EXCEL_HEADER = "Scan"
SCAN_EXCEL_NONE = "Scan 없음"
SCAN_EXCEL_UNREADABLE = "Scan 이미지를 읽을 수 없음"
SCAN_EXPORT_PHASE = "엑셀로 저장 중 — Scan 이미지 확인"

# ── 일반 상태 표시 ─────────────────────────────────────────────────────────
COUNT_PLUS_N_FMT = "+{n}"
# 진행 표시는 **두 등급**으로 나뉜다 — 슬롯명은 보조(mute), 수치는 모노 본문 잉크.
# 화면의 핵심 상태('몇 장 남았나')가 가장 약한 잉크에 묻혀 있던 것을 올린 결과다.
# 자동 매치 중(우측 후보 패널을 떼어 낸 상태) 중앙 카드 아래 한 줄 안내.
MATCH_AUTO_RESULT_NOTE = "매치 결과는 다음 ‘매치 검토’ 화면에서 확인합니다."
PROGRESS_SLOT_ONLY_FMT = "{slot}  ·"
PROGRESS_COUNT_FMT = "{done} / {total}"
GROUP_HEADER_FMT = "{slot}  ·  {count}장"
GROUP_HEADER_NO_FMT = "{slot}\n#{no}  ·  {count}장"
# 후보 선별 상단의 슬롯별 전체 장수 — 참고용 (#2).  ★ 'LOT' 이 아니다.
LOT_COUNTS_PREFIX = "슬롯별 장수:  "

# ── UI 개선 (#11 / #13 / #16) ─────────────────────────────────────────────
# 썸네일 우클릭 컨텍스트 메뉴 — 원본 크게 보기 (#13).
CTX_VIEW_LARGER = "크게보기"
# 매치 검토 각 행 slot 라벨 아래 ‘크게 보기’ 버튼 — 좌우 비교 뷰어를 연다.
# ★ 확대 글리프(⤢/⧉ 등)를 **붙이지 않는다.**  이 글자들은 폰트 폴백이 플랫폼마다 달라
#   컬러 이모지로 렌더되는 경우가 있다(실측: 이 리눅스 캡처 박스에서 주황·파랑 화살표로
#   나왔다) — 무채색 도면 팔레트를 깨고, 대비 측정까지 오염시킨다.  버튼임은 테두리와
#   라운드가 말한다(role="rowAction").
BTN_VIEW_LARGER = "크게 보기"
# 좌우 비교 뷰어에서 ‘이 후보로 매치’ 액션 버튼 (#4).
BTN_MATCH_THIS = "이 후보로 매치"
# 차순위 후보 ‘후보 한 줄 더 보기’ / ‘접기’ 버튼 (#5/#4).
# ★ 몇 개가 더 숨어 있는지 라벨에 싣는다 — 최대 50개까지 보관하므로 개수를 모르면
#   '몇 번 더 눌러야 하는가' 를 알 수 없다.  +N 타일·'매치 없음 사진 보기 (n)' 과
#   같은 개수 표기 관습이다.
RUNNERUP_MORE_ROW_FMT = "후보 한 줄 더 보기 (+{n}) ▾"
RUNNERUP_LESS_ROW = "접기 ▴"

# ── 앱 내 메시지 시트 버튼 (widgets/sheet_host.py) ─────────────────────────
# 별도 OS 창(QMessageBox)을 대체하므로 표준 버튼 라벨도 여기서 관리한다.
# ※ 확인/취소는 이미 있는 공통 버튼을 그대로 쓴다(같은 말을 두 번 정의하지 않는다).
MSG_BTN_OK = BTN_OK
MSG_BTN_CANCEL = BTN_CANCEL
MSG_BTN_YES = "예"
MSG_BTN_NO = "아니오"
MSG_BTN_CLOSE = "닫기"


# ---------------------------------------------------------------------------
# 화면에 직접 박혀 있던 문구를 모아 온 것 (U-12).  위젯에 리터럴을 남기면
# 같은 말이 화면마다 조금씩 달라지고, 고칠 때 한 곳을 빠뜨린다.
# ---------------------------------------------------------------------------
# 좌우 비교 뷰어
VIEWER_BTN_PREV = "◀ 이전"
VIEWER_BTN_NEXT = "다음 ▶"
VIEWER_BTN_CLOSE = MSG_BTN_CLOSE
VIEWER_NO_CANDIDATES = "후보 없음"

# 매치 실패 검토
UNMATCHED_FAIL_LIST_TITLE = "실패 목록"
UNMATCHED_CAND_COUNT_FMT = "후보 {n}장 (유사도 순)"
# 후보가 300장 이상인 좌표 세션 — 유사도를 다시 계산하지 않고 좌표 매칭이 만든
# 순서를 그대로 쓴다.  그때는 위 문구('유사도 순')와 백분율이 모두 거짓이 되므로
# 순서 기준을 바로 적고, 점수 자리에는 아래 문구를 쓴다 (C-2).
UNMATCHED_CAND_COUNT_COORD_FMT = "후보 {n}장 (좌표 거리 순)"
# ★ 점수 자리에 그대로 들어가므로 **백분율만큼 짧게** 유지한다 — 타일은 고정
#   크기라(`_CandidateTile`) 길면 잘린다(실측 굵은 서체: "100.0 %"=54px,
#   "계산 안 함"=55px, "유사도 계산 안 함"=95px).  무엇을 계산 안 했는지는 바로
#   위 후보 수 문구가 말해 준다.
SCORE_NOT_COMPUTED = "계산 안 함"
# 점수 계산을 시도했지만 실패한 후보 — 0% 와 구분한다(짧게 유지).
SCORE_FAILED = "계산 불가"
UNMATCHED_CAND_NONE = "후보 0장"
UNMATCHED_REF_PREFIX = "기준 — "

# 슬롯 매핑
SLOT_MAP_METHOD_INFO = "정보파일"
SLOT_MAP_NO_PHOTO = "사진파일 없음"
SLOT_MAP_UNREAD = "판독 실패"
SLOT_MAP_NO_PHOTO_LINE = "\n⚠ 사진파일 없음"
SLOT_MAP_UNREAD_LINE = "\n→ 판독 실패 (수동 매핑)"

# 좌표 매칭 — 좌표를 못 읽은 사진의 사유 표기
COORD_MISSING = "좌표 정보가 없습니다"

# 결과/검토에서 '매치 아님' 으로 되돌린 항목의 사유
NOTE_UNMATCHED = "미매칭"
NOTE_UNMATCHED_BY_USER = "미매칭 (사용자 검토)"

# 호기 이름을 비워 두었을 때 채우는 기본값
DEFAULT_REF_MACHINE = "기준호기"
DEFAULT_VAL_MACHINE = "검증호기"

# 예외 원인을 안내문 뒤에 덧붙일 때의 머리말
CAUSE_PREFIX = "\n\n[원인] "

# ── Wafer map ────────────────────────────────────────────────────────────────
WAFER_MAP_BUTTON = "Wafer Map 보기"
WAFER_MAP_TITLE = "Wafer Map"
WAFER_MAP_SUBTITLE = "결함 사진을 웨이퍼 위 실제 위치에 찍습니다 — 휠: 확대 · 드래그: 이동 · 점에 마우스: 사진 · 점 더블클릭: 상세 정보"
WAFER_MAP_PICK_FOLDER = "폴더 선택"
WAFER_MAP_PICK_FOLDER_ANOTHER = "다른 폴더"
WAFER_MAP_PICK_FOLDER_TITLE = "웨이퍼(슬롯) 폴더 또는 LOT 폴더 선택"
WAFER_MAP_NO_FOLDER = (
    "‘폴더 선택’ 으로 사진이 든 웨이퍼(슬롯) 폴더를 고르세요.\n"
    "사진(여러 장 가능)을 끌어다 놓으면 그 결함만 봅니다.\n\n"
    "좌표는 그 폴더의 정보파일에서 읽습니다 — "
    "ColorImageGrabingInfo.ini(Camtek) · LIVE 파일명 · KLA 정보파일."
)
WAFER_MAP_NO_IMAGES = "이 폴더에는 사진이 없습니다."
WAFER_MAP_BUILD_FAILED = "Wafer Map 을 만드는 중 오류가 났습니다 — 폴더를 다시 골라 보세요(자세한 내용은 app.log)."
WAFER_MAP_NO_FRAME = "die 기하(pitch·웨이퍼 중심)를 찾지 못해 맵을 그릴 수 없습니다."
WAFER_MAP_SLOT_LABEL = "슬롯"
WAFER_MAP_ALL_SLOTS = "전체 (LOT 합산)"
WAFER_MAP_SIDE_REF_FMT = "기준 · {machine}"
WAFER_MAP_SIDE_VAL_FMT = "검증 · {machine}"
WAFER_MAP_LEGEND_MATCHED = "매치됨"
WAFER_MAP_LEGEND_UNMATCHED = "미매치"
WAFER_MAP_LEGEND_DEFECT = "결함"
WAFER_MAP_COUNT_FMT = "{n}장"
WAFER_MAP_DEFECT_TOTAL_FMT = "Defect {n:,}개"
WAFER_MAP_UNPLACED_FMT = "좌표 없음 {n}장"
WAFER_MAP_CENTER_ASSUMED = "중심 가정(±½ die)"
WAFER_MAP_GRID_COMPUTED = "die 격자: 계산값(장비 die 맵 없음)"
WAFER_MAP_PITCH_ASSUMED = "die 크기 추정(사진 좌표 기준 — 폴더에 die 크기 정보 없음, 위치 근사)"
WAFER_MAP_TIP_COLROW_FMT = "col {col} · row {row}"
WAFER_MAP_WARN_HEAD = "⚠ 이 Wafer map 은 실제와 다르게 그려졌을 수 있습니다"
WAFER_MAP_WARN_OFF_DIE_FMT = "die 가 없는 칸(또는 웨이퍼 밖)에 찍힌 사진 {n}장"
WAFER_MAP_WARN_MIXED_FRAMES = "합친 슬롯들의 die 격자가 서로 달라 다른 슬롯 점이 엉뚱한 칸에 찍힐 수 있음"
WAFER_MAP_WARN_UNPLACED_FMT = "좌표를 읽지 못해 맵에서 빠진 사진 {n}장"
WAFER_MAP_WARN_NUMBER_GUESS_FMT = "col / row 를 장비 번호표 없이 계산한 사진 {n}장 — 장비 화면으로 확인"
WAFER_MAP_WARN_PITCH_ASSUMED = "die 크기 정보가 없어 사진으로 추정함 — die 칸은 맞지만 die 크기·웨이퍼 외곽은 근사"
WAFER_MAP_WARN_LIVE_UNVERIFIED = (
    "LIVE 파일로 만든 맵은 아직 검증이 충분히 이뤄지지 않아 틀린 정보가 있을 수 있습니다 — "
    "중요한 정보는 반드시 장비 화면이나 원본 데이터로 재검토하세요")
WAFER_MAP_WARN_SIDE_FMT = "{side} — {reasons}"
WAFER_MAP_SHEET_COL_WARN = "주의(칸이 틀렸을 수 있음)"
WAFER_MAP_DISCLAIMER = (
    "※ Wafer map 은 파일명·장비 파일로 다시 그린 참고용 그림입니다. "
    "die 위치와 판정은 반드시 장비 화면이나 원본 데이터로 확인하세요."
)
WAFER_MAP_TIP_NO_DIE = "die 인덱스 없음(절대좌표)"
# die 안쪽 x·y — 장비·Conder scan 과 같은 표기.  아래 X·Y 는 웨이퍼 중심 기준이라 다르다.
WAFER_MAP_TIP_DIE_FMT = "col {col} · row {row} · x {x:,.0f} · y {y:,.0f} ㎛"
WAFER_MAP_TIP_XY_FMT = "웨이퍼 중심 기준 X {x:,.0f} · Y {y:,.0f} ㎛"
WAFER_MAP_SHEET = "Wafer Map"
WAFER_MAP_SHEET_COL_SLOT = "슬롯"
WAFER_MAP_SHEET_COL_REF = "기준"
WAFER_MAP_SHEET_COL_VAL = "검증"
WAFER_MAP_SHEET_ALL = "전체 (LOT 합산)"
# Wafer Map 시트의 기준/검증 머리칸 — 요약 시트 머리(그룹 위 · AOI-N 아래)와 같은
# 두 줄 표기.  어느 호기의 맵인지 시트만 봐도 알 수 있어야 한다(사용자 지적).
WAFER_MAP_SHEET_COL_MACHINE_FMT = "{role}\n{machine}"
WAFER_MAP_PICK_SLOTS = "슬롯 선택…"
WAFER_MAP_LOT_ALL_FMT = "{lot} · 전체 슬롯 {total}개 합산"
WAFER_MAP_LOT_SUBSET_FMT = "{lot} · 슬롯 {n}/{total} 합산"
WAFER_MAP_LOADING_SCAN = "폴더 탐색 중 — 사진 목록 확인"
WAFER_MAP_LOADING_COORDS = "좌표 읽는 중"
WAFER_MAP_LOADING_THUMBS = "사진 미리보기 준비 중"
# 보기 옵션 — die 색칠 · 노치 방향(90° 단위 회전) · 사진 1장만 보기.
WAFER_MAP_FILL_DIES = "die 색칠"
WAFER_MAP_FILL_DIES_TIP = (
    "결함 위치(점) 대신 결함이 든 die 칸을 통째로 칠합니다(점과 같은 색). "
    "die 격자를 모르는 폴더(절대좌표)에서는 점 그대로입니다.")
WAFER_MAP_UNMATCHED_FIRST = "미매치 우선"
WAFER_MAP_UNMATCHED_FIRST_TIP = (
    "한 die 칸에 매치됨·미매치 결함이 섞여 있을 때 칸 색을 정합니다. "
    "켜면 미매치 색(미매치가 가려지지 않음), 끄면 매치됨 색입니다.")
WAFER_MAP_DOT_SIZE = "점 크기"
WAFER_MAP_DOT_SIZE_TIP = "결함 점을 키우거나 줄입니다(화면 보기 전용 — die 색칠 중에는 꺼집니다)."
WAFER_MAP_NOTCH_FMT = "노치: {dir}"
WAFER_MAP_NOTCH_DIRS = ("아래", "왼쪽", "위", "오른쪽")
WAFER_MAP_NOTCH_TIP = "누를 때마다 90°씩 돌려 노치 방향을 맞춥니다(화면 보기 전용)."
WAFER_MAP_ONE_IMAGE_FMT = "{name} · 사진 1장"
WAFER_MAP_IMAGES_FMT = "사진 {n}장"
WAFER_MAP_FULLSCREEN = "전체화면"
WAFER_MAP_FULLSCREEN_EXIT = "전체화면 나가기 (ESC)"
WAFER_MAP_FULLSCREEN_TIP = (
    "맵만 남기고 주변 표시(설명·버튼·제목·범례)를 감춘 뒤 앱 창도 전체화면으로 "
    "바꿉니다. ESC 를 누르면 원래대로 돌아옵니다.")
WAFER_MAP_NO_COORD = "이 사진을 맵에 찍지 못했습니다 — 좌표 또는 die 기하를 읽지 못했습니다."

# ── 왼쪽 메뉴 — [매칭](기본 화면)·메뉴 접기(사용자 요청 2026-10-30) ──
MATCH_NAV_BUTTON = "매칭"
MATCH_NAV_TOOLTIP = "기준·검증 폴더를 고르고 매칭을 시작하는 기본 화면"
RAIL_FOLD_TOOLTIP = "메뉴 접기 (아이콘만)"
RAIL_UNFOLD_TOOLTIP = "메뉴 펼치기"

# ── Defect 추출 (매칭 없이 한쪽 폴더에서 고른 사진을 엑셀로) ─────────────────
# 흐름: 설정(한쪽만) → 후보 선별(매칭과 같은 화면) → 요약 → 저장.
EXTRACT_BUTTON = "Defect 추출"
EXTRACT_BUTTON_TOOLTIP = (
    "매칭 없이, wafer 또는 LOT 폴더에서 고른 defect 사진과 그 정보(좌표·계측)를\n"
    "엑셀로 저장합니다.")
# ★ 짧게 둔다 — [Defect 추출] 과 같은 자리를 바꿔 쓰므로, 길면 800px 창에서 액션바가
#   페이지를 창보다 넓게 민다(실측: "← 매칭 검증으로" 일 때 864px > 840px).
EXTRACT_TITLE = "Defect 추출"
EXTRACT_GROUP = "대상 장비"
# 여러 LOT — 대상 장비 카드에 줄을 늘린다(최대 10개).  줄마다 슬롯을 따로 고른다.
EXTRACT_FOLDER_PLACEHOLDER = "LOT 또는 wafer 폴더 (끌어다 놓기 가능)"
# 끌어다 놓은 폴더가 LOT 줄 최대 개수를 넘을 때.
EXTRACT_DROP_TOO_MANY_FMT = "LOT 은 최대 {max}개까지 넣을 수 있어 {n}개는 넣지 않았습니다."
EXTRACT_LOT_ADD_FMT = "+ LOT 추가 ({n}/{max})"
EXTRACT_LOT_REMOVE = "이 LOT 빼기"
EXTRACT_SLOT_BTN_ALL = "슬롯: 전체"
EXTRACT_SLOT_BTN_FMT = "슬롯 {n}/{total}"
EXTRACT_SLOT_NEED_FOLDER = "먼저 이 줄의 폴더를 선택하세요."
# 교차검증(양방향) 스위치 — 매칭 모드의 실행 옵션.  앱을 켤 때마다 꺼진 채 시작한다.
CROSS_SWITCH = "교차검증 (양방향)"
# 엑셀 — 검증에만 있는 사진 행의 메모.  기준 쪽 미매칭은 예전 그대로 '미매칭'.
NOTE_ONLY_VAL = "미매칭 (검증에만 있음)"
EXTRACT_WAFER_MAP_SWITCH = "Wafer Map 시트 넣기"
EXTRACT_WAFER_MAP_SWITCH_DESC = "끄면 엑셀에 Wafer Map 시트를 만들지 않습니다(저장이 빨라집니다)."
BTN_EXTRACT_START = "추출 시작"
# 선별 화면을 추출에 쓸 때 바꿔 끼우는 문구(`SelectPage.set_extract_mode`) — 키는 매칭
# 문구 이름 그대로다.  추출에는 '검증' 이 없다(사용자 지적).  패널 제목은 짧게 둔다
# (`test_pane_title_fits` — 매칭 제목과 글자 수가 같다).
EXTRACT_SELECT_TEXT = {
    "PANEL_LEFT_CANDIDATES": "추출 후보",
    "PANEL_LEFT_CANDIDATES_TOOLTIP": "아직 추출/제외를 결정하지 않은 남은 사진들",
    "PANEL_CENTER_DECIDE": "추출 결정할 사진",
    "PANEL_RIGHT_TARGETS": "추출 대상",
    "PANEL_RIGHT_TARGETS_TOOLTIP": "엑셀로 저장할 사진들",
    "PANEL_RIGHT_EMPTY": "→ 또는 [✓ 추출] 로 보낸 사진이 여기에 쌓입니다.",
    "BTN_VERIFY": "추출",
    "BTN_BATCH_EXCLUDE": "선택 항목 추출 제외",
    "BTN_BATCH_VERIFY": "선택 항목 추출 대상 지정",
    "BTN_INLINE_VERIFY_FMT": "선택 {n}장 추출",
    "BTN_MOVE_TO_TARGET": "추출 대상으로 이동",
    "BTN_VIEW_EXCLUDED_FMT": "제외한 사진 보기 ({n})",
    "BULK_SELECT_EXCLUDED_TITLE": "제외한 사진",
    "END_SELECTION_CONFIRM_FMT": (
        "남은 {n}장의 미결정 사진을 모두 제외하고 저장 단계로 넘어갈까요?"),
    "SHORTCUT_TOOLTIP": "단축키:  → = 추출   /   ← = 제외   /   Z = 되돌리기",
}
# 로딩 오버레이 단계 — 추출에는 매칭이 없다(마지막 단계는 선별 화면 준비).
EXTRACT_LOAD_JOURNEY_STEPS = ("폴더 스캔", "썸네일", "선별 준비")
EXTRACT_BLOCKED_HINT = "LOT 또는 wafer 폴더를 먼저 지정하세요."
EXTRACT_AUTOMATION_USER_SELECT = "추출할 사진을 직접 고릅니다"
EXTRACT_AUTOMATION_AUTO_ALL = "모든 사진 자동 — 선별 없이 전부 추출"
EXTRACT_SAVE_NAME_BODY = (
    "아래 이름으로 저장합니다. 필요하면 고쳐 주세요.\n"
    "규칙: 호기 자재_Layer_S/M Defect 추출")
EXTRACT_NONE_FOUND = "추출할 사진을 찾지 못했습니다.\n폴더를 다시 확인하세요."
EXTRACT_NONE_CHOSEN_TITLE = "고른 사진이 없습니다"
EXTRACT_NONE_CHOSEN_BODY = (
    "추출할 사진을 한 장도 고르지 않았습니다.\n\n"
    "설정 화면으로 돌아갈까요? (아니오 = 선별 화면에 남기 — Z 로 되돌릴 수 있습니다)")
EXTRACT_SUMMARY_TITLE = "Defect 추출"
EXTRACT_SUMMARY_FMT = "슬롯 {wafers}개에서 defect {n}건을 엑셀로 저장합니다."
# 저장 방식 — Recipe 로 나눌지(사용자 결정: 시트 분리 / 열 나란히 둘 다, 요약 창에서 고른다).
EXTRACT_SAVE_SINGLE = "한 시트로 저장"
EXTRACT_SAVE_SHEETS = "Recipe별 시트로 저장"
EXTRACT_SAVE_COLUMNS = "Recipe별 열로 저장"
EXTRACT_SUMMARY_LAYOUT_HINT = (
    "Recipe별 시트: Recipe 마다 시트를 나눕니다.\n"
    "Recipe별 열: 한 시트에 Recipe 마다 사진·정보 열을 옆으로 나란히 둡니다.")
# Recipe 이름(Surface.flt 의 recipe 코드 → RecipesInfo.ini 이름).  못 읽으면 아래로.
EXTRACT_RECIPE_NONE = "Recipe 없음"
EXTRACT_RECIPE_CODE_FMT = "Recipe {code}"
# 저장 첫 단계 — 엑셀에 넣을 사진을 미리 준비한다(로딩 때 만든 것이 있으면 즉시 끝난다).
EXPORT_PREPARE_IMAGES = "엑셀에 넣을 사진 준비 중…"
EXTRACT_SUMMARY_BACK = "선별로 돌아가기"
EXTRACT_SUMMARY_CANCEL = "설정으로 돌아가기"      # 선별을 건너뛴 경우(모든 사진 자동)
# 저장 파일 이름 — 결과 엑셀 제목 규칙에 '추출' 을 붙인 것(사용자 결정).
EXTRACT_FILE_TITLE_FMT = "{machine} {tag} Defect 추출.xlsx"
EXTRACT_FILE_TITLE_FALLBACK_FMT = "AOI {machine} Defect 추출.xlsx"
# 엑셀 — 요약 시트 D열 머리(C열 사진의 파일명·계측·좌표 칸)와 Wafer Map 시트 머리.
EXTRACT_INFO_HEADER = "정보"
EXTRACT_MAP_SHEET_COL = "결함 위치"

# 선별 화면 — 사진 가운데만 잘라 크게 보기(결함은 사진 정중앙).
CENTER_CROP_LABEL = "가운데 확대"
CENTER_CROP_FULL = "전체"
CENTER_CROP_TOOLTIP = "사진 가운데(결함 위치)만 잘라 크게 봅니다 — 50% 는 가운데 절반, 30% 는 더 좁게."

# 좌표 보정(KLA ↔ Camtek) — 매칭 직전, 사용자가 '같은 결함' 사진 쌍을 골라 어긋남을 뺀다.
# 보정은 매칭 계산에만 쓰이고 엑셀·화면 좌표는 바뀌지 않는다(사용자 지시).
COORD_CAL_TITLE = "좌표 보정 (KLA ↔ Camtek)"
COORD_CAL_HINT_FMT = (
    "① 왼쪽에서 {src} 사진을 고르고  ② 오른쪽에서 같은 결함인 {dst} 사진을 누르세요 — 3쌍쯤이면 충분해요. "
    "두 장비 좌표의 어긋남을 매칭 전에 보정합니다(엑셀·화면 좌표는 그대로).")
COORD_CAL_SRC_HEAD_FMT = "{side} 사진 {n}장"
COORD_CAL_SRC_MORE_FMT = "가까운 짝 후보가 있는 사진만 보여요 · 후보가 많은 {n}장은 생략"
COORD_CAL_SIDE_REF_FMT = "기준({dev})"
COORD_CAL_PICK_FIRST = "왼쪽에서 사진을 고르세요."
COORD_CAL_CANDS_HEAD_FMT = "같은 결함인 {dst} 사진을 누르세요 — 그럴듯한 순서 · 숫자는 보정 전 거리"
COORD_CAL_ANCHOR_FMT = "기준 ({dev})"
COORD_CAL_DIST_FMT = "{d:.0f} µm"
COORD_CAL_PAIRED_FMT = "✓ {i}번 쌍"
COORD_CAL_PAIRS_NONE = "아직 고른 쌍이 없습니다 — 3쌍쯤 고르면 좋아요."
COORD_CAL_PAIR_ROW_FMT = "{i}.  {a}  ↔  {b}      가로 {dx:+.0f} · 세로 {dy:+.0f} µm"
COORD_CAL_RESULT_FMT = "보정값  가로 {dx:+.0f} µm · 세로 {dy:+.0f} µm   ({n}쌍 · 쌍별 남은 오차 최대 {r:.0f} µm)"
COORD_CAL_RESIDUAL_WARN_FMT = (
    "남은 오차가 큰 쌍이 있어요(최대 {r:.0f} µm). 잘못 고른 쌍이면 지워 주세요.")
KLA_INFO_BROKEN_FMT = (
    "KLA 정보파일(.001)이 비어 있는 슬롯이 {n}개 있어요:\n{names}\n\n"
    "파일 이름의 WaferID 와 슬롯 번호가 상대 장비와 맞는 {k}개는 짝을 지었어요.\n"
    "이 슬롯들은 KLA 결함 좌표가 없어 좌표 매칭이 되지 않아요. KLA 결과 파일을 확인해 주세요.")
COORD_CAL_AUTO_FMT = (
    "자동 계산값  가로 {dx:+.0f} µm · 세로 {dy:+.0f} µm   (근거 {n}쌍) — "
    "그대로 '보정 적용' 을 누르거나, 쌍을 골라 직접 정할 수 있어요.")
COORD_CAL_AUTO_WEAK_FMT = (
    "자동 계산은 근거가 부족해요(맞는 짝 {n}쌍 · 다른 후보 무리 {m}쌍). "
    "같은 결함 쌍을 직접 골라 주세요.")
COORD_CAL_AUTO_DIFF_FMT = (
    "고른 쌍의 보정값이 자동 계산값(가로 {ax:+.0f} · 세로 {ay:+.0f} µm)과 {d:.0f} µm 달라요. "
    "같은 결함이 맞는지 확인해 주세요.")
COORD_CAL_REMOVE = "지우기"
COORD_CAL_SKIP = "보정 건너뛰기"
COORD_CAL_APPLY = "보정 적용"
NOTCH_TITLE = "Notch 방향"
NOTCH_SIDE_FMT = "{side} · {machine}"
NOTCH_REF = "기준"
NOTCH_VAL = "검증"
NOTCH_DIRS = {"up": "위", "left": "왼쪽", "right": "오른쪽", "down": "아래"}
NOTCH_OK = "확인"
NOTCH_AUTO = "자동 감지"
NOTCH_CHECKING = "Notch 방향 확인 중…"
NOTCH_AUTO_BUSY = "검증 폴더를 네 방향으로 돌려 맞춰 보는 중…"
NOTCH_AUTO_FOUND_FMT = "검증 Notch: {dir} (기준 사진 {hit}장이 짝을 찾았습니다)"
NOTCH_AUTO_UNSURE = "뚜렷한 방향을 찾지 못했습니다 — 직접 골라 주세요."
NOTCH_FAIL_FMT = ("Notch 방향을 맞추지 못했습니다 — 웨이퍼 중심·die 크기를 읽을 수 없는 폴더가 있습니다.\n"
                  "{detail}")
NOTCH_LOG_FMT = "Notch 방향 보정(매칭 전용): {dirs}"

COORD_CAL_LOADING = "좌표 보정 준비 중 — 두 장비의 좌표를 읽고 있습니다…"

# ── GL 히스토그램 뷰어 ────────────────────────────────────────────────────
IMAGE_INFO_GL = "GL 보기"
GL_BUTTON = "GL 히스토그램"
GL_BUTTON_TOOLTIP = "사진의 밝기(GL) 분포를 히스토그램·선 프로파일·통계로 봅니다"
GL_COMING_SOON = "Coming soon"
GL_COMING_SOON_TOOLTIP = "GL 히스토그램 — 준비 중입니다"
GL_TITLE = "GL 히스토그램"
GL_OPEN = "사진 열기"
GL_OPEN_FILTER_FMT = "사진 ({patterns});;모든 파일 (*.*)"
GL_EMPTY_HINT = "사진을 열거나 이곳에 끌어다 놓으세요"
GL_LOADING = "사진을 불러오는 중"
GL_SAVE_XLSX = "엑셀 저장"
GL_SAVE_PNG = "색 칠한 PNG 저장"
GL_SAVE_XLSX_TITLE = "GL 분석 엑셀 저장"
GL_SAVE_PNG_TITLE = "색 칠한 PNG 저장"
GL_SAVED_FMT = "저장했어요: {name}"
GL_SAVE_FAILED_FMT = "저장하지 못했어요: {why}"
GL_NO_IMAGE = "먼저 사진을 열어 주세요."
GL_OPEN_FAILED_FMT = "사진을 열지 못했어요: {why}"
GL_COMPARE = "두 사진 비교"
GL_COMPARE_CLOSE = "사진 하나로 돌아가기"
GL_CMP_PICK = "비교할 B 사진 고르기"
GL_CMP_MISMATCH_FMT = ("두 사진은 크기와 비트가 같아야 ROI 를 겹칠 수 있어요. "
                       "A {a} · B {b}")
GL_CMP_CLOSED_FMT = "새 A 사진({a})이 B 와 크기가 달라 비교를 닫았어요."

GL_TOOL_MOVE = "이동"
GL_TOOL_HLINE = "수평선"
GL_TOOL_VLINE = "수직선"
GL_TOOL_RECT = "사각형"
GL_TOOL_SQUARE = "정사각형"
GL_TOOL_CIRCLE = "원"
GL_TOOL_TIP_FMT = "{name} 도구 (단축키 {key})"
GL_SHOW_HLINE = "수평선 보기"
GL_SHOW_VLINE = "수직선 보기"
GL_SIZE_MINUS = "−"
GL_SIZE_PLUS = "＋"
GL_SIZE_LABEL = "크기"
GL_SIZE_TIP = "선택한 도형 크기 조절 (＋ / − 키, 원은 반지름 1 px, Shift 는 10배)"
GL_FIT = "맞춤"
GL_ONE_TO_ONE = "1:1"
GL_UNDO = "되돌리기"
GL_CLEAR = "모두 지우기"
GL_TOOLBAR_HINT = ("선은 클릭 한 번이면 사진 전체를 가로지르고, 끌어서 옮깁니다 · "
                   "선택한 ROI 는 방향키로 1 px(Shift 10 px) 이동")

GL_THRESHOLD = "판정 임계값"
GL_THR_LOW = "하한 이하 = 파랑"
GL_THR_HIGH = "상한 이상 = 빨강"
GL_THR_AUTO = "자동 추천 (하위·상위 0.5%)"
GL_THR_ORDER_NOTE = "하한은 상한보다 작아야 해서 상한 바로 아래에서 멈췄어요."
GL_SCOPE_ALL = "사진 전체"
GL_SCOPE_ROI = "ROI 안쪽만"
GL_SCOPE_OFF = "끄기"
GL_AUTO_CONTRAST = "화면 대비 자동 (보기 전용, 분석 값은 그대로)"
GL_BITS = "GL 범위"
GL_BITS_AUTO_FMT = "{bits} bit (자동)"
GL_BITS_FMT = "{bits} bit"
GL_HIST = "GL 히스토그램"
GL_HIST_ALL = "사진 전체"
GL_HIST_OVERLAY = "ROI끼리 겹쳐 보기"
GL_HIST_LOG = "로그 눈금"
GL_HIST_DATA_RANGE = "데이터 범위만"
GL_PROFILE = "선 위치별 GL"
GL_PROFILE_EMPTY = "수평선·수직선을 그으면 위치별 GL 이 나옵니다"

GL_COL_ROI = "ROI"
GL_COL_BOX = "위치·크기"
GL_COL_COUNT = "픽셀 수"
GL_COL_MEAN = "평균"
GL_COL_STD = "표준편차"
GL_COL_MIN = "최소"
GL_COL_MAX = "최대"
GL_COL_BELOW = "하한 이하"
GL_COL_ABOVE = "상한 이상"
GL_ROW_ALL = "사진 전체"
GL_ROW_LINE_FMT = "{axis} {pos}"
GL_AXIS_ROW = "행"
GL_AXIS_COL = "열"

GL_STATUS_FMT = "X {x} · Y {y} · GL {gl}"
GL_STATUS_OUT = "—"
GL_STATUS_VIEW_FMT = "{w}×{h} · {bits} bit · 배율 {zoom}%"

GL_WARN_COLOR = "컬러 사진이라 밝기(0.299R+0.587G+0.114B)로 바꿔 분석합니다."
GL_WARN_JPEG = "JPEG 는 손실 압축이라 원본 GL 과 조금 다를 수 있어요."
GL_WARN_HUGE = "1억 화소가 넘어 느릴 수 있어요."
GL_SCAN_FOUND_FMT = ("컬러 결함 사진이라 같은 폴더의 Scan 사진 {name} 에서 결함 위치"
                     "(300 µm)를 확대해 보여 줍니다. 맞춤(F)으로 Scan 전체를 볼 수 있어요.")
GL_SCAN_MISSING = "컬러 사진인데 이 폴더에서 Scan 사진을 찾지 못해 컬러 사진의 밝기로 분석합니다."

GL_RAW_TITLE = "RAW 사진 설정"
GL_RAW_WIDTH = "가로(px)"
GL_RAW_HEIGHT = "세로(px)"
GL_RAW_BITS = "비트"
GL_RAW_ENDIAN = "바이트 순서"
GL_RAW_LITTLE = "Little endian"
GL_RAW_BIG = "Big endian"
GL_RAW_HEADER = "헤더 크기(byte)"
GL_RAW_OK = "열기"
GL_RAW_CANCEL = "취소"

GL_XLSX_SHEET_STATS = "ROI 통계"
GL_XLSX_SHEET_HIST = "히스토그램"
GL_XLSX_SHEET_PROFILE = "선 프로파일"
GL_XLSX_SHEET_INFO = "분석 조건"
GL_XLSX_GL = "GL"
GL_XLSX_POS = "위치"

GL_CANVAS_NAME = "GL 사진 화면"
GL_TOO_SMALL = "도형이 너무 작습니다 (최소 2 px)"
GL_LOUPE_FMT = "X {x}  Y {y}  GL {gl}"
GL_LOUPE_LOW = "  ▼하한 이하"
GL_LOUPE_HIGH = "  ▲상한 이상"
GL_HIST_HOVER_FMT = "GL {gl:,} · {items}"
GL_HIST_HOVER_ONE_FMT = "{n:,}개 ({pct:.2f}%)"
GL_HIST_HOVER_ITEM_FMT = "{name} {n:,}개 ({pct:.2f}%)"
GL_PROFILE_HOVER_FMT = "위치 {i:,} · {vals}"
GL_PNG_ROIS = "ROI 선·이름도 그리기"
GL_PNG_WRITE_FAILED = "PNG 를 쓰지 못했습니다"
GL_INFO_PHOTO = "사진"
GL_INFO_ANALYZED = "분석한 사진"
GL_INFO_SIZE = "크기"
GL_INFO_BITS = "GL 범위"
GL_INFO_LOW = "하한 이하"
GL_INFO_HIGH = "상한 이상"
GL_INFO_SCAN = "Scan 사진"
GL_INFO_B = "B 사진"
GL_COL_BELOW_PCT = "하한 이하 %"
GL_COL_ABOVE_PCT = "상한 이상 %"
