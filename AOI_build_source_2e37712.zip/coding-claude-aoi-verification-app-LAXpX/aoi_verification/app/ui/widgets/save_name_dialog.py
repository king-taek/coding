"""저장 직전에 결과 엑셀의 **이름만** 확인·수정하는 시트.

사용자 요청: "이 규칙으로 추천 파일 제목을 작성해주고 사용자가 추천 파일 제목에서
수정할 수 있도록 창을 띄워줘.  근데 파일 저장은 (검증과) 동시에 진행하고, 파일
제목을 수정하거나 결정하는 동안 파일은 이미 저장 중인 거로 하자."

그래서 이 창은 **저장을 기다리게 하지 않는다.**  여기서 정하는 것은 결과 파일이
가질 이름뿐이고, [이 이름으로 저장] 을 누르는 즉시 그 이름으로 저장이 시작된다.
폴더는 바꾸지 않는다 — 위치를 고르는 창은 따로 있다(양식이 없어 결과 경로를 못 정한
경우에만 뜬다).

★ 파일은 이 창 **전에는 존재하지 않는다.**  예전에는 [검증 시작] 때 양식을 복사해
  둔 '작업 파일' 이 있어 이름을 바꾸면 그 파일을 옮겨야 했는데, 저장까지 안 간
  세션마다 빈 xlsx 가 남는 것이 문제였다(사용자 신고).  지금은 이름이 곧 저장
  경로이고, 옮길 파일이 없다.

★ 확장자는 화면에 보이되 **사용자가 지우면 되살린다** — `.xlsx` 가 빠진 파일은
  엑셀이 열지 못한다.  이름을 고치라고 열어 준 창이 열 수 없는 파일을 만들면 안 된다.

이름 아래에는 제목을 이루는 칸(장비·자재·Layer·S/M)이 추천값으로 채워져 있고, 고친 뒤
[제목 자동 생성] 을 누르면 위 이름을 그 칸으로 다시 만든다(사용자 요청 2026-10-30) —
자재·Layer·S/M 은 못 읽는 제품이 있어 빈 칸으로 올 수 있다(`models/lot_info.py`).
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QDialog, QGridLayout, QHBoxLayout, QLabel,
                             QLineEdit, QVBoxLayout)

from ... import i18n
from .. import theme
from .neon_button import NeonButton

__all__ = ["SaveNameDialog", "sanitize_name", "compose_title"]

# Windows 파일명 금지 문자 — 여기서 막지 않으면 저장이 OS 오류로 실패한다.
_BAD = set('\\/:*?"<>|')
_EXT = ".xlsx"


def sanitize_name(text: str) -> tuple[str, str]:
    """``(정리된 이름, 오류 문구)`` — 오류 문구가 비어 있으면 쓸 수 있는 이름이다.

    순수 함수다(파일시스템을 보지 않는다) — 헤드리스로 그대로 테스트한다.
    """
    name = (text or "").strip()
    if not name:
        return ("", i18n.KO.SAVE_NAME_EMPTY)
    if any(ch in _BAD for ch in name):
        return ("", i18n.KO.SAVE_NAME_BAD_CHARS)
    if not name.lower().endswith(_EXT):
        name += _EXT                    # 확장자를 지웠으면 되살린다(위 주석)
    # 확장자만 남는 경우(".xlsx") 는 이름이 없는 것과 같다.
    if name.lower() == _EXT:
        return ("", i18n.KO.SAVE_NAME_EMPTY)
    return (name, "")


def compose_title(fields: dict[str, str]) -> str:
    """제목 칸 → 파일 이름(순수 함수 — 헤드리스 테스트).

    ``fields`` 에 ``machine`` 이 있으면 Defect 추출 제목, ``cross`` 가 있으면 교차검증
    제목(양방향이라 ``기준 vs 검증``), 아니면 검증 결과 제목이다(``val``·``ref``).  ``layer``·``material``·``sm`` 중 빈 칸은 빠지고, 모두 비면 폴백 이름."""
    # 칸 안의 연속 공백은 하나로 — 빈 장비 칸이 이름에 이중 공백을 남기지 않게.
    g = {k: " ".join((v or "").split()) for k, v in fields.items()}
    tag = "_".join(t for t in (g.get("material", ""), g.get("layer", ""), g.get("sm", ""))
                   if t)
    return " ".join(_compose(g, tag).split())


def _compose(g: dict[str, str], tag: str) -> str:
    if "machine" in g:
        if not tag:
            return i18n.KO.EXTRACT_FILE_TITLE_FALLBACK_FMT.format(machine=g["machine"])
        return i18n.KO.EXTRACT_FILE_TITLE_FMT.format(machine=g["machine"], tag=tag)
    if g.get("cross"):
        if not tag:
            return i18n.KO.CROSS_FILE_TITLE_FALLBACK_FMT.format(
                val=g.get("val", ""), ref=g.get("ref", ""))
        return i18n.KO.CROSS_FILE_TITLE_FMT.format(
            val=g.get("val", ""), ref=g.get("ref", ""), tag=tag)
    if not tag:
        return i18n.KO.RESULT_FILE_TITLE_FALLBACK_FMT.format(
            val=g.get("val", ""), ref=g.get("ref", ""))
    return i18n.KO.RESULT_FILE_TITLE_FMT.format(
        val=g.get("val", ""), ref=g.get("ref", ""), tag=tag)


# 칸 순서 = 제목에 나오는 순서.
_FIELD_LABELS = (
    ("machine", i18n.KO.SAVE_NAME_FIELD_MACHINE),
    ("val", i18n.KO.SAVE_NAME_FIELD_VAL),
    ("material", i18n.KO.SAVE_NAME_FIELD_MATERIAL),
    ("layer", i18n.KO.SAVE_NAME_FIELD_LAYER),
    ("sm", i18n.KO.SAVE_NAME_FIELD_SM),
    ("ref", i18n.KO.SAVE_NAME_FIELD_REF),
)


class SaveNameDialog(QDialog):
    """추천 이름을 보여주고 고치게 한다.  :attr:`chosen` 이 결과(취소면 ``None``)."""

    def __init__(self, suggested: str, folder: Path, parent=None,
                 *, body: str | None = None,
                 fields: dict[str, str] | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle(i18n.KO.SAVE_NAME_TITLE)
        self._chosen: str | None = None
        self._folder = Path(folder)
        self._fields: dict[str, QLineEdit] = {}
        # 칸이 아닌 제목 종류 표시(``cross``) — 칸 입력과 함께 이름 재생성에 넘긴다.
        self._kind = {k: v for k, v in (fields or {}).items() if k == "cross"}
        if body is None:
            body = (i18n.KO.SAVE_NAME_CROSS_BODY if self._kind.get("cross")
                    else i18n.KO.SAVE_NAME_BODY)
        self._build(suggested, self._folder, body, fields)

    @property
    def chosen(self) -> str | None:
        return self._chosen

    # ------------------------------------------------------------------
    def _build(self, suggested: str, folder: Path, body_text: str,
               fields: dict[str, str] | None) -> None:
        root = QVBoxLayout(self)
        m = theme.PROFILE.page_margin // 2
        root.setContentsMargins(m, m, m, m)
        root.setSpacing(10)

        head = QLabel(i18n.KO.SAVE_NAME_TITLE, self)
        head.setProperty("role", "title")
        root.addWidget(head)

        body = QLabel(body_text, self)
        body.setProperty("role", "muted")
        body.setWordWrap(True)
        root.addWidget(body)

        self.edit = QLineEdit(suggested, self)
        self.edit.setMinimumWidth(420)
        self.edit.textChanged.connect(self._revalidate)
        # 확장자를 뺀 부분만 선택해 둔다 — 바로 타이핑해도 `.xlsx` 가 살아남는다.
        stem = suggested[:-len(_EXT)] if suggested.lower().endswith(_EXT) else suggested
        self.edit.setSelection(0, len(stem))
        root.addWidget(self.edit)

        self._err = QLabel("", self)
        self._err.setProperty("role", "error")
        self._err.setMinimumHeight(16)      # 자리를 예약한다(창 높이가 흔들리지 않게)
        self._err.setWordWrap(True)
        root.addWidget(self._err)

        if fields:
            # QFormLayout 은 라벨을 칸 위쪽에 붙여 그린다(테마의 큰 입력칸) — 격자로
            # 라벨을 칸 가운데 높이에 맞춘다.
            form = QGridLayout()
            form.setHorizontalSpacing(12)
            form.setVerticalSpacing(6)
            form.setColumnStretch(1, 1)
            for key, label in _FIELD_LABELS:
                if key not in fields:
                    continue
                ed = QLineEdit(fields[key] or "", self)
                self._fields[key] = ed
                r = form.rowCount()
                form.addWidget(QLabel(label, self), r, 0,
                               alignment=Qt.AlignmentFlag.AlignVCenter)
                form.addWidget(ed, r, 1)
            root.addLayout(form)
            hint = QLabel(i18n.KO.SAVE_NAME_FIELDS_HINT, self)
            hint.setProperty("role", "muted")
            hint.setWordWrap(True)
            auto_row = QHBoxLayout()
            auto_row.addWidget(hint, 1)
            self.btn_auto = NeonButton(i18n.KO.SAVE_NAME_AUTO, role="ghost")
            self.btn_auto.clicked.connect(self._on_auto)
            auto_row.addWidget(self.btn_auto)
            root.addLayout(auto_row)

        where = QLabel(i18n.KO.SAVE_NAME_FOLDER_FMT.format(path=str(folder)), self)
        where.setProperty("role", "muted")
        where.setWordWrap(True)
        root.addWidget(where)

        row = QHBoxLayout()
        row.setSpacing(8)
        row.addStretch(1)
        self.btn_cancel = NeonButton(i18n.KO.SAVE_NAME_CANCEL, role="ghost")
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_ok = NeonButton(i18n.KO.SAVE_NAME_OK, role="primary")
        self.btn_ok.setDefault(True)
        self.btn_ok.clicked.connect(self._on_ok)
        row.addWidget(self.btn_cancel)
        row.addWidget(self.btn_ok)
        root.addLayout(row)

        self.edit.setFocus(Qt.FocusReason.OtherFocusReason)
        self._revalidate()

    def _on_auto(self) -> None:
        """칸으로 이름을 다시 만든다.  같은 이름의 파일이 폴더에 있으면 시각을 붙인다
        (검증 시작 때의 추천 이름과 같은 규칙 — 지난 결과를 덮지 않게)."""
        name = compose_title({**{k: ed.text() for k, ed in self._fields.items()},
                              **self._kind})
        try:
            exists = (self._folder / name).exists()
        except (OSError, ValueError):
            exists = False
        if exists:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            name = name[:-len(_EXT)] + f"_{ts}" + _EXT
        self.edit.setText(name)

    def _revalidate(self) -> None:
        """쓸 수 없는 이름이면 **누르기 전에** 이유를 말하고 [확인] 을 잠근다."""
        _name, err = sanitize_name(self.edit.text())
        self._err.setText(err)
        self.btn_ok.setEnabled(not err)

    def _on_ok(self) -> None:
        name, err = sanitize_name(self.edit.text())
        if err:
            self._err.setText(err)
            return
        self._chosen = name
        self.accept()
