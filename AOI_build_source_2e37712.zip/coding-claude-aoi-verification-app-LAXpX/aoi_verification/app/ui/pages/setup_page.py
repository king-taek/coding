"""초기 입력 화면 (Setup) — 모드/폴더/호기/임계치 입력."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import (QObject, QSize, Qt, QThread, QTimer,
                          QVariantAnimation, pyqtSignal)
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import (QBoxLayout, QDoubleSpinBox, QFrame,
                              QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                              QMessageBox, QScrollArea, QSizePolicy,
                              QStackedWidget, QVBoxLayout, QWidget)

from ..deferred import call_later
from ..folder_picker import FolderPicker
from ..teardown import tolerate_teardown
from ... import i18n
from .. import theme
from ...utils import paths
from ...utils import prefs as _prefs
from ... import config
from ...utils.prefs import AutomationLevel, EngineMode
from ..rail_icons import rail_icon
from ..widgets.app_logo import build_logo_label
from ..widgets.neon_button import NeonButton
from ..widgets.neon_card import NeonCard
from ..widgets.no_wheel_slider import NoWheelDoubleSpinBox, NoWheelSlider
from ..widgets.option_group import OptionGroup
from ..widgets.switch_row import SwitchRow
from ..widgets import sheet_host as sheets

# 조용히 삼키던 사실을 남기는 로거 — `main._setup_logging` 이 캐시 폴더의 app.log 로
# 보낸다(`ui/main_window.py` 와 같은 이름 규칙).
_LOG = logging.getLogger("aoi.ui")


@dataclass
class SetupInput:
    mode: str        # "single" | "cross"(교차검증 — `models/cross_check.py`)
    ref_root: Path
    val_root: Path
    ref_machine: str
    val_machine: str
    threshold: float
    automation_level: str = AutomationLevel.USER_SELECT
    # 유사도 엔진 + 기타 설정 (계산 전용).
    engine_mode: str = EngineMode.COORDINATE   # EngineMode.{BASIC,EFFICIENCY,COORDINATE}
    persist_scores: bool = True      # 유사도 점수 디스크 캐시 — 항상 기본 적용
    accel_concurrency: int = 32      # 고효율 모드 동시 추론 수(in-flight)
    use_cpu: bool = True             # 고효율 장치 토글(테스트용)
    use_gpu: bool = True
    embed_batch: int = 1             # 정적 배치 B (1=끔)
    # 좌표 기반 매칭(v2) 허용 오차 — µm 단위.
    coord_tolerance: float = config.DEFAULT_COORD_TOLERANCE
    # 진행할 슬롯 부분집합 (None = 전체 진행). '일부 슬롯만 진행' 옵션으로 설정.
    selected_slots: Optional[set] = None
    # Defect 추출 — 매칭 없이 ``ref_root`` 한쪽에서 고른 사진을 엑셀로.  이때
    # ``val_root``·``val_machine`` 은 쓰지 않는다(``val_root`` 는 ``ref_root`` 와 같게 둔다).
    extract: bool = False
    # Defect 추출 대상 폴더들(여러 LOT).  하나면 ``[ref_root]``.  ``ref_root`` 는 첫 폴더다.
    extract_roots: Optional[list] = None
    # Defect 추출 엑셀에 Wafer Map 시트를 넣을지(설정 화면 스위치, 사용자 결정).
    extract_wafer_map: bool = True
    # LOT 별 '일부 슬롯'(``extract_roots`` 와 같은 순서, ``None`` = 전체).
    extract_slots: Optional[list] = None
    # 기준 1 ↔ 검증 여러 장비 — 두 번째부터의 검증 장비 ``[(폴더, 호기), …]``.
    # 첫 검증 장비는 ``val_root``/``val_machine`` 그대로다(비면 예전과 똑같은 실행).
    # 흐름은 `models/multi_val.py`.
    extra_vals: Optional[list] = None


# '실행 옵션'·'매칭 설정' 두 카드를 가로로 나란히 세우려면 이만큼은 있어야 한다.
# 이보다 좁으면 세로로 쌓는다 — 나란히 두면 카드가 최소 폭을 못 얻어 가로 스크롤이
# 생긴다(800px 실측 69px 넘침).  후보 배치안 5종을 비교한 끝에 '나란히' 를 채택했고,
# 좁은 창 폴백만 덧붙였다.
_SIDE_BY_SIDE_MIN_W = 900
# 왼쪽 메뉴를 이름까지 펼쳐 둘 최소 폭 — 이보다 좁으면 아이콘만 남긴다
# (800×600 에서 메뉴 200px 가 카드 폭을 갉아 가로 스크롤이 생기는 것을 막는다).
_RAIL_SIDE_MIN_W = 1000


# 살아 있는 die 기하 스캔을 여기에 붙잡아 둔다 — **페이지의 자식으로 두지 않는다.**
#
# ★ 이유: 실행 중인 QThread 가 파괴되면 Qt 는 "QThread: Destroyed while thread is
#   still running" 으로 프로세스를 죽인다.  스캔이 끝나기 전에 페이지가 사라지면(창
#   닫기 등) 정확히 그 일이 벌어진다.  부모를 떼고 여기서 참조를 쥐고 있다가 `finished` 에서 놓아 주면
#   페이지가 언제 죽든 스레드는 자기 수명을 다 살고 조용히 사라진다
#   (`widgets/zoom_window.py` 의 `_LIVE_LOADERS` 와 같은 패턴).
_LIVE_DIE_SCANS: set = set()


class _DieGeometryScan(QThread):
    """기준 폴더의 die 크기를 **워커 스레드에서** 읽는다(UI 가 멈추지 않게).

    ★ 스레드만으로는 부족했다.  워커가 하는 일이 순수 파이썬 파싱(결함 수천 건의
    INI·die 맵)이면 GIL 을 쥔 채 UI 스레드를 굶겨, 폴더를 고른 뒤 'die 안내가 뜰 때까지'
    창이 멈춘다(사용자 신고 — 스캔을 워커로 옮긴 뒤에도 남았다).  그래서 워커가 하는
    일 자체를 **작은 파일 몇 개의 읽기**로 줄였다(`SetupPage._detect_die_geometry`).
    스레드는 그래도 남긴다 — NAS 왕복은 I/O 라 GIL 을 놓지만, 끊긴 경로에서는 OS
    타임아웃까지 돌아오지 않는다.

    ``token`` 은 **결과가 늦게 도착했을 때 버리기 위한 세대 번호**다.  사용자가 폴더를
    연달아 바꾸면 스캔이 겹치는데, 늦게 끝난 옛 스캔이 새 폴더의 안내를 덮어쓰면 안 된다.
    ``signals`` 는 메인 스레드에서 만들어지므로 emit 은 큐 연결이 된다."""

    class _Signals(QObject):
        done = pyqtSignal(int, object, str, bool)    # token, pitch|None, src, broken

    def __init__(self, token: int, ref_text: str) -> None:
        super().__init__()                  # 부모 없음(위 주석)
        self._token = token
        self._ref_text = ref_text
        self.signals = self._Signals()

    def run(self) -> None:      # type: ignore[override]
        # `_detect_die_geometry` 는 전 구간 fail-safe 지만, 워커에서 예외가 새면
        # 안내가 영원히 '확인 중' 으로 남는다 — 여기서도 한 번 더 막는다.
        try:
            pitch, src, broken = SetupPage._detect_die_geometry(self._ref_text)
        except Exception:
            pitch, src, broken = (None, "", False)
        self.signals.done.emit(self._token, pitch, src, broken)


_LIVE_DIR_PROBES: set = set()


class _DirProbe(QThread):
    """두 폴더가 실제로 있는지 **워커 스레드에서** 확인한다 (P-15).

    ``Path.is_dir()`` 는 값싸 보이지만 네트워크 폴더(NAS)에서는 응답이 초 단위로
    늦거나, 연결이 끊긴 경로에서는 OS 타임아웃까지 통째로 멈춘다.  이 확인은
    입력란을 **한 글자 칠 때마다**(250ms 디바운스) 돌기 때문에, UI 스레드에서
    하면 경로를 타이핑하는 내내 창이 끊긴다.

    ``token`` 은 늦게 도착한 옛 확인을 버리기 위한 세대 번호다 — 사용자가 계속
    타이핑하면 확인이 겹치는데, 옛 결과가 새 경로의 판정을 덮으면 안 된다."""

    class _Signals(QObject):
        done = pyqtSignal(int, str, str, str, str)   # token, ref_text, ref_state, val_text, val_state

    def __init__(self, token: int, ref_text: str, val_text: str,
                 multi: bool = False) -> None:
        super().__init__()                  # 부모 없음(`_DieGeometryScan` 과 같은 이유)
        self._token = token
        self._ref_text = ref_text
        self._val_text = val_text
        # Defect 추출 — 입력란에 폴더 여러 개(`;` 구분).  매칭은 경로 하나다.
        self._state = SetupPage._dirs_state if multi else SetupPage._dir_state
        self.signals = self._Signals()

    def run(self) -> None:      # type: ignore[override]
        try:
            ref_state = self._state(self._ref_text)
            val_state = self._state(self._val_text)
        except Exception:
            # 여기서 예외가 새면 안내가 영원히 '확인 중' 으로 남는다.
            ref_state = val_state = "missing"
        self.signals.done.emit(self._token, self._ref_text, ref_state,
                               self._val_text, val_state)


def extract_drop_folders(local_paths, *, is_dir, is_image) -> list[str]:
    """끌어다 놓은 경로들 → Defect 추출 입력란에 넣을 폴더(순서 유지, 중복 없음).

    폴더는 그 폴더 그대로(LOT 든 wafer 든 — 입력란이 둘 다 받는다), 사진은 **그 사진이
    든 폴더**(wafer 폴더).  그 밖의 파일은 버린다.  순수 — 헤드리스 테스트한다."""
    import os
    out: list[str] = []
    seen: set[str] = set()
    for raw in local_paths:
        if not raw:
            continue
        p = Path(raw)
        if is_dir(p):
            d = p
        elif is_image(str(p)):
            d = p.parent
        else:
            continue
        key = os.path.normcase(os.path.normpath(str(d)))
        if key not in seen:
            seen.add(key)
            out.append(str(d))
    return out


class SetupPage(QWidget):
    """검증 시작 화면."""

    start_requested = pyqtSignal(object)             # SetupInput
    excel_ref_requested = pyqtSignal(str)            # 이전 결과 엑셀을 기준으로 (경로)
    update_check_requested = pyqtSignal()            # '업데이트 확인' 버튼
    extract_mode_changed = pyqtSignal(bool)          # Defect 추출 ↔ 매칭 (레일 단계 이름)
    cross_mode_changed = pyqtSignal(bool)            # 교차검증 스위치 (레일 단계 이름)
    page_changed = pyqtSignal(str)                   # 왼쪽 메뉴로 바꾼 화면(창이 단계 줄을 감춘다)
    tool_fullscreen_changed = pyqtSignal(bool)       # Wafer Map '맵만 보기' (창이 여정 레일을 감춘다)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        # 무거운 구성 요소(영상 처리·가속)가 준비됐는가 — 준비 전엔 [검증 시작] 을
        # 잠근다.  ★ 기본은 True 다: 이 페이지를 단독으로 띄우는 곳(테스트·미리보기)
        # 에서 버튼이 영원히 잠기면 안 된다.  메인 창이 곧바로 False 로 뒤집는다.
        self._backend_ready = True
        # Defect 추출 모드 — 검증 장비 카드·매칭 설정을 감추고 한쪽 폴더만 받는다.
        # ★ `_build` 전에 둔다: 액션바를 만들며 부르는 `_validate` 가 읽는다.
        self._extract_mode = False
        # die 기하 스캔(백그라운드) 상태.  `_die_scanned_for` 는 **이미 스캔이 끝난
        # 경로** 다 — 같은 경로로 `_validate` 가 다시 와도(허용 오차를 건드리면 온다)
        # 다시 훑지 않고 캐시한 결과로 문구만 다시 그린다.
        self._die_token = 0
        self._die_scanned_for: Optional[str] = None
        self._die_scanning_for: Optional[str] = None
        self._die_result: tuple = (None, "", False)
        self._die_scan: Optional[_DieGeometryScan] = None
        # 폴더 존재 확인(P-15) — {경로 문자열: '' | 'missing'}.  네트워크 폴더에서
        # `is_dir()` 이 초 단위로 걸리기 때문에 워커가 채우고 UI 는 읽기만 한다.
        self._probe_token = 0
        self._probed: dict[str, str] = {}
        # 지금 워커가 확인 중인 (기준, 검증) 경로 쌍 — 같은 쌍으로 `_validate` 가 다시
        # 와도 스레드를 새로 띄우지 않는다(die 스캔의 `_die_scanning_for` 와 같은 뜻).
        self._probing_for: Optional[tuple[str, str]] = None
        # [폴더 선택…] 의 OS 브라우저 — 비동기(`ui/folder_picker.py`).  어느 입력란이
        # 눌렀는지는 `_browse_target` 에 기억해 두고 `picked` 에서 채운다.
        self._folder_picker = FolderPicker(self)
        self._folder_picker.picked.connect(self._on_folder_picked)
        self._folder_picker.closed.connect(self._on_folder_dialog_closed)
        self._browse_target: Optional[QLineEdit] = None
        # 헤드리스에서는 동기로 확인한다 — 테스트가 `_validate()` 의 반환값을
        # 호출 즉시 단언한다(`widgets/zoom_window.py` 와 같은 게이트).
        import os
        self._sync_probe = (
            os.environ.get("QT_QPA_PLATFORM", "") == "offscreen")
        self._build()

    # ------------------------------------------------------------------
    def _build(self) -> None:
        # [왼쪽 메뉴 | 세로선 | 오른쪽 화면 스택].  메뉴는 화면을 바꿔도 그 자리에 남고,
        # 오른쪽만 매칭 설정 ↔ 사진 정보 · Wafer Map · GL 히스토그램으로 바뀐다
        # (사용자 요청 2026-10-30: 도구는 팝업이 아니라 창 이동).
        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        # 도구 화면은 처음 누를 때 만들고 그 뒤로는 살려 둔다 — 돌아오면 보던 사진·맵이 그대로다.
        self._tool_pages: dict[str, QWidget] = {}
        self._page_key = "match"
        outer.addWidget(self._build_tool_rail())
        self._rail_rule = QWidget(self)
        self._rail_rule.setFixedWidth(1)
        self._rail_rule.setProperty("role", "vrule")
        outer.addWidget(self._rail_rule)
        self._pages = QStackedWidget(self)
        outer.addWidget(self._pages, 1)

        match_host = QWidget(self)
        mh = QVBoxLayout(match_host)
        mh.setContentsMargins(0, 0, 0, 0)
        mh.setSpacing(0)
        self._pages.addWidget(match_host)
        self._match_host = match_host

        # 좁은/짧은 창에서도 모든 컨트롤에 접근 가능하도록 스크롤 영역으로 감싼다.
        # 스크롤바는 ‘필요할 때만’ 자동으로 나타난다.
        scroll = QScrollArea(match_host)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        # QScrollArea 자체의 배경/보더가 페이지 배경 위에 겹쳐 보이지 않게.
        # ★ 뷰포트 배경은 '맨 선언(bare)' 스타일시트로 주면 안 된다 — 자식으로 캐스케이드돼
        #   선택된 세그먼트/타일의 :checked 배경(채움)을 덮어써 '빈 박스'로 렌더된다.
        #   뷰포트를 objectName 으로 스코프해 자식에 새지 않게 한다.
        scroll.setStyleSheet(
            "QScrollArea { background: transparent; border: none; }"
            "QScrollArea > QWidget#qt_scrollarea_viewport { background: transparent; }"
        )
        mh.addWidget(scroll)
        self._scroll = scroll

        host = QWidget()
        host.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.MinimumExpanding)
        scroll.setWidget(host)

        root = QVBoxLayout(host)
        # ★ 하드코딩 40/20 이 `PROFILE.page_margin`·`section_gap` 을 죽은 토큰으로
        #   만들고 있었다 — 밀도를 한 곳에서 조절할 수 있게 토큰을 쓴다.
        #   왼쪽은 메뉴 세로선에서 띄우는 간격이다(창 가장자리 여백은 메뉴가 가진다).
        m, gap = theme.PROFILE.page_margin, theme.PROFILE.section_gap
        root.setContentsMargins(gap, m, m, 0)
        root.setSpacing(gap)
        self._build_body(root)

        # 시작 바는 스크롤 **밖**에 고정한다(주요 액션이 항상 손에 닿게).
        if self._pinned_action_bar():
            bar = self._build_action_bar()
            self._bar_host = bar
            bar.setContentsMargins(gap, 10, m, 10)
            mh.addWidget(bar)

        # ★ 첫 포커스를 첫 입력란에 둔다.  이전엔 탭 체인 첫 정지가 보기 옵션이라,
        #   키보드 사용자가 폴더를 입력하려면 그 컨트롤을 먼저 지나야 했다.  QTimer 로 미루는 이유는 show() 이후에야 포커스가 실제로
        #   들어가기 때문.
        QTimer.singleShot(0, self._focus_first_field)


    def _focus_first_field(self) -> None:
        """탭 체인의 출발점을 첫 입력란으로 — 파괴적 컨트롤을 먼저 지나지 않게."""
        edit = getattr(self, "ref_path_edit", None)
        if edit is not None and edit.isVisible():
            edit.setFocus(Qt.FocusReason.OtherFocusReason)

    # ==================================================================
    # 본문 빌더 — 각 조각은 위젯 하나를 만들어 돌려준다.  순서·열 구성은
    # ``_build_body``, 컨트롤 디자인은 개별 빌더에서 바꾼다.
    # ==================================================================
    def _pinned_action_bar(self) -> bool:
        """액션바를 스크롤 밖에 고정할지.

        ★ 항상 True 다.  한때 액션바를 스크롤 **안**에 둔 배치안이 있었는데, 800×600
        에서 내용이 뷰포트를 넘겨 [검증 시작]이 화면 밖으로 밀려났다(실측).  '주요
        액션을 찾으려면 스크롤해야 한다'는 어떤 배치에서도 결함이다."""
        return True

    def _build_body(self, root: QVBoxLayout) -> None:
        """「진행 순서형」 — 한 열, 위에서 아래로(폴더 → 옵션 → 시작).

        폴더가 먼저다: 매번 바뀌는 값이고, 자동화 수준·진행 범위는 대체로 그대로 쓴다.
        그 둘은 전체폭 카드 두 장을 차지하다가 **'실행 옵션' 카드 하나**로 합쳐졌다
        (아래 `_build_run_options_card` 주석 참조).

        두 설정 카드는 ``_place_setting_cards`` 가 창 폭에 따라 나란히/위아래로 놓는다."""
        # 왼쪽 메뉴는 `_build` 가 화면 스택 밖에 둔다 — 여기는 장비·설정 카드만.
        # `_wide` = 방식 구역을 나란히 세울 만큼 넓은가(좁으면 위아래, 메뉴는 아이콘만).
        self._wide = True
        device_row = self._build_device_row()
        self._place_setting_cards(root)
        root.addWidget(device_row, 1, Qt.AlignmentFlag.AlignTop)
        if not self._pinned_action_bar():
            root.addWidget(self._build_action_bar())
        # ★ 크레딧을 여기에 두지 않는다 — `main_window` 의 **상태바**가 모든 화면에
        #   공통으로 띄운다(`main_window._credit_label`).  둘 다 두면 한 화면에
        #   'Developed by …' 가 두 번 보인다(실측: 가운데 + 좌하단).

    # ------------------------------------------------------------------
    # 설정 카드 배치 — 두 카드를 나란히(넓을 때) / 위아래로(좁을 때)
    # ------------------------------------------------------------------
    def _place_setting_cards(self, root: QVBoxLayout) -> None:
        """장비 카드 둘과 설정 카드 둘을 **두 열**로 놓는다(사용자 결정 2026-10-27, D안).

        왼쪽 열 = 기준 장비 + 실행 옵션, 오른쪽 열 = 검증 장비 + 매칭 설정.  검증 장비를
        여러 대 추가해 오른쪽이 길어져도 왼쪽은 자기 높이를 지킨다.  예전에는 장비 줄과
        설정 줄이 각각 가로 한 줄이라, 오른쪽이 길어지면 같은 줄의 기준 카드가 같이
        늘어나 내용이 떠 보이고 실행 옵션은 그만큼 아래로 밀렸다.

        ★ 세 가지를 지킨다.
        1. **좁은 창에서는 한 열로 쌓는다**(기준 → 검증 → 실행 옵션 → 매칭 설정 — 폴더가
           먼저다).  800×600 에서 두 열은 카드가 최소 폭을 못 얻어 가로 스크롤이 생긴다.
        2. **열은 `QVBoxLayout` + 맨 끝 stretch** 다.  그래야 NeonCard(Preferred=Grow)가
           열 높이만큼 늘어나지 않는다.
        3. 레이아웃은 **하나만** 만들고 위젯만 옮겨 담는다(재생성하면 Qt 가 거부한다)."""
        self._sec_folder = QLabel(i18n.KO.SETUP_SECTION_FOLDER, self)
        self._sec_mode = QLabel(i18n.KO.SETUP_SECTION_MODE, self)
        for lb in (self._sec_folder, self._sec_mode):
            lb.setProperty("role", "sectionHead")
        run_card = self._build_run_options_card()
        eng_card = self._build_engine_card()
        self._setting_cards = (run_card, eng_card)
        # 교차검증은 유사도 엔진 쪽 옵션과 한 묶음 — 오른쪽 카드 맨 위로 옮긴다.
        eng_card.body().insertWidget(0, self._cross_switch)
        # '2 방식' 은 자동화·범위(왼쪽) | 교차검증·엔진(오른쪽) 한 줄 — 좁으면 위아래.
        self._mode_row = QWidget(self)
        self._mode_row.setProperty("role", "rowHost")
        self._mode_lay = QBoxLayout(QBoxLayout.Direction.TopToBottom, self._mode_row)
        self._mode_lay.setContentsMargins(0, 0, 0, 0)
        self._mode_lay.setSpacing(theme.PROFILE.section_gap)
        self._cards_side_by_side: Optional[bool] = None
        self._apply_card_orientation(self._side_by_side_fits())

    # 한 열 "번호 흐름"(1 폴더 → 2 방식, 사용자 선택 2026-10-28 목업).  두 열 배치 코드는
    # 남겨 두고 이 값만 끈다.
    _TWO_COLUMN = False

    def _side_by_side_fits(self) -> bool:
        """지금 폭에서 두 열로 세워도 가로가 넘치지 않는가(추출 모드는 한 열)."""
        if getattr(self, "_extract_mode", False) or not self._TWO_COLUMN:
            return False
        width = self.width() or self.sizeHint().width()
        if int(width) < _SIDE_BY_SIDE_MIN_W:
            return False
        # 카드 열이 쓸 수 있는 폭 — 레일이 왼쪽에 서 있으면 그만큼 빼고 잰다.
        rail = self._tool_rail.width() + 1
        avail = int(width) - theme.PROFILE.page_margin - theme.PROFILE.section_gap - rail
        need = max([c.minimumSizeHint().width() for c in self._device_cards]
                   + [self._VAL_CARD_MIN_W])
        return avail >= 2 * need + theme.PROFILE.section_gap

    def _apply_card_orientation(self, side_by_side: bool) -> None:
        """두 열 ↔ 한 열 — 위젯만 옮겨 담는다."""
        if side_by_side == self._cards_side_by_side:
            return
        self._cards_side_by_side = side_by_side
        ref, val = self.ref_group, self.val_group
        run, eng = self._setting_cards
        lay, left, right = self._device_lay, self._col_left, self._col_right
        for box in (left, right, lay):       # 전부 비운다(위젯은 지우지 않는다)
            while box.count():
                box.takeAt(0)
        if side_by_side:
            left.addWidget(ref)
            left.addWidget(run)
            left.addStretch(1)
            right.addWidget(val)
            right.addWidget(eng)
            right.addStretch(1)
            lay.addLayout(left, 1)
            lay.addLayout(right, 1)
            lay.setDirection(QBoxLayout.Direction.LeftToRight)
            lay.setSpacing(theme.PROFILE.section_gap)
        else:
            lay.setDirection(QBoxLayout.Direction.TopToBottom)
            lay.setSpacing(0)               # 평면 카드는 구분선이 간격을 대신한다
            while self._mode_lay.count():
                self._mode_lay.takeAt(0)
            top = Qt.AlignmentFlag.AlignTop      # 한쪽이 커져도 다른 쪽 높이는 그대로
            self._mode_lay.addWidget(run, 1, top)
            self._mode_lay.addWidget(eng, 1, top)
            self._mode_lay.setDirection(
                QBoxLayout.Direction.LeftToRight if getattr(self, "_wide", False)
                else QBoxLayout.Direction.TopToBottom)
            for w in (self._sec_folder, ref, val, self._sec_mode, self._mode_row):
                lay.addWidget(w)

    def _build_mode_badge(self) -> QWidget:
        """상단 모드 배지 — 지금 무슨 엔진·무슨 판정 수치로 도는지.

        판정 기준 문장이 엔진 카드 안에만 있어서, A안은 화면 밖·C안은 접힘 아래로
        밀려 '모르고 켜둔 채 실행'을 막지 못했다(채점자 5인 공통 지적).  모드 이름만
        담으면 부족하다 — **판정 수치까지** 담아야 오조작이 눈에 걸린다."""
        card = NeonCard(role="card", parent=self)
        card.setProperty("bare", True)       # 박스 없이 글자만(구형일 땐 색으로 말한다)
        card.setToolTip(i18n.KO.MODE_BADGE_TOOLTIP)
        # ★ 배지는 '항상 보이는 요약' 이지 카드 콘텐츠가 아니다 — 일반 카드 패딩(20)
        #   에 캡션/값 2단으로 두면 실높이가 ~90px 로 26px 제목의 3배가 돼, 첫 줄의
        #   시각 중심이 배지 쪽으로 쏠리고 폴드 위 공간(장비 카드)을 먹는다.
        #   패딩을 줄이고 캡션과 값을 **한 줄**로 눕힌다.
        card.body().setContentsMargins(14, 8, 14, 8)
        cap = QLabel(i18n.KO.MODE_BADGE_CAPTION, card)
        cap.setProperty("role", "badgeCaption")
        # 이름(한국어, 본문 서체) + 수치(모노) — 한 라벨에 모노를 걸면 한글 글리프가
        # 없어 문장 안에서 서체가 갈린다.
        badge_row = QWidget(card)
        badge_row.setProperty("role", "rowHost")
        brow = QHBoxLayout(badge_row)
        brow.setContentsMargins(0, 0, 0, 0)
        brow.setSpacing(8)
        brow.addWidget(cap)
        self._mode_badge = QLabel("", badge_row)
        self._mode_badge.setProperty("role", "modeBadge")
        self._mode_badge_value = QLabel("", badge_row)
        self._mode_badge_value.setProperty("role", "modeBadgeValue")
        brow.addWidget(self._mode_badge)
        brow.addWidget(self._mode_badge_value)
        brow.addStretch(1)
        card.body().addWidget(badge_row)
        card.setMinimumWidth(1)              # 좁은 창에서 시작 바가 창 폭을 밀어내지 않게
        self._mode_badge_card = card
        return card

    def judgement_text(self) -> tuple[str, str]:
        """판정 기준을 (이름, 수치) 로 — **단일 출처**.

        ★ 배지와 C안 요약이 각자 문장을 만들어 같은 사실을 서로 다른 말로 했다
        (배지 '구형 고효율 · 유사도 임계치 55 %' vs 요약 '구형 유사도 엔진 (임계치 55 %)').
        판정 기준은 하나이므로 문장도 하나에서 나와야 한다."""
        if self.legacy_switch.is_on():
            sub = (i18n.KO.ENGINE_MODE_EFFICIENCY_SHORT
                   if self.legacy_group.current_key() == EngineMode.EFFICIENCY
                   else i18n.KO.ENGINE_MODE_BASIC_SHORT)
            return (i18n.KO.JUDGE_NAME_LEGACY_FMT.format(sub=sub),
                    i18n.KO.JUDGE_VALUE_LEGACY_FMT.format(
                        th=float(self.slider.value())))
        return (i18n.KO.JUDGE_NAME_COORD,
                i18n.KO.JUDGE_VALUE_COORD_FMT.format(
                    tol=float(self.coord_tol_spin.value())))

    def _refresh_mode_badge(self) -> None:
        badge = getattr(self, "_mode_badge", None)
        if badge is None or not hasattr(self, "legacy_switch"):
            return
        name, value = self.judgement_text()
        badge.setText(name)
        self._mode_badge_value.setText(value)
        # 구형은 예외 경로 — 배지가 색으로도 말하게 한다(모르고 켜둔 채 실행 방지).
        card = getattr(self, "_mode_badge_card", None)
        if card is not None:
            state = "legacy" if self.legacy_switch.is_on() else ""
            card.setProperty("badgeState", state)
            card.style().unpolish(card)
            card.style().polish(card)

    def _build_title(self) -> QWidget:
        # 화면 크기 컨트롤은 별도 버튼 없이 OS 의 표준 창 조작
        # (드래그, 최대화/복원, 모서리 리사이즈) 으로만 처리.
        title = QLabel(i18n.KO.SETUP_TITLE, self)
        title.setProperty("role", "title")
        self._title_label = title
        return title

    # ★ 나란히 둘지는 **카드가 요구하는 폭**으로 판단한다 — '900px' 같은 매직 넘버는
    #   맞출 수 없다.  실제로 900 으로 두었더니 1000px 창에서 두 카드가 나란히 서고
    #   가로 스크롤 58px 이 났다(경로 입력란 하한 240 + 라벨 + [폴더 선택…] × 2).
    #   `minimumSizeHint()` 는 카드 패딩·라벨·버튼을 모두 포함한 진짜 하한이다.
    # 101단계 슬라이더를 1200px 에 펼치면 단계당 12px — 넓을수록 정밀해지지 않는다.
    _SLIDER_MAX_W = 320
    _SLIDER_MIN_W = 200      # 101단계를 74px 에 펼치면 조절이 불가능하다(실측)
    # 폴더 이름이 읽히는 하한.  ★ 이건 **가독성 하한**이지 배치 상수가 아니다 —
    #   칸이 넓으면 입력란이 알아서 늘어난다(grid 의 열 stretch).  그런데 이 값이
    #   기준/검증 카드의 `minimumSizeHint` 를 통해 페이지 전체의 최소 폭을 결정해서,
    #   240 으로 두면 **1024px 창에서 6px 가 넘쳤다**(동봉 폰트 NanumSquare 로 바꾼 뒤
    #   라벨·[폴더 선택…] 버튼이 조금씩 넓어진 결과).  하한을 낮춰 여유를 준다 —
    #   실측: 224 일 때 1024px 에서 26px 여유(회귀 가드
    #   `test_setting_cards_layout.py::test_no_horizontal_scroll_at_any_width`).
    _PATH_MIN_W = 224

    def _build_device_row(self) -> QWidget:
        """기준/검증 장비 카드를 만들고, 설정 카드와 함께 놓일 호스트를 돌려준다.

        카드를 놓는 일은 `_place_setting_cards` 가 한다(두 열/한 열)."""
        host = QWidget(self)
        gap = theme.PROFILE.section_gap
        self._device_lay = QBoxLayout(QBoxLayout.Direction.LeftToRight, host)
        self._device_lay.setContentsMargins(0, 0, 0, 0)
        self._device_lay.setSpacing(gap)
        self._col_left = QVBoxLayout()
        self._col_right = QVBoxLayout()
        for col in (self._col_left, self._col_right):
            col.setContentsMargins(0, 0, 0, 0)
            col.setSpacing(gap)
        # Defect 추출 — 첫 LOT 줄의 [슬롯 선택](추출 모드에서만 보인다).
        self._lot1_slot_btn = NeonButton(i18n.KO.EXTRACT_SLOT_BTN_ALL, role="ghost")
        self._lot1_slot_btn.setVisible(False)
        # 이전 결과 엑셀을 기준으로 — 매칭 모드의 기준 폴더 줄 끝(추출 모드에서는 감춘다).
        self._excel_ref_btn = NeonButton(i18n.KO.EXCEL_REF_BTN, role="ghost")
        self._excel_ref_btn.setToolTip(i18n.KO.EXCEL_REF_BTN_TIP)
        self._excel_ref_btn.clicked.connect(self._pick_excel_ref)
        self.ref_group, self.ref_path_edit, self.ref_machine_edit = \
            self._make_machine_group(i18n.KO.SETUP_REF_GROUP,
                                     extra=self._lot1_slot_btn,
                                     extra2=self._excel_ref_btn)
        self._build_lot_list()
        self.val_group, self.val_path_edit, self.val_machine_edit = \
            self._make_machine_group(i18n.KO.SETUP_VAL_GROUP)
        self._build_val_list()
        self.ref_group.setProperty("joined", True)   # 기준/검증 사이엔 구분선을 두지 않는다
        self.val_group.body().setContentsMargins(0, 0, 0, 20)   # 구분선 위 숨 쉴 자리
        self._device_cards = [self.ref_group, self.val_group]
        self._device_host = host
        # 자기 폭이 정해진 뒤 두 열/한 열을 다시 고른다 — 호스트의 resize 를 직접 듣는다.
        host.installEventFilter(self)
        return host

    # ------------------------------------------------------------------
    # Defect 추출 — LOT 줄(최대 10개) + LOT 별 슬롯 선택
    # ------------------------------------------------------------------
    MAX_LOTS = 10

    def _build_lot_list(self) -> None:
        """대상 장비 카드 안, 첫 폴더 줄 아래의 추가 LOT 줄들 + [+ LOT 추가].

        첫 LOT 은 원래의 폴더 입력란(``ref_path_edit``)이다 — 매칭과 같은 칸을 쓴다.
        추가 줄마다 [폴더 선택…] · [슬롯 선택] · [✕].  추출 모드에서만 보인다."""
        self._lot_rows: list[dict] = [{
            "host": None, "edit": self.ref_path_edit,
            "slot_btn": self._lot1_slot_btn, "sel": None, "total": 0}]
        self._lot1_slot_btn.clicked.connect(lambda: self._pick_lot_slots(0))
        self.ref_path_edit.textChanged.connect(lambda _t: self._reset_lot_slots(0))
        host = QWidget(self.ref_group)
        host.setProperty("role", "rowHost")
        lay = QVBoxLayout(host)
        lay.setContentsMargins(0, 4, 0, 0)
        lay.setSpacing(8)
        self._lot_rows_lay = QVBoxLayout()
        self._lot_rows_lay.setSpacing(8)
        lay.addLayout(self._lot_rows_lay)
        self._lot_add_btn = NeonButton("", role="ghost")
        self._lot_add_btn.clicked.connect(self._add_lot_row)
        add_row = QHBoxLayout()
        add_row.addWidget(self._lot_add_btn)
        add_row.addStretch(1)
        lay.addLayout(add_row)
        host.setVisible(False)
        self.ref_group.body().addWidget(host)
        self._lot_list = host
        self._refresh_lot_add_btn()

    def _add_lot_row(self) -> None:
        if len(self._lot_rows) >= self.MAX_LOTS:
            return
        host = QWidget(self._lot_list)
        host.setProperty("role", "rowHost")
        row = QHBoxLayout(host)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)
        label = QLabel("", host)
        edit = QLineEdit(host)
        edit.setMinimumWidth(self._PATH_MIN_W)
        edit.setPlaceholderText(i18n.KO.EXTRACT_FOLDER_PLACEHOLDER)
        edit.setAcceptDrops(False)          # 놓기는 페이지가 받는다(`dropEvent`)
        browse = NeonButton(i18n.KO.BTN_BROWSE, role="ghost")
        slot_btn = NeonButton(i18n.KO.EXTRACT_SLOT_BTN_ALL, role="ghost")
        remove = NeonButton("✕", role="ghost")
        remove.setToolTip(i18n.KO.EXTRACT_LOT_REMOVE)
        remove.setAccessibleName(i18n.KO.EXTRACT_LOT_REMOVE)
        for w in (label, edit, browse, slot_btn, remove):
            row.addWidget(w, 1 if w is edit else 0)
        rec = {"host": host, "edit": edit, "slot_btn": slot_btn, "sel": None,
               "total": 0, "label": label}
        self._lot_rows.append(rec)
        browse.clicked.connect(lambda: self._browse(edit))
        slot_btn.clicked.connect(lambda: self._pick_lot_slots(self._lot_rows.index(rec)))
        remove.clicked.connect(lambda: self._remove_lot_row(rec))
        edit.textChanged.connect(
            lambda _t: (self._reset_lot_slots(self._lot_rows.index(rec)),
                        self._schedule_validate()))
        self._lot_rows_lay.addWidget(host)
        self._refresh_lot_add_btn()
        edit.setFocus()

    def _remove_lot_row(self, rec: dict) -> None:
        self._lot_rows.remove(rec)
        rec["host"].setParent(None)
        rec["host"].deleteLater()
        self._refresh_lot_add_btn()
        self._schedule_validate()

    def _refresh_lot_add_btn(self) -> None:
        n = len(self._lot_rows)
        self._lot_add_btn.setText(i18n.KO.EXTRACT_LOT_ADD_FMT.format(
            n=n, max=self.MAX_LOTS))
        self._lot_add_btn.setEnabled(n < self.MAX_LOTS)
        for k, r in enumerate(self._lot_rows[1:], start=2):     # 줄 번호
            r["label"].setText(f"LOT {k}")

    def _lot_paths(self) -> list[str]:
        """비어 있지 않은 LOT 줄의 경로들(위에서부터)."""
        return [r["edit"].text().strip() for r in self._lot_rows
                if r["edit"].text().strip()]

    # ------------------------------------------------------------------
    # 기준 1 ↔ 검증 여러 장비 — 검증 카드 안의 추가 장비 줄 + [+ 검증 장비 추가]
    # ------------------------------------------------------------------
    MAX_VALS = 5             # 첫 검증 장비 포함
    # 추가 장비 줄(✕ · 라벨 · 폴더 · 호기 · [폴더 선택…])이 들어갈 카드의 하한.  ★ 줄을
    # 추가하는 순간 카드의 최소 폭이 커져 두 열 ↔ 한 열이 뒤집히면 화면이 튄다 — 그래서
    # 줄이 없을 때도 이 값을 두 열 판단에 미리 넣는다(`_side_by_side_fits`).
    _VAL_ROW_EDIT_MIN_W = 150
    _VAL_CARD_MIN_W = 570
    _VAL_REMOVE_W = 44       # ✕ 폭 — 라벨 열이 '검증 5' + ✕ 를 담도록 `_row_label_w` 가 쓴다

    def _build_val_list(self) -> None:
        """검증 카드 아래의 추가 장비 줄들(`_build_lot_list` 와 같은 모양).

        줄마다 [폴더] [폴더 선택…] [호기] [✕].  하나도 없으면 예전 화면과 같다.
        Defect 추출에서는 검증 카드째 숨는다."""
        self._val_rows: list[dict] = []
        host = QWidget(self.val_group)
        host.setProperty("role", "rowHost")
        lay = QVBoxLayout(host)
        lay.setContentsMargins(0, 4, 0, 0)
        lay.setSpacing(8)
        self._val_rows_lay = QVBoxLayout()
        self._val_rows_lay.setSpacing(8)
        lay.addLayout(self._val_rows_lay)
        self._val_add_btn = NeonButton("", role="ghost")
        self._val_add_btn.clicked.connect(lambda: self._add_val_row())
        add_row = QHBoxLayout()
        add_row.addWidget(self._val_add_btn)
        add_row.addStretch(1)
        lay.addLayout(add_row)
        self.val_group.body().addWidget(host)
        self._val_list = host
        self._refresh_val_add_btn()

    def _add_val_row(self, path: str = "", machine: str = "") -> None:
        if len(self._val_rows) + 1 >= self.MAX_VALS:
            return
        host = QWidget(self._val_list)
        host.setProperty("role", "rowHost")
        row = QHBoxLayout(host)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)
        label = QLabel("", host)
        edit = QLineEdit(host)
        edit.setMinimumWidth(self._VAL_ROW_EDIT_MIN_W)
        edit.setPlaceholderText(i18n.KO.SETUP_FOLDER_PLACEHOLDER)
        edit.setText(path)
        browse = NeonButton(i18n.KO.BTN_BROWSE, role="ghost")
        machine_edit = QLineEdit(host)
        machine_edit.setPlaceholderText(i18n.KO.MULTI_VAL_MACHINE_PLACEHOLDER)
        machine_edit.setFixedWidth(120)      # 첫 장비와 같은 폭 — 줄 끝이 맞는다
        machine_edit.setText(machine)
        remove = NeonButton("✕", role="ghost")
        remove.setToolTip(i18n.KO.MULTI_VAL_REMOVE)
        remove.setAccessibleName(i18n.KO.MULTI_VAL_REMOVE)
        # ✕ 는 라벨 왼쪽 — 줄 끝이 첫 장비(…[폴더 선택])와 같고, 라벨+✕ 가 첫 장비의
        # 라벨 폭을 나눠 써서 입력란이 첫 장비와 같은 자리에서 시작한다.
        remove.setFixedWidth(self._VAL_REMOVE_W)
        label.setFixedWidth(self._row_label_w(label) - self._VAL_REMOVE_W - 10)
        for w in (remove, label, edit, machine_edit, browse):   # ✕ · 라벨 · 경로 · 호기 · 폴더 선택
            row.addWidget(w, 1 if w is edit else 0)
        rec = {"host": host, "edit": edit, "machine": machine_edit, "label": label}
        self._val_rows.append(rec)
        browse.clicked.connect(lambda: self._browse(edit))
        remove.clicked.connect(lambda: self._remove_val_row(rec))
        self._val_rows_lay.addWidget(host)
        self._refresh_val_add_btn()
        if not path:
            edit.setFocus()

    def _remove_val_row(self, rec: dict) -> None:
        self._val_rows.remove(rec)
        rec["host"].setParent(None)
        rec["host"].deleteLater()
        self._refresh_val_add_btn()

    def _refresh_val_add_btn(self) -> None:
        n = len(self._val_rows) + 1
        self._val_add_btn.setText(i18n.KO.MULTI_VAL_ADD_FMT.format(
            n=n, max=self.MAX_VALS))
        self._val_add_btn.setEnabled(n < self.MAX_VALS)
        for k, r in enumerate(self._val_rows, start=2):        # 줄 번호
            r["label"].setText(i18n.KO.MULTI_VAL_ROW_FMT.format(n=k))

    def _collect_extra_vals(self, ref_root: Path, val_root: Path):
        """추가 검증 장비 ``[(폴더, 호기), …]`` — 빈 줄은 건너뛴다.  잘못되면 None.

        같은 폴더를 두 번 넣으면 같은 결과가 두 벌 나올 뿐이라 막는다(기준과 같은
        폴더도 마찬가지 — 첫 검증 장비는 예전처럼 묻고 진행할 수 있다)."""
        out: list[tuple[Path, str]] = []
        seen = {ref_root.resolve(), val_root.resolve()}
        for k, rec in enumerate(self._val_rows, start=2):
            text = rec["edit"].text().strip()
            if not text:
                continue
            root = Path(text)
            if not root.is_dir():
                sheets.warn(self, i18n.KO.APP_TITLE,
                            i18n.KO.WARN_PATH_NOT_EXIST.format(path=root))
                return None
            if root.resolve() in seen:
                sheets.warn(self, i18n.KO.APP_TITLE,
                            i18n.KO.MULTI_VAL_DUPLICATE_FMT.format(path=root))
                return None
            seen.add(root.resolve())
            machine = (rec["machine"].text().strip()
                       or i18n.KO.MULTI_VAL_DEFAULT_MACHINE_FMT.format(n=k))
            out.append((root, machine))
        return out

    # -- 끌어다 놓기(Defect 추출) -------------------------------------
    @staticmethod
    def _drop_locals(event) -> list[str]:
        data = event.mimeData()
        if not data.hasUrls():
            return []
        return [u.toLocalFile() for u in data.urls() if u.toLocalFile()]

    def dragEnterEvent(self, event):        # noqa: N802
        # 여기서는 디스크를 보지 않는다(NAS 에서 멈추지 않게) — 로컬 경로가 있으면 받는다.
        # 도구 화면이 떠 있을 때는 받지 않는다 — 안 보이는 추출 목록에 몰래 쌓인다.
        if self._extract_mode and self._page_key == "match" and self._drop_locals(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):         # noqa: N802
        self.dragEnterEvent(event)

    def dropEvent(self, event):             # noqa: N802
        if not self._extract_mode or self._page_key != "match":
            event.ignore()
            return
        folders = extract_drop_folders(
            self._drop_locals(event), is_dir=lambda p: p.is_dir(),
            is_image=config.CONFIG.is_image)
        if not folders:
            event.ignore()
            return
        event.acceptProposedAction()
        self.add_extract_folders(folders)

    def add_extract_folders(self, folders: list[str]) -> int:
        """폴더들을 LOT 입력란에 넣는다 — 빈 줄부터 채우고, 모자라면 줄을 늘린다.

        이미 들어 있는 폴더는 건너뛴다.  최대 줄 수를 넘는 것은 넣지 않고 알린다.
        넣은 개수를 돌려준다."""
        import os

        def key(t: str) -> str:
            return os.path.normcase(os.path.normpath(t))

        have = {key(t) for t in self._lot_paths()}
        todo = [f for f in folders if key(f) not in have]
        added = 0
        for f in list(todo):
            row = next((r for r in self._lot_rows if not r["edit"].text().strip()),
                       None)
            if row is None:
                if len(self._lot_rows) >= self.MAX_LOTS:
                    break
                self._add_lot_row()
                row = self._lot_rows[-1]
            row["edit"].setText(f)
            todo.remove(f)
            added += 1
        if todo:
            sheets.info(self, i18n.KO.APP_TITLE,
                        i18n.KO.EXTRACT_DROP_TOO_MANY_FMT.format(
                            max=self.MAX_LOTS, n=len(todo)))
        return added

    def _reset_lot_slots(self, idx: int) -> None:
        """폴더가 바뀌면 그 줄의 슬롯 선택은 무효다 — 전체로 되돌린다."""
        if 0 <= idx < len(self._lot_rows):
            rec = self._lot_rows[idx]
            rec["sel"], rec["total"] = None, 0
            rec["slot_btn"].setText(i18n.KO.EXTRACT_SLOT_BTN_ALL)

    def _pick_lot_slots(self, idx: int) -> None:
        """LOT 한 줄의 슬롯을 고른다 — 매칭의 '일부 슬롯만' 과 같은 선택 창."""
        from ...models.slot import extract_slot_dirs
        from ..widgets.slot_select_dialog import SlotSelectDialog

        rec = self._lot_rows[idx]
        text = rec["edit"].text().strip()
        root = Path(text) if text else None
        if root is None or not root.is_dir():
            sheets.warn(self, i18n.KO.APP_TITLE, i18n.KO.EXTRACT_SLOT_NEED_FOLDER)
            return
        dirs = extract_slot_dirs(root)
        names = sorted(dirs)
        if not names:
            sheets.info(self, i18n.KO.APP_TITLE, i18n.KO.SLOT_SELECT_EMPTY)
            return
        dlg = SlotSelectDialog(names, preselected=rec["sel"], ref_dirs=dirs,
                               val_root=None, parent=self)
        if not (sheets.run(dlg) and dlg.accepted_ok):
            return                                   # 취소 — 그대로 둔다
        chosen = set(dlg.selected or ())
        if not chosen or chosen == set(names):
            self._reset_lot_slots(idx)
        else:
            rec["sel"], rec["total"] = chosen, len(names)
            rec["slot_btn"].setText(i18n.KO.EXTRACT_SLOT_BTN_FMT.format(
                n=len(chosen), total=len(names)))

    @tolerate_teardown
    def eventFilter(self, obj, event):  # noqa: N802
        from PyQt6.QtCore import QEvent
        if (event.type() == QEvent.Type.Resize
                and obj is getattr(self, "_device_host", None)):
            self._reflow_device_row()
        elif (event.type() == QEvent.Type.KeyPress
                and event.key() == Qt.Key.Key_Escape
                and any(obj is p.property("_dialog")
                        for p in getattr(self, "_tool_pages", {}).values())):
            # 화면으로 끼운 도구는 Esc 로 닫히면 안 된다(`_make_tool_page`).
            # 맵 전체화면만은 Esc 가 '빠져나오기' 다 — 그건 맵이 직접 받게 둔다.
            fs = getattr(obj, "is_fullscreen", None)
            return not (callable(fs) and fs())
        return super().eventFilter(obj, event)

    def _apply_width_class(self, wide: bool) -> None:
        """넓은 창 ↔ 좁은 창 — 같은 쪽이면 아무것도 안 한다.

        좁은 창(800×600 등)에서는 메뉴를 아이콘만 남기고 방식 구역을 위아래로 쌓는다
        (메뉴 200px 가 카드 폭을 갉아 가로 스크롤이 생기는 것을 막는다).  넓어지면
        사용자가 고른 상태로 되돌린다."""
        if wide == getattr(self, "_wide", None) or not hasattr(self, "_tool_rail"):
            return
        self._wide = wide
        self._rail_narrow_open = False
        if hasattr(self, "_mode_lay"):       # 방식 구역: 넓으면 나란히, 좁으면 위아래
            D = QBoxLayout.Direction
            self._mode_lay.setDirection(D.LeftToRight if wide else D.TopToBottom)
        self._apply_rail_collapsed(animate=False)

    def _reflow_device_row(self) -> None:
        """두 열/한 열을 지금 폭에 맞춘다(같은 배치면 아무것도 하지 않는다)."""
        if not hasattr(self, "_setting_cards"):
            return                       # 카드가 아직 다 만들어지기 전
        self._apply_width_class((self.width() or self.sizeHint().width())
                                >= _RAIL_SIDE_MIN_W)
        self._apply_card_orientation(self._side_by_side_fits())

    def resizeEvent(self, event):  # noqa: N802
        super().resizeEvent(event)
        self._reflow_device_row()

    def _build_run_options_card(self) -> QWidget:
        """실행 옵션 — '자동화 수준' 과 '진행 범위' 를 **한 카드**에 작은 세그먼트로.

        ★ 전에는 각각 전체폭 카드 한 장 + 694×58 타일 두 장이었다.  둘 다 값이 **둘뿐인**
        설정이고 매번 바꾸는 값도 아닌데, 화면의 두 덩어리를 차지해 '폴더를 고르고 시작
        한다'는 이 화면의 본론을 아래로 밀어냈다.  타일 크기는 고르는 값의 수가 아니라
        **그 선택의 무게**를 따라야 한다 — 그래서 34px 세그먼트로 강등하고 카드를 합쳤다
        (카드 2장 → 1장, 세로 ~200px 절약).

        각 줄은 `라벨 — 세그먼트 — (남는 폭)` 이다.  라벨을 왼쪽에 고정해 두 줄의 세그먼트
        왼쪽 변이 한 축에 정렬된다.
        """
        _prefs_now = _prefs.load()
        self._selected_slots: Optional[set] = None
        card = NeonCard(role="card", parent=self)
        card.setProperty("flat", True)
        card.setProperty("joined", True)     # 아래 허용 오차·구형 줄과 한 덩어리 — 구분선 없음
        card.body().setContentsMargins(0, 12, 0, 2)
        col = card.body()

        # ── 자동화 수준 — 키가 곧 AutomationLevel 값이라 분기 없이 읽는다.
        _last_auto = getattr(_prefs_now, "automation_level",
                             AutomationLevel.USER_SELECT)
        self.auto_group = OptionGroup(
            [(AutomationLevel.USER_SELECT, i18n.KO.AUTOMATION_USER_SELECT_SHORT),
             (AutomationLevel.AUTO_ALL, i18n.KO.AUTOMATION_AUTO_ALL_SHORT)],
            current=_last_auto, role="segment",
            min_tile_w=self._SEGMENT_MIN_W, fixed_cols=2,
            # 부수효과 없음(prefs 저장뿐) → 방향키로 바로 고를 수 있다(라디오 감각).
            activate_on_arrow=True, parent=card,
        )
        self.auto_group.set_option_tooltip(AutomationLevel.USER_SELECT,
                                           i18n.KO.AUTOMATION_USER_SELECT)
        self.auto_group.set_option_tooltip(AutomationLevel.AUTO_ALL,
                                           i18n.KO.AUTOMATION_AUTO_ALL)
        self.auto_group.selection_changed.connect(
            lambda key: _prefs.patch(automation_level=key))
        auto_row = self._labeled_segment_row(card, i18n.KO.AUTOMATION_TITLE,
                                             self.auto_group)
        col.addWidget(auto_row)

        # ── 진행 범위 — 상태가 **세그먼트 자신**에 산다(옆 라벨에 두지 않는다).
        #    ★ activate_on_arrow 를 켜지 않는다(기본 False) — 'subset' 선택은 슬롯 선택
        #      **모달**을 띄운다.  방향키로 훑는 것만으로 창이 떠선 안 된다.
        self.scope_group = OptionGroup(
            [("all", i18n.KO.SCOPE_ALL), ("subset", i18n.KO.SCOPE_SUBSET)],
            current="all", role="segment",
            min_tile_w=self._SEGMENT_MIN_W, fixed_cols=2, parent=card,
        )
        self.scope_group.set_option_tooltip("subset",
                                            i18n.KO.SLOT_SELECT_BTN_TOOLTIP)
        self.scope_group.selection_changed.connect(self._on_scope_changed)
        # 진행 범위 줄 — 추출 모드에서는 LOT 줄마다 [슬롯 선택] 이 대신한다(숨김).
        self._scope_row = self._labeled_segment_row(card, i18n.KO.SCOPE_TITLE,
                                                    self.scope_group)
        col.addWidget(self._scope_row)

        # Defect 추출 전용 — 엑셀에 Wafer Map 시트를 넣을지(사용자 결정: 끌 수 있게).
        # 추출 모드에서만 보인다(`set_extract_mode`).  마지막 선택을 기억한다.
        self._map_switch = SwitchRow(
            i18n.KO.EXTRACT_WAFER_MAP_SWITCH,
            description=i18n.KO.EXTRACT_WAFER_MAP_SWITCH_DESC,
            checked=bool(getattr(_prefs_now, "extract_wafer_map", True)),
            compact=True, parent=card)
        self._map_switch.toggled.connect(
            lambda on: _prefs.patch(extract_wafer_map=bool(on)))
        self._map_switch.setVisible(False)
        col.addWidget(self._map_switch)

        # 교차검증(양방향) — 매칭 전용(추출에서는 숨긴다).  기억하지 않는다 — 앱을 켤
        # 때마다 꺼진 채 시작한다(사용자 결정 2026-10-24).
        self._cross_switch = SwitchRow(i18n.KO.CROSS_SWITCH, checked=False, compact=True,
                                       parent=card)
        self._cross_switch.toggled.connect(self.cross_mode_changed)
        col.addWidget(self._cross_switch)

        return card

    # 세그먼트 하나의 **하한** 폭.  실제 폭은 그룹 안 가장 넓은 라벨에 맞춰 균등해진다
    # (OptionGroup._equalize_segments).  하한을 두는 이유는 '모든 슬롯'처럼 짧은 라벨이
    # 손가락에 너무 좁아지지 않게 하는 것.  둘이 나란히 서도 800px 창에서 넘치지 않는다
    # (110×2 + 간격 4 + 라벨 92 + 카드 패딩 40 ≈ 356 < 800 - 마진 80).
    _SEGMENT_MIN_W = 110
    _SEGMENT_LABEL_W = 92        # 두 줄의 세그먼트 왼쪽 변을 한 축에 맞춘다

    def _labeled_segment_row(self, parent: QWidget, label: str,
                             group: OptionGroup) -> QWidget:
        """`라벨 — 세그먼트 — 남는 폭` 한 줄.  두 설정이 같은 격자에 앉게 한다."""
        row = QWidget(parent)
        # 맨 QWidget 은 전역 `QWidget { background: $bg }` 를 물려받아 카드 면 위에 색이
        # 다른 띠로 보인다 — 투명으로 못 박는다(로딩 패널·행 호스트와 같은 함정).
        row.setProperty("role", "rowHost")
        lay = QHBoxLayout(row)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)
        lbl = QLabel(label, row)
        lbl.setFixedWidth(self._SEGMENT_LABEL_W)
        lay.addWidget(lbl)
        lay.addWidget(group)
        # ★ 남는 폭을 흡수하는 stretch — 없으면 세그먼트가 카드 폭만큼 늘어나 '작게'라는
        #   의도가 무너진다(그리드가 열마다 stretch 1 을 주기 때문).
        lay.addStretch(1)
        return row

    def _on_scope_changed(self, key: str) -> None:
        if key == "subset":
            self._open_slot_select()          # 취소/전체선택이면 내부에서 'all' 로 복귀
        else:
            self._reset_slot_selection()

    def _build_engine_card(self) -> QWidget:
        """매칭 설정 — 허용 오차(좌표) + 구형(유사도) 모드."""
        _prefs_now = _prefs.load()
        engine_card = NeonCard(role="card-soft", parent=self)
        engine_card.setProperty("flat", True)
        engine_card.setProperty("joined", True)    # 마지막 섹션 — 바 윗선이 맺음선이다
        engine_card.body().setContentsMargins(0, 2, 0, 12)

        # 좌표 매칭 허용 오차 — **항상 이 자리에 있다.**  구형 모드일 땐 비활성으로만
        # 보인다(숨기면 아래 구형 스위치가 위로 튄다 — `_sync_engine_controls` 참조).
        self._tol_row = QWidget(engine_card)
        # 맨 QWidget 은 전역 `QWidget { background: $bg }` 를 물려받아 카드 면($panel)
        # 위에 색이 다른 띠로 보인다 — 투명으로 못 박는다(로딩 패널과 같은 함정).
        self._tol_row.setProperty("role", "rowHost")
        _tol_layout = QHBoxLayout(self._tol_row)
        _tol_layout.setContentsMargins(0, 0, 0, 0)
        _tol_layout.setSpacing(6)
        _tol_label = QLabel(i18n.KO.COORD_TOLERANCE_LABEL, self._tol_row)
        _tol_label.setToolTip(i18n.KO.COORD_TOLERANCE_TOOLTIP)
        self.coord_tol_spin = NoWheelDoubleSpinBox(self._tol_row)
        self.coord_tol_spin.setRange(10.0, 5000.0)
        self.coord_tol_spin.setSingleStep(50.0)
        # 배지와 표기를 일치시킨다 — 같은 값을 200 / 200.0 두 가지로 쓰지 않는다.
        self.coord_tol_spin.setDecimals(0)
        self.coord_tol_spin.setSuffix(" µm")
        # 앱을 켤 때마다 기본값에서 시작한다 — 지난번 값을 기억하지 않는다(사용자 결정
        # 2026-10-24: '허용오차 기본값은 200um').
        self.coord_tol_spin.setValue(config.DEFAULT_COORD_TOLERANCE)
        self.coord_tol_spin.setToolTip(i18n.KO.COORD_TOLERANCE_TOOLTIP)
        # 수치는 모노 — '도면' 컨셉의 핵심인데 이 화면엔 모노가 한 글자도 없었다.
        self.coord_tol_spin.valueChanged.connect(
            lambda _v: (self._refresh_mode_badge(), self._schedule_validate()))
        self.coord_tol_spin.setProperty("role", "mono")
        self.coord_tol_spin.setAlignment(Qt.AlignmentFlag.AlignRight
                                        | Qt.AlignmentFlag.AlignVCenter)
        # ★ Qt 기본 up/down 버튼을 쓰지 않는다.  스타일시트로는 삼각형 화살표를 그릴 수
        #   없어(이미지 리소스 필요) 납작한 막대로 잘려 렌더되고, 폭도 ~10px 이라
        #   WCAG 2.5.8(24px)에 한참 못 미쳤다(4가지 방식 실측 비교 후 결론).
        #   대신 진짜 QPushButton −/+ 를 옆에 둔다 — 경계·포커스 링·타깃 규칙을 전부
        #   공유하고 새 리소스가 필요 없다.
        self.coord_tol_spin.setButtonSymbols(
            QDoubleSpinBox.ButtonSymbols.NoButtons)
        self.coord_tol_spin.setMinimumWidth(120)
        self.tol_minus_btn = self._stepper_button("−", -1)
        self.tol_plus_btn = self._stepper_button("+", +1)
        _tol_layout.addWidget(_tol_label)
        _tol_layout.addWidget(self.coord_tol_spin)
        _tol_layout.addWidget(self.tol_minus_btn)
        _tol_layout.addWidget(self.tol_plus_btn)
        _tol_layout.addStretch()
        engine_card.body().addWidget(self._tol_row)

        # 기준 폴더에서 읽어낸 die 크기 — 허용 오차를 자재에 맞게 정하도록 돕는다.
        # ★ 값을 대신 바꾸지 않는다.  조용히 값을 바꾸면 기존 결과가 달라진다 — 알리기만 한다.
        # ★ `_start_hint`·`_errLabel` 과 같은 관습: 자리를 예약해 두고 **문자열만** 바꾼다
        #   (setVisible 을 쓰면 아래 위젯이 위아래로 튄다).
        self._die_hint = QLabel("", engine_card)
        self._die_hint.setProperty("role", "muted")
        self._die_hint.setWordWrap(True)
        engine_card.body().addWidget(self._die_hint)

        # ── 구형(유사도) 모드 — 명시적 스위치 ─────────────────────────────
        # ★ 접이식 섹션을 쓰지 않는다.  예전에는 '섹션이 펼쳐졌는가'가 곧 엔진 모드였고,
        #   설명을 읽으려고 펼치기만 해도 좌표 → 유사도로 조용히 바뀌었다.  읽을 대상
        #   자체를 없애 같은 실수가 재발할 수 없게 한다.
        _legacy_on, _legacy_sub = self._resolved_legacy_state(_prefs_now)

        # 스위치는 제목 **바로 옆**(사용자 요청 — 카드 오른쪽 끝에 떨어져 있었다).
        self.legacy_switch = SwitchRow(
            i18n.KO.LEGACY_SWITCH_TITLE,
            checked=_legacy_on, compact=True,
            parent=engine_card,
        )
        # 언제 이 모드를 쓰는지는 툴팁으로 — 화면을 조용하게 유지한다.
        self.legacy_switch.setToolTip(i18n.KO.LEGACY_MODE_HINT)
        self.legacy_switch.toggled.connect(self._on_legacy_toggled)
        engine_card.body().addWidget(self.legacy_switch)

        # 구형 하위 선택 — 스위치가 켜졌을 때만 활성.
        self.legacy_group = OptionGroup(
            [(EngineMode.BASIC, i18n.KO.ENGINE_MODE_BASIC),
             (EngineMode.EFFICIENCY, i18n.KO.ENGINE_MODE_EFFICIENCY)],
            current=_legacy_sub,
            # 부수효과 없음 → 방향키 즉시 커밋 허용.
            activate_on_arrow=True, parent=engine_card,
        )
        self.legacy_group.selection_changed.connect(self._on_legacy_sub_changed)
        engine_card.body().addWidget(self.legacy_group)

        # 임계치 슬라이더 (구형 모드 전용 파라미터)
        self._threshold_row = QWidget(engine_card)
        self._threshold_row.setProperty("role", "rowHost")
        sl_row = QHBoxLayout(self._threshold_row)
        sl_row.setContentsMargins(0, 0, 0, 0)
        sl_row.addWidget(QLabel(i18n.KO.SETUP_THRESHOLD_LABEL, self._threshold_row))
        self.slider = NoWheelSlider(Qt.Orientation.Horizontal, self._threshold_row)
        self.slider.setRange(0, 100)
        self.slider.setValue(int(round(_prefs_now.threshold * 100)))
        # 101단계를 1219px 에 펼치면 단계당 12px 이라 정밀 조절이 오히려 어렵다.
        self.slider.setMaximumWidth(self._SLIDER_MAX_W)
        self.slider.setMinimumWidth(self._SLIDER_MIN_W)
        self.threshold_label = QLabel(f"{self.slider.value()} %", self._threshold_row)
        # 값은 모노 + 우측 정렬 — 자릿수가 바뀌어도 좌우로 춤추지 않는다.
        self.threshold_label.setProperty("role", "mono")
        self.threshold_label.setAlignment(Qt.AlignmentFlag.AlignRight
                                          | Qt.AlignmentFlag.AlignVCenter)
        self.threshold_label.setFixedWidth(56)
        self.slider.valueChanged.connect(self._on_threshold_changed)
        sl_row.addWidget(self.slider, stretch=1)
        sl_row.addWidget(self.threshold_label)
        sl_row.addStretch(1)          # 상한 폭을 넘는 여백은 오른쪽으로
        engine_card.body().addWidget(self._threshold_row)

        # 지금 어느 파라미터가 유효한지 문장으로 — 비활성 컨트롤의 이유를 말해준다.
        self._engine_inert_hint = QLabel("", engine_card)
        self._engine_inert_hint.setProperty("role", "muted")
        self._engine_inert_hint.setWordWrap(True)
        engine_card.body().addWidget(self._engine_inert_hint)

        self._sync_engine_controls()
        return engine_card

    def _stepper_button(self, glyph: str, step: int) -> NeonButton:
        """허용 오차 ±  — 정사각 버튼.  Qt 스핀 버튼 대신 쓴다(위 주석 참조)."""
        btn = NeonButton(glyph, role="stepper")
        side = theme.PROFILE.input_h
        btn.setFixedWidth(side)     # 높이는 QSS 가 input_h 로 고정한다(중심 정렬)
        btn.setAccessibleName(i18n.KO.TOL_STEP_UP if step > 0
                              else i18n.KO.TOL_STEP_DOWN)
        btn.setToolTip(btn.accessibleName())
        btn.clicked.connect(lambda: self.coord_tol_spin.stepBy(step))
        return btn

    # ------------------------------------------------------------------
    @staticmethod
    def _resolved_legacy_state(p) -> tuple[bool, str]:
        """prefs → (구형 on?, 하위 엔진).  실제 prefs 로 생성되므로 방어적으로."""
        try:
            return _prefs.resolve_legacy_state(p)
        except Exception:
            return (False, EngineMode.BASIC)

    def _current_engine_mode(self) -> str:
        """엔진 모드는 **명시 컨트롤 상태**에서만 유도한다.

        ★ 접이식 펼침 상태(is_expanded 등)를 절대 읽지 않는다 — 설명을 읽는 행위가
        엔진을 바꾸던 버그의 재발 방지."""
        if not self.legacy_switch.is_on():
            return EngineMode.COORDINATE
        sub = self.legacy_group.current_key()
        return sub if sub in (EngineMode.BASIC, EngineMode.EFFICIENCY) \
            else EngineMode.BASIC

    def _sync_engine_controls(self) -> None:
        """무효한 파라미터를 정리한다 — **다만 토글은 절대 움직이지 않게.**

        | 구형 스위치 | 허용 오차(µm) | 구형 하위 선택 · 유사도 임계치 |
        |---|---|---|
        | OFF (좌표 매칭) | 보임 · 사용 가능 | **숨김** |
        | ON (구형)       | 보임 · **비활성(회색)** | 보임 |

        ★ 숨기기와 비활성을 **위치로 나눈다.**  이 카드의 위젯 순서는
        `제목 → 허용 오차 → [구형 스위치] → 구형 하위선택 → 임계치` 다.

        - 스위치 **아래**에 있는 것(하위 선택·임계치)은 숨겨도 스위치가 안 움직인다
          → 안 쓸 때 숨긴다(사용자 결정 유지).
        - 스위치 **위**에 있는 허용 오차를 숨기면 스위치가 그 높이+간격만큼 위로
          튄다 — 사용자가 "구형 모드 켜면 박스 안 객체들이 움직이면서 토글 위치가
          변한다" 고 신고한 그 현상이다.  그래서 **자리는 지키고 비활성**으로만 보인다.

        비활성 회색은 이미 있는 QSS 가 칠한다(`QDoubleSpinBox:disabled` ·
        `QLabel:disabled` · `QPushButton[role="stepper"]:disabled`) — 새 스타일 불필요.
        `setEnabled(False)` 는 자식에 전파되므로 행 전체가 한 번에 회색이 된다.

        지금 어느 엔진이 도는지는 `_engine_inert_hint` 한 줄과 상단 모드 배지가 말한다."""
        legacy_on = self.legacy_switch.is_on()
        self.legacy_group.setVisible(legacy_on)
        self._threshold_row.setVisible(legacy_on)
        self._tol_row.setVisible(True)
        self._tol_row.setEnabled(not legacy_on)
        if legacy_on:
            short = (i18n.KO.ENGINE_MODE_EFFICIENCY_SHORT
                     if self.legacy_group.current_key() == EngineMode.EFFICIENCY
                     else i18n.KO.ENGINE_MODE_BASIC_SHORT)
            text = i18n.KO.ENGINE_ACTIVE_LEGACY_FMT.format(sub=short)
        else:
            # 좌표 매칭(기본)일 때는 문장을 두지 않는다(사용자 요청 — 배지가 이미 말한다).
            text = ""
        self._engine_inert_hint.setText(text)
        self._engine_inert_hint.setVisible(bool(text))
        self._refresh_mode_badge()

    def _on_legacy_toggled(self, on: bool) -> None:
        self._sync_engine_controls()
        _prefs.patch(legacy_enabled=bool(on),
                     engine_mode=self._current_engine_mode())

    def _on_legacy_sub_changed(self, key: str) -> None:
        self._sync_engine_controls()
        _prefs.patch(legacy_engine=key, engine_mode=self._current_engine_mode())

    # 도구 레일 폭 — 가장 긴 이름 'Wafer Map 보기' 가 들어가는 하한.
    _RAIL_W = 200
    # 접은 메뉴의 버튼 한 변 — 아이콘(20) 양옆 16px.
    _RAIL_ICON_W = 52
    # 접은 메뉴의 좌우 여백.  펼친 메뉴는 창 여백(page_margin)·섹션 간격을 쓴다.
    _RAIL_FOLD_PAD = 12

    def _build_tool_rail(self) -> QWidget:
        """왼쪽 메뉴 — 매칭 · 사진 정보 · Wafer Map · Defect 추출 · GL, 맨 아래 업데이트 확인.

        ★ 메뉴는 화면 스택 **밖**에 있다 — 어느 화면에서든 그 자리에 남아 화면을 바꾼다
        (사용자 요청 2026-10-30).  지금 보는 화면의 버튼은 눌린 모양(checked)이다.
        [«] 를 누르면 아이콘만 남고(이름은 툴팁), 도구 화면으로 가면 저절로 접힌다.
        도구는 흐린 글자 링크가 아니라 **이름이 보이는 같은 크기 버튼**이다(사용자 요청:
        사이드 기능도 중요)."""
        host = QWidget(self)
        host.setProperty("role", "rowHost")
        col = QVBoxLayout(host)
        self._rail_lay = col
        col.setSpacing(10)
        # 로고 + 제목 + [«] 한 줄(로고는 사용자 요청 2026-10-29 로 메뉴 맨 위).
        head = QWidget(host)
        head.setProperty("role", "rowHost")
        hl = QHBoxLayout(head)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setSpacing(10)
        # 로고+제목은 한 칸에 묶는다 — 서랍이 좁아지면 이 칸이 오른쪽부터 가려진다(제목 →
        # 로고 순).  칸의 최소 폭을 0 으로 풀어 [«] 를 밀어내지 않는다.
        brand = QWidget(head)
        brand.setProperty("role", "rowHost")
        brand.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        bl = QHBoxLayout(brand)
        bl.setSizeConstraint(QHBoxLayout.SizeConstraint.SetNoConstraint)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(10)
        self._rail_logo = build_logo_label(brand, inline=True)
        self._rail_logo.setFixedSize(34, 34)
        self._rail_logo.setScaledContents(True)
        bl.addWidget(self._rail_logo)
        title = self._build_title()
        title.setProperty("role", "railTitle")       # 26px 제목이 아니라 레일 폭에 맞는 크기
        bl.addWidget(title, 1)
        self._rail_brand = brand
        hl.addWidget(brand, 1)
        # 제목이 숨으면 이 빈칸이 [«] 를 오른쪽 끝에 붙들어 둔다(서랍이 움직이는 동안 안 튄다).
        hl.addStretch(0)
        self.rail_fold_btn = NeonButton("", role="ghost")
        self.rail_fold_btn.setProperty("grade", "railFold")
        self.rail_fold_btn.setFixedSize(34, 34)
        self.rail_fold_btn.setIconSize(QSize(20, 20))
        self.rail_fold_btn.clicked.connect(self.toggle_rail)
        hl.addWidget(self.rail_fold_btn)
        self._rail_head = head
        col.addWidget(head)
        col.addSpacing(6)
        # 기본 화면(매칭 설정)으로 돌아오는 버튼 — 아이콘은 프로그램 아이콘(사용자 요청).
        self.match_btn = NeonButton(i18n.KO.MATCH_NAV_BUTTON, role="ghost")
        self.match_btn.setToolTip(i18n.KO.MATCH_NAV_TOOLTIP)
        self.match_btn.clicked.connect(lambda: self.show_page("match"))
        # 사진 한 장의 결함 정보를 바로 보는 도구.
        self.image_info_btn = NeonButton(i18n.KO.IMAGE_INFO_BUTTON, role="ghost")
        self.image_info_btn.clicked.connect(self._open_image_info)
        # 웨이퍼 폴더 하나의 결함 위치를 원 위에 보는 도구.
        self.wafer_map_btn = NeonButton(i18n.KO.WAFER_MAP_BUTTON, role="ghost")
        self.wafer_map_btn.clicked.connect(self._open_wafer_map)
        # Defect 추출 — 같은 화면을 한쪽 폴더만 받는 모드로 바꾼다([매칭] 으로 되돌아간다).
        self.extract_btn = NeonButton(i18n.KO.EXTRACT_BUTTON, role="ghost")
        self.extract_btn.setToolTip(i18n.KO.EXTRACT_BUTTON_TOOLTIP)
        self.extract_btn.clicked.connect(lambda: self.show_page("extract"))
        # 사진 한 장의 GL(밝기) 분포를 히스토그램·선 프로파일·통계로 보는 도구.
        # 준비 전(`config.GL_HISTOGRAM_READY`)에는 아이콘은 그대로 두고 'Coming soon' 으로 막는다.
        if config.GL_HISTOGRAM_READY:
            self.gl_btn = NeonButton(i18n.KO.GL_BUTTON, role="ghost")
            self.gl_btn.setToolTip(i18n.KO.GL_BUTTON_TOOLTIP)
            self.gl_btn.clicked.connect(self._open_gl_viewer)
        else:
            self.gl_btn = NeonButton(i18n.KO.GL_COMING_SOON, role="ghost")
            self.gl_btn.setToolTip(i18n.KO.GL_COMING_SOON_TOOLTIP)
        self.update_btn = NeonButton(i18n.KO.MENU_CHECK_UPDATE, role="ghost")
        self.update_btn.clicked.connect(self.update_check_requested.emit)
        self._nav_buttons = {"match": self.match_btn, "image_info": self.image_info_btn,
                             "wafer_map": self.wafer_map_btn, "extract": self.extract_btn,
                             "gl": self.gl_btn}
        for b in self._nav_buttons.values():
            b.setProperty("grade", "rail")
            b.setCheckable(True)
            b.setMinimumHeight(52)
            col.addWidget(b)
        self.match_btn.setIcon(QIcon(str(paths.logo_path("logo.ico"))))
        for b, icon in ((self.image_info_btn, "camera"), (self.wafer_map_btn, "globe"),
                        (self.extract_btn, "doc"), (self.gl_btn, "bars"),
                        (self.update_btn, "refresh")):
            b.setIcon(rail_icon(icon))
        if not config.GL_HISTOGRAM_READY:
            # 누를 수 없게 하되 아이콘은 회색으로 바꾸지 않는다(사용자 요청 '아이콘은 그대로').
            icon = self.gl_btn.icon()
            icon.addPixmap(icon.pixmap(QSize(20, 20)), QIcon.Mode.Disabled)
            self.gl_btn.setIcon(icon)
            self.gl_btn.setEnabled(False)
        for b in (*self._nav_buttons.values(), self.update_btn):
            b.setIconSize(QSize(20, 20))
            b.setProperty("_railText", b.text())
            b.setProperty("_railTip", b.toolTip())
        col.addStretch(1)
        # 업데이트 확인 + 크레딧은 유틸리티라 도구 목록과 떨어진 메뉴 맨 아래.
        self.update_btn.setProperty("grade", "rail")
        self.update_btn.setMinimumHeight(52)
        col.addWidget(self.update_btn)
        self._rail_credit = QLabel(i18n.KO.CREDIT, host)
        self._rail_credit.setProperty("role", "muted")
        col.addWidget(self._rail_credit)
        # 레일 순서 계약(test_setup_controls) — 매칭 + 도구 넷.  업데이트는 맨 아래 따로.
        self._tool_buttons = [self.match_btn, self.image_info_btn, self.wafer_map_btn,
                              self.extract_btn, self.gl_btn]
        self._tool_rail = host
        # 접힘 상태 — 상황마다 따로 기억한다(`_rail_should_fold`).  매칭 화면에서 고른 것
        # (`_rail_user_folded`)은 도구 화면·좁은 창에서 잠깐 펼쳐도 바뀌지 않는다.
        self._rail_t = 1.0
        # 서랍이 좁아지는 동안 버튼·글자가 칸을 밀어내지 않고 **가려지게** — 최소 폭을
        # 글자 폭이 아니라 아이콘 칸으로 낮춘다.
        for b in (*self._nav_buttons.values(), self.update_btn):
            b.setMinimumWidth(self._RAIL_ICON_W)
        for lb in (self._title_label, self._rail_credit):
            lb.setMinimumWidth(1)
            lb.setSizePolicy(QSizePolicy.Policy.Ignored, lb.sizePolicy().verticalPolicy())
        self._rail_user_folded = False
        self._rail_tool_open = False         # 도구 화면에서 사용자가 펼쳤나(들어갈 때마다 접힘)
        self._rail_narrow_open = False       # 좁은 창에서 사용자가 펼쳤나(폭이 바뀌면 접힘)
        self._rail_folded: Optional[bool] = None
        self._rail_anim = None
        self._apply_rail_collapsed(animate=False)
        self._sync_nav_checked()
        return host

    # ------------------------------------------------------------------
    # 왼쪽 메뉴 — 접기 · 화면 이동
    # ------------------------------------------------------------------
    def is_rail_folded(self) -> bool:
        return bool(self._rail_folded)

    def _rail_should_fold(self) -> bool:
        """도구 화면이면 접고, 좁은 창이면 접고, 아니면 사용자가 고른 대로 — 각 상황에서
        사용자가 [»] 로 펼쳤으면 그 상황 동안은 펼친다(눌러도 안 펼쳐지면 죽은 버튼이다)."""
        if self._page_key != "match":
            return not self._rail_tool_open
        if not getattr(self, "_wide", True):
            return not self._rail_narrow_open
        return self._rail_user_folded

    def toggle_rail(self) -> None:
        """[«]/[»] — 메뉴를 아이콘만 ↔ 이름까지.  지금 상황의 선택만 바꾼다."""
        if self._page_key != "match":
            self._rail_tool_open = bool(self._rail_folded)
        elif not getattr(self, "_wide", True):
            self._rail_narrow_open = bool(self._rail_folded)
        else:
            self._rail_user_folded = not self._rail_folded
        self._apply_rail_collapsed(animate=True)

    def _apply_rail_collapsed(self, *, animate: bool) -> None:
        self._set_rail_folded(self._rail_should_fold(), animate=animate)

    def _rail_width(self, folded: bool) -> int:
        if folded:
            return 2 * self._RAIL_FOLD_PAD + self._RAIL_ICON_W
        return theme.PROFILE.page_margin + self._RAIL_W + theme.PROFILE.section_gap

    def _set_rail_folded(self, folded: bool, *, animate: bool) -> None:
        """메뉴를 접는다/편다 — **서랍처럼** 닫히고 열린다.

        폭과 좌우 여백을 한 진행값(`_rail_t`, 0=접힘·1=펼침)으로 함께 몰아, 아이콘은
        제자리에서 미끄러지고 이름은 서랍 오른쪽 끝에 가려지며 사라진다(펴질 때는 그
        반대).  글자를 먼저 지우거나 끝에 툭 붙이지 않는다 — 접힌 52px 칸에서는 글자가
        어차피 가려져 있어, 시작·끝에 글자를 바꿔도 화면에 이음매가 없다.
        """
        folded = bool(folded)
        if folded == self._rail_folded:
            return
        self._rail_folded = folded
        from .. import motion
        self.rail_fold_btn.setIcon(rail_icon("unfold" if folded else "fold"))
        self.rail_fold_btn.setToolTip(i18n.KO.RAIL_UNFOLD_TOOLTIP if folded
                                      else i18n.KO.RAIL_FOLD_TOOLTIP)
        end = 0.0 if folded else 1.0
        if self._rail_anim is not None:
            self._rail_anim.stop()
        if not folded:
            self._rail_show_labels(True)       # 52px 칸에선 가려져 있다가 서랍이 열리며 드러난다
        # 크레딧은 서랍이 움직이는 동안 감춰 두고 멈춘 뒤 자리를 정한다(_rail_settle) — 그때
        # 창이 상태줄을 켜고 끈다.  시작에 바꾸면 상태줄이 서랍보다 먼저 튀어 화면이 밀린다.
        self._rail_credit.setVisible(False)
        if not animate or not motion.enabled() or not self.isVisible():
            self._apply_rail_t(end)
            self._rail_settle()
            return
        anim = self._rail_anim
        if anim is None:
            # ★ 위젯당 하나만 만들어 재사용한다(motion 규약).  tick 은 부모(this)의 자식만 만진다.
            anim = QVariantAnimation(self)
            anim.valueChanged.connect(self._on_rail_tick)
            anim.finished.connect(self._rail_settle)
            self._rail_anim = anim
        # 서랍 — 감속 곡선 하나로 끝까지 보이게(motion 기본).  닫힐 때가 조금 더 짧다
        # (나가는 쪽을 짧게: motion.py 원칙).
        anim.setEasingCurve(motion.EASE_PRIMARY)
        anim.setDuration(motion.DUR_RAIL_FOLD if folded else motion.DUR_RAIL_UNFOLD)
        anim.setStartValue(float(self._rail_t))
        anim.setEndValue(end)
        # 서랍이 움직이는 동안 도구 화면의 폭이 잠깐 최소 폭보다 좁아져 가로 스크롤이
        # 깜빡인다 — 움직이는 동안만 막고, 멈추면(_rail_settle) 되돌린다.
        self._set_tool_hscroll(False)
        anim.start()

    def _on_rail_tick(self, value) -> None:
        self._apply_rail_t(float(value))

    def _apply_rail_t(self, t: float) -> None:
        """진행값 t(0=접힘·1=펼침) 하나로 폭·여백·머리줄을 맞춘다."""
        t = max(0.0, min(1.0, float(t)))
        self._rail_t = t
        m, gap, pad = theme.PROFILE.page_margin, theme.PROFILE.section_gap, self._RAIL_FOLD_PAD
        w0, w1 = self._rail_width(True), self._rail_width(False)
        left = round(pad + (m - pad) * t)
        right = round(pad + (gap - pad) * t)
        self._tool_rail.setFixedWidth(round(w0 + (w1 - w0) * t))
        self._rail_lay.setContentsMargins(left, m, right, 10)
        # [«] 는 펼치면 머리줄 오른쪽 끝, 접히면 아이콘 줄과 같은 세로선(52 칸의 가운데) —
        # 그 사이를 같은 t 로 옮긴다(끝에서 튀지 않게).
        shift = round((self._RAIL_ICON_W - self.rail_fold_btn.width()) / 2 * (1.0 - t))
        self._rail_head.layout().setContentsMargins(0, 0, shift, 0)
        # 로고·제목은 묶음 칸째 서랍 끝에 가려지며 줄어든다 — 다 닫혔을 때만 감춘다.
        self._rail_brand.setVisible(t > 0.0)

    def _rail_settle(self) -> None:
        """서랍이 멈춘 자리 — 최종 값을 박고, 접혔으면 이름을 툴팁으로 옮긴다."""
        folded = bool(self._rail_folded)
        self._apply_rail_t(0.0 if folded else 1.0)
        self._rail_show_labels(not folded)
        self._rail_credit.setVisible(not folded)
        self._set_tool_hscroll(True)
        if hasattr(self, "_setting_cards"):
            self._apply_card_orientation(self._side_by_side_fits())

    def _set_tool_hscroll(self, on: bool) -> None:
        policy = (Qt.ScrollBarPolicy.ScrollBarAsNeeded if on
                  else Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        for holder in self._tool_pages.values():
            holder.setHorizontalScrollBarPolicy(policy)

    def _rail_show_labels(self, on: bool) -> None:
        """이름 ↔ 아이콘만.  접힌 동안 이름은 툴팁으로 옮긴다(아이콘만으로는 뜻을 모른다)."""
        for b in (*self._nav_buttons.values(), self.update_btn):
            text, tip = b.property("_railText") or "", b.property("_railTip") or ""
            b.setText(text if on else "")
            b.setToolTip(tip if on else (f"{text}\n{tip}" if tip else text))

    def tool_title(self) -> str:
        """지금 보이는 도구 화면의 제목(매칭·추출이면 빈 문자열) — 창 맨 위 단계 줄에 띄운다."""
        dlg = self.tool_dialog(self._page_key) if self._page_key != "match" else None
        return dlg.windowTitle() if dlg is not None else ""

    def current_page(self) -> str:
        """지금 오른쪽에 보이는 화면 — match · extract · image_info · wafer_map · gl."""
        if self._page_key == "match" and self._extract_mode:
            return "extract"
        return self._page_key

    def _sync_nav_checked(self) -> None:
        cur = self.current_page()
        for key, b in self._nav_buttons.items():
            b.setChecked(key == cur)

    def show_page(self, key: str) -> None:
        """왼쪽 메뉴로 화면을 옮긴다.

        - ``match``·``extract``: 매칭 설정 화면(추출은 같은 화면의 한쪽 폴더 모드).
          도구 화면에서 돌아오면 메뉴를 사용자가 매칭 화면에서 고른 접힘 상태로 되돌린다.
        - ``image_info``·``wafer_map``·``gl``: 도구 화면.  처음 갈 때 만들고 살려 두며,
          메뉴는 저절로 아이콘만 남긴다(사용자 요청 — 도구는 화면이 넓어야 한다).

        화면이 바뀌는 순간은 **한 박자**로 묶는다: 오른쪽 화면은 누른 즉시 바뀌고,
        메뉴 서랍이 닫히며(또는 열리며) 창 위 단계 줄이 같은 시간·곡선으로 접혀
        올라간다(창이 `page_changed` 를 받아).
        ★ 새 화면에 페이드(그래픽 이펙트)를 걸지 마라 — 페이지는 배경을 칠하지 않아
          첫 프레임이 **검은 사각형**으로 찍혔다(실측, 프레임 캡처)."""
        if key in ("match", "extract"):
            self._page_key = "match"
            self._pages.setCurrentWidget(self._match_host)
            if (key == "extract") != self._extract_mode:
                self.set_extract_mode(key == "extract")
            self._apply_rail_collapsed(animate=True)
        else:
            page = self._tool_pages.get(key)
            if page is None:
                page = self._make_tool_page(key)
                self._tool_pages[key] = page
                self._pages.addWidget(page)
            entering = self._page_key == "match"
            self._page_key = key
            self._pages.setCurrentWidget(page)
            if entering:
                self._rail_tool_open = False
            self._apply_rail_collapsed(animate=True)
            page.property("_dialog").setFocus(Qt.FocusReason.OtherFocusReason)
        self._sync_nav_checked()
        self.page_changed.emit(self.current_page())

    def tool_dialog(self, key: str):
        """만들어 둔 도구 화면의 본체(없으면 None) — 테스트·창이 상태를 볼 때."""
        page = self._tool_pages.get(key)
        return page.property("_dialog") if page is not None else None

    def _make_tool_page(self, key: str) -> QWidget:
        """도구 다이얼로그를 **화면**으로 끼운다(시트로 띄우지 않는다).

        시트일 때 제목줄이 하던 '무슨 화면인지' 는 창 맨 위 단계 줄이 대신한다(`tool_title`,
        사용자 요청 2026-10-30 — 화면 안에 제목줄을 또 두지 않는다).  닫기 ✕ 는 없다 —
        나가는 길은 왼쪽 메뉴다.  ★ Esc 는 삼킨다: QDialog 는 Esc 로 reject→hide
        하므로 그냥 두면 화면이 빈 칸으로 사라진다(맵 전체화면의 Esc 는 그대로 통과)."""
        if key == "image_info":
            from ..widgets.image_info_dialog import ImageInfoDialog
            dlg = ImageInfoDialog(self)
        elif key == "wafer_map":
            from ..widgets.wafer_map_dialog import WaferMapDialog
            dlg = WaferMapDialog(self)
            dlg.fullscreen_changed.connect(self._on_tool_fullscreen)
        else:
            from ..widgets.gl_viewer_dialog import GlViewerDialog
            dlg = GlViewerDialog(self)
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        dlg.setParent(page)
        dlg.setWindowFlags(Qt.WindowType.Widget)
        dlg.installEventFilter(self)
        v.addWidget(dlg, 1)
        dlg.show()
        # ★ 스크롤 칸으로 감싼다.  QStackedWidget 의 최소 크기는 **숨은 페이지까지** 합쳐
        #   잡히므로, 한 번 연 도구(긴 파일명·줄바꿈 없는 도구줄)가 매칭 화면까지 넓혀
        #   좁은 창에서 가로 스크롤을 만든다.  스크롤 칸은 자기 최소 크기가 작아 그걸 끊는다.
        holder = QScrollArea(self._pages)
        holder.setWidgetResizable(True)
        holder.setFrameShape(QScrollArea.Shape.NoFrame)
        holder.setStyleSheet(
            "QScrollArea { background: transparent; border: none; }"
            "QScrollArea > QWidget#qt_scrollarea_viewport { background: transparent; }")
        holder.setWidget(page)
        holder.setProperty("_dialog", dlg)
        return holder

    def _on_tool_fullscreen(self, on: bool) -> None:
        """맵만 남기는 보기 — 메뉴도 감추고, 창(맨 위 단계 줄·상태바)에 알린다."""
        self._tool_rail.setVisible(not on)
        self._rail_rule.setVisible(not on)
        self.tool_fullscreen_changed.emit(bool(on))

    def _build_action_bar(self) -> QWidget:
        """고정 시작 바 — 판정 기준(왼쪽) · 시작할 수 없는 이유 · [검증 시작](오른쪽)."""
        host = QWidget(self)
        host.setProperty("role", "actionBar")      # 본문과 다른 면 — 고정된 바닥임을 보인다
        host.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        bar = QHBoxLayout(host)
        bar.setContentsMargins(0, 0, 0, 0)
        # ★ 자리 계약: 판정 기준 배지 → stretch → 힌트 → 주 액션(start_btn).
        #   새 위젯은 반드시 stretch **뒤**에 붙인다 — 잘못 넣으면 주 액션이 가운데로
        #   밀린다(test_action_bar_index_contract).  판정 기준이 시작 버튼과 같은 줄에
        #   있어야 '무슨 기준으로 도는지' 를 보고 누른다(모르고 켜둔 구형 엔진 방지).
        self._action_bar = bar
        bar.addWidget(self._build_mode_badge())   # 판정 기준 — 바 왼쪽 끝(사용자 결정 2026-10-28)
        self._refresh_mode_badge()
        bar.addStretch(1)
        # 왜 시작할 수 없는지 — 툴팁이 아니라 버튼 옆에 보이게.
        self._start_hint = QLabel("", host)
        self._start_hint.setProperty("role", "muted")
        # ★ 좁은 창에서는 두 줄로 접힌다(한 줄 고정이면 이 문구가 바의 최소 폭을 정한다).
        # 넓을 땐 한 줄(두 줄로 접히면 바가 어색하게 높아진다) — 좁은 창에서만 접는다.
        self._start_hint.setWordWrap(False)
        bar.addWidget(self._start_hint)
        self.start_btn = NeonButton(i18n.KO.BTN_START, role="primary")
        self.start_btn.setMinimumWidth(220)
        self.start_btn.setMinimumHeight(48)   # 유일한 primary — 가장 크게
        self.start_btn.clicked.connect(self._on_start)
        bar.addWidget(self.start_btn)
        self._validate()                      # 초기 상태(폴더 미지정) 반영
        return host

    # ------------------------------------------------------------------
    @staticmethod
    def _row_label_w(w: QWidget) -> int:
        """폴더 줄 왼쪽 라벨(기준/검증/대상 장비)의 공통 폭 — 굵은 글씨 여유 포함.

        추가 검증 줄의 '검증 N + ✕' 가 들어갈 폭을 하한으로 둔다(첫 줄 라벨 열도 같이 넓어져
        모든 줄의 입력란이 같은 자리에서 시작한다)."""
        fm = w.fontMetrics()
        names = (i18n.KO.SETUP_REF_GROUP, i18n.KO.SETUP_VAL_GROUP, i18n.KO.EXTRACT_GROUP)
        w_names = max(fm.horizontalAdvance(n) for n in names) + 14
        # 추가 검증 줄은 같은 열에 '검증 N' + ✕ 를 담는다 — 안 잘리게 하한을 둔다.
        w_extra = (fm.horizontalAdvance(i18n.KO.MULTI_VAL_ROW_FMT.format(n=5))
                   + SetupPage._VAL_REMOVE_W + 20)
        return max(w_names, w_extra)

    def _make_machine_group(self, title: str, extra: Optional[QWidget] = None,
                            extra2: Optional[QWidget] = None
                            ) -> tuple[QWidget, QLineEdit, QLineEdit]:
        """기준/검증 장비 입력 카드.

        QGroupBox(라디우스 8px + margin-top) 대신 카드 + 그리드로 — 시트의 형태 언어와
        일치하고, 두 카드의 필드가 같은 열에 정렬된다."""
        card = NeonCard(role="card", parent=self)
        card.setProperty("flat", True)
        card.body().setContentsMargins(0, 8, 0, 0)
        head = QLabel(title, card)
        head.setProperty("role", "cardTitle")
        card.setProperty("_headLabel", head)      # 추출 모드가 제목을 바꾼다
        head.setMinimumWidth(self._row_label_w(head))   # 기준/검증이 같은 폭 — 입력란이 같은 선

        grid = QGridLayout()
        grid.setContentsMargins(0, 4, 0, 0)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(4)
        grid.setColumnStretch(1, 1)          # 입력란이 늘어난다

        path_edit = QLineEdit(card)
        # 폴더 경로는 읽혀야 의미가 있다 — 컨테이너 계산이 어긋나도 이 하한은 남는다
        # (B안 그리드 칸에서 104px 까지 짜부라진 적이 있다).
        path_edit.setMinimumWidth(self._PATH_MIN_W)
        path_edit.setPlaceholderText(i18n.KO.SETUP_FOLDER_PLACEHOLDER)
        path_edit.setReadOnly(False)
        browse = NeonButton(i18n.KO.BTN_BROWSE, role="ghost")
        browse.clicked.connect(lambda: self._browse(path_edit))
        grid.addWidget(head, 0, 0)           # 목업: '기준' 이 폴더 줄의 라벨이다
        grid.addWidget(path_edit, 0, 1)
        grid.addWidget(browse, 0, 3)
        if extra is not None:                # 추출 모드의 첫 LOT [슬롯 선택]
            grid.addWidget(extra, 0, 4)

        # 이유를 말하는 인라인 오류 줄.
        # ★ show/hide 하면 카드 높이가 30px, 옆 카드 정렬이 23px 흔들린다(실측 지적) —
        #   **자리를 예약**하고 문자열만 비운다(항상 표시, 높이 고정).
        err = QLabel("", card)
        err.setProperty("role", "error")
        err.setMinimumHeight(12)
        err.setWordWrap(True)
        if extra2 is not None:               # 매칭 모드의 [엑셀로] — [폴더 선택…] 바로 아래(카드 폭을 늘리지 않는다)
            grid.addWidget(err, 1, 1, 1, 2)
            grid.addWidget(extra2, 1, 3, Qt.AlignmentFlag.AlignTop)
        else:
            grid.addWidget(err, 1, 1, 1, 3)

        machine_edit = QLineEdit(card)
        machine_edit.setPlaceholderText(i18n.KO.SETUP_MACHINE_PLACEHOLDER)
        machine_label = QLabel(i18n.KO.SETUP_MACHINE_LABEL, card)
        machine_label.hide()
        machine_edit.setFixedWidth(120)
        grid.addWidget(machine_edit, 0, 2)

        card.body().addLayout(grid)
        # 유효성 표시를 위해 오류 라벨을 입력란에 붙여 둔다.
        path_edit.setProperty("_errLabel", err)
        path_edit.textChanged.connect(self._schedule_validate)
        return card, path_edit, machine_edit

    # ── 입력 유효성 — 비활성 버튼이 이유를 말하게 ─────────────────────────────
    def _schedule_validate(self) -> None:
        """타이핑마다 stat 하지 않도록 디바운스(죽은 네트워크 드라이브 대비)."""
        timer = getattr(self, "_validate_timer", None)
        if timer is None:
            timer = QTimer(self)
            timer.setSingleShot(True)
            timer.timeout.connect(self._validate)
            self._validate_timer = timer
        timer.start(250)

    @staticmethod
    def _dir_state(text: str) -> str:
        """'' | 'empty' | 'missing' — 경로 문자열의 유효성."""
        t = (text or "").strip()
        if not t:
            return "empty"
        try:
            return "" if Path(t).is_dir() else "missing"
        except OSError:
            return "missing"                 # 접근 불가한 경로도 '없음' 취급

    @staticmethod
    def split_roots(text: str) -> list[str]:
        """LOT 줄들을 이은 문자열(줄바꿈 구분) → 폴더 목록.  경로에 올 수 없는 글자다."""
        return [t.strip() for t in (text or "").split("\n") if t.strip()]

    @staticmethod
    def _dirs_state(text: str) -> str:
        """여러 폴더 판정 — 하나라도 없으면 ``missing``, 하나도 없으면 ``empty``."""
        roots = SetupPage.split_roots(text)
        if not roots:
            return "empty"
        return "" if all(SetupPage._dir_state(r) == "" for r in roots) else "missing"

    def _set_field_state(self, edit: QLineEdit, state: str) -> None:
        """동적 프로퍼티 + repolish(안 하면 QSS 가 다시 그려지지 않는다)."""
        edit.setProperty("state", "invalid" if state else "")
        edit.style().unpolish(edit)
        edit.style().polish(edit)
        err = edit.property("_errLabel")
        if err is not None:
            # ★ 'empty' 분기는 두지 않는다.  `_validate()` 가 빈 필드에는 state 를 주지
            #   않기 때문에(빈 상태에서 빨간 테두리로 겁주지 않으려는 의도) 도달할 수
            #   없고, 같은 말은 이미 버튼 옆 `_start_hint`(START_BLOCKED_HINT)가 한다.
            #   도달 불가 분기는 '처리되고 있다'는 착각만 남긴다.
            if state == "missing":
                err.setText(i18n.KO.SETUP_INVALID_FOLDER)
            else:
                err.setText("")
            # ★ setVisible 을 쓰지 않는다 — 자리를 예약해 뒀으므로 문자열만 바꾼다.

    def set_backend_ready(self, ready: bool) -> None:
        """무거운 구성 요소가 준비됐는지 알린다 — 창을 먼저 띄우는 시작 흐름용.

        준비 전에는 [검증 시작] 을 잠그고 버튼에 '준비 중' 을 표기한다.  활성 여부는
        여전히 :meth:`_validate` 하나가 정한다 — 여기서 직접 ``setEnabled`` 를 부르면
        다음 폴더 입력의 디바운스가 그것을 곧바로 덮어쓴다."""
        self._backend_ready = bool(ready)
        self._refresh_start_text()
        self._validate()

    def _refresh_start_text(self) -> None:
        if not self._backend_ready:
            self.start_btn.setText(i18n.KO.BTN_START_PREPARING)
        else:
            self.start_btn.setText(i18n.KO.BTN_EXTRACT_START if self._extract_mode
                                   else i18n.KO.BTN_START)

    def is_extract_mode(self) -> bool:
        return self._extract_mode

    def is_cross_mode(self) -> bool:
        """교차검증 스위치 — 추출 모드에서는 숨겨지므로 꺼진 것으로 본다."""
        return not self._extract_mode and self._cross_switch.is_on()

    def set_extract_mode(self, on: bool) -> None:
        """Defect 추출 ↔ 매칭 검증.  **같은 화면**에서 한쪽만 받도록 바꾼다(사용자 결정).

        감추는 것: 검증 장비 카드 · 매칭 설정 카드 · 모드 배지(판정 기준은 매칭에만 있다).
        남기는 것: 기준 장비 카드(제목만 '대상 장비') · 실행 옵션(자동화 수준 = 선별
        건너뛰기, 진행 범위 = 일부 슬롯).  입력값은 그대로 둔다 — 되돌아오면 이어서 쓴다."""
        on = bool(on)
        self._extract_mode = on
        self._title_label.setText(i18n.KO.EXTRACT_TITLE if on else i18n.KO.SETUP_TITLE)
        head = self.ref_group.property("_headLabel")
        if head is not None:
            head.setText(i18n.KO.EXTRACT_GROUP if on else i18n.KO.SETUP_REF_GROUP)
        self.val_group.setVisible(not on)
        # 그리드에서도 빼야 빈 칸이 반폭을 차지하지 않는다(재배치는 reflow 가 한다).
        self._device_cards = [self.ref_group] if on else [self.ref_group, self.val_group]
        self._reflow_device_row()
        self._setting_cards[1].setVisible(not on)          # 매칭 설정 카드
        self._mode_badge_card.setVisible(not on)
        self._map_switch.setVisible(on)                    # 추출 전용 옵션
        self._cross_switch.setVisible(not on)              # 매칭 전용 옵션
        self._lot1_slot_btn.setVisible(on)
        self._excel_ref_btn.setVisible(not on)
        self._lot_list.setVisible(on)
        self._scope_row.setVisible(not on)
        # 자동화 툴팁 — 매칭 문구는 '매치·검토 화면' 을 말한다(추출에는 없다).
        self.auto_group.set_option_tooltip(
            AutomationLevel.USER_SELECT,
            i18n.KO.EXTRACT_AUTOMATION_USER_SELECT if on
            else i18n.KO.AUTOMATION_USER_SELECT)
        self.auto_group.set_option_tooltip(
            AutomationLevel.AUTO_ALL,
            i18n.KO.EXTRACT_AUTOMATION_AUTO_ALL if on
            else i18n.KO.AUTOMATION_AUTO_ALL)
        self.ref_path_edit.setPlaceholderText(
            i18n.KO.EXTRACT_FOLDER_PLACEHOLDER if on
            else i18n.KO.SETUP_FOLDER_PLACEHOLDER)
        self._sync_nav_checked()
        # 추출 모드에서는 사진·폴더를 화면 어디에 놓아도 입력란에 들어간다(사용자 요청).
        # 첫 입력란이 놓기를 가로채 'file:///…' 글자를 끼워 넣지 않게, 그때만 페이지가 받는다.
        self.setAcceptDrops(on)
        self.ref_path_edit.setAcceptDrops(not on)
        self._refresh_start_text()
        self._validate()
        self.extract_mode_changed.emit(on)

    def _probe_state(self, text: str) -> Optional[str]:
        """파일시스템에 **손대지 않고** 알 수 있는 것만 — 모르면 ``None``(확인 필요).

        빈 칸은 디스크를 볼 필요가 없으므로 즉시 답한다.  나머지는 워커가 답을
        채워 둔 것만 쓴다 (P-15)."""
        t = (text or "").strip()
        if not t:
            return "empty"
        return self._probed.get(t)

    def _start_dir_probe(self, ref_text: str, val_text: str) -> None:
        """폴더 존재 확인을 워커에 맡긴다 — 캐시가 있어도 **매번 다시 확인**한다.

        캐시는 '멈추지 않기' 위한 것이지 '다시 안 보기' 위한 것이 아니다.  그래서
        사용자가 그 사이에 폴더를 만들었다면 다음 확인에서 저절로 풀린다.

        ★ 단, **같은 쌍을 이미 확인 중이면 새로 띄우지 않는다.**  `_validate` 는 두
        입력란·허용 오차·디바운스가 모두 부르는 자리라 자주 오는데, 끊긴 NAS 에서
        `is_dir()` 은 OS 타임아웃까지(수십 초) 안 돌아온다 — 그동안 부를 때마다
        스레드를 새로 띄우면 답도 없는 확인만 쌓인다.  확인이 끝나면 풀리므로 '매번
        다시 확인' 은 그대로다(`_on_dir_probe_done`)."""
        if (ref_text, val_text) == self._probing_for:
            return
        self._probing_for = (ref_text, val_text)
        self._probe_token += 1
        probe = _DirProbe(self._probe_token, ref_text, val_text,
                          multi=self._extract_mode)
        probe.signals.done.connect(self._on_dir_probe_done)
        _LIVE_DIR_PROBES.add(probe)
        probe.finished.connect(lambda p=probe: _LIVE_DIR_PROBES.discard(p))
        probe.start()

    def _on_dir_probe_done(self, token: int, ref_text: str, ref_state: str,
                           val_text: str, val_state: str) -> None:
        """확인이 끝났다 — **최신 세대만** 반영하고 판정을 다시 그린다."""
        if token != self._probe_token:
            return
        self._probing_for = None
        self._log_after_pick("probe", ref_state or "ok", val_state or "ok")
        changed = (self._probed.get(ref_text) != ref_state
                   or self._probed.get(val_text) != val_state)
        self._probed[ref_text] = ref_state
        self._probed[val_text] = val_state
        if changed:
            self._validate()          # 새 답으로 화면을 다시 그린다(재귀는 1회).

    def _validate(self) -> bool:
        """두 폴더가 모두 유효하고 **구성 요소가 준비됐을 때만** [검증 시작] 활성화.

        폴더 확인 자체는 워커가 한다 (P-15) — 아직 답이 없으면 '확인 중' 으로 두고
        시작을 잠근다.  헤드리스에서는 동기로 확인해 호출 즉시 판정이 나오게 한다
        (테스트가 `_validate()` 의 반환값을 그 자리에서 단언한다)."""
        ref_text = self.ref_path_edit.text()
        if self._extract_mode:
            # LOT 줄 전부를 한 문자열로(줄바꿈 구분) — 확인 워커가 폴더별로 본다.
            ref_text = "\n".join(self._lot_paths())
        # 추출 모드는 검증 폴더를 받지 않는다 — 기준 폴더를 한 번 더 보면 판정이 같다.
        val_text = ref_text if self._extract_mode else self.val_path_edit.text()
        if self._sync_probe:
            judge = self._dirs_state if self._extract_mode else self._dir_state
            ref_state: Optional[str] = judge(ref_text)
            val_state: Optional[str] = judge(val_text)
        else:
            self._start_dir_probe(ref_text, val_text)
            ref_state = self._probe_state(ref_text)
            val_state = self._probe_state(val_text)
        checking = ref_state is None or val_state is None
        # 비어 있는 초기 상태에서 빨간 테두리로 겁주지 않는다 — 문구만 조용히.
        # 확인 중(None)도 마찬가지다 — 아직 모르는 것을 틀렸다고 칠할 수는 없다.
        self._set_field_state(self.ref_path_edit,
                              "missing" if ref_state == "missing" else "")
        self._set_field_state(self.val_path_edit,
                              "missing" if val_state == "missing" else "")
        dirs_ok = ref_state == "" and val_state == ""
        ok = dirs_ok and self._backend_ready
        self.start_btn.setEnabled(ok)
        if hasattr(self, "_start_hint"):
            # 폴더 문제가 먼저다 — 그건 사용자가 지금 고칠 수 있는 것이고,
            # '준비 중' 은 가만히 있으면 저절로 풀린다.
            if checking:
                self._start_hint.setText(i18n.KO.START_CHECKING_HINT)
            elif not dirs_ok:
                self._start_hint.setText(i18n.KO.EXTRACT_BLOCKED_HINT
                                         if self._extract_mode
                                         else i18n.KO.START_BLOCKED_HINT)
            elif not self._backend_ready:
                self._start_hint.setText(i18n.KO.START_PREPARING_HINT)
            else:
                self._start_hint.setText("")
        # die 안내는 **폴더가 확실히 있을 때만** 시작한다 — 확인 중(None)에 넘기면
        # 있는지도 모르는 경로를 훑는다.
        die_text = ref_text
        if self._extract_mode:                 # 여러 LOT 면 첫 폴더로 안내한다
            die_text = (self.split_roots(ref_text) or [""])[0]
        self._refresh_die_hint(die_text if ref_state == "" and die_text.strip() else None)
        return ok

    def _refresh_die_hint(self, ref_text: Optional[str]) -> None:
        """기준 폴더의 die 크기 안내를 갱신한다 — **스캔은 백그라운드에서** 한다.

        ★ 여기서 직접 훑지 않는다.  UI 스레드에서 파일을 열면 **폴더를 고르는 순간
        창이 그만큼 멈춘다** — 이게 실제 사용자 신고였다.
        ★ 그리고 워커가 하는 일도 **가볍다**(`_detect_die_geometry`).  예전에는 매칭과
        같은 `camtek_geometry` 를 불러 결함 수천 건의 INI 와 die 맵을 파싱했는데, 그
        순수 파이썬 파싱은 워커에서 돌아도 GIL 을 쥐어 UI 를 굶겼다 — 워커로 옮긴
        뒤에도 "die 안내가 뜰 때까지 멈춘다" 는 신고가 남은 이유다.  매칭의 pitch
        검산(정확도 가드, CLAUDE.md)은 그대로다 — 안내는 그 가드를 **쓰지 않을** 뿐,
        가드 자체는 손대지 않았다.

        같은 경로로 다시 불리면 스캔하지 않고 캐시한 결과로 문구만 다시 그린다 —
        허용 오차를 건드릴 때마다(`coord_tol_spin.valueChanged` → `_schedule_validate`)
        폴더를 다시 훑던 낭비가 사라진다.  전 구간 fail-safe."""
        hint = getattr(self, "_die_hint", None)
        if hint is None:
            return
        if not ref_text:
            # 경로가 비었/잘못됐다 — 진행 중인 스캔 결과를 버리고 조용히 비운다.
            self._die_token += 1
            self._die_scanned_for = None
            self._die_scanning_for = None
            self._die_result = (None, "", False)
            self._apply_die_hint(None, "", False)
            return
        if ref_text == self._die_scanned_for:
            self._apply_die_hint(*self._die_result)     # 캐시 — 스캔하지 않는다
            return
        if ref_text == self._die_scanning_for:
            # ★ 같은 경로를 이미 훑는 중이다 — 결과를 기다린다.  기준 폴더를 고른
            #   직후 검증 폴더를 고르면 `_validate` 가 다시 오는데(두 입력란이 같은
            #   디바운스를 공유한다), 그때마다 워커를 새로 띄우면 같은 폴더를 두 번
            #   훑는다.  느린 NAS 에서 부하가 그대로 두 배가 된다.
            return
        self._die_token += 1
        self._die_scanning_for = ref_text
        self._set_die_hint_text(i18n.KO.DIE_SIZE_CHECKING, "muted")
        scan = _DieGeometryScan(self._die_token, ref_text)
        scan.signals.done.connect(self._on_die_scan_done)
        _LIVE_DIE_SCANS.add(scan)
        scan.finished.connect(lambda s=scan: _LIVE_DIE_SCANS.discard(s))
        self._die_scan = scan
        scan.start()

    def _on_die_scan_done(self, token: int, pitch, src: str, broken: bool) -> None:
        """워커가 끝났다 — **최신 세대의 결과만** 반영한다.

        폴더를 연달아 바꾸면 스캔이 겹치고, 늦게 끝난 옛 스캔이 새 폴더의 안내를
        덮어쓸 수 있다.  세대 번호가 다르면 그 결과는 버린다."""
        if token != self._die_token:
            return
        self._log_after_pick("die", "pitch" if pitch else "none", "")
        self._die_scanned_for = self._die_scanning_for
        self._die_scanning_for = None
        self._die_result = (pitch, src, broken)
        self._apply_die_hint(pitch, src, broken)

    def _set_die_hint_text(self, text: str, role: str) -> None:
        """문구 + 동적 프로퍼티 repolish(안 하면 QSS 가 다시 그려지지 않는다)."""
        hint = self._die_hint
        hint.setText(text)
        hint.setProperty("role", role)
        hint.style().unpolish(hint)
        hint.style().polish(hint)

    def _apply_die_hint(self, pitch, src: str, broken: bool) -> None:
        """스캔 결과 → 화면 문구.  순수 렌더링(파일을 읽지 않는다)."""
        if pitch is None:
            # ★ die 크기를 모른다고 곧장 경고하지 않는다.  KLA 슬롯·LIVE 파일명 슬롯은
            #   die 크기 없이도 좌표가 나온다 — 진짜 못 쓰는 경우(`broken`)만 경고한다.
            self._set_die_hint_text(i18n.KO.DIE_SIZE_NOT_FOUND if broken else "",
                                    "warn" if broken else "muted")
            return
        text = i18n.KO.DIE_SIZE_DETECTED_FMT.format(x=pitch[0], y=pitch[1], src=src)
        self._set_die_hint_text(text, "muted")

    @staticmethod
    def _detect_die_geometry(ref_text: str):
        """기준 폴더의 **첫 슬롯 하나**를 읽어 ``((pitch_x, pitch_y) | None, 출처, 못쓰는가)``.

        · Camtek 슬롯 → `Params_WaferInfo.ini`·`ProductInfo.ini` 에 적힌 die pitch
        · KLA 슬롯    → `.001` 헤더의 `DiePitch`
        · LIVE 파일명 슬롯 → die pitch 는 없지만 **좌표는 파일명에서 나온다**(경고 대상 아님)

        '못쓰는가' 는 **Camtek INI 가 있는데 pitch 를 적은 파일이 없는** 경우만 True 다.
        전 구간 fail-safe — 안내가 실패해도 설정 화면이 막히면 안 된다.

        ★ **작은 파일만 읽는다**(사용자 신고: 폴더를 고르면 die 안내가 뜰 때까지 멈춤).
        예전에는 매칭과 같은 `camtek_geometry`·`kla_info.load_folder` 를 불러 결함
        수천 건의 INI·die 맵·DefectList 를 파싱했다.  그 파싱은 순수 파이썬이라 워커
        스레드에서 돌아도 GIL 을 쥔 채 UI 스레드를 굶긴다 — 스캔을 워커로 옮기고
        표본을 슬롯 하나로 줄인 뒤에도 정지가 남은 이유다.  지금 여는 것은 pitch 가
        적힌 몇 줄짜리 INI 와 `.001` 헤더(앞 64KB)뿐이다
        (`wafer_geometry.peek_die_pitch`·`kla_info.peek_die_pitch`).

        ⚠ 바뀌는 것: 안내는 파일에 적힌 값을 **검산 없이** 보여 준다.  검산(INI 의
        Col/Row 와 대조)은 매칭이 pitch 를 채택할 때 그대로 한다 — 안내가 보여 준 값을
        매칭이 거부하는 드문 자재라면 매칭은 예전처럼 절대좌표로 간다.  **매칭 정확도는
        영향받지 않는다.**

        ★ **슬롯 하나만 읽는다**(사용자 결정).  이 값은 화면의 안내 한 줄에만 쓰이고
        매칭 정확도·[검증 시작] 활성화와 무관하므로, 표본은 한 슬롯이면 된다."""
        from ...coords import camtek_ini, kla_info
        from ...coords.wafer_geometry import peek_die_pitch
        from ...models.slot import list_slot_dirs

        try:
            root = Path(ref_text.strip())
            if not root.is_dir():
                return (None, "", False)
            # 숨김 폴더는 표본에서 뺀다 — 결과 폴더 옆에 `.aoi_verification_cache`
            # 같은 점 폴더가 있으면 이름순 첫 자리를 그것이 차지해 표본이 통째로
            # 엉뚱해진다(`kla_info._info_candidates` 와 같은 관습).
            slots = sorted((n, d) for n, d in list_slot_dirs(root).items()
                           if not n.startswith("."))
            if not slots:
                return (None, "", False)
            _name, folder = slots[0]          # 표본 한 슬롯 — 위 주석 참조
            got = peek_die_pitch(folder)
            if got is not None:
                px, py, src = got
                return ((px, py), src, False)
            kla = kla_info.peek_die_pitch(folder)          # KLA 슬롯 — 헤더에 있다
            if kla is not None:
                return (kla, i18n.KO.DIE_SIZE_SRC_KLA, False)
            # 변환할 INI 는 있는데 pitch 를 적은 파일이 없다 — 진짜 문제라 경고한다.
            return (None, "", camtek_ini.has_ini(folder))
        except Exception:
            return (None, "", False)

    def _browse(self, target: QLineEdit) -> None:
        """[폴더 선택…] — OS 파일 브라우저를 **비동기로** 열고, 고른 경로를 입력란에 넣는다.

        ★ ``QFileDialog.getExistingDirectory`` 를 쓰지 않는다.  그 함수는 ``exec()``
        라 Windows 에서 Explorer 창을 **UI 스레드 안에서** 돌려, 셸 확장 로딩·네트워크
        열거·닫을 때의 COM 정리가 전부 UI 정지가 되고, 그동안 멈춘 타이머·워커 결과가
        닫는 순간 몰린다 — '텍스트로 치면 안 멈추는데 폴더 버튼으로 고르면 멈춘다' 의
        원인이다(두 경로는 ``setText`` 이후가 같다).  `ui/folder_picker.py` 가
        ``open()`` 으로 네이티브 창을 Qt 의 보조 스레드에 띄우고 결과를 시그널로 준다.

        ★ 정지 **계측은 그대로** 남긴다(로그만).  이 변경이 맞다면 `app.log` 의
        '폴더 창을 닫은 직후 UI 가 …초 멈췄다' 가 사라져야 한다 — 남으면 다음 후보를
        그 로그가 가리킨다.  브라우저에 머문 시간은 취소해도 잰다(이전과 같다).
        """
        from .. import stall_watch
        self._browse_target = target
        # ★ 창이 열려 있는 **동안**도 잰다.  비동기 창이라 UI 루프가 도니 잴 수 있고,
        #   닫힌 뒤의 정지가 0건인데 신고가 남은 지금은 이 구간이 다음 후보다.
        self._folder_dialog_open = True
        stall_watch.watch(self, self._log_stall, seconds=self._DIALOG_WATCH_S,
                          on_stack=self._log_stall_stack)
        self._folder_picker.open(i18n.KO.SETUP_FOLDER_LABEL)

    # ── 이전 결과 엑셀을 기준으로 ─────────────────────────────────────────────
    def _pick_excel_ref(self) -> None:
        """[엑셀로] — 엑셀 파일 하나를 **비동기로** 고른다(`exec()` 금지: 폴더 선택과 같은 이유)."""
        from PyQt6.QtWidgets import QFileDialog
        dlg = getattr(self, "_excel_dialog", None)
        if dlg is None:
            dlg = QFileDialog(self, i18n.KO.EXCEL_REF_PICK_CAPTION, "",
                              i18n.KO.EXCEL_REF_FILTER)
            dlg.setFileMode(QFileDialog.FileMode.ExistingFile)
            dlg.fileSelected.connect(self._on_excel_picked)
            self._excel_dialog = dlg
        dlg.open()

    def _on_excel_picked(self, path: str) -> None:
        if path:
            self.excel_ref_requested.emit(path)

    def _reset_excel_ref_btn(self) -> None:
        self._excel_ref_btn.setText(i18n.KO.EXCEL_REF_BTN)
        self._excel_ref_btn.setToolTip(i18n.KO.EXCEL_REF_BTN_TIP)
        self.ref_path_edit.setToolTip("")

    def apply_excel_ref(self, xlsx: str, root: str, machine: str,
                        photos: int, slots: int, coords: int) -> None:
        """풀어 둔 기준 폴더를 기준 칸에 넣는다(메인 창이 불러온 뒤 부른다)."""
        self.ref_path_edit.setText(root)
        self._reset_slot_selection()          # 이전 기준 폴더의 슬롯 선택은 더 이상 맞지 않는다
        if machine and not self.ref_machine_edit.text().strip():
            self.ref_machine_edit.setText(machine)
        tip = i18n.KO.EXCEL_REF_DONE_TIP_FMT.format(
            name=Path(xlsx).name, photos=photos, groups=slots, coords=coords)
        self.ref_path_edit.setToolTip(tip)
        self._excel_ref_btn.setText(i18n.KO.EXCEL_REF_DONE_BTN)
        self._excel_ref_btn.setToolTip(tip)

    def _on_folder_picked(self, path: str) -> None:
        target = getattr(self, "_browse_target", None)
        if target is None or not path:
            return
        import time
        t0 = time.perf_counter()
        target.setText(path)
        # 기준 폴더가 바뀌면 이전 슬롯 선택은 더 이상 유효하지 않다.
        if target is self.ref_path_edit:
            self._reset_slot_selection()
            self._reset_excel_ref_btn()
        # 입력란에 넣는 일 자체가 비싼지(textChanged 연쇄) — 보통 0.00초여야 한다.
        _LOG.info("폴더 선택: 입력란에 넣기 %.3f초 — %s",
                  time.perf_counter() - t0, path)
        self._picked_at = time.perf_counter()

    # 폴더 창이 열려 있는 동안의 정지 감시 상한 — 사용자가 폴더를 찾는 시간은 길 수
    # 있다(실측 최대 99초).  닫히면 6초짜리로 다시 건다.
    _DIALOG_WATCH_S = 600.0

    def _on_folder_dialog_closed(self, chosen: bool, dialog_s: float,
                                 since_nav: float) -> None:
        from .. import stall_watch
        self._folder_dialog_open = False
        # 브라우저에 머문 시간에는 사용자가 폴더를 찾은 시간이 섞여 있다 — 정지시간이
        # 아니다.  `since_nav`(마지막으로 폴더를 누른 뒤 닫히기까지)가 Windows 가 창을
        # 닫는 데 쓴 꼬리이고, 아래 감시자가 재는 '닫힌 뒤의 정지' 와 짝지어 본다.
        _LOG.info("폴더 선택: 파일 브라우저가 %.2f초 열려 있었다(%s) — "
                  "마지막 폴더 클릭 뒤 닫히기까지 %s / 창 안 순서: %s",
                  dialog_s, "고름" if chosen else "취소",
                  "모름" if since_nav < 0 else f"{since_nav:.2f}초",
                  self._folder_picker.timeline() or "없음")
        stall_watch.watch(self, self._log_stall, on_stack=self._log_stall_stack)
        self._probe_input_ready(time.perf_counter(), 0)

    def _probe_input_ready(self, closed_at: float, n: int) -> None:
        """창이 닫힌 뒤 주 창이 입력을 받을 수 있게 되기까지 — 0.25초마다 상태를 남긴다.

        UI 정지 로그 없이 화면이 입력을 못 받는 구간이 있다면 여기서 보인다(모달 위젯이
        남아 있거나, 주 창이 비활성이거나).  상태가 '정상' 이 되면 멈춘다."""
        from PyQt6.QtWidgets import QApplication
        win = self.window()
        modal = QApplication.activeModalWidget()
        active = QApplication.activeWindow()
        ok = win.isEnabled() and modal is None and active is win
        if ok or n >= 40:
            _LOG.info("폴더 창 닫힌 뒤 %.2f초: 주 창 입력 %s", time.perf_counter() - closed_at,
                      "가능" if ok else "여전히 불가(10초 감시 종료)")
            return
        if n == 0 or n % 4 == 0:
            _LOG.info("폴더 창 닫힌 뒤 %.2f초: 주 창 입력 불가 — enabled=%s 모달=%s 활성창=%s",
                      time.perf_counter() - closed_at, win.isEnabled(),
                      type(modal).__name__ if modal else None,
                      type(active).__name__ if active else None)
        call_later(self, 250, lambda: self._probe_input_ready(closed_at, n + 1))

    def _log_stall_stack(self, stale_s: float, stack: str) -> None:
        """멈춰 있는 **도중에** 보조 스레드가 부른다 — 그 순간 UI 스레드의 호출 스택.

        맨 아래 줄이 ``app.exec`` 뿐이면 Qt/Windows 안(우리 파이썬 밖)에서 막힌 것이고,
        그 위에 우리 파일(`aoi_verification/…`)이 있으면 그 줄이 멈춤의 자리다."""
        _LOG.warning("UI 스레드가 %.1f초째 멈춰 있다(폴더 창 %s) — 그 순간 하던 일:\n%s",
                     stale_s,
                     "열림" if getattr(self, "_folder_dialog_open", False) else "닫힘",
                     stack or "(스택을 못 떴다)")

    def _log_after_pick(self, what: str, a: str, b: str) -> None:
        """폴더를 고른 뒤 워커들이 언제 끝났는지 — 고른 순간부터의 초.

        문구는 `_LOG` 호출 안에만 둔다(화면 문구 가드 기준) — ``what`` 은 키다."""
        picked_at = getattr(self, "_picked_at", None)
        if picked_at is None:
            return
        import time
        dt = time.perf_counter() - picked_at
        if dt > 60.0:                        # 그 뒤 한참 지난 결과는 폴더 선택과 무관
            return
        if what == "probe":
            _LOG.info("폴더 선택 뒤 %.2f초: 폴더 확인 끝(기준 %s · 검증 %s)", dt, a, b)
        else:
            _LOG.info("폴더 선택 뒤 %.2f초: die 안내 스캔 끝(%s)", dt, a)

    def _log_stall(self, seconds: float, jobs: str) -> None:
        """폴더를 고른 뒤 UI 가 멈췄다 — 얼마나·그때 무엇이 돌았는지 남긴다.

        ★ 문구를 `_LOG` 호출 안에 둔다.  화면에 나가지 않고 `app.log` 로만 가는
        진단 문자열이므로 `i18n` 이 아니라 여기가 자리다(`test_no_hardcoded_korean`
        이 로거 인자를 화면 문구로 세지 않는 것과 같은 기준).

        QThread 는 ``threading.enumerate`` 에 안 잡혀 `stall_watch` 가 못 본다 —
        이 페이지가 워커에 맡겨 둔 일은 여기서 덧붙인다."""
        _LOG.warning(
            "폴더 창%s UI 가 %.2f초 멈췄다 — 그때 돌던 작업: %s"
            " / 폴더 확인 %s · die 안내 스캔 %s",
            "이 열려 있는 동안" if getattr(self, "_folder_dialog_open", False)
            else "을 닫은 직후",
            seconds, jobs or "없음",
            "진행 중" if self._probing_for is not None else "아님",
            "진행 중" if self._die_scanning_for is not None else "아님")

    # ------------------------------------------------------------------
    def _reset_slot_selection(self) -> None:
        """전체 진행으로 되돌린다 — 타일 라벨·선택까지 원복."""
        self._selected_slots = None
        self.scope_group.set_option_label("subset", i18n.KO.SCOPE_SUBSET)
        self.scope_group.set_current_key("all")        # emit 없음(재귀 방지)

    def _open_slot_select(self) -> None:
        """'일부 슬롯만 진행' — 기준 폴더의 슬롯을 스캔해 부분 선택."""
        from ...models.slot import list_slot_dirs
        from ..widgets.slot_select_dialog import SlotSelectDialog

        ref_text = self.ref_path_edit.text().strip()
        ref_root = Path(ref_text) if ref_text else None
        if ref_root is None or not ref_root.is_dir():
            sheets.warn(
                self, i18n.KO.APP_TITLE, i18n.KO.SLOT_SELECT_NEED_REF,
            )
            self._reset_slot_selection()       # 고를 수 없으면 전체 진행으로 복귀
            return
        ref_dirs = list_slot_dirs(ref_root)
        slot_names = sorted(ref_dirs.keys())
        if not slot_names:
            sheets.info(
                self, i18n.KO.APP_TITLE, i18n.KO.SLOT_SELECT_EMPTY,
            )
            self._reset_slot_selection()
            return
        # 슬롯별 사진 수는 **창이 뜬 뒤 워커가** 채운다(폴더 열거가 슬롯 × 2회라
        # 여기서 세면 NAS 에서 창이 뜨는 순간 그만큼 멈춘다).  검증 경로는 비어
        # 있을 수도 있고 — 그러면 검증 칸이 '—' 로 남는다(경고하지 않는다).
        val_text = self.val_path_edit.text().strip()
        dlg = SlotSelectDialog(
            slot_names, preselected=self._selected_slots,
            ref_dirs=ref_dirs, val_root=(Path(val_text) if val_text else None),
            parent=self,
        )
        if sheets.run(dlg) and dlg.accepted_ok:
            chosen = dlg.selected
            # 전체 선택과 동일하면 '전체 진행'(None)으로 정규화.
            if not chosen or chosen == set(slot_names):
                self._reset_slot_selection()
            else:
                self._selected_slots = set(chosen)
                # 상태를 타일 라벨에 — 옆 라벨을 보러 갈 필요가 없다.
                self.scope_group.set_option_label(
                    "subset", i18n.KO.SCOPE_SUBSET_COUNT_FMT.format(
                        n=len(chosen), total=len(slot_names)))
                self.scope_group.set_current_key("subset")
        else:
            self._reset_slot_selection()        # 취소 → 전체 진행 유지

    def _open_image_info(self) -> None:
        """단일 사진 정보 — 사진 1장의 결함 좌표/measurement 확인(화면 이동)."""
        self.show_page("image_info")

    def _open_gl_viewer(self) -> None:
        """GL 히스토그램 — 빈 화면으로 열고 사진은 안에서 고른다(화면 이동)."""
        self.show_page("gl")

    def _open_wafer_map(self) -> None:
        """Wafer map — 웨이퍼 폴더 하나의 결함 위치를 원 위에 본다(화면 이동)."""
        self.show_page("wafer_map")

    def _on_threshold_changed(self, v: int) -> None:
        self.threshold_label.setText(f"{v} %")
        self._refresh_mode_badge()
        _prefs.patch(threshold=v / 100.0)

    # ------------------------------------------------------------------
    def _on_start(self) -> None:
        inp = self._collect_input()
        if inp is None:
            return
        self.start_requested.emit(inp)

    def _collect_input(self):
        if self._extract_mode:
            return self._collect_extract_input()
        ref_root = Path(self.ref_path_edit.text().strip())
        val_root = Path(self.val_path_edit.text().strip())
        ref_machine = self.ref_machine_edit.text().strip()
        val_machine = self.val_machine_edit.text().strip()

        if not ref_root.exists() or not ref_root.is_dir():
            sheets.warn(self, i18n.KO.APP_TITLE,
                                i18n.KO.WARN_PATH_NOT_EXIST.format(path=ref_root))
            return
        if not val_root.exists() or not val_root.is_dir():
            sheets.warn(self, i18n.KO.APP_TITLE,
                                i18n.KO.WARN_PATH_NOT_EXIST.format(path=val_root))
            return
        if not ref_machine:
            ref_machine = i18n.KO.DEFAULT_REF_MACHINE
        if not val_machine:
            val_machine = i18n.KO.DEFAULT_VAL_MACHINE

        extra_vals = self._collect_extra_vals(ref_root, val_root)
        if extra_vals is None:
            return

        if ref_root.resolve() == val_root.resolve():
            r = sheets.ask(
                self, i18n.KO.WARN_SAME_PATH_TITLE, i18n.KO.WARN_SAME_PATH_BODY,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if r != QMessageBox.StandardButton.Yes:
                return

        mode = "cross" if self.is_cross_mode() else "single"
        threshold = self.slider.value() / 100.0
        # 타일 키가 곧 AutomationLevel 값 — 분기 없이 읽는다.
        automation = self.auto_group.current_key() or AutomationLevel.USER_SELECT
        # 엔진 모드는 명시 스위치에서만 유도한다(펼침 상태를 읽지 않는다).
        engine_mode = self._current_engine_mode()
        coord_tolerance = float(self.coord_tol_spin.value())
        persist_scores = True   # 디스크 점수 캐시 항상 기본 적용(토글 제거).
        accel_concurrency = 32      # 자동 산정 상한(슬라이더 제거) — 워크로드 기반 유동.
        # 효율 모드 = CPU+GPU fusion-zscore 고정.
        use_cpu = True
        use_gpu = True
        embed_batch = 1

        # 마지막 입력 값을 영속화 (#14)
        _prefs.patch(
            threshold=threshold,
            last_ref_root=str(ref_root),
            last_val_root=str(val_root),
            last_ref_machine=ref_machine,
            last_val_machine=val_machine,
            last_mode=mode,
            automation_level=automation,
            engine_mode=engine_mode,
            persist_scores=persist_scores,
            accel_concurrency=accel_concurrency,
            use_cpu=use_cpu,
            use_gpu=use_gpu,
            embed_batch=embed_batch,
            coord_tolerance=coord_tolerance,
        )
        return SetupInput(
            mode=mode,
            ref_root=ref_root,
            val_root=val_root,
            ref_machine=ref_machine,
            val_machine=val_machine,
            threshold=threshold,
            automation_level=automation,
            engine_mode=engine_mode,
            persist_scores=persist_scores,
            accel_concurrency=accel_concurrency,
            use_cpu=use_cpu,
            use_gpu=use_gpu,
            embed_batch=embed_batch,
            coord_tolerance=coord_tolerance,
            selected_slots=(set(self._selected_slots)
                            if self._selected_slots is not None else None),
            extra_vals=extra_vals or None,
        )

    def _collect_extract_input(self):
        """Defect 추출 입력 — 대상 폴더 하나 + 호기 + 실행 옵션.

        매칭 전용 값(임계치·엔진·허용 오차)은 넘기지 않는다(기본값).  prefs 에는
        폴더·호기만 남긴다 — 매칭의 '마지막 입력' 을 추출이 덮어쓰지 않게 따로 두지는
        않는다: 같은 입력란이라 다음에 열 때 그대로 보이는 것이 맞다."""
        rows = [(t.strip(), r["sel"]) for r in self._lot_rows
                for t in [r["edit"].text()] if t.strip()]
        roots = [Path(t) for t, _sel in rows]
        for r in roots:
            if not r.is_dir():
                sheets.warn(self, i18n.KO.APP_TITLE,
                            i18n.KO.WARN_PATH_NOT_EXIST.format(path=r))
                return None
        if not roots:
            return None
        root = roots[0]
        wafer_map = self._map_switch.is_on()
        machine = (self.ref_machine_edit.text().strip()
                   or i18n.KO.DEFAULT_REF_MACHINE)
        automation = self.auto_group.current_key() or AutomationLevel.USER_SELECT
        _prefs.patch(last_ref_root=str(root), last_ref_machine=machine,
                     automation_level=automation, extract_wafer_map=wafer_map)
        return SetupInput(
            mode="single", ref_root=root, val_root=root,
            ref_machine=machine, val_machine="",
            threshold=self.slider.value() / 100.0,
            automation_level=automation,
            extract=True, extract_roots=roots, extract_wafer_map=wafer_map,
            extract_slots=[set(sel) if sel is not None else None
                           for _t, sel in rows],
        )

    # ------------------------------------------------------------------
    def apply_state(self, ref_root: str, val_root: str,
                    ref_machine: str, val_machine: str,
                    threshold: float) -> None:
        self.ref_path_edit.setText(ref_root)
        self.val_path_edit.setText(val_root)
        self.ref_machine_edit.setText(ref_machine)
        self.val_machine_edit.setText(val_machine)
        self.slider.setValue(int(threshold * 100))
