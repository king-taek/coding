"""Stage 2 — 유사도 기반 매칭 화면.

중앙: 기준 사진 1장 / 우: 검증 장비 후보 (점수 정렬).
9장 이상이면 8장 + +N. 우측 사진 클릭 → 매칭 확정.

보류/매칭없음 사진들은 상단 [보류된 사진 보기 (n)] 버튼으로 팝업에서 모아 본다
(좁은 화면에서 좌측 패널이 자리만 차지하던 문제 해결).
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

from PyQt6.QtCore import QByteArray, Qt, pyqtSignal
from PyQt6.QtGui import QKeySequence, QShortcut
from PyQt6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel,
                              QProgressBar, QScrollArea, QSizePolicy, QSlider,
                              QSplitter, QStackedWidget, QVBoxLayout, QWidget)

from ... import config, i18n
from .. import theme
from ..deferred import call_later
from ...models.result import MatchResult
from ...models.slot import ImageItem
from ...utils import prefs as _prefs
from ...similarity.slot_features import (SlotFeatureCache, SlotPrecomputeWorker,
                                            SlotScoreCache)
from ...workers.matcher import Candidate, MatcherWorker
from ...workers import efficiency_matcher as _eff
from ...workers import coord_matcher as _coord
from ...workers import thumb_plan
from ...utils.prefs import EngineMode
from .progress_row import ProgressRowMixin
from ..widgets.app_logo import build_logo_label
from ..widgets.loading_overlay import LoadingOverlay
from ..widgets.match_expand_view import MatchExpandView
from ..widgets.neon_button import NeonButton
from ..widgets.no_wheel_slider import NoWheelSlider
from ..widgets.neon_card import NeonCard
from ..widgets.scalable_image import ScalableImage
from ..widgets.slot_section import SlotSection
from ..widgets.thumb_grid import ThumbEntry, ThumbGrid
from ..widgets.zoom_window import ZoomWindow, SOURCE_CANDIDATES
from ..widgets import sheet_host as sheets


# ---------------------------------------------------------------------------
@dataclass
class Stage2State:
    queue: list[ImageItem]                        # 매칭해야 할 기준 사진 큐
    matches: list[MatchResult] = field(default_factory=list)
    # ‘잠시 보류’ — Skip 재시도 대상
    skipped: dict[str, list[ImageItem]] = field(default_factory=lambda: defaultdict(list))
    # ‘매칭 없음 확정’ — 미탐으로 영구 기록 (재시도 대상 아님)
    no_match: dict[str, list[ImageItem]] = field(default_factory=lambda: defaultdict(list))
    # slot → 매칭에 사용할 검증 후보 풀
    val_pool: dict[str, list[ImageItem]] = field(default_factory=dict)


def _stage2_title(sim_cfg) -> str:
    """Stage 2 표제 — 좌표 매칭 모드면 전용 제목.

    ★ 표제의 주인인 이 파일이 갖는다.  예전에는 `main_window` 가 이 문자열을 만들어
    **부제 라벨**로 넘겼고, 큰 표제는 "유사도 기반" 으로 굳어 있었다 — 좌표 모드에서
    화면이 스스로 모순됐다.  이제 `load_state` 가 이 함수로 표제를 갱신한다.
    """
    if EngineMode.is_coordinate(getattr(sim_cfg, "engine", "")):
        dx, dy = tuple(getattr(sim_cfg, "coord_offset", None) or (0.0, 0.0))
        if dx or dy:                # 좌표 보정(KLA ↔ Camtek)을 적용했으면 값을 보인다
            return i18n.KO.STAGE2_TITLE_COORD + i18n.KO.STAGE2_COORD_OFFSET_FMT.format(
                dx=dx, dy=dy)
        return i18n.KO.STAGE2_TITLE_COORD
    return i18n.KO.STAGE2_TITLE


@dataclass(frozen=True)
class ReviewContext:
    """매칭이 끝난 뒤 **검토·결과 화면이 필요로 하는** MatchPage 상태 묶음.

    이전에는 `main_window` 가 MatchPage 의 비공개 속성을 여덟 군데에서 `getattr`
    로 찔렀고, 엔진 설정을 푸는 블록이 두 벌 복붙돼 있었다(한쪽만 좌표 실패
    개수를 세는 등 이미 갈라져 있었다).

    ★ 허용 오차 기본값을 **여기 한 곳**에서만 정한다 — 호출부마다 따로 두면 값이
    어긋났을 때 좌표 모드 검토 후보 노출 규칙(허용 오차의 3배까지)이 조용히
    달라진다.
    """

    score_cache: object
    fast_results: dict
    coord_mode: bool
    tolerance: float
    coord_failed_count: int
    elapsed_s: float
    # 실패 검토 창이 계산한 점수의 **세션 수명 보관처**(`MatchPage._review_scores`).
    # 창은 열 때마다 새로 만들어지므로 여기에 매달아야 재계산도, 차순위 소실도 없다.
    review_scores: object = None
    # 좌표 세션에서 **고전 유사도로 폴백 채점된** ref 집합 {(slot, ref_path)}.
    # `fast_results` 안의 점수가 거리인지 유사도인지 가르는 유일한 근거다.
    coord_classical_refs: frozenset = frozenset()


class MatchPage(ProgressRowMixin, QWidget):
    """Stage 2 의 메인 페이지."""

    match_confirmed = pyqtSignal(object)        # MatchResult
    match_undone = pyqtSignal(object)           # MatchResult — 되돌리기(#C1)
    skipped_changed = pyqtSignal()              # 외부 자동 저장 트리거
    finished = pyqtSignal()                     # 모든 큐 처리 완료
    cancelled = pyqtSignal()                    # #8 사용자가 중지 버튼 누름
    # 좌표 매칭이 슬롯 하나를 끝냈다 — (슬롯, 그 슬롯의 후보로 나온 사진들).
    # 본창이 그 사진들의 썸네일만 뒤에서 만든다(`workers/thumb_plan`).
    coord_candidates_ready = pyqtSignal(str, object)

    # 좁은 창에선 중앙/우측 2-pane 을 세로 스택으로 자동 전환 (#2).
    _RESPONSIVE_THRESH_LO = 840
    _RESPONSIVE_THRESH_HI = 940

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._state: Stage2State | None = None
        self._current: Optional[ImageItem] = None
        self._threshold = config.CONFIG.default_threshold
        # 되돌리기 히스토리 (#C1) — 세션 직렬화에 영향 없도록 인메모리 전용.
        # 각 항목: (action, ref_item, match_or_None), action ∈ {match,no_match,skip}.
        self._match_history: list[tuple[str, ImageItem, object]] = []
        self._build()
        self._loading = LoadingOverlay(self)
        self._loading.cancel_requested.connect(self._on_cancel_requested)
        self._worker: Optional[MatcherWorker] = None
        self._candidates: list[Candidate] = []
        # 슬롯 단위 검증측 특징 캐시 — 같은 슬롯의 reference 들이 공유.
        self._slot_cache = SlotFeatureCache(keep_lookahead=False)
        # (ref, val) 쌍 점수 사전 계산 캐시 — load_state 시 한 번에 채워서
        # 매 reference 마다 점수 재계산을 회피한다.
        self._score_cache = SlotScoreCache()
        self._precompute_worker: Optional[SlotPrecomputeWorker] = None
        # 수동 모드 한정: 슬롯 단위 스트리밍 사전 계산 상태.
        self._streaming_precompute: bool = False
        self._waiting_for_slot: Optional[str] = None
        # 스트리밍 워커가 이미 ‘처리 완료’ 한 슬롯 목록 — extract 실패로 점수가
        # 누락된 슬롯에서도 무한 대기에 빠지지 않도록 추적 (워커는 슬롯마다
        # 한 번만 slot_finished 를 emit 하므로 두 번째 신호를 기대하면 안 됨).
        self._precompute_processed_slots: set[str] = set()
        # 자동 매치 모드 (#3): True 면 사용자 클릭 없이 임계치 이상 최고 점수 후보를
        # 자동으로 매치 / 후보 없으면 ‘매치 없음’ 으로 자동 처리.
        self._auto_mode: bool = False
        # 유사도 엔진 설정 (기본/고효율 + 중앙 crop 토글).  기본값 = 현행 동작.
        self._engine_cfg = config.DEFAULT_SIM_CONFIG
        # 고효율 모드 활성 여부 — 결과를 _fast_results 에 선계산해 즉시 응답.
        self._fast_mode: bool = False
        self._efficiency_mode: bool = False
        self._coord_mode: bool = False
        # 고효율 선계산 결과: {(slot, ref_path): [(val_path, score), ...]}.
        self._fast_results: dict = {}
        # 현재 사전 계산 단계 라벨 (#8).
        self._precompute_phase: str = ""
        # 마지막으로 받은 사전 계산 진행도(라벨만 바뀔 때 진행 바 유지용).
        self._precompute_done: int = 0
        self._precompute_total: int = 0
        # 좌표 매칭 실패 목록 — 검토 화면으로 전달용
        self._coord_failed_set: set = set()
        # 좌표 매칭이 **고전 유사도로 폴백 채점한** ref 들 (slot, ref_path).
        # `_fast_results` 에는 거리 인코딩과 유사도가 섞여 들어오는데 값만으로는
        # 구분이 안 된다 — 실패 검토 창이 점수를 %로 찍을지 정하는 데 쓴다.
        self._coord_classical_refs: set = set()
        # 실패 검토 창이 **그 자리에서 계산한** (ref, val) 점수의 보관처.
        # ★ `_score_cache` 와 **다른 통**이다 — 그래야 `_launch_matcher` 의
        #   `has_all_pairs` 가 이 값들 때문에 True 로 뒤집혀 2회차 매칭이 낡은
        #   값을 정답으로 서빙하는 일이 없다.  그러면서 **세션 수명**이라
        #   (창은 [실패 검토] 를 누를 때마다 새로 만들어진다) 두 번째 열기가
        #   같은 쌍을 다시 계산하지 않고, 확정된 매치의 차순위 후보도
        #   `build_candidates_by_ref` 가 그대로 찾아낸다.
        self._review_scores = SlotScoreCache()
        # 매칭(사전 계산) 소요시간 — run_log 통계용.  매칭을 한 번도 돌리지 않고
        # 세션이 끝날 수 있으므로 여기서 만들어 둔다(읽는 쪽이 getattr 로 방어하지
        # 않아도 되게).
        self._precompute_elapsed: float = 0.0
        # 사용자가 [중지] 로 이 세션을 버렸는가 — 자동 사슬을 멈추는 유일한 표식.
        # ★ 워커를 멈추는 것만으로는 사슬이 안 멈춘다: 자동 매치는 워커가 아니라
        #   `QTimer.singleShot(0, _on_pick)` 사슬로 돈다.  중지 시점에 이미 예약된
        #   콜백이 남아 있어, 실측으로 150장 중 41장에서 중지했는데도 끝까지 돌아
        #   `finished` 까지 나갔다 — 상위는 `_phase` 가 그대로라 **버린 세션의 검토
        #   화면을 열었다.**  `load_state` 가 새 세션마다 되돌린다.
        self._aborted: bool = False

    # ------------------------------------------------------------------
    def _build(self) -> None:
        root = QVBoxLayout(self)
        pm = theme.PROFILE.page_margin
        root.setContentsMargins(pm, 16, pm, 16)
        root.setSpacing(10)

        # 로고는 표제 줄 왼쪽 끝 — 설정 화면과 같은 머리말.
        top = QHBoxLayout()
        top.addWidget(build_logo_label(self, inline=True))
        top.addSpacing(16)
        # ★ [← 설정으로] 는 없앴다 — 여정 레일이 복귀를 통일해서 맡는다
        #   (구조개편 1안-A).  폐기 확인은 `_on_cancel_requested` 에 그대로 남아
        #   있고, 레일이 `request_back_to_setup()` 으로 그것을 부른다.
        self.title = QLabel(_stage2_title(None), self)
        self.title.setProperty("role", "title")
        top.addWidget(self.title)
        # 진행 상태는 표제 바로 옆 (구조개편 2안-B) — 다섯 화면이 같은 자리를 쓴다.
        top.addSpacing(14)
        self.progress_label = QLabel("", self)
        self.progress_label.setProperty("role", "muted")
        top.addWidget(self.progress_label)
        self.progress_count = QLabel("", self)
        self.progress_count.setProperty("role", "progressCountLg")
        top.addWidget(self.progress_count)
        top.addSpacing(16)
        # 백그라운드 사전 계산 상태 — 수동 모드에서만 표시. 매칭 화면이 이미
        # 열려 있는 동안에도 ‘나머지 슬롯이 X / Y 완료’ 임을 알려준다.
        # ★ pass(제도 녹색)는 **판정 성공 전용**이다 — 진행 중인 계산을 초록으로
        #   띄우면 '이미 성공했다' 는 거짓 신호가 되고, '강조 하나' 원칙의 시선
        #   경쟁자가 늘어난다.  수치가 든 상태 문구이므로 모노+보조색으로 적는다.
        self.bg_status_label = QLabel("", self)
        self.bg_status_label.setProperty("role", "monoMuted")
        top.addWidget(self.bg_status_label)
        top.addStretch(1)
        # [보류된 사진 보기 (n)] — 좌측 패널 대신 팝업으로 모아 보기.
        self.btn_view_skipped = NeonButton(
            i18n.KO.BTN_VIEW_SKIPPED_FMT.format(n=0), role="ghost",
        )
        self.btn_view_skipped.clicked.connect(self._open_skipped_dialog)
        self.btn_view_skipped.setVisible(False)        # (#3) — 기본 숨김
        top.addWidget(self.btn_view_skipped)
        # [보류 재시도] 버튼은 보류 사진이 있을 때만 표시 (#3).
        self.retry_btn = NeonButton(i18n.KO.BTN_RETRY_SKIP, role="warn")
        self.retry_btn.setVisible(False)
        self.retry_btn.clicked.connect(self._retry_skipped)
        top.addWidget(self.retry_btn)
        root.addLayout(top)

        # 제목 줄 바로 아래 폭 전체 진행 눈금 — 표시 전용(텍스트 없음, 채움 스냅).
        self.progress_bar = QProgressBar(self)
        self.progress_bar.setProperty("role", "pageProgress")
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setVisible(False)
        root.addWidget(self.progress_bar)

        # 2 pane — QSplitter 로 사용자가 분할 비율 조절 -------------------
        self._h_splitter = QSplitter(Qt.Orientation.Horizontal, self)
        self._h_splitter.setHandleWidth(6)
        self._h_splitter.setChildrenCollapsible(False)

        # CENTER: 기준 사진 1장
        center = NeonCard(role="card", parent=self)
        cl = center.body()
        title = QLabel(i18n.KO.PANEL_MATCH_REF, center)
        title.setProperty("role", "paneTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cl.addWidget(title)
        self._ref_pane_title = title        # 교차검증 역방향에서 문구를 바꾼다

        # Slot 명만 표시 (파일명 미표시) -------------------------------
        self.slot_label = QLabel("", center)
        self.slot_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.slot_label.setProperty("role", "slotLabel")
        cl.addWidget(self.slot_label)

        # 사진 크기 슬라이더 -------------------------------------------
        # ★ 이 줄은 **사진 아래**에 붙인다(아래 `cl.addLayout(size_row)`) — 선별
        #   화면과 같은 이유다.  설정 컨트롤이 슬롯명과 사진 사이에 상주하면 시선
        #   축(슬롯 → 사진 → 판단)을 가로지르고 사진 시작점이 내려간다.
        size_row = QHBoxLayout()
        size_row.setSpacing(8)
        size_label = QLabel(i18n.KO.IMAGE_SIZE_LABEL, center)
        size_label.setProperty("role", "muted")
        self.size_slider = NoWheelSlider(Qt.Orientation.Horizontal, center)
        self.size_slider.setRange(ScalableImage.MIN_LONG_EDGE,
                                   ScalableImage.MAX_LONG_EDGE)
        # 모니터 크기에 맞춰 자동 시작값 — 세션 한정 (재시작 시 다시 자동맞춤).
        self.size_slider.setValue(ScalableImage.auto_fit_long_edge())
        self.size_slider.setSingleStep(20)
        self.size_slider.setPageStep(80)
        self.size_value = QLabel(f"{self.size_slider.value()} px", center)
        self.size_value.setProperty("role", "monoMuted")
        self.size_value.setFixedWidth(64)
        self.size_value.setAlignment(Qt.AlignmentFlag.AlignRight
                                     | Qt.AlignmentFlag.AlignVCenter)
        self.size_slider.valueChanged.connect(self._on_size_changed)
        size_row.addWidget(size_label)
        size_row.addWidget(self.size_slider, stretch=1)
        size_row.addWidget(self.size_value)

        # 이미지 (스크롤 영역) -----------------------------------------
        self.center_img = ScalableImage(center)
        self._img_scroll = QScrollArea(center)
        self._img_scroll.setWidgetResizable(False)
        self._img_scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._img_scroll.setWidget(self.center_img)
        # 색은 QSS 가 준다 — 인스턴스 스타일시트로 굽지 않는다.
        self._img_scroll.setProperty("role", "imageViewport")
        self._img_scroll.setMinimumHeight(300)
        self._img_scroll.setSizePolicy(QSizePolicy.Policy.Expanding,
                                       QSizePolicy.Policy.Expanding)
        cl.addWidget(self._img_scroll, stretch=1)
        cl.addLayout(size_row)          # 설정은 시선 축 밖(사진 아래) — 위 주석 참조

        bar = QHBoxLayout()
        bar.setContentsMargins(0, 6, 0, 0)
        # 되돌리기 (#C1) — 직전 매칭/매칭없음 결정을 취소하고 그 기준 사진을 다시
        # 큐 맨 앞으로 복귀.  Stage 1 은 Z 를 쓰므로 충돌을 피해 Ctrl+Z 사용.
        self.undo_btn = NeonButton(i18n.KO.BTN_MATCH_UNDO, role="ghost")
        self.undo_btn.setToolTip(i18n.KO.MATCH_UNDO_TOOLTIP)
        self.undo_btn.clicked.connect(self._undo_match)
        self.undo_btn.setEnabled(False)
        bar.addWidget(self.undo_btn)
        # ★ ‘매칭 없음’ 버튼을 두지 않는다 — 이 화면에 **사용자가 누를 것이 없다.**
        #
        #   `AutomationLevel.AUTO_MODES` 는 `{USER_SELECT, AUTO_ALL}` 이라 `is_auto()`
        #   가 **모든 자동화 수준에서 True** 다.  즉 2단계 매칭은 언제나 자동이고,
        #   수동 스트리밍 경로(`streaming = not self._auto_mode`)는 실제로 도달하지
        #   않는다.  후보 칸도 자동 모드에서는 비어 있다.
        #
        #   그런데 이 버튼과 `N` 단축키는 그 사이에도 눌렸다.  선계산이 끝나
        #   오버레이가 내려간 뒤에도 자동 매치 사슬은 계속 도는데(실측: ref 400장에서
        #   오버레이는 359ms 에 사라지고 남은 356장 = **89%** 가 덮개 없이 처리됐다),
        #   그때 이것을 누르면 처리 중이던 사진이 조용히 ‘매칭 없음’ 으로 확정돼
        #   **엑셀에 사실이 아닌 미탐이 남는다.**  사용자는 자기가 무엇을 바꿨는지도
        #   모른다 — 이 저장소가 가장 비싸게 치는 오류다.
        #
        #   누를 이유가 없는 것을 누를 수 있게 두지 않는 것이 가장 확실한 방어다.
        #   자동 경로가 쓰는 `_confirm_no_match(user=False)` 는 그대로 남는다.
        bar.addStretch(1)
        cl.addLayout(bar)

        # 자동 모드에서 우측 후보 패널을 떼면 이 카드가 폭 전체를 쓴다 — 결과를
        # 어디서 보는지 한 줄로 알려 준다(빈 칸에 용도를 말하는 emptyHint 규칙의
        # 연장이다).  수동 폴백에서는 감춘다.
        self._auto_note = QLabel(i18n.KO.MATCH_AUTO_RESULT_NOTE, center)
        self._auto_note.setProperty("role", "muted")
        self._auto_note.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._auto_note.setVisible(False)
        cl.addWidget(self._auto_note)

        center.setMinimumWidth(360)
        self._h_splitter.addWidget(center)

        # RIGHT: 후보들 — 내부에 ‘그리드 ↔ 더 크게 보기’ 스택을 두어
        # 좌측 skip 패널과 중앙 기준 사진은 그대로 두고 후보 패널 안에서만 확대.
        right = QFrame(self)
        right.setProperty("role", "section")
        rl = QVBoxLayout(right)
        rl.setContentsMargins(10, 10, 10, 10)
        rl.setSpacing(8)
        rt = QLabel(i18n.KO.PANEL_MATCH_CANDIDATES, right)
        rt.setProperty("role", "paneTitle")
        rl.addWidget(rt)
        self._cand_pane_title = rt

        # 후보 패널 내부 스택: page 0 = 썸네일 그리드, page 1 = 확대 보기
        self._right_stack = QStackedWidget(right)

        # page 0 — 기존 그리드 (scroll area 를 host widget 으로 감싼다)
        grid_host = QWidget(self._right_stack)
        grid_host_layout = QVBoxLayout(grid_host)
        grid_host_layout.setContentsMargins(0, 0, 0, 0)
        grid_host_layout.setSpacing(0)
        self._right_scroll = QScrollArea(grid_host)
        self._right_scroll.setWidgetResizable(True)
        self._right_host = QWidget()
        self._right_grid = QGridLayout(self._right_host)
        self._right_grid.setContentsMargins(4, 4, 4, 4)
        self._right_grid.setSpacing(8)
        self._right_scroll.setWidget(self._right_host)
        grid_host_layout.addWidget(self._right_scroll, stretch=1)
        self._right_stack.addWidget(grid_host)

        # page 1 — 확대 보기 (기준 사진과 나란히 비교 가능하도록 후보 칸 안에서만)
        self._expand_view = MatchExpandView(self._right_stack)
        self._expand_view.confirm_match.connect(self._on_expand_confirm)
        self._expand_view.back_requested.connect(self._exit_expand_view)
        self._right_stack.addWidget(self._expand_view)

        rl.addWidget(self._right_stack, stretch=1)
        # 3 col × 134(tile) + spacing 16 + 패널 padding 20 = 438 → 후보 9 장이
        # 가로 스크롤 없이 한 화면에 깔리도록.
        right.setMinimumWidth(360)
        self._right_panel = right
        self._h_splitter.addWidget(right)

        # 좌측 skip 패널을 제거했으므로 splitter index 가 0/1 로 줄었다.
        self._h_splitter.setStretchFactor(0, 4)
        self._h_splitter.setStretchFactor(1, 3)
        root.addWidget(self._h_splitter, stretch=1)

        # 저장된 분할 비율 복원 + 변경 시 영속화 -------------------------
        _p_match = _prefs.load()
        if _p_match.splitter_state_match_h:
            self._h_splitter.restoreState(
                QByteArray.fromBase64(
                    _p_match.splitter_state_match_h.encode("ascii")
                )
            )
        self._h_splitter.splitterMoved.connect(self._save_splitter_state)

        # ★ ‘N’(매칭 없음) 단축키도 두지 않는다 — 버튼과 같은 이유다(위 주석 참조).
        #   버튼만 지우고 단축키를 남기면 **보이지 않는 손잡이**가 되어 더 나쁘다:
        #   화면에 아무 것도 없는데 키 하나로 사실이 아닌 미탐이 확정된다.
        #   ‘S’(잠시 보류) 는 이미 #3 에서 비활성화됐다.
        # 되돌리기 (#C1) — Stage 1 의 Z 와 충돌하지 않도록 Ctrl+Z.
        QShortcut(QKeySequence("Ctrl+Z"), self, activated=self._undo_match)

    # ------------------------------------------------------------------
    def resizeEvent(self, event):                       # noqa: N802
        super().resizeEvent(event)
        self._update_splitter_orientation()

    def _update_splitter_orientation(self) -> None:
        """창 폭에 따라 H ↔ V splitter 전환 — 가로 스크롤 회피 (#2)."""
        if not hasattr(self, "_h_splitter"):
            return
        cur = self._h_splitter.orientation()
        w = self.width()
        if cur == Qt.Orientation.Horizontal and w < self._RESPONSIVE_THRESH_LO:
            self._h_splitter.setOrientation(Qt.Orientation.Vertical)
            self._h_splitter.setSizes([400, 400])
        elif cur == Qt.Orientation.Vertical and w > self._RESPONSIVE_THRESH_HI:
            self._h_splitter.setOrientation(Qt.Orientation.Horizontal)
            self._h_splitter.setSizes([500, 500])

    # ------------------------------------------------------------------
    def _save_splitter_state(self, *args) -> None:
        try:
            _prefs.patch(
                splitter_state_match_h=bytes(
                    self._h_splitter.saveState().toBase64()
                ).decode("ascii"),
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    # 교차검증 두 번째 방향(검증 → 기준)인가 — 큐가 검증 사진, 후보가 기준 사진이다.
    #   계산은 방향을 모른다(큐 쪽을 ``ref_path`` 로 담는다).  바뀌는 것은 문구뿐이다.
    _reverse = False
    _cross = False

    def set_reverse(self, on: bool, cross: bool = False) -> None:
        """교차검증 방향 표기 — ``load_state`` **전에** 부른다(표제는 거기서 갱신)."""
        self._reverse = bool(on)
        self._cross = bool(cross)
        self._ref_pane_title.setText(i18n.KO.PANEL_MATCH_REF_REVERSE if on
                                     else i18n.KO.PANEL_MATCH_REF)
        self._cand_pane_title.setText(i18n.KO.PANEL_MATCH_CANDIDATES_REVERSE if on
                                      else i18n.KO.PANEL_MATCH_CANDIDATES)

    def load_state(self,
                   queue: list[ImageItem],
                   val_pool_by_slot: dict[str, list[ImageItem]],
                   threshold: float,
                   *,
                   matches: list[MatchResult] | None = None,
                   skipped: dict[str, list[ImageItem]] | None = None,
                   session_id: str = "",
                   auto_mode: bool = False,
                   engine_cfg=None) -> None:
        self._state = Stage2State(
            queue=list(queue),
            matches=list(matches or []),
            skipped=defaultdict(list, {k: list(v) for k, v in (skipped or {}).items()}),
            val_pool={k: list(v) for k, v in val_pool_by_slot.items()},
        )
        self._threshold = threshold
        self._session_id = session_id or ""
        self._auto_mode = bool(auto_mode)
        # ★ 자동 모드에서는 우측 후보 패널을 **아예 붙이지 않는다.**  Stage 2 는 두
        #   자동화 수준 모두에서 자동 매치라, 이 패널은 세션 내내 빈 회색 칸으로
        #   남아 화면 절반이 '고장난 칸' 처럼 보였다.  수동 폴백(`_populate_right`)이
        #   실제로 돌면 그때 되살린다.
        self._set_candidate_pane_visible(not self._auto_mode)
        self._aborted = False              # 새 세션 — 중지 표식 해제
        self._engine_cfg = engine_cfg or config.DEFAULT_SIM_CONFIG
        self._fast_results.clear()
        self._match_history.clear()        # 되돌리기 히스토리 초기화 (#C1)
        self._update_undo_button()
        self.title.setText(_stage2_title(self._engine_cfg)
                           + i18n.direction_suffix(self._reverse, self._cross))
        self._refresh_skipped_panel()
        # 모든 (ref, val) 쌍 점수를 미리 계산 → 이후 매칭은 캐시 조회만.
        self._start_precompute()

    # ------------------------------------------------------------------
    def _start_precompute(self) -> None:
        """슬롯별 (ref, val) 점수를 사전 계산.

        - 자동 모드: 모든 슬롯의 모든 쌍을 한 번에 (ThreadPoolExecutor 병렬)
          사전 계산한 뒤 자동 매치 시작.  ‘한장한장 따로’ 가 아니라 ‘여러
          장 동시’ 처리.
        - 수동 모드: 첫 슬롯이 끝나면 곧장 매칭 시작 + 나머지 슬롯은
          백그라운드에서 슬롯 단위로 진행 (메모리 절약을 위해 features 는
          슬롯 처리 직후 폐기).
        """
        if self._state is None:
            return
        # 매칭(사전 계산) 소요시간 측정 시작 — run_log 통계용.
        import time as _t
        self._precompute_t0 = _t.perf_counter()
        self._precompute_elapsed = 0.0
        # 사전 계산은 항상 첫 매칭(_advance)보다 앞선다 — 진행 바 갱신 가드
        # (_current is None) 가 직전 세션의 잔여 상태에 흔들리지 않도록 초기화.
        self._current = None
        # ★ 진행도도 함께 리셋한다.  이 둘은 어디서도 초기화되지 않아, 2회차
        #   실행에서 `_on_precompute_phase` 가 **직전 세션의 done/total** 로
        #   set_progress 를 불러 바가 엉뚱한 위치에서 시작했다.
        self._precompute_done = 0
        self._precompute_total = 0
        self._precompute_phase = ""
        # 슬롯별 ref 수집 — queue 순서를 따라 사용자가 마주칠 순서대로 처리.
        refs_by_slot: dict[str, list[ImageItem]] = defaultdict(list)
        for r in self._state.queue:
            refs_by_slot[r.slot].append(r)
        tasks: list[tuple[str, list[ImageItem], list[ImageItem]]] = []
        for slot, refs in refs_by_slot.items():
            vals = self._state.val_pool.get(slot, [])
            if refs and vals:
                tasks.append((slot, refs, vals))
        total_pairs = sum(len(r) * len(v) for _, r, v in tasks)
        if total_pairs == 0:
            # 계산할 게 없으면 바로 진행
            self.bg_status_label.setText("")
            self._streaming_precompute = False
            self._waiting_for_slot = None
            self._advance()
            return

        # 이전 워커가 살아있으면 시그널 끊은 뒤 중단 — 늦게 도착할 ``slot_finished``
        # 가 새 워커의 상태(_streaming_precompute / _waiting_for_slot) 를 건드리지
        # 않도록 (MatcherWorker 의 동일 패턴 참고).
        self._stop_precompute_worker()

        # 엔진 모드 판별
        _engine = self._engine_cfg.engine
        eff_mode = EngineMode.is_efficiency(_engine)
        coord_mode = EngineMode.is_coordinate(_engine)
        self._efficiency_mode = eff_mode
        self._coord_mode = coord_mode
        self._fast_mode = eff_mode or coord_mode
        # 좌표 모드에서는 하드웨어 가속 라벨 숨김
        if coord_mode:
            self.bg_status_label.setVisible(False)
        else:
            self.bg_status_label.setVisible(True)
        if eff_mode and not _eff.has_accel_units():
            # 가속 장치 없음 → CPU 단독으로 고효율 모드 실행 (안내 로그).
            import logging
            logging.getLogger("aoi.match").info(i18n.KO.ENGINE_EFFICIENCY_CPU_ONLY)

        # 수동 = 스트리밍(첫 슬롯 후 곧장 검토 + 나머지 백그라운드).
        # 자동 = 전체 선계산(한 번의 진행 바) → 끝난 뒤 자동 매칭, 백그라운드 없음
        #        (#2/#3: 사진 한 장씩/이중 계산처럼 보이는 현상 제거).
        streaming = not bool(self._auto_mode)
        self._streaming_precompute = streaming
        self._waiting_for_slot = None

        if streaming:
            # 첫 슬롯이 끝날 때까지만 차단 오버레이 — 그 다음은 백그라운드.
            self._loading.show_overlay(i18n.KO.LOAD_PRECOMPUTE_FIRST_SLOT,
                                       cancelable=True)
            self.bg_status_label.setText(
                i18n.KO.PRECOMPUTE_BG_STATUS_FMT.format(idx=0, total=len(tasks))
            )
        else:
            # 자동 — 전체 진행을 하나의 차단 오버레이로 표시.
            self._loading.show_overlay(
                i18n.KO.LOAD_COORD if coord_mode else i18n.KO.LOAD_SCORING,
                cancelable=True,
            )
            self.bg_status_label.setText("")

        if coord_mode:
            # 좌표 매칭 모드(v2) — 유사도 계산 없이 좌표로 직접 매칭.
            self.bg_status_label.setText(i18n.KO.PHASE_COORD)
            self._precompute_worker = _coord.CoordScheduler(
                tasks, cfg=self._engine_cfg, threshold=self._threshold,
                auto=self._auto_mode, results=self._fast_results, parent=self,
            )
        elif eff_mode:
            # 고효율 모드 — CPU+GPU 가 협업해 ref 를 처리, 결과를 _fast_results 에 저장.
            self.bg_status_label.setText(_eff.describe_active_units(self._engine_cfg))
            self._precompute_worker = _eff.EfficiencyScheduler(
                tasks, cfg=self._engine_cfg, threshold=self._threshold,
                auto=self._auto_mode, results=self._fast_results, parent=self,
            )
        else:
            self._precompute_worker = SlotPrecomputeWorker(
                tasks, slot_cache=self._slot_cache,
                score_cache=self._score_cache,
                release_after_slot=streaming,
                cfg=self._engine_cfg,
                parent=self,
            )
        self._precompute_worker.signals.progress.connect(
            self._on_precompute_progress
        )
        self._precompute_worker.signals.slot_finished.connect(
            self._on_precompute_slot_finished
        )
        self._precompute_worker.signals.finished.connect(
            self._on_precompute_finished
        )
        self._precompute_worker.signals.failed.connect(self._on_precompute_failed)
        try:
            self._precompute_worker.signals.phase.connect(self._on_precompute_phase)
        except (AttributeError, TypeError):
            pass
        self._precompute_worker.start()

    def showEvent(self, e):  # noqa: N802
        """페이지가 실제로 보이는 순간, 사전 계산 중이면 오버레이를 다시 세운다.

        ★ ``main_window`` 는 ``load_state``(→ ``show_overlay``) 를 부른 **뒤에**
        ``_show_page`` 로 전환하는데, 그 전환은 ``w.grab()`` 스냅샷으로 ≈240ms
        진행된다.  스냅샷을 뜨는 시점의 오버레이는 페이드 0 이라 **그림에 안
        찍히고**, 사전 계산이 그 사이에 끝나버리면 사용자는 로딩을 한 번도 못
        본다.  전환 순서를 바꾸면 '보이지 않는 동안에도 자동 진행'(
        test_stage2_autostart) 계약을 건드리므로, 여기서 한 번 더 세우기만 한다.
        이미 떠 있으면 ``show_overlay`` 는 무해하고, 끝났으면 워커가 None 이라
        아무 일도 하지 않는다."""
        super().showEvent(e)
        if self._precompute_worker is None or self._current is not None:
            return
        self._loading.show_overlay(
            getattr(self, "_precompute_phase", "") or self._default_phase(),
            cancelable=True,
        )
        if self._precompute_total > 0:
            self._loading.set_progress(
                self._precompute_done, self._precompute_total,
                getattr(self, "_precompute_phase", "") or self._default_phase(),
            )

    def _precompute_signal_is_current(self) -> bool:
        """이 시그널이 **현재 활성** precompute 워커에서 온 것인지 (#B2).

        정지된 구 워커가 disconnect 직전 이벤트 루프에 이미 쌓아둔 늦은 시그널이
        새 워커의 상태를 건드리는 race 를 차단한다.  단, 판별이 불확실하면(sender
        없음/워커 참조 없음) 막지 않아 정상 시그널은 절대 누락되지 않게 한다.
        """
        w = self._precompute_worker
        if w is None:
            return True
        s = self.sender()
        if s is None:
            return True
        return s is w.signals

    def _default_phase(self) -> str:
        """단계 신호가 오기 전 기본 라벨 — 좌표 모드는 유사도를 계산하지 않는다."""
        return (i18n.KO.PHASE_COORD_PARSE if self._coord_mode
                else i18n.KO.PHASE_SCORING)

    def _on_precompute_phase(self, phase: str) -> None:
        """현재 작업 단계 라벨 갱신 (#8) — '이미지 특징 분석'/'유사도 계산' 등.

        선행 단계(특징 분석/임베딩)에서 progress emit 이 늦어도 라벨은 **즉시**
        오버레이에 반영해, '유사도 계산 0' 처럼 보이던 문제를 없앤다.
        """
        if not self._precompute_signal_is_current():
            return
        self._precompute_phase = phase or self._default_phase()
        if self._current is None:
            # 마지막으로 받은 진행도를 유지하며 라벨만 바꾼다(아직 없으면 busy 표시).
            self._loading.set_progress(
                self._precompute_done, self._precompute_total,
                self._precompute_phase,
            )

    def _on_precompute_progress(self, done: int, total: int) -> None:
        if not self._precompute_signal_is_current():
            return
        # 첫 슬롯이 끝나 매칭이 시작되기 전(차단 오버레이 표시 중)에는 진행 바를
        # 갱신해 "0% 에서 멈춘 것처럼" 보이지 않게 한다.  매칭이 시작되면
        # (_current 설정) 백그라운드 슬롯의 progress 는 매칭 오버레이를 건드리지
        # 않도록 무시 — bg_status_label 이 슬롯 단위 진행을 대신 보여준다.
        # (set_progress 는 hidden 오버레이를 다시 show 하지 않으므로 안전.)
        self._precompute_done = done
        self._precompute_total = total
        if self._current is None:
            phase = getattr(self, "_precompute_phase", "") or self._default_phase()
            # 라벨엔 현재 작업명, 진행도는 처리 갯수(done / total)로 표시.
            self._loading.set_progress(done, total, phase)

    def _on_precompute_slot_finished(self,
                                      slot: str,
                                      idx: int,
                                      total: int) -> None:
        """슬롯 1 개의 점수 계산이 끝났을 때 호출.

        수동 모드에서는:
        - 첫 슬롯 완료 시 매칭 화면을 즉시 활성화 (_advance).
        - 사용자가 ‘아직 점수 안 끝난 슬롯’ 에 도착해 기다리는 중이라면
          그 슬롯이 끝났을 때 자동으로 _advance 를 재시도.
        - 상단 상태 라벨 갱신 (백그라운드 진행 표시).
        """
        if not self._precompute_signal_is_current():
            return
        self._precompute_processed_slots.add(slot)
        self.bg_status_label.setText(
            i18n.KO.PRECOMPUTE_BG_STATUS_FMT.format(idx=idx, total=total)
        )
        if self._coord_mode and self._state is not None:
            self.coord_candidates_ready.emit(slot, thumb_plan.candidate_items(
                self._fast_results, slot, self._state.val_pool.get(slot, [])))
        if not self._streaming_precompute:
            return
        if idx == 1:
            # 첫 슬롯 끝 → 차단 오버레이를 내리고 매칭 시작.
            self._loading.hide_overlay()
            self._advance()
            return
        if self._waiting_for_slot == slot:
            self._waiting_for_slot = None
            self._loading.hide_overlay()
            self._advance()

    def _on_precompute_failed(self, msg: str) -> None:
        """사전 계산 워커가 실패로 종료 — 사용자가 오버레이에 갇히지 않도록
        대기 상태를 해제하고 ``_advance`` 로 폴백 (MatcherWorker 가 lazy 계산).

        Bug #6: 이전엔 오버레이 텍스트만 갱신하고 _waiting_for_slot 을 풀지
        않아, 사용자가 점수 계산 대기 중인 슬롯에 도달했을 때 워커가 죽으면
        영구히 ‘잠시만 기다려주세요’ 오버레이에 갇혔다.
        """
        if not self._precompute_signal_is_current():
            return
        try:
            self._loading.hide_overlay()
        except Exception:
            pass
        self._waiting_for_slot = None
        self._streaming_precompute = False
        # 좌표 매칭 모드에서 좌표 없음 오류 — 사용자에게 안내 후 설정 화면 복귀.
        if self._coord_mode and msg and i18n.KO.COORD_MISSING in msg:
            sheets.warn(self, i18n.KO.APP_TITLE, msg)
            self.cancelled.emit()
            return
        if self.bg_status_label is not None:
            self.bg_status_label.setText(msg or "")
        if self._current is not None or (self._state and self._state.queue):
            # 실패해도 **자동 사슬은 계속 돈다** — 그러면 덮개도 계속 있어야 한다.
            # (위 `hide_overlay` 는 좌표 없음 안내 시트를 가리지 않기 위한 것이다.)
            self._update_auto_progress()
            self._advance()
            return
        # 큐도 비었고 현재 ref 도 없다 — 여기서 그냥 반환하면 main_window 는 아무
        # 신호도 못 받아 Stage 2 에 갇힌다.  빈 큐는 '끝'과 같으므로 그렇게 알린다.
        if self._state is not None:
            self._advance()             # queue 가 비어 있으므로 finished 를 낸다

    def _on_precompute_finished(self) -> None:
        if not self._precompute_signal_is_current():
            return
        import time as _t
        if getattr(self, "_precompute_t0", None):
            self._precompute_elapsed = _t.perf_counter() - self._precompute_t0
        # 좌표 매칭 실패 목록 수집 — 검토 화면 통계용.
        if self._coord_mode and self._precompute_worker is not None:
            fs = getattr(self._precompute_worker, "failed_set", set())
            self._coord_failed_set = set(fs)
            # 좌표가 없어 고전 유사도로 폴백 채점된 ref — 그 점수는 거리가 아니다.
            cr = getattr(self._precompute_worker, "classical_refs", set())
            self._coord_classical_refs = set(cr)
        else:
            self._coord_failed_set = set()
            self._coord_classical_refs = set()
        was_streaming = self._streaming_precompute
        self.bg_status_label.setText(i18n.KO.PRECOMPUTE_BG_DONE)
        self._streaming_precompute = False
        if not was_streaming:
            # 자동(전체 선계산) — 모든 계산이 끝났으니 이제 매칭 시작.
            # _current 가 아직 None 이므로 진행 바가 정상 갱신됐고, 여기서 한 번만
            # _advance → 캐시/결과 조회로 즉시 자동 매칭 (백그라운드 없음).
            #
            # ★ **덮개를 내리지 않는다 — 이어받는다.**  선계산이 끝난 것이지 작업이
            #   끝난 것이 아니다.  여기서 `hide_overlay()` 를 부르면 뒤이어 도는 자동
            #   매치 사슬 전체가 무방비가 되고(실측 88.6%), 그 사이 Ctrl+Z 한 번이면
            #   ref↔val 이 통째로 밀린다 — `_update_auto_progress` 주석 참조.
            #   해제는 `_advance` 의 빈-큐 분기 한 곳뿐이다.
            self._update_auto_progress()
            self._advance()
            return
        # 수동 스트리밍 — 첫 슬롯에서 이미 _advance 됨.  대기 슬롯만 해제.
        if self._waiting_for_slot is not None:
            self._waiting_for_slot = None
            self._loading.hide_overlay()
            self._advance()
            return
        # ★ 안전망 — 스트리밍인데 대기 슬롯도 없고 아직 아무 ref 도 잡지 못했다면
        #   (첫 `slot_finished` 가 끝내 오지 않은 경우: 워커가 중단·예외로 슬롯
        #   루프를 빠져나가면 `finished` 만 온다) 여기서 진행을 열어 준다.
        #   이게 없으면 '잠시만 기다려주세요' 오버레이가 영구히 남는다.
        if self._current is None and self._state is not None and self._state.queue:
            self._loading.hide_overlay()
            self._advance()

    def get_state(self) -> Stage2State | None:
        return self._state

    def review_context(self) -> ReviewContext:
        """검토·결과 화면에 넘길 상태를 한 번에 (`ReviewContext` 참고)."""
        cfg = self._engine_cfg
        coord_mode = EngineMode.is_coordinate(getattr(cfg, "engine", ""))
        return ReviewContext(
            score_cache=self._score_cache,
            fast_results=self._fast_results,
            coord_mode=coord_mode,
            tolerance=float(getattr(cfg, "coord_tolerance",
                                    config.DEFAULT_SIM_CONFIG.coord_tolerance)),
            # 좌표 모드가 아니면 실패 집합은 의미가 없다(직전 세션 잔재일 수 있다).
            coord_failed_count=len(self._coord_failed_set) if coord_mode else 0,
            elapsed_s=float(self._precompute_elapsed),
            review_scores=self._review_scores,
            # 실패 집합과 같은 이유로 좌표 모드에서만 의미가 있다.
            coord_classical_refs=(frozenset(self._coord_classical_refs)
                                  if coord_mode else frozenset()),
        )

    def build_candidates_by_ref(self, matches) -> dict:
        """매치 검토 화면(#7)용 — 각 ref 의 후보 [(ImageItem, score), ...] 산출.

        고속 모드는 _fast_results(선계산 top-K)에서, 기본 모드는 score_cache
        에서 가져온다.  키는 (slot, ref_path.name) — 점수 내림차순.
        """
        out: dict = {}
        if self._state is None:
            return out
        for m in matches:
            key = (m.slot, m.ref_path.name)
            if key in out:
                continue
            vitems = self._state.val_pool.get(m.slot, []) or []
            by_path = {v.path: v for v in vitems}
            scored: list = []
            fres = self._fast_results.get((m.slot, m.ref_path))
            if fres:
                for vp, s in fres:
                    vi = by_path.get(vp)
                    if vi is not None:
                        scored.append((vi, float(s)))
            else:
                for vi in vitems:
                    s = self._score_cache.get_pair(m.slot, m.ref_path, vi.path)
                    if s is None:
                        # ★ 실패 검토 창이 계산한 점수도 본다.  좌표 모드에서
                        #   이웃을 못 찾은 ref 는 `_fast_results` 에 **빈 목록**이
                        #   들어가(falsy) 이쪽으로 오는데, 그 ref 를 실패 검토에서
                        #   확정하면 유일한 점수 출처가 여기다 — 안 보면 확정한
                        #   매치의 차순위 후보가 통째로 사라진다(실측 6 → 0).
                        s = self._review_scores.get_pair(
                            m.slot, m.ref_path, vi.path)
                    if s is not None:
                        scored.append((vi, float(s)))
            scored.sort(key=lambda x: x[1], reverse=True)
            out[key] = scored
        return out

    # ------------------------------------------------------------------
    def request_back_to_setup(self) -> None:
        """창(여정 레일)이 부르는 복귀 진입점 — 중지와 같은 길이다.

        ★ 화면 안의 [← 설정으로] 버튼은 없앴다(구조개편 1안-A).  '계산을 전부
        폐기한다' 는 사실은 이 화면만 아는 것이라 확인은 `_confirm_cancel` 에 남는다."""
        self._on_cancel_requested()

    def _on_cancel_requested(self) -> None:
        """#8 중지 — 진행 중인 사전계산/매칭 워커를 안전하게 멈추고 세션 중단."""
        if not self._confirm_cancel():
            return
        # ★ 표식을 **워커를 멈추기 전에** 세운다 — 아래 정리 도중에도 예약된
        #   `_on_pick` 이 배달될 수 있고, 그것까지 막아야 사슬이 진짜로 선다.
        self._aborted = True
        self._stop_precompute_worker()
        self._detach_worker()
        self._worker = None
        # ★ 다음 실행이 **처음처럼** 시작되게 계산 결과를 전부 버린다.
        #   특히 `_score_cache` 를 남기면 2회차의 `has_all_pairs` 가 True 가 되어
        #   `_launch_matcher` 가 **1회차 후보를 그대로 재사용**한다 — 설정(허용 오차·
        #   엔진)을 바꿔 다시 돌려도 옛 결과가 나오는 정확도 사고다.
        self._score_cache.clear()
        # 실패 검토가 계산해 둔 점수도 같은 세션의 계산 결과다 — 함께 버린다.
        self._review_scores.clear()
        self._slot_cache.clear()
        self._candidates = []
        self._coord_failed_set = set()
        self._coord_classical_refs = set()
        self._loading.hide_overlay()
        self.cancelled.emit()

    def _confirm_cancel(self) -> bool:
        """진행 중이면 한 번 묻는다 — 중단은 '잠깐 멈춤' 이 아니라 계산 전부 폐기다.

        ★ 로딩 오버레이는 시트보다 **위**에 있다(main_window 가 그렇게 만든다).
        띄운 채 물으면 확인창이 어두운 화면 뒤에 가려 보이지 않으므로, 물어보는 동안만
        내렸다가 '아니오' 면 그대로 되돌린다."""
        done, total = self._cancel_progress()
        if done <= 0:
            return True                      # 아직 한 것이 없다 — 묻지 않는다
        from PyQt6.QtWidgets import QMessageBox
        was_visible = self._loading.isVisible()
        msg = getattr(self._loading, "_label", None)
        keep_msg = msg.text() if msg is not None else ""
        if was_visible:
            self._loading.hide()
        r = sheets.ask(
            self, i18n.KO.MATCH_CANCEL_CONFIRM_TITLE,
            i18n.KO.MATCH_CANCEL_CONFIRM_FMT.format(done=done, total=total),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if r == QMessageBox.StandardButton.Yes:
            return True
        # ★ 되돌리기 전에 **이 페이지가 아직 화면에 있는지** 확인한다.  위 `ask` 는
        #   중첩 이벤트 루프라 그동안 워커 시그널이 계속 배달된다 — 확인창을 읽는 몇 초
        #   사이에 매칭이 끝나 검토 화면으로 넘어가 있을 수 있다.  그때 오버레이를
        #   되살리면 부모가 숨겨져 있어 화면에는 안 나타나면서 앱 전역 입력 잠금만
        #   걸리고, 보상 해제인 hideEvent 도 오지 않아 **키보드가 통째로 죽는다.**
        #   이미 다음 단계로 넘어갔다면 되돌릴 것도 없다.
        if was_visible and self.isVisible():  # 되돌린다 — 작업은 계속 돌고 있다
            self._loading.show_overlay(keep_msg, cancelable=True)
            if total > 0:
                self._loading.set_progress(done, total, keep_msg)
        return False

    def _cancel_progress(self) -> tuple[int, int]:
        """확인창에 넣을 '지금까지 얼마나 했는가' — 단계에 따라 출처가 다르다.

        ★ **매칭이 시작된 뒤에는 매칭 진행을 보고한다.**  선계산 총량을 그대로 쓰면
        자동 매치 사슬이 도는 동안 [중지] 를 눌렀을 때 이미 100% 인 선계산 수치
        ('400 / 400')가 뜬다 — 사용자가 무엇을 버리는지 알 수 없다.  덮개를 사슬
        구간까지 이어받으면서 [중지] 가 그 구간 내내 보이게 됐으므로 함께 맞춘다.
        """
        state = self._state
        if state is not None and self._current is not None:
            done = len(state.matches) + sum(
                len(v) for v in state.no_match.values()
            )
            return done, done + len(state.queue)
        done = int(getattr(self, "_precompute_done", 0) or 0)
        total = int(getattr(self, "_precompute_total", 0) or 0)
        if total > 0:
            return done, total
        if state is not None:
            done = len(state.matches)
            return done, done + len(state.queue)
        return 0, 0

    # ------------------------------------------------------------------
    def _detach_worker(self) -> None:
        """살아있는 매칭 워커의 시그널을 끊고 중단 + 대기.

        wait() 가 timeout 으로 끝나도 ‘늦게 도착한 done’ 이 새 후보 리스트를
        덮어쓰지 않게 시그널부터 끊는다.  참조는 호출자가 정리한다."""
        w = self._worker
        if w is None:
            return
        try:
            w.signals.progress.disconnect()
            w.signals.done.disconnect()
            w.signals.failed.disconnect()
        except (TypeError, RuntimeError):
            pass
        if w.isRunning():
            w.stop()
            w.wait(500)

    def _stop_precompute_worker(self) -> None:
        """현재 precompute 워커의 시그널을 모두 끊고 중단 + 대기.

        - 다음 _start_precompute 호출 전에 호출되어 ‘이전 워커의 늦은 시그널이
          새 워커 상태를 건드리는’ race 를 방지.
        - 매칭 완료 (queue 비움) 시점에도 호출되어 단일 모드 → 결과 페이지로
          넘어갈 때 백그라운드 워커가 헛돌지 않도록 정리.

        호출 후 스트리밍 관련 상태(streaming flag / waiting slot / 처리된 슬롯
        집합 / 상단 상태 라벨) 도 모두 초기화. 워커가 없어도 상태는 항상 비운다.
        """
        w = self._precompute_worker
        if w is not None:
            # ★ `phase` 도 포함한다 — 빠져 있어서 죽은 워커가 계속 `_on_precompute_phase`
            #   에 연결된 채 남았다(지금은 `_precompute_signal_is_current` 가 막아 주지만,
            #   '끊는다'고 적어 놓고 하나만 안 끊는 건 다음 사람을 오도한다).
            for sig in (w.signals.progress, w.signals.slot_finished,
                        w.signals.finished, w.signals.failed, w.signals.phase):
                try:
                    sig.disconnect()
                except (TypeError, RuntimeError):
                    pass
            if w.isRunning():
                w.stop()
                w.wait(500)
            # 죽은 워커 핸들을 남기지 않는다 — `_advance` 의 slot_pending 판정과
            # `_on_precompute_finished` 의 failed_set 조회가 이걸 그대로 읽는다.
            self._precompute_worker = None
        self._streaming_precompute = False
        self._waiting_for_slot = None
        self._precompute_processed_slots.clear()
        self.bg_status_label.setText("")

    # ------------------------------------------------------------------
    def _advance(self) -> None:
        if self._state is None or self._aborted:
            return                           # 중지된 세션 — 사슬을 잇지 않는다
        if not self._state.queue:
            self._current = None
            self.center_img.clear_image()
            self.slot_label.setText("")
            self._clear_progress()
            self._clear_right_grid()
            # ★ 23안 — 이 앱에서 '수 분짜리 작업의 끝' 은 여기 한 곳이다(자동 매칭).
            #   눈금이 완료색으로 200ms 머문 **뒤** 오버레이가 걷힌다 — 다른 창을
            #   보던 사용자의 주변시에 걸리라고 둔 단 하나의 틱이다.  스캔·썸네일·
            #   엑셀 저장 같은 짧은 작업에는 달지 않는다(시안 명시).
            self._loading.finish_tick(then=self._loading.hide_overlay)
            # 백그라운드 사전 계산이 아직 돌고 있으면 즉시 중단 — 매칭이 끝났으니
            # 이후 슬롯 점수는 더 이상 필요 없음 (CPU/RAM 회수).
            self._stop_precompute_worker()
            self.finished.emit()
            return

        self._current = self._state.queue[0]
        self._show_center(self._current)
        self._set_progress(self._current.slot, len(self._state.matches),
                           len(self._state.matches) + len(self._state.queue))

        val_items = self._state.val_pool.get(self._current.slot, [])
        if not val_items:
            # 자동 모드는 매 ref 마다 모달이 뜨는 ‘모달 폭격’ 을 피하려고
            # 모달 없이 조용히 ‘매칭 없음’ 처리 (Bug #4).  수동 모드만 안내.
            if not self._auto_mode:
                sheets.info(self, i18n.KO.APP_TITLE,
                                        i18n.KO.INFO_NO_VAL_PHOTOS)
            self._confirm_no_match(user=False)
            return

        # 스트리밍 모드에서 사용자가 ‘아직 점수 계산 중인 슬롯’ 에 도착하면
        # 짧은 오버레이로 안내 후, 그 슬롯이 끝났다는 시그널이 오면 자동으로
        # 다시 _advance 가 호출된다 (_on_precompute_slot_finished 에서).
        # 단, 워커가 이미 그 슬롯을 처리했는데도 점수가 누락된 경우 (extract
        # 실패 등) 무한 대기에 빠지지 않도록 처리 여부도 함께 확인.
        slot = self._current.slot
        slot_pending = (
            self._streaming_precompute
            and self._precompute_worker is not None
            and self._precompute_worker.isRunning()
            and slot not in self._precompute_processed_slots
            and not self._score_cache.has_all_pairs(
                slot, self._current.path, [v.path for v in val_items],
            )
        )
        if slot_pending:
            self._waiting_for_slot = slot
            self._loading.show_overlay(
                i18n.KO.LOAD_PRECOMPUTE_WAIT_FMT.format(slot=slot),
                cancelable=True,
            )
            return

        self._launch_matcher(self._current, val_items)

    def _launch_matcher(self,
                        ref: ImageItem,
                        val_items: list[ImageItem]) -> None:
        self._clear_right_grid()
        self._detach_worker()

        # 고속 모드 자동 — 선계산된 결과(_fast_results)가 있으면 즉시 응답
        # (사진 한 장씩 백그라운드 계산 없이 바로 매칭, #2/#3).
        if self._fast_mode:
            key = (ref.slot, ref.path)
            if key in self._fast_results:
                by_path = {v.path: v for v in val_items}
                cands = []
                # 좌표 모드: 음수 score(허용범위 초과 근접 1장)도 포함
                effective_threshold = -float("inf") if self._coord_mode else self._threshold
                for vp, s in self._fast_results[key]:
                    vitem = by_path.get(vp)
                    if vitem is not None and s >= effective_threshold:
                        cands.append(Candidate(item=vitem, score=float(s)))
                cands.sort(key=lambda c: c.score, reverse=True)
                self._on_matcher_done(cands)
                return

        # 점수 사전 계산이 끝나 있으면 캐시 조회만으로 즉시 응답.
        val_paths = [v.path for v in val_items]
        if self._score_cache.has_all_pairs(ref.slot, ref.path, val_paths):
            cached: list = []
            for v in val_items:
                s = self._score_cache.get_pair(ref.slot, ref.path, v.path)
                if s is not None and s >= self._threshold:
                    cached.append(Candidate(item=v, score=float(s)))
            cached.sort(key=lambda c: c.score, reverse=True)
            self._on_matcher_done(cached)
            return

        # 사전 계산이 안 됐거나 누락된 경우 — 기존 워커 fallback.
        self._slot_cache.set_active(ref.slot)
        val_features = self._slot_cache.get_features(ref.slot) or {}
        # 모든 val 이 이미 캐시에 들어 있으면 ‘유사도 계산’ 모드.
        # 누락이 있으면 ‘특징 추출’ 모드로 표시.
        self._slot_features_ready = (
            len(val_features) >= len(val_items)
            and all(it.path in val_features for it in val_items)
        )
        loading_fmt = (
            i18n.KO.LOAD_SCORING if self._slot_features_ready
            else i18n.KO.LOAD_FEATURE
        )
        self._loading.show_overlay(
            loading_fmt,
            cancelable=True,
        )
        self._current_loading_fmt = loading_fmt

        self._worker = MatcherWorker(
            ref, val_items, threshold=self._threshold,
            val_features=val_features,
            slot_cache=self._slot_cache,
            cfg=self._engine_cfg,
        )
        self._worker.signals.progress.connect(self._on_matcher_progress)
        self._worker.signals.done.connect(self._on_matcher_done)
        self._worker.signals.failed.connect(self._on_matcher_failed)
        self._worker.start()

    def _on_matcher_failed(self, msg: str) -> None:
        """매칭 워커 실패 — **오버레이를 풀고 다음 ref 로 넘어간다.**

        ``MatcherWorker.run`` 은 ``done`` 또는 ``failed`` 중 하나만 낸다.  예전엔
        여기서 오버레이 문구만 갈아 끼워서, ref 하나의 특징 추출이 실패하면
        차단 오버레이가 뜬 채 **영구히 멈췄다**.  ``_on_precompute_failed`` 가
        같은 함정(Bug #6)을 이미 고쳤는데 이쪽만 남아 있었다 — 같은 규칙을 쓴다:
        **실패도 하나의 결과다.  후보 0개로 취급하고 진행을 계속한다.**"""
        try:
            self._loading.hide_overlay()
        except Exception:
            pass
        if self.bg_status_label is not None and msg:
            self.bg_status_label.setText(msg)
        # 후보 0개와 동일 경로 — 자동이면 '매칭 없음' 확정, 수동이면 안내.
        self._on_matcher_done([])

    def _on_matcher_progress(self, done: int, total: int) -> None:
        msg = getattr(self, "_current_loading_fmt", i18n.KO.LOAD_FEATURE)
        self._loading.set_progress(done, total, msg)

    def _on_matcher_done(self, candidates: list) -> None:
        self._candidates = list(candidates)
        if not self._candidates:
            # 자동 모드면 모달 없이 ‘매칭 없음’ 으로 즉시 처리 (이벤트 루프에
            # 한 번 양보해 진행 라벨이 보이도록 QTimer.singleShot 으로 defer).
            if self._auto_mode:
                self._update_auto_progress()
                # ★ user=False — 페이지 전환 애니메이션 중에는 isVisible() 이
                #   False 라, 사람이 부른 것처럼 다루면 사슬이 끊긴다.
                call_later(self, 0, lambda: self._confirm_no_match(user=False))
            else:
                self._loading.hide_overlay()
                sheets.info(self, i18n.KO.APP_TITLE,
                                        i18n.KO.INFO_NO_MATCH_FOUND)
                self._confirm_no_match(user=False)  # ‘잠시 보류’ 제거 (#3)
            return

        # 자동 매치 모드: 최고 점수 후보를 즉시 확정하고 다음 ref 로.
        if self._auto_mode:
            top = self._candidates[0]
            self._update_auto_progress()
            call_later(self, 0, lambda: self._on_pick(
                ThumbEntry(item=top.item, extra={"score": float(top.score)})
            ))
            return

        self._loading.hide_overlay()
        self._populate_right(self._candidates)

    def _update_auto_progress(self) -> None:
        """자동 모드 진행 표시 — done / total ref.  **덮개도 여기서 책임진다.**

        ★ 예전엔 `set_progress` 만 불렀다.  그런데 `set_progress` 는 **숨은 오버레이를
        다시 띄우지 않는다** — 선계산이 끝나며 오버레이를 내린 뒤로는 자동 매치 사슬이
        끝까지 **덮개 없이** 돌았다(실측 ref 400장: 오버레이는 479ms 에 사라지고 사슬은
        3.0초에 끝나 **88.6%** 가 무방비였다).  그 구간에 남아 있던 Ctrl+Z / [되돌리기]
        가 한 번만 눌려도, 이미 예약돼 있던 `singleShot(0, _on_pick)` 이 바뀐 `_current`
        에 적용돼 **ref↔val 이 한 칸씩 밀린 채 끝까지 복구되지 않는다**(실측 200쌍 중
        157쌍이 엉뚱한 val 로 확정 — 개수·중복·누락은 정상이라 엑셀에서 티가 안 난다).

        그래서 '작업 중에는 덮는다' 는 이 저장소의 로딩 계약을 그대로 지킨다: 진행을
        보고하는 이 한 곳이 덮개도 다시 세운다.  해제는 `_advance` 의 빈-큐 분기
        **한 곳**뿐이다(끝은 한 곳).  ``is_retiring`` 까지 보는 이유는 최소 표시 래치·
        퇴장 페이드 중에는 `isVisible()` 이 아직 True 이기 때문이다.
        """
        if self._state is None or not self._auto_mode:
            return
        if (not self._loading.isVisible()) or self._loading.is_retiring():
            self._loading.show_overlay(i18n.KO.LOAD_AUTO_MATCH, cancelable=True)
        done = len(self._state.matches) + sum(
            len(v) for v in self._state.no_match.values()
        )
        total = done + len(self._state.queue)
        # 총량을 모르는 경우(total<=0)엔 set_progress 가 busy 로 떨어진다 — 0 에 멈추지 않는다.
        self._loading.set_progress(
            done, total,
            i18n.KO.LOAD_AUTO_MATCH,
        )

    # ------------------------------------------------------------------
    def _show_center(self, item: ImageItem) -> None:
        self.center_img.set_image(item.path)
        # Stage 2 도 파일명은 미표시, Slot 만 노출 (요청 사항).
        self.slot_label.setText(i18n.KO.SLOT_LABEL_FMT.format(slot=item.slot))

    def _on_size_changed(self, value: int) -> None:
        self.size_value.setText(f"{value} px")
        self.center_img.set_target_size(value)
        # 사용자 변경은 세션 동안만 유지 — 재시작 시 자동 맞춤으로 초기화.

    def _clear_right_grid(self) -> None:
        while self._right_grid.count():
            it = self._right_grid.takeAt(0)
            w = it.widget()
            if w is not None:
                w.deleteLater()

    def _set_candidate_pane_visible(self, on: bool) -> None:
        """우측 후보 패널 표시/숨김 + 중앙 카드의 안내 한 줄을 반대로 토글.

        스플리터는 숨은 자식을 자리로 치지 않으므로 남은 pane 이 폭을 전부 쓴다
        (저장된 분할 비율은 그대로 남아 있다가 패널이 돌아오면 다시 적용된다)."""
        self._right_panel.setVisible(bool(on))
        self._auto_note.setVisible(not on)

    def _populate_right(self, candidates: list[Candidate]) -> None:
        # 수동 폴백이 실제로 돌았다 — 자동 모드에서 떼어 뒀던 패널을 되살린다.
        self._set_candidate_pane_visible(True)
        self._clear_right_grid()
        visible = candidates[: config.CONFIG.match_top_visible]
        extra = len(candidates) - len(visible)

        # 후보는 가로 2 개씩 + mid 캐시 (~800px) 를 소스로 (#5).  표시 크기
        # 도 일반 썸네일보다 크게 (260 px) 잡아 시인성 ↑.
        grid = ThumbGrid(columns=2, select_mode=False, truncate=False,
                         show_expand=True, tile_px=config.Sizing.DIALOG_CAND_PX,
                         prefer_mid=True,
                         parent=self._right_host)
        entries = [ThumbEntry(item=c.item, extra={"score": c.score}) for c in visible]
        grid.set_entries(entries)
        grid.tile_clicked.connect(self._on_pick)
        grid.expand_requested.connect(self._on_expand_requested)
        self._right_grid.addWidget(grid, 0, 0)

        if extra > 0:
            # +N 카드 — 클릭 시 줌 윈도우로 전체 표시
            from ..widgets.thumb_grid import _PlusTile
            plus = _PlusTile(extra, parent=self._right_host)
            plus.clicked.connect(self._open_all_candidates)
            self._right_grid.addWidget(plus, 0, 1)

    def _on_pick(self, entry: ThumbEntry) -> None:
        # 중지된 세션에는 아무것도 확정하지 않는다 — 이미 예약된 콜백이 남아 있다.
        if self._state is None or self._current is None or self._aborted:
            return
        ref = self._current
        val = entry.item
        score = float(entry.extra.get("score", 0.0)) if entry.extra else 0.0
        match = MatchResult(
            slot=ref.slot,
            ref_path=ref.path,
            val_path=val.path,
            score=score,
        )
        self._match_history.append(("match", ref, match))
        self._state.matches.append(match)
        self._state.queue.pop(0)
        self.match_confirmed.emit(match)
        self.skipped_changed.emit()
        self._update_undo_button()
        self._advance()

    def _open_all_candidates(self) -> None:
        if self._current is None:
            return
        items = [c.item for c in self._candidates]
        win = ZoomWindow(self._current.slot, items, SOURCE_CANDIDATES, parent=self)
        win.action_requested.connect(self._on_zoom_candidates_action)
        sheets.run(win, full_bleed=True)

    # ------------------------------------------------------------------
    # ‘더 크게 보기’ 모드
    # ------------------------------------------------------------------
    def _on_expand_requested(self, entry: ThumbEntry) -> None:
        if self._current is None or not self._candidates:
            return
        items = [c.item for c in self._candidates]
        start = 0
        for i, c in enumerate(self._candidates):
            if c.item.path == entry.item.path:
                start = i
                break
        # 기본 표시 크기 = 중앙 기준 사진의 현재 크기 (#1).  사용자가 확대
        # 보기 안에서 슬라이더를 만진 적이 있으면 그 값이 우선 (세션 유지).
        self._expand_view.load_candidates(
            self._current.slot, items, start,
            default_long_edge=self.size_slider.value(),
        )
        self._right_stack.setCurrentIndex(1)
        # 단축키가 동작하도록 포커스 이동.
        self._expand_view.setFocus()

    def _exit_expand_view(self) -> None:
        self._right_stack.setCurrentIndex(0)

    def _on_expand_confirm(self, item: ImageItem) -> None:
        """확대 모드에서 [이 사진으로 매칭] 또는 Enter."""
        score = 0.0
        for c in self._candidates:
            if c.item.path == item.path:
                score = float(c.score)
                break
        # 그리드 복귀 후 매칭 확정 흐름 재사용.
        self._exit_expand_view()
        self._on_pick(ThumbEntry(item=item, extra={"score": score}))

    def _on_zoom_candidates_action(self, action: str, items: list[ImageItem]) -> None:
        """줌-뷰에서 ‘이 사진을 매칭으로 확정’ 을 누른 경우 → _on_pick 흐름 재사용."""
        if action != "pick" or not items:
            return
        picked = items[0]
        # 후보 리스트에서 해당 item 의 ThumbEntry 를 만들어 _on_pick 으로 위임
        score = 0.0
        for c in self._candidates:
            if c.item.path == picked.path:
                score = float(c.score)
                break
        self._on_pick(ThumbEntry(item=picked, extra={"score": score}))

    # ------------------------------------------------------------------
    def _skip_current(self, *, user: bool = True) -> None:
        """잠시 보류 — Skip 재시도 풀로 들어감. 미탐 시트엔 들어가지 않음.

        ``user`` 의 의미는 :meth:`_confirm_no_match` 와 같다 — 단축키/버튼처럼
        **사람이 눌렀을 때만** 가시성을 검사한다."""
        if user and not self.isVisible():
            return
        if self._state is None or self._current is None:
            return
        item = self._current
        self._match_history.append(("skip", item, None))
        self._state.queue.pop(0)
        self._state.skipped[item.slot].append(item)
        self._refresh_skipped_panel()
        self.skipped_changed.emit()
        self._update_undo_button()
        self._advance()

    def _confirm_no_match(self, *, user: bool = True) -> None:
        """매칭 없음 확정 — 미탐 시트에 들어가고, Skip 재시도 대상이 아님.

        ★ **이제 사람 경로는 없다.**  이 화면의 [매칭 없음] 버튼과 ``N`` 단축키를
        제거했다 — 2단계는 언제나 자동이라 사용자가 누를 것이 없는데, 자동 매치가
        도는 동안 눌리면 처리 중이던 사진이 조용히 미탐으로 확정됐기 때문이다
        (`_build` 의 액션 바 주석에 실측과 함께 적어 두었다).

        ★ 그래도 **기본값은 ``user=True`` 로 둔다.**  한 번 `False` 로 뒤집었다가
        되돌렸다 — 프로그램 호출부가 이미 전부 `user=False` 를 명시하고 있으므로
        기본값을 뒤집어 얻는 것은 없는데, **잃는 것이 있다**: 나중에 누가 인자를
        빠뜨리고 부르면 가시성 가드가 조용히 풀린 채 큐를 소비한다.  '모르면
        사람이 누른 것으로 본다' 가 안전한 쪽이다(회귀 가드:
        `test_stage2_autostart.py::test_user_shortcut_is_still_ignored_when_page_hidden`).

        ★ ``user`` 는 **누가 불렀는가**다.  가시성 검사를 사람이 누른 경로에만 건다.

        예전엔 무조건 ``if not self.isVisible(): return`` 이었고, 그 한 줄이
        '가끔 Stage 2 에 들어가도 자동 매칭이 진행되지 않는' 버그의 원인이었다:
        ``main_window._show_page`` 는 전환 애니메이션(≈160ms) 동안 스냅샷만 띄우고
        **실제 위젯을 비-current 로 되돌린다** — 그 사이 ``isVisible()`` 은 False 다.
        두 진입점(`_enter_stage2_*`)이 ``load_state`` 를 먼저 부르므로 워커는 그
        '보이지 않는 창' 안에서 돌고, 후보가 0개인 ref 를 만나는 순간 자동 사슬이
        여기서 조용히 끊겼다(매칭되는 ref 를 처리하는 ``_on_pick`` 엔 같은 가드가
        없어 더 눈에 안 띄었다).  좌표 모드는 계산이 즉시 끝나고 허용 오차를 넘는
        ref 가 정상적으로 빈 후보를 남기므로 특히 잘 터졌다.

        가드 자체는 필요하다 — 'N' 단축키가 ``WidgetWithChildrenShortcut`` 로
        좁혀졌어도, 버튼/단축키 경로가 엉뚱한 화면에서 큐를 소비하는 일은 막아야
        한다.  그래서 지우는 대신 **사람 경로와 프로그램 경로를 나눈다.**
        """
        if user and not self.isVisible():
            return
        if self._state is None or self._current is None:
            return
        item = self._current
        self._match_history.append(("no_match", item, None))
        self._state.queue.pop(0)
        self._state.no_match[item.slot].append(item)
        self._refresh_skipped_panel()
        self.skipped_changed.emit()
        self._update_undo_button()
        self._advance()

    # ------------------------------------------------------------------
    # 되돌리기 (#C1) — 직전 매칭/매칭없음/보류 결정을 취소
    # ------------------------------------------------------------------
    def _update_undo_button(self) -> None:
        btn = getattr(self, "undo_btn", None)
        if btn is not None:
            btn.setEnabled(bool(self._match_history))

    def _undo_match(self) -> None:
        """직전 결정을 취소하고 해당 기준 사진을 큐 맨 앞으로 복귀.

        - 'match' : state.matches 에서 제거 + ``match_undone`` 으로 상위(main_window)
                    집계까지 되돌림 (결과에 남지 않도록).
        - 'no_match'/'skip' : 해당 풀에서 제거.
        매칭 화면이 보이지 않을 때(이미 다음 단계로 이동)는 무시.
        """
        if not self.isVisible():
            return
        if self._state is None or not self._match_history:
            return
        action, ref, match = self._match_history.pop()
        if action == "match" and match is not None:
            for i in range(len(self._state.matches) - 1, -1, -1):
                if self._state.matches[i].key == match.key:
                    del self._state.matches[i]
                    break
            self.match_undone.emit(match)
        elif action == "no_match":
            lst = self._state.no_match.get(ref.slot)
            if lst and ref in lst:
                lst.remove(ref)
            self._refresh_skipped_panel()
        elif action == "skip":
            lst = self._state.skipped.get(ref.slot)
            if lst and ref in lst:
                lst.remove(ref)
            self._refresh_skipped_panel()
        # 기준 사진을 큐 맨 앞으로 되돌리고 현재 항목 재설정 → _advance 가 다시 표시.
        self._state.queue.insert(0, ref)
        self._current = None
        self.skipped_changed.emit()
        self._update_undo_button()
        self._advance()

    # ------------------------------------------------------------------
    def _refresh_skipped_panel(self) -> None:
        """상단 [보류된 사진 보기 (n)] / [보류 재시도] 버튼 활성/카운트 갱신.

        ‘잠시 보류’ 버튼 제거 (#3) 이후로는 새로 보류가 만들어지지 않지만,
        과거 autosave 의 보류 항목이 있을 수 있어 두 버튼 자체는 유지하고
        해당 항목 수가 0 이면 ‘완전히 숨김’ 처리 — 화면이 깔끔하게 보임.
        """
        if self._state is None:
            self.btn_view_skipped.setText(
                i18n.KO.BTN_VIEW_SKIPPED_FMT.format(n=0)
            )
            self.btn_view_skipped.setVisible(False)
            self.retry_btn.setVisible(False)
            return
        n_defer = sum(len(v) for v in self._state.skipped.values())
        n_none = sum(len(v) for v in self._state.no_match.values())
        total = n_defer + n_none
        self.btn_view_skipped.setText(
            i18n.KO.BTN_VIEW_SKIPPED_FMT.format(n=total)
        )
        # 0 이면 숨김 — ‘잠시 보류’ 자체가 사라졌으므로.
        self.btn_view_skipped.setVisible(total > 0)
        # ‘보류 재시도’ 는 defer 만 활성 — none 은 영구 미탐
        self.retry_btn.setVisible(n_defer > 0)

    def _open_skipped_dialog(self) -> None:
        """[보류된 사진 보기] 클릭 → 보류/매칭없음 사진을 큰 팝업에 모아 표시."""
        if self._state is None:
            return
        from PyQt6.QtWidgets import QDialog as _QDialog
        dlg = _QDialog(self)
        # 닫는 즉시 C++ 위젯 해제 — 버튼 클릭마다 누적되지 않도록.
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setWindowTitle(i18n.KO.SKIPPED_DIALOG_TITLE)
        dlg.setModal(True)
        from PyQt6.QtWidgets import QApplication as _QA
        scr = (self.screen() if hasattr(self, "screen") else None) \
            or _QA.primaryScreen()
        if scr is not None:
            g = scr.availableGeometry()
            dlg.resize(min(1200, int(g.width() * 0.9)),
                       min(800, int(g.height() * 0.85)))
        else:
            dlg.resize(1200, 800)
        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        defer_slots = sorted(s for s, v in self._state.skipped.items() if v)
        none_slots = sorted(s for s, v in self._state.no_match.items() if v)
        if not defer_slots and not none_slots:
            lab = QLabel(i18n.KO.SKIPPED_DIALOG_EMPTY, dlg)
            lab.setProperty("role", "muted")
            layout.addWidget(lab)
        else:
            scroll = QScrollArea(dlg)
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QScrollArea.Shape.NoFrame)
            host = QWidget()
            hl = QVBoxLayout(host)
            hl.setContentsMargins(4, 4, 4, 4)
            hl.setSpacing(10)
            if defer_slots:
                n = sum(len(self._state.skipped[s]) for s in defer_slots)
                hdr = QLabel(
                    i18n.KO.SKIPPED_SECTION_DEFER_FMT.format(n=n), host,
                )
                hdr.setProperty("role", "sectionWarn")
                hl.addWidget(hdr)
                for slot in defer_slots:
                    sec = SlotSection(slot, columns=4, select_mode=False,
                                      parent=host)
                    sec.set_entries([
                        ThumbEntry(item=it)
                        for it in self._state.skipped[slot]
                    ])
                    hl.addWidget(sec)
            if none_slots:
                n = sum(len(self._state.no_match[s]) for s in none_slots)
                hdr = QLabel(
                    i18n.KO.SKIPPED_SECTION_NO_MATCH_FMT.format(n=n), host,
                )
                hdr.setProperty("role", "sectionDanger")
                hl.addWidget(hdr)
                for slot in none_slots:
                    sec = SlotSection(slot, columns=4, select_mode=False,
                                      parent=host)
                    sec.set_entries([
                        ThumbEntry(item=it)
                        for it in self._state.no_match[slot]
                    ])
                    hl.addWidget(sec)
            hl.addStretch(1)
            scroll.setWidget(host)
            layout.addWidget(scroll, stretch=1)

        bar = QHBoxLayout()
        bar.addStretch(1)
        close = NeonButton(i18n.KO.BTN_OK, role="ghost")
        close.clicked.connect(dlg.accept)
        bar.addWidget(close)
        layout.addLayout(bar)
        sheets.run(dlg, full_bleed=True)

    def _retry_skipped(self) -> None:
        """Skip 된 항목들을 큐 앞으로 다시 밀어넣고, 임계치를 낮춰 재시도."""
        if self._state is None:
            return
        flat: list[ImageItem] = []
        for slot, items in self._state.skipped.items():
            flat.extend(items)
        self._state.skipped.clear()
        # 임계치 70% → 55% 로 한 단계 완화 (한 번에 0.15 씩)
        self._threshold = max(0.0, self._threshold - 0.15)
        # 큐 앞에 삽입
        self._state.queue = flat + self._state.queue
        self._refresh_skipped_panel()
        self._advance()
