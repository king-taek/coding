"""die 격자 기하(pitch·인덱스 원점)를 **스캔 결과 폴더에서 읽는다**.

``models.py`` 의 ``CAMTEK_PITCH_X`` 같은 상수는 TB500 한 대의 값이었다.  die 크기가
다른 디바이스에서는 ``x = X − Col × 37247.7`` 이 통째로 틀린 값을 내 좌표·매칭·엑셀이
전부 어긋난다.  필요한 값은 이미 결과 폴더 안에 있다 — 코드가 안 읽고 있었을 뿐이다.

출처:
  · Camtek : ``Params_WaferInfo.ini``  ``[Geometry] DieStep_X/DieStep_Y``
             (``DieSize_*`` 는 폴백 — 실측상 DieStep 과 미세히 다르다)
  · KLA    : ``.001`` 헤더 ``DiePitch X Y`` 와 ``SampleTestPlan`` 의 die 인덱스 목록

실측 불변식(``dev/좌표 확인`` 63건 전부 일치) — **읽은 pitch 의 검산에 쓴다**::

    Col == floor(X / DieStep_X)      Row == floor(Y / DieStep_Y)

즉 Camtek 의 die 격자는 stage 원점(0,0)에 고정돼 있다.  읽은 pitch 로 이 식이 안 맞으면
엉뚱한 키를 읽은 것이므로 채택하지 않는다.

⚠ 다만 ``Row`` 쪽 등호는 **레시피마다 원점이 1 다를 수 있다**(실측 15호기).  그래서
검산은 X 만 등호를 요구하고 Y 는 '레시피별로 차이가 상수' 만 본다 — :func:`_grid_check`
와 ``docs/디바이스_하드코딩_조사.md`` §6-F 참조.  좌표 변환 자체는 이 필드를 안 쓰고
``floor(좌표/pitch)`` 로 유도한다(:mod:`.camtek_ini`).

``pixel_size.py`` 와 같은 관습: 폴더 단위 ``@lru_cache``, 전 구간 fail-safe(절대 raise 안 함),
합리적 범위 클램프.  못 읽으면 ``models.py`` 의 TB500 폴백을 쓰되 **경고를 남긴다**
(조용히 옛 경로로 떨어지면 아무도 모른다).
"""

from __future__ import annotations

import logging
import math
import re
import struct
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Optional

from .ini_text import read_ini_text
from .models import (CAMTEK_COL_OFFSET, CAMTEK_PITCH_X, CAMTEK_PITCH_Y,
                     DEFAULT_WAFER_DIAMETER, KLA_ZERO_X, KLA_ZERO_Y)

__all__ = ["CamtekGeometry", "KlaGeometry", "camtek_geometry", "kla_geometry",
           "has_camtek_entries", "peek_die_pitch", "live_geometry", "FALLBACK_CAMTEK",
           "FALLBACK_KLA", "EXPORT_SOURCE_TAG", "DIELUT_SOURCE_TAG", "AGREE_SOURCE_TAG",
           "is_trusted_source", "dielut_cells", "KLA_CENTER_SOURCE"]

_LOG = logging.getLogger("aoi.coords")

# 합리적 die pitch 범위(µm) — 엉뚱한 키를 읽었을 때 채택 방지.
_MIN_PITCH, _MAX_PITCH = 100.0, 500000.0
# 합리적 웨이퍼 직경 범위(µm) — 2인치(50 mm) ~ 450 mm.
_MIN_DIAMETER, _MAX_DIAMETER = 50000.0, 450000.0
# die 인덱스 기준의 상식 범위 — 웨이퍼가 stage 원점에서 이보다 멀리 놓일 수 없다.
_MAX_DIE_INDEX = 200

# Diameter 를 담은 파일 후보 — pitch 후보와 같은 폴더 탐색 순서로 찾는다.
_DIAMETER_SOURCES = ("Params_WaferInfo.ini", "ProductInfo.ini")

# 웨이퍼 중심의 **2순위 소스** — `[Geometric] Center_X/Y` 가 0(미기록)일 때 쓴다.
# `Wafer2Table_X/Y = a11 a12 t1` 두 줄이 어파인 변환 `wafer = M·table + t` 를 준다.
_W2T_FILE = "Wafer2Table.ini"
_W2T_PAT = re.compile(
    r"(?im)^\s*Wafer2Table_([XY])\s*=\s*"
    r"([-\d.eE]+)\s+([-\d.eE]+)\s+([-\d.eE]+)\s*$")

# Camtek die pitch 후보 (상대경로, X키, Y키) 우선순위.
# ⚠ **간격(step) 계열만** 넣는다.  die '크기' 는 pitch 가 아니다 — 스크라이브 street 이
# 있는 자재는 둘이 다르다(실측 PGEE48: XDieSize 4147.352 vs XDieIndex 4160.900, 13.5 µm 차).
# 크기를 pitch 로 쓰면 col 70 에서 die 폭의 23% 가 어긋난다.  그래서 `DieSize_*`
# `DieSelectedSize_*` `XDieSize/YDieSize` 는 후보에서 제외한다.
_CAMTEK_SOURCES = (
    ("Params_WaferInfo.ini", "DieStep_X", "DieStep_Y"),
    ("ProductInfo.ini", "XDieIndex", "YDieIndex"),
    ("ProductInfo.ini", "CustomerDiePitch_X", "CustomerDiePitch_Y"),
)
# 사진 폴더가 웨이퍼 폴더의 하위일 수 있어 부모를 몇 단계까지 올라가 찾는다.
_PARENT_LEVELS = 2
# 파일에서 못 읽었을 때의 마지막 후보(`models.py` 상수)의 출처 표기 — 검산이 '의미
# 있음' 까지 확인해야만 채택된다(`camtek_geometry`).  안내용 `peek_die_pitch` 는 이
# 후보를 내지 않는다(파일에 없는 값을 '감지됨' 이라 말하지 않는다).
_CONST_SOURCE = "models.py 상수"

# 장비가 쓴 die 맵 — 그 웨이퍼의 die 전체 목록(좌표).  col/row 번호의 기준을 유도하지
# 않고 여기서 **읽는다**(:func:`_die_map_origins`).  레코드 배치는 장비 소프트웨어마다
# 달라서(실측 72 / 128) 옆의 ``.md`` 사이드카가 알려 준다.
_DIE_MAP_FILE = "s_DieLocation.dat"
# 이보다 적으면 die 맵으로 인정하지 않는다 — 웨이퍼 한 장에 die 가 수백~수천 개다.
# 몇 개짜리 파일을 맵으로 받아들이면 col/row 기준이 통째로 틀어진다.
_MIN_DIE_MAP = 50
_VT_DOUBLE = 5                      # 장비가 쓰는 VARIANT 코드 (VT_R8)
_RECSIZE_PAT = re.compile(r'RecordSize\s+Size="(\d+)"')
_FIELD_PAT = re.compile(r'Name="([^"]+)"[^>]*?Offset="(\d+)"[^>]*?Vartype="(\d+)"')

_DIEPITCH_PAT = re.compile(r'DiePitch\s+([\d.eE+\-]+)\s+([\d.eE+\-]+)', re.IGNORECASE)
# SampleTestPlan <개수> 뒤에 (XINDEX YINDEX) 쌍이 ';' 까지 이어진다.
_TESTPLAN_PAT = re.compile(r'SampleTestPlan\s+\d+(.*?);', re.IGNORECASE | re.DOTALL)
_INDEX_PAIR_PAT = re.compile(r'(-?\d+)\s+(-?\d+)')
# 웨이퍼 중심의 die 격자 좌표(µm) — Camtek `[Geometric] Center_X/Y` 에 대응한다.
_SAMPLE_CENTER_PAT = re.compile(
    r'SampleCenterLocation\s+([\d.eE+\-]+)\s+([\d.eE+\-]+)', re.IGNORECASE)
# `SampleSize 1 300;` → 웨이퍼 직경 300 **mm**.
_SAMPLE_SIZE_PAT = re.compile(r'SampleSize\s+\d+\s+([\d.eE+\-]+)', re.IGNORECASE)


@dataclass(frozen=True)
class CamtekGeometry:
    """Camtek INI 좌표 변환에 필요한 die 격자 기하.

    ``col = x_index − col_origin``,  ``row = row_total − y_index``,
    ``x = floor(X − x_index × pitch_x)``,  ``y = floor(Y − y_index × pitch_y)``

    ``col_origin``·``row_total`` 은 상수가 아니라 **웨이퍼가 stage 위 어디에 놓였는지**
    (``Center_X``/``Center_Y``)에서 유도한다 — 각각 '온전히 들어오는 첫 열' 과
    '온전히 들어오는 마지막 행' 이다(:func:`_col_origin`·:func:`_row_total`).
    """
    pitch_x: float
    pitch_y: float
    col_origin: int
    row_total: int
    source: str      # 진단용 — 어느 파일에서 왔는지("fallback" 이면 TB500 상수)


@dataclass(frozen=True)
class KlaGeometry:
    """KLA .001 좌표 변환에 필요한 die 격자 기하.

    ``col = XINDEX + zero_x``,  ``row = YINDEX + zero_y``
    """
    pitch_x: float
    pitch_y: float
    zero_x: int
    zero_y: int
    source: str


def _row_total(center_y: Optional[float], diameter: float, pitch_y: float) -> int:
    """row 번호 기준 = **웨이퍼 안에 온전히 들어오는 마지막 die 행**.

    ``row = row_total − y_index`` 가 0 부터 시작하게 하는 값이다(Camtek 은 Y 가 아래로
    커져서 *마지막* 행이 화면 맨 아래 = row 0 이다 — :func:`_col_origin` 이 *첫* 열을
    쓰는 것과 축 방향만 다르고 같은 규칙이다)::

        row_total = floor((Center_Y + Diameter/2) / DieStep_Y) − 1

    실측 근거(``docs/디바이스_하드코딩_조사.md`` §6-J): RDL4 로트에서 **같은 장비가 같은
    사진을 두 형태로** 남겼는데(점표기 파일 + col/row 가 박힌 파일명), 그 파일명이 이
    유도값과 두 축 모두 오차 0 으로 맞는다.  옛 식 ``ceil(Diameter/pitch_y)`` 는 같은
    자재에서 7 을 내 row 가 전 구간 1 컸다.

    ``center_y`` 가 없거나 기록되지 않았으면(``0``) 옛 식으로 폴백한다 — 장비 화면 정답
    4사례(``TestGoldenEquipmentExamples``)가 그 값이고 ``Center_Y`` 를 갖고 있지 않다.
    ⚠ **두 식은 보통 1 다르다.** 폴백은 '아는 게 없을 때의 기존 동작 보존' 이지 같은 값이
    아니다 — 그래서 KLA 쪽 ``zero_y`` 도 같은 조건에서 함께 폴백해야 정렬이 유지된다.
    """
    if not center_y:                       # None 또는 0.0 → 미기록
        return math.ceil(diameter / pitch_y)
    total = math.floor((center_y + diameter / 2.0) / pitch_y) - 1
    if not (0 <= total <= _MAX_DIE_INDEX):
        _LOG.warning("Center_Y %.1f 로 계산한 row 기준 %d 이 비상식적이라 "
                     "ceil(Diameter/pitch_y) 로 폴백합니다.", center_y, total)
        return math.ceil(diameter / pitch_y)
    return total


# 장비가 die 번호를 매기는 격자 = **웨이퍼 가장자리에서 이만큼 안쪽 원에 온전히 드는 die**.
# 유도(2026-10-25): 실측 10사례(대형 die 6종 + AVAGO NELA26·PGEE48 · T254 · RDL4 17호기)가
# 장비 정답과 전부 맞는 값의 범위가 2,925~3,975 µm 이다.  범위를 가르는 건 die 가 작은
# AVAGO 제품 하나뿐이라(대형 die 는 0~4 mm 어디서나 같은 답) 3 mm 는 **가정**이다 —
# 업계 표준 edge exclusion 값이고 그 범위 안에 든다.  다른 제품의 실제 설정은 미확인.
_EDGE_EXCLUSION = 3000.0


def _grid_origins(center_x: Optional[float], center_y: Optional[float], diameter: float,
                  pitch_x: float, pitch_y: float) -> Optional[tuple[int, int]]:
    """``(col_origin, row_total)`` = 웨이퍼 가장자리 :data:`_EDGE_EXCLUSION` 안쪽 원에
    **네 모서리가 모두 드는** die 의 첫 열 · 마지막 행.  중심을 모르면 None.

    :func:`_col_origin`·:func:`_row_total` 은 축 위 한 점(원의 좌우·위아래 끝)만 보는
    1차원 식이라, die 가 작아 원 둘레를 따라 계단이 촘촘한 제품에서 틀린다 — AVAGO
    NELA26·PGEE48 은 row 기준을 56 으로 냈는데 장비는 55 다(관측).  대형 die 6종은
    두 식이 같은 값을 낸다(관측, ``TestDerivedPathGolden``).

    지금은 **die 맵이 가장자리를 빠뜨렸는지 가르는 데만** 쓴다(:func:`_with_origins`) —
    1차원 식과 같은 값일 때만 맵을 넓힌다.  1차원 식을 대신하지 않는다: 대형 die 에서
    두 식이 갈리는 배치(무작위 배치의 약 16%, 유도)는 실측이 없고, '중심만 들면 센다'
    (반지름 ≈144 mm) 같은 경쟁 가설도 지금 표본으로는 구분되지 않는다."""
    if not center_x or not center_y:
        return None
    r = diameter / 2.0 - _EDGE_EXCLUSION
    if r <= 0:
        return None
    i_lo, i_hi = math.floor((center_x - r) / pitch_x), math.ceil((center_x + r) / pitch_x)
    j_lo, j_hi = math.floor((center_y - r) / pitch_y), math.ceil((center_y + r) / pitch_y)
    inside = [(i, j) for i in range(i_lo, i_hi + 1) for j in range(j_lo, j_hi + 1)
              if all(math.hypot(x - center_x, y - center_y) <= r
                     for x in (i * pitch_x, (i + 1) * pitch_x)
                     for y in (j * pitch_y, (j + 1) * pitch_y))]
    if not inside:
        return None
    origin, total = min(i for i, _ in inside), max(j for _, j in inside)
    if not (0 <= origin <= _MAX_DIE_INDEX and 0 <= total <= _MAX_DIE_INDEX):
        return None
    return origin, total


def _col_origin(center_x: Optional[float], diameter: float, pitch_x: float) -> int:
    """col 번호 기준 = **웨이퍼 안에 온전히 들어오는 첫 die 열**.

    ``col = x_index − col_origin`` 이 0 부터 시작하게 하는 값이다::

        col_origin = ceil((Center_X − Diameter/2) / DieStep_X)

    ``Center_X`` 는 웨이퍼가 stage 위 어디에 놓였는지다.  같은 자재라도 위치가 한 die
    달라지면 ``x_index`` 가 통째로 1 밀리므로, **상수로 둘 수 없다**(실측: RDL4 는 1,
    15호기는 2).  상수 2 를 쓰면 RDL4 에서 ``col = −1`` 이 나온다 — 0-based 웨이퍼 맵에
    없는 값이다.  근거는 사진으로 확인한 LIVE↔Camtek 8쌍
    (``docs/디바이스_하드코딩_조사.md`` §6-H).

    ``center_x`` 가 없거나 기록되지 않았으면(``0``) :data:`CAMTEK_COL_OFFSET` 로 폴백한다 —
    ``Center_X=0.000000`` 인 실물이 있고(같은 파일에 ``MeasuredDiameter=0`` 이 함께 온다)
    그건 값이 0 이라는 뜻이 아니라 **정렬 정보 미기록**이다.
    """
    if not center_x:                       # None 또는 0.0 → 미기록
        return CAMTEK_COL_OFFSET
    origin = math.ceil((center_x - diameter / 2.0) / pitch_x)
    if not (0 <= origin <= _MAX_DIE_INDEX):
        _LOG.warning("Center_X %.1f 로 계산한 col 기준 %d 이 비상식적이라 상수 %d 을 씁니다.",
                     center_x, origin, CAMTEK_COL_OFFSET)
        return CAMTEK_COL_OFFSET
    return origin


# 데이터에서 못 읽을 때 쓰는 TB500 폴백 — 값은 models.py 가 보유한다.
FALLBACK_CAMTEK = CamtekGeometry(
    pitch_x=CAMTEK_PITCH_X, pitch_y=CAMTEK_PITCH_Y,
    col_origin=CAMTEK_COL_OFFSET,
    row_total=_row_total(None, DEFAULT_WAFER_DIAMETER, CAMTEK_PITCH_Y),   # = 7
    source="fallback",
)
FALLBACK_KLA = KlaGeometry(
    pitch_x=CAMTEK_PITCH_X, pitch_y=CAMTEK_PITCH_Y,
    zero_x=KLA_ZERO_X, zero_y=KLA_ZERO_Y, source="fallback",
)


def _read_key(path: Path, key: str, lo: float = _MIN_PITCH,
              hi: float = _MAX_PITCH) -> Optional[float]:
    """INI 에서 ``key=값`` 을 읽어 float 로. 없거나 [lo, hi] 밖이면 None."""
    txt = read_ini_text(path)
    if txt is None:
        return None
    # 값 뒤에 다른 문자가 붙으면(예: 소수점이 ',' 인 로캘) **잘라 읽지 않고 거부**한다.
    # `37247,700000` 을 37247.0 으로 조용히 받아들이면 검산을 통과해 버릴 수 있다.
    m = re.search(r"(?im)^\s*" + re.escape(key) + r"\s*=\s*([-\d.eE]+)\s*$", txt)
    if not m:
        return None
    try:
        v = float(m.group(1))
    except ValueError:
        return None
    return v if lo <= v <= hi else None


def _search_dirs(folder: Path) -> list[Path]:
    """폴더 자신 + 부모 ``_PARENT_LEVELS`` 단계."""
    dirs = [folder]
    cur = folder
    for _ in range(_PARENT_LEVELS):
        parent = cur.parent
        if parent == cur:
            break
        dirs.append(parent)
        cur = parent
    return dirs


def _read_diameter(folder: Path) -> float:
    """웨이퍼 직경(µm) — ``[Geometric] Diameter``.  못 찾으면 기본 300 mm.

    row 번호 기준 ``ceil(Diameter / pitch_y)`` 계산에 쓴다.  실측 확인상 현재 모든
    device 가 300 mm 라 기본값이 안전하지만, 파일 값이 있으면 그쪽을 쓴다."""
    for base in _search_dirs(folder):
        for rel in _DIAMETER_SOURCES:
            v = _read_key(base / rel, "Diameter", _MIN_DIAMETER, _MAX_DIAMETER)
            if v is not None:
                return v
    return DEFAULT_WAFER_DIAMETER


def _read_center(folder: Path, key: str) -> Optional[float]:
    """웨이퍼 중심의 stage 좌표(µm) — ``[Geometric] Center_X``/``Center_Y``.  미기록이면 None.

    ``0.000000`` 은 **값이 아니라 '기록 안 됨'** 이다(같은 파일에 ``MeasuredDiameter=0``,
    ``FlatNotchVal=-1`` 이 함께 온다).  :func:`_read_key` 의 하한이 그걸 걸러 준다."""
    for base in _search_dirs(folder):
        for rel in _DIAMETER_SOURCES:
            v = _read_key(base / rel, key, _MIN_PITCH, _MAX_DIAMETER)
            if v is not None:
                return v
    return None


def _read_wafer2table(folder: Path) -> Optional[tuple[float, float]]:
    """``Wafer2Table.ini`` 의 정렬 변환에서 **웨이퍼 중심의 stage 좌표**를 푼다.

    파일이 담은 것은 어파인 변환 ``wafer = M·table + t`` 다(실측 앵커 3점을 2.7 µm 안에
    재현).  웨이퍼 중심은 ``wafer = (0,0)`` 인 지점이므로::

        중심(stage) = M⁻¹ · (−t)

    ``Params_WaferInfo.ini [Geometric] Center_X/Y`` 가 ``0.000000``(정렬 정보 미기록)인
    스캔에도 **이 파일에는 값이 있다** — 그게 이 소스의 존재 이유다.  T254 실측에서
    여기서 푼 중심 ``(165994, 202629)`` 이 장비 화면 정답(``col_origin=2``,
    ``row_total=10``)을 그대로 낸다(``docs/디바이스_하드코딩_조사.md`` §6-L).
    """
    for base in _search_dirs(folder):
        txt = read_ini_text(base / _W2T_FILE)
        if txt is None:
            continue
        rows: dict[str, tuple[float, float, float]] = {}
        for m in _W2T_PAT.finditer(txt):
            try:
                rows[m.group(1).upper()] = (float(m.group(2)), float(m.group(3)),
                                            float(m.group(4)))
            except ValueError:
                return None
        if {"X", "Y"} - rows.keys():
            continue
        (a11, a12, t1), (a21, a22, t2) = rows["X"], rows["Y"]
        det = a11 * a22 - a12 * a21
        if abs(det) < 1e-9:            # 특이행렬 — 못 푼다
            return None
        cx = (a22 * -t1 - a12 * -t2) / det
        cy = (-a21 * -t1 + a11 * -t2) / det
        if not all(_MIN_PITCH <= v <= _MAX_DIAMETER for v in (cx, cy)):
            _LOG.warning("%s 로 푼 웨이퍼 중심 (%.1f, %.1f) 이 비상식적이라 무시합니다: %s",
                         _W2T_FILE, cx, cy, base)
            return None
        return (cx, cy)
    return None


def _wafer_center(folder: Path) -> tuple[Optional[float], Optional[float]]:
    """웨이퍼 중심의 stage 좌표 ``(X, Y)`` — 축마다 없으면 ``None``.

    1순위 ``Params_WaferInfo.ini [Geometric] Center_X/Y``, 2순위 ``Wafer2Table.ini``.
    ``Center_*=0.000000`` 은 값이 아니라 '기록 안 됨' 이라 2순위로 넘어간다."""
    cx = _read_center(folder, "Center_X")
    cy = _read_center(folder, "Center_Y")
    if cx is not None and cy is not None:
        return (cx, cy)
    w2t = _read_wafer2table(folder)
    if w2t is None:
        return (cx, cy)
    return (cx if cx is not None else w2t[0], cy if cy is not None else w2t[1])


def _pitch_candidates(folder: Path):
    """(pitch_x, pitch_y, 출처) 후보를 우선순위대로 내놓는다.

    마지막 후보는 :mod:`.models` 의 상수다 — **다른 후보와 똑같이 검산을 받는다**.
    폴더 자신의 Col/Row 가 확인해 주면 그건 추정이 아니라 검증된 값이고, 다른 자재에서는
    검산이 거부하므로 옛 상수가 조용히 쓰이는 경로가 없다."""
    for base in _search_dirs(folder):
        for rel, kx, ky in _CAMTEK_SOURCES:
            px = _read_key(base / rel, kx)
            py = _read_key(base / rel, ky)
            if px is not None and py is not None:
                yield (px, py, f"{rel}:{kx}/{ky}")
    yield (CAMTEK_PITCH_X, CAMTEK_PITCH_Y, _CONST_SOURCE)


def peek_die_pitch(folder: Path) -> Optional[tuple[float, float, str]]:
    """설정 화면 안내용 — **파일에 적힌** die pitch 를 검산 없이 읽는다.

    ``(pitch_x, pitch_y, 출처)``.  :func:`camtek_geometry` 와 같은 후보 파일
    (`Params_WaferInfo.ini`·`ProductInfo.ini`, 몇 줄짜리)을 같은 순서로 보되,
    **`ColorImageGrabingInfo.ini`(결함 수천 건)·`s_DieLocation.dat`(die 수천 개)는
    열지 않는다.**

    ★ 왜 따로 있는가.  그 파싱은 순수 파이썬이라 워커 스레드에서 돌려도 **GIL 을 쥔
    채** UI 스레드를 굶긴다 — 설정 화면이 "폴더를 고르면 die 안내가 뜰 때까지 멈춘다"
    고 신고된 원인이다(스레드로 옮겨도 남던 정지).  안내 한 줄에 검산은 필요 없다:
    검산은 **매칭이** pitch 를 채택할 때의 정확도 가드이고(`camtek_geometry`), 그쪽은
    그대로다.  상수 후보는 내지 않는다 — 파일에 없는 값을 '감지됨' 이라 말하지 않는다.
    전 구간 fail-safe."""
    try:
        for px, py, src in _pitch_candidates(folder):
            if src == _CONST_SOURCE:
                break
            return (px, py, src)
    except Exception:
        pass
    return None


def has_camtek_entries(folder: Path) -> bool:
    """이 폴더가 **Camtek INI 좌표를 가진 폴더**인가(변환 대상이 있는가).

    KLA 슬롯이나 LIVE 파일명 슬롯은 여기서 False — die pitch 를 못 찾아도 문제가 아니다
    (그쪽은 각자 자기 경로로 좌표를 만든다)."""
    from . import camtek_ini

    try:
        return bool(camtek_ini.load_raw_folder(folder))
    except Exception:
        return False


def _grid_check(folder: Path, pitch_x: float, pitch_y: float) -> tuple[bool, bool]:
    """INI 의 ``Col``/``Row`` 필드를 참조값 삼아 pitch 를 검산한다.

    **두 축을 다르게 본다** — 실측 근거는 :mod:`docs.디바이스_하드코딩_조사` §6-F::

        X : Col == floor(X/pitch_x)                       전 항목 **등호**
        Y : {floor(Y/pitch_y) − Row} 가 **레시피별로 상수**  (0 일 필요 없음)

    Y 를 완화하는 이유는 레시피마다 ``Row`` 필드의 원점이 1 다를 수 있어서다(같은 결함을
    두 레시피가 찍으면 ``Col`` 은 같은데 ``Row`` 만 1 어긋난다).  **X 는 절대 완화하지
    않는다** — 항목이 1건뿐인 폴더에서 '상수' 조건은 공허하게 참이 돼, 격자가 다른 자재에
    TB500 상수가 채택되는 길이 열린다(``x = −1,652,266 µm`` 참사의 재현).  실제로 기존
    거부 경로는 전부 X 축에서 걸린다.

    반환 ``(통과, 의미있음)``.  '의미있음' 은 검산이 실제로 pitch 를 제약했는지다 —
    모든 항목이 ``Col=0`` 이면 어떤 pitch 든 통과하므로 검산이 아무 말도 못 한 것이다.
    파일에서 읽은 값은 '통과' 만으로 채택하지만, 상수 후보는 '의미있음' 까지 요구한다.
    """
    from . import camtek_ini      # 순환 import 회피 — 검산 시점에만 필요

    try:
        raw = camtek_ini.load_raw_folder(folder)
        recipes = camtek_ini.load_recipe_folder(folder)
    except Exception:
        return (False, False)
    if not raw:
        return (False, False)

    # X: 등호 그대로.
    if not all(math.floor(X / pitch_x) == col_i for X, _, col_i, _ in raw.values()):
        return (False, False)

    # Y: 레시피별로 차이가 일정하기만 하면 된다.
    by_recipe: dict[int, set[int]] = {}
    for stem, (_X, Y, _col_i, row_i) in raw.items():
        by_recipe.setdefault(recipes.get(stem, 0), set()).add(
            math.floor(Y / pitch_y) - row_i)
    if any(len(diffs) != 1 for diffs in by_recipe.values()):
        return (False, False)

    # 조용한 폴백 금지 — INI 필드가 die 인덱스와 어긋난 채 통과했으면 남긴다.
    off = {r: next(iter(d)) for r, d in by_recipe.items() if next(iter(d)) != 0}
    if off:
        _LOG.info("INI Row 가 die 인덱스와 어긋난다(레시피별 상수라 채택). "
                  "좌표 산출은 좌표에서 유도하므로 영향 없음 — recipe별 차이 %s: %s",
                  off, folder)

    meaningful = (any(col_i >= 1 for _, _, col_i, _ in raw.values())
                  and any(row_i >= 1 for *_, row_i in raw.values()))
    return (True, meaningful)


@lru_cache(maxsize=256)
def camtek_geometry(folder: Path) -> Optional[CamtekGeometry]:
    """폴더의 Camtek die 격자 기하.

    후보를 우선순위대로 돌며 **검산을 통과한 첫 값**을 채택한다.  통과한 후보가 하나도
    없으면 ``None`` — 호출부는 좌표를 만들지 않는다.  **틀린 좌표를 내느니 안 내는 편이
    낫다**(die 가 4 mm 인 자재에 37 mm pitch 를 쓰면 x 가 −1,652,266 µm 같은 값이 된다).
    전 구간 fail-safe.
    """
    try:
        for px, py, src in _pitch_candidates(folder):
            ok, meaningful = _grid_check(folder, px, py)
            if not ok:
                continue
            if src == _CONST_SOURCE and not meaningful:
                continue      # 검산이 pitch 를 제약하지 못했다 — 상수를 추정으로 쓰지 않는다
            return _with_origins(folder, px, py, src)
        # ★ Camtek INI 자체가 없는 폴더(KLA 슬롯·LIVE 파일명 슬롯)는 **조용히** None.
        #   경고는 '변환할 항목이 있는데 pitch 를 못 정한' 진짜 문제일 때만 낸다 —
        #   안 그러면 KLA 폴더마다 무의미한 경고가 쌓인다.
        if has_camtek_entries(folder):
            _LOG.warning(
                "die pitch 를 확정하지 못해 **절대 wafer 좌표**로 매칭합니다(매칭은 정상). "
                "die 내부 좌표·row 표기를 보려면 Params_WaferInfo.ini `DieStep_X/Y` 또는 "
                "ProductInfo.ini `XDieIndex/YDieIndex` 가 필요합니다: %s", folder)
        return None
    except Exception:
        # 조용한 폴백 금지 — 여기서 None 이면 그 실행의 Camtek 좌표가 전부 절대좌표로 내려간다.
        _LOG.exception("die 격자 기하를 읽다 실패해 절대 wafer 좌표로 매칭합니다: %s", folder)
        return None


_EXPORT_FILE = "ProductInfo.ini"
_EXPORT_SECTION = re.compile(r"(?ims)^\s*\[ExportData\]\s*$(.*?)(?=^\s*\[|\Z)")
_EXPORT_KEYS = ("cMin", "cMax", "rMin", "rMax")
# :attr:`CamtekGeometry.source` 에 이 꼬리표가 있으면 번호 기준을 장비 번호표에서 읽은 것이다.
EXPORT_SOURCE_TAG = f"{_EXPORT_FILE}[ExportData]"

_DIELUT_FILE = "DieLut.dat"
# 장비가 **스캔 때** 써 두는 die 목록(UTF-8 XML ``<DieLutData Col Row RecipeNum …/>``, Col/Row 는
# stage 인덱스).  전체 레코드의 (min Col, max Col, min Row, max Row) 가 ``[ExportData]`` 의
# (cMin, cMax, rMin, rMax) 와 같았다 — 둘 다 있는 26 LOT·51 폴더 전부(관측 2026-10-26), 계산이
# 틀리던 AVAGO 01C1(die 맵 col 3 → 2) · T254 GX57007306(부분 맵 row 9 → 10) 도 포함.  검토
# (Export Map) 전 폴더에도 있어, 번호표가 없는 RDL2 43장이 이것으로 장비 번호를 얻는다.
# **다중 레시피 스캔(MultiRecipe.ini 의 recipe_N 이 켜진 스캔)에만 있다** — TI CCB·CCG, KUH,
# QORVO, T254 TSC-FS, 단일 레시피로 찍은 RDL4 에는 없다.  → docs/규칙_배경.md
DIELUT_SOURCE_TAG = _DIELUT_FILE
# 번호표도 die 목록도 없을 때: 1차원 중심식과 2차원 3 mm 격자식(die 맵을 채택했으면 맵도)이
# **같은 값**이면 그 값을 ⚠ 없이 쓴다.  번호표 있는 131 폴더에서 둘이 같은 123 폴더는 전부
# 번호표와 같았고, 틀린 8(AVAGO 2 · QORVO 6)은 전부 둘이 다르거나 격자가 없었다(관측 2026-10-26).
# 저장소 샘플 83 폴더도 같다(둘 일치 69, 틀림 0).  사용자 결정 2026-10-27: "지금까지 준 샘플에서
# 전부 정답인 규칙이면 경고 표시 없어도 됨".  둘이 다르거나 하나뿐이면 ⚠(NUMBER_WARN_NO_TABLE).
AGREE_SOURCE_TAG = "중심식=격자식"
_TRUSTED_TAGS = (EXPORT_SOURCE_TAG, DIELUT_SOURCE_TAG, AGREE_SOURCE_TAG)
_DIELUT_REC = re.compile(r"<DieLutData\b([^>]*?)/?>")
_DIELUT_ATTR = re.compile(r'\b(Col|Row)="(-?\d+)"')


def is_trusted_source(source: str) -> bool:
    """:attr:`CamtekGeometry.source` 의 번호 기준이 ⚠ 없이 믿을 것인가 — 장비 기록(번호표 ·
    die 목록)이거나, 표본 전부에서 맞았던 '중심식=격자식' 일치다.  그 밖은 유도값이라 경고."""
    return any(tag in source for tag in _TRUSTED_TAGS)


def dielut_cells(folder: Path) -> Optional[frozenset[tuple[int, int]]]:
    """``DieLut.dat`` 의 die 칸 ``(Col, Row)`` 집합(stage 인덱스).  없거나 비었으면 None.

    레시피(RecipeNum)마다 같은 칸이 반복되므로 집합으로 합친다.  Wafer map 의 칸과
    번호 기준(:func:`_dielut_origins`)이 **같은 집합**을 쓰도록 여기 하나로 읽는다.
    전 구간 fail-safe."""
    p = folder / _DIELUT_FILE
    try:
        st = p.stat()
    except OSError:
        return None
    return _dielut_cells(p, st.st_mtime_ns, st.st_size)


@lru_cache(maxsize=256)
def _dielut_cells(p: Path, _mtime_ns: int, _size: int) -> Optional[frozenset[tuple[int, int]]]:
    try:
        txt = p.read_bytes().decode("utf-8", "replace")
    except OSError:
        return None
    cells = set()
    for m in _DIELUT_REC.finditer(txt):
        kv = dict(_DIELUT_ATTR.findall(m.group(1)))
        if "Col" in kv and "Row" in kv:
            cells.add((int(kv["Col"]), int(kv["Row"])))
    return frozenset(cells) or None


def _dielut_origins(folder: Path, px: float, py: float, dia: float,
                    cx: Optional[float], cy: Optional[float]) -> Optional[tuple[int, int]]:
    """``DieLut.dat`` 의 die 목록 범위로 ``(col_origin, row_total)`` = ``(min Col, max Row)``.

    채택 조건은 :func:`_export_origins` 와 같다(어긋나면 None — 계산 경로로 간다): 같은 폴더
    ``ProductInfo.ini`` 의 ``XDieIndex/YDieIndex`` 가 채택한 pitch 와 같다(다른 격자의 목록을
    섞지 않게) · 웨이퍼 중심을 알고 범위가 웨이퍼 원의 인덱스 범위 안이다 · die 맵이 있으면
    die 가 전부 범위 안이다(관측: s_DieLocation.dat ⊂ DieLut.dat).  ``_MAX_DIE_INDEX`` 상한은
    쓰지 않는다(번호표와 같은 이유)."""
    cells = dielut_cells(folder)
    if cells is None:
        return None
    c_min, c_max = min(i for i, _ in cells), max(i for i, _ in cells)
    r_min, r_max = min(j for _, j in cells), max(j for _, j in cells)
    if c_min < 0 or r_min < 0:
        return None
    xi = _read_key(folder / _EXPORT_FILE, "XDieIndex", _MIN_PITCH, _MAX_PITCH)
    yi = _read_key(folder / _EXPORT_FILE, "YDieIndex", _MIN_PITCH, _MAX_PITCH)
    if xi is None or yi is None or abs(xi - px) > 0.01 or abs(yi - py) > 0.01:
        return None
    if not cx or not cy:
        return None
    r = dia / 2.0
    if not (math.floor((cx - r) / px) <= c_min and c_max <= math.floor((cx + r) / px)
            and math.floor((cy - r) / py) <= r_min and r_max <= math.floor((cy + r) / py)):
        _LOG.warning("%s 범위가 웨이퍼 밖이라 쓰지 않습니다: %s", _DIELUT_FILE, folder)
        return None
    dmap = die_map_cells(folder, px, py)
    if dmap is not None and not all(c_min <= i <= c_max and r_min <= j <= r_max
                                    for i, j in dmap):
        _LOG.warning("%s 범위 밖에 die 맵의 die 가 있어 쓰지 않습니다: %s", _DIELUT_FILE, folder)
        return None
    return c_min, r_max


def _export_origins(folder: Path, px: float, py: float, dia: float,
                    cx: Optional[float], cy: Optional[float]) -> Optional[tuple[int, int]]:
    """``ProductInfo.ini [ExportData] cMin/cMax/rMin/rMax`` 로 ``(col_origin, row_total)``.

    장비가 결과를 내보낼 때 쓰는 **die 번호 격자의 범위**(stage 인덱스)다 —
    ``col = x_index − cMin``, ``row = rMax − y_index`` 가 장비 화면 번호다.

    실측 근거(2026-10-25, 관측):

    * QORVO W97218SGZ4BK16 (11호기, pitch 919.8, 3장): 장비 화면·Conder LIVE 파일명 55장이
      전부 ``(x−5, 319−y)`` = ``(cMin, rMax)`` 였다.  중심 유도(2, 326→상한으로 327)·die 맵
      (6, 317)·3 mm 격자(5, 323) 어느 것도 맞지 않았다.
    * 그 밖에 이미 맞는 것으로 확인된 웨이퍼 폴더 165개(TB500 RDL4·SGG·KUH · T254 FS UBM·WVU ·
      TI CCB · AVAGO NELA26)에서 기존 결과와 **전부 같다** — 1차원 유도가 틀리던 AVAGO
      01C1(맵 3 → 장비 2)·T254 GX57007306(부분 맵) 도 이 값이 장비 번호와 같다.

    ⚠ 자기 폴더의 파일만 믿는다(부모·형제 폴더 것 쓰지 않음).  채택 조건(어긋나면 None —
    기존 경로로 간다): 네 키가 정수로 다 있고 ``min ≤ max`` · 같은 파일의
    ``XDieIndex/YDieIndex`` 가 채택한 pitch 와 같다(다른 격자의 번호를 섞지 않게) ·
    웨이퍼 중심을 알고 범위가 웨이퍼 원의 인덱스 범위 안이다 · die 맵이 있으면 die 가 전부
    범위 안이다.  관측 171 폴더가 이 조건을 모두 통과했다.  ``_MAX_DIE_INDEX`` 상한은
    여기 쓰지 않는다 — die 가 작은 제품(QORVO row 319)에서 정당한 값을 버린다."""
    txt = read_ini_text(folder / _EXPORT_FILE)
    if not txt:
        return None
    sec = _EXPORT_SECTION.search(txt)
    if sec is None:
        return None
    kv = dict(re.findall(r"(?m)^\s*(\w+)\s*=\s*(-?\d+)\s*(?:;.*)?$", sec.group(1)))
    try:
        c_min, c_max, r_min, r_max = (int(kv[k]) for k in _EXPORT_KEYS)
    except (KeyError, ValueError):
        return None
    if not (0 <= c_min <= c_max and 0 <= r_min <= r_max):
        return None
    xi = _read_key(folder / _EXPORT_FILE, "XDieIndex", _MIN_PITCH, _MAX_PITCH)
    yi = _read_key(folder / _EXPORT_FILE, "YDieIndex", _MIN_PITCH, _MAX_PITCH)
    if xi is None or yi is None or abs(xi - px) > 0.01 or abs(yi - py) > 0.01:
        return None
    if not cx or not cy:
        return None
    r = dia / 2.0
    if not (math.floor((cx - r) / px) <= c_min and c_max <= math.floor((cx + r) / px)
            and math.floor((cy - r) / py) <= r_min and r_max <= math.floor((cy + r) / py)):
        _LOG.warning("%s [ExportData] 범위가 웨이퍼 밖이라 쓰지 않습니다: %s", _EXPORT_FILE, folder)
        return None
    cells = die_map_cells(folder, px, py)
    if cells is not None and not all(c_min <= i <= c_max and r_min <= j <= r_max
                                     for i, j in cells):
        _LOG.warning("%s [ExportData] 범위 밖에 die 맵의 die 가 있어 쓰지 않습니다: %s",
                     _EXPORT_FILE, folder)
        return None
    return c_min, r_max


def _with_origins(folder: Path, px: float, py: float, src: str) -> CamtekGeometry:
    """채택한 pitch 에 col·row 기준을 붙인다 — :func:`camtek_geometry` 와
    :func:`live_geometry` 가 **같은 규칙**을 쓰게 한 곳에 둔다."""
    # col·row 기준: 번호표([ExportData]) → die 목록(DieLut.dat) → 장비가 쓴 die 맵(§6-N)
    # → 중심 유도.  유도하던 값을 되도록 장비가 적어 둔 대로 읽는다.  맵이 없으면
    # 기존 유도로 폴백한다: 중심은 Params 의 Center_X/Y → Wafer2Table.ini 순으로
    # 찾고(§6-L), 그래도 없으면 각각 상수/옛 식으로 폴백한다(§6-H·§6-J).
    dia = _read_diameter(folder)
    cx, cy = _wafer_center(folder)
    # ★ 0순위: 장비가 내보낸 격자 범위(ProductInfo.ini [ExportData]) — 장비 화면 번호 그 자체다.
    exp = _export_origins(folder, px, py, dia, cx, cy)
    # ★ 1순위: 장비가 스캔 때 쓴 die 목록(DieLut.dat)의 범위 — 번호표와 같았다(51/51).
    lut = _dielut_origins(folder, px, py, dia, cx, cy)
    if exp is not None:
        if lut is not None and lut != exp:
            # 반증 조건 — 관측된 적 없다.  생기면 그 폴더를 보존해 규칙을 다시 본다.
            _LOG.warning("[ExportData] %s 와 %s 범위 %s 가 다릅니다 — 번호표를 씁니다: %s",
                         exp, _DIELUT_FILE, lut, folder)
        return CamtekGeometry(pitch_x=px, pitch_y=py, col_origin=exp[0], row_total=exp[1],
                              source=f"{src}+{EXPORT_SOURCE_TAG}")
    if lut is not None:
        return CamtekGeometry(pitch_x=px, pitch_y=py, col_origin=lut[0], row_total=lut[1],
                              source=f"{src}+{DIELUT_SOURCE_TAG}")
    d_origin = _col_origin(cx, dia, px)
    d_total = _row_total(cy, dia, py)
    grid = _grid_origins(cx, cy, dia, px, py)

    def _agree(origin: int, total: int) -> str:
        """채택값이 중심식·격자식과 모두 같을 때만 '계산 일치' 꼬리표 — 그래야 ⚠ 가 빠진다."""
        return f"+{AGREE_SOURCE_TAG}" if grid == (origin, total) == (d_origin, d_total) else ""

    cells = lot_die_map_cells(folder, px, py)
    if cells is not None and _covers_wafer(cells, cx, cy, dia, px, py, folder):
        m_origin = min(i for i, _ in cells)
        m_total = max(j for _, j in cells)
        # ★ 맵은 die **목록**이라 가장자리 열·행이 통째로 빠질 수 있다(AVAGO 25장 중 12장,
        #   장비 번호는 빠지지 않은 격자 기준).  형제가 없으면 합집합으로도 못 메운다.
        #   **두 유도(1차원 식 · 2차원 격자)가 같은 값으로 맵보다 넓다고 할 때만** 넓힌다 —
        #   둘이 갈리면 맵을 믿는다(PGEE48 row: 1차원 56 · 격자 55 · 맵 55 = 장비).
        #   격자 하나만으로 바꾸지 않는 이유: 가장자리 3 mm 는 소형 die 한 제품으로 정한
        #   가정이고, 대형 die 에서는 '중심만 들면 센다' 같은 경쟁 가설과 구분되지 않는다.
        if grid is not None:
            if grid[0] == d_origin < m_origin:
                _LOG.warning("die 맵의 첫 열(%d)이 격자보다 좁아 %d 로 넓힙니다(가장자리 열이 "
                             "목록에서 빠진 웨이퍼): %s", m_origin, d_origin, folder)
                m_origin = d_origin
            if grid[1] == d_total > m_total:
                _LOG.warning("die 맵의 마지막 행(%d)이 격자보다 좁아 %d 로 넓힙니다(가장자리 "
                             "행이 목록에서 빠진 웨이퍼): %s", m_total, d_total, folder)
                m_total = d_total
        # ⚠ 맵은 유도값과 **±1 이내일 때만** 믿는다.  이 파일이 웨이퍼 전체가
        #   아니라 '스캔한 영역'만 담은 스캔이 오면 min/max 가 통째로 좁아져
        #   기준이 조용히 틀어진다 — 실측 74장의 차이는 전부 0 또는 −1 이라
        #   ±1 밖은 관측된 적 없는 영역이고, 그때는 검증된 유도 경로를 지킨다.
        if abs(m_origin - d_origin) <= 1 and abs(m_total - d_total) <= 1:
            # 조용히 갈리지 않게 남긴다 — 유도식이 틀리는 스캔을 나중에
            # 알아보려면 이 기록이 있어야 한다(실측 74장 중 1장이 그랬다).
            if (m_origin, m_total) != (d_origin, d_total):
                _LOG.info(
                    "die 맵과 중심 유도가 다르다 — 맵을 쓴다(맵이 장비 "
                    "표시값이다). col_origin %d→%d · row_total %d→%d: %s",
                    d_origin, m_origin, d_total, m_total, folder)
            return CamtekGeometry(pitch_x=px, pitch_y=py,
                                  col_origin=m_origin, row_total=m_total,
                                  source=f"{src}+{_DIE_MAP_FILE}{_agree(m_origin, m_total)}")
        _LOG.warning(
            "%s 의 die 기준 (%d, %d) 이 유도값 (%d, %d) 과 1 넘게 달라 "
            "무시합니다(부분 맵 의심 — 웨이퍼 전체 맵이면 있을 수 없는 차이): %s",
            _DIE_MAP_FILE, m_origin, m_total, d_origin, d_total, folder)
    return CamtekGeometry(pitch_x=px, pitch_y=py,
                          col_origin=d_origin, row_total=d_total,
                          source=f"{src}{_agree(d_origin, d_total)}")


@lru_cache(maxsize=256)
def live_geometry(folder: Path) -> Optional[CamtekGeometry]:
    """**Camtek INI 항목이 없는** 폴더(LIVE 파일명 슬롯)의 die 기하 — Wafer map 배치 전용.

    LIVE 사진은 파일명에 ``col``/``row``·die 내부 ``x``/``y`` 를 다 갖고 있어 매칭에는
    기하가 필요 없다.  하지만 **맵에 찍으려면** die pitch 가 있어야 하는데,
    :func:`camtek_geometry` 는 검산할 INI 항목이 없으면 None 이라 LIVE 전용 폴더의
    사진이 전부 '좌표 없음' 이 됐다.

    검산(:func:`_grid_check`)은 INI 의 ``Col``/``Row`` 필드로 pitch 를 확인하는 장치라
    여기서는 돌릴 재료가 없다 — 파일(폴더·부모의 ``Params_WaferInfo.ini`` 등)에 적힌
    pitch 를 그대로 쓴다.  **상수(TB500)는 쓰지 않는다** — 다른 자재에서 조용히 틀린
    자리에 찍힌다.  파일이 없으면 None(호출부가 사진 좌표로 추정한다).
    col·row 기준은 :func:`camtek_geometry` 와 같은 :func:`_with_origins` 로 붙인다.
    전 구간 fail-safe."""
    try:
        got = peek_die_pitch(folder)
        return None if got is None else _with_origins(folder, *got)
    except Exception:
        return None


def _die_map_origins(folder: Path, px: float, py: float
                     ) -> Optional[tuple[int, int]]:
    """**장비가 쓴 die 맵**에서 ``(col_origin, row_total)`` 을 그대로 읽는다.

    ``s_DieLocation.dat`` 은 그 웨이퍼에 있는 die 전체 목록(좌표)이다.  거기서 나오는
    ``x_index`` 최솟값이 col 기준, ``y_index`` 최댓값이 row 기준이다 — :func:`_col_origin`
    ·:func:`_row_total` 이 웨이퍼 중심에서 **유도**하던 그 값을, 유도하지 않고 장비가
    적어 둔 대로 쓴다.

    실측 근거(웨이퍼 74장 / 장비 11대 / 제품군 5종, ``docs/디바이스_하드코딩_조사.md`` §6-N):

    * ``col_origin`` 은 **74/74 전부** 중심 유도값과 같다.
    * ``row_total`` 은 **73/74 가 같고**, 한 스캔(``EagleTP_108150`` 의 PGEE48)에서만
      1 작다.  그 웨이퍼는 사용자가 장비 화면으로 확인한 값과도 1 어긋나 있었다 —
      즉 이 파일이 맞고 유도식이 틀렸다(서로 독립인 두 소스가 같은 답을 냈다).
    * 그 스캔은 이 파일의 **레코드 배치부터 다르다**(``RecordSize`` 72 vs 나머지 128).
      장비마다 소프트웨어가 다르다는 뜻이라, 배치를 하드코딩하지 않고 옆에 있는
      ``s_DieLocation.dat.md`` 를 읽어 따라간다.

    ⚠ **장비별·자재별 상수를 만들지 마라.**  그 표본에서 장비와 자재는 완전히 얽혀 있어
    (그 장비의 웨이퍼가 1장뿐) 무엇이 원인인지 구분되지 않는다.  게다가 같은 장비라도
    값이 고정이라는 보장이 없다(사용자 확인 — 소프트웨어가 갱신될 수 있다).  그래서
    이 함수는 **스캔 폴더마다 그 폴더의 파일을 읽는다** — 원인을 몰라도 맞는다.

    ⚠ 이 함수는 **자기가 확인할 수 있는 것만** 믿는다 — ``.md`` 가 없거나, 레코드 수가
    안 맞거나, die 가 :data:`_MIN_DIE_MAP` 개 미만이거나, 인덱스가 상식 범위를 벗어나면
    ``None`` 을 돌려 기존 유도 경로로 넘긴다.  전 구간 fail-safe.
    """
    cells = die_map_cells(folder, px, py)
    if cells is None:
        return None
    return min(i for i, _ in cells), max(j for _, j in cells)


def lot_die_map_cells(folder: Path, px: float, py: float
                      ) -> Optional[frozenset[tuple[int, int]]]:
    """자기 die 맵에 **같은 LOT(형제 슬롯 폴더)의 die 맵을 합친** 칸 집합.  자기 맵이 없으면 None.

    die 맵은 **그 웨이퍼의 die 목록**이라, 웨이퍼마다 가장자리 die 가 빠질 수 있다.
    실측(AVAGO 15966TA0 NELA26, 25장 · 중심 25장 동일): 12장은 맨 왼쪽 열이 목록에
    없어 ``min(x_index)`` 가 3, 나머지는 2 였다.  장비는 25장 모두 2 기준으로 표시했다 —
    01C1(맵 3)의 LIVE 파일명 20장이 전부 ``x_index − 2`` 였고(앱은 1 작게 냈다),
    07F6(맵 2)도 Conder 와 일치했다.  즉 기준은 웨이퍼 목록이 아니라 **격자**의 것이다.

    col·row 기준(:func:`_with_origins`)과 Wafer map 의 칸(``wafer_map``)이 **같은 집합**을
    쓰도록 이 함수 하나로 계산한다.  합치는 조건(어긋나면 자기 맵 그대로):

    * 자기 폴더의 웨이퍼 중심을 안다 — 모르면 유도값이 상수라 '같은 격자' 를 가를 수 없다.
    * 형제의 pitch · 지름 · 중심 유도값이 같다(= stage 위 같은 격자).
    * 형제 칸은 **이 웨이퍼 원 안에 온전히 드는 것만** 받는다 — 실측 맵 5장(T254·NELA26
      ·PGEE48·XYA2, 관측)의 칸은 전부 원 안에 온전히 들었다.  원 밖 칸 하나가 LOT 전체의
      기준을 끌어내리지 못하게 한다(±1 클램프는 유도값과 비교하므로 그걸 못 막는다).

    전 구간 fail-safe."""
    own = die_map_cells(folder, px, py)
    if own is None:
        return None
    key = _grid_key(folder, px, py)
    if key is None:
        return own
    dia, (cx, cy), _ = key
    r = dia / 2.0
    cells = set(own)
    try:
        siblings = sorted(p for p in folder.parent.iterdir()
                          if p != folder and (p / _DIE_MAP_FILE).is_file())
    except OSError:
        return own
    for sib in siblings:
        if _grid_key(sib, px, py) is None or _grid_key(sib, px, py)[::2] != key[::2]:
            continue                      # 다른 자재·다른 격자(웨이퍼 위치)는 섞지 않는다
        cells |= {(i, j) for i, j in die_map_cells(sib, px, py) or ()
                  if all(math.hypot(x - cx, y - cy) <= r
                         for x in (i * px, (i + 1) * px) for y in (j * py, (j + 1) * py))}
    return frozenset(cells)


@lru_cache(maxsize=1024)
def _grid_key(folder: Path, px: float, py: float):
    """``(지름, 중심, 중심 유도 (col_origin, row_total))`` — 형제 비교용.  pitch 가 다르거나
    중심을 모르면 None.  슬롯마다 형제를 전부 훑으므로(N²) 폴더 단위로 캐시한다 —
    :func:`camtek_geometry` 도 폴더 단위 캐시라 같은 수명이다."""
    if (peek_die_pitch(folder) or (None, None))[:2] != (px, py):
        return None
    cx, cy = _wafer_center(folder)
    if cx is None or cy is None:
        return None
    dia = _read_diameter(folder)
    return dia, (cx, cy), (_col_origin(cx, dia, px), _row_total(cy, dia, py))


# die 맵이 '웨이퍼 전체' 로 인정받으려면 웨이퍼 원 안에 온전히 드는 칸의 이만큼은 담아야
# 한다.  관측: 전체 맵 0.88(T254 GX57001305)·0.95(NELA26 25장)·0.96(PGEE48),
# 부분 맵 0.38(T254 GX57007306 — 50칸, row 기준이 1 작아 LIVE 248장 전부 row 1 어긋남).
# 0.7 은 그 사이에 둔 **가정**이다(표본 제품 4종).  가장자리 제외 폭이 큰 제품은 전체 맵도
# 0.7 아래로 떨어질 수 있는데, 그때는 맵을 버리고 검증된 중심 유도로 간다(경고가 남는다).
# 판정은 기준을 정하는 집합(LOT 합집합)에 한다 — 자기 맵이 비어도 형제가 격자를 채우면
# 기준은 격자의 것이라 맞다(AVAGO 와 같은 이유).
_MIN_MAP_COVERAGE = 0.7


def _covers_wafer(cells, cx: Optional[float], cy: Optional[float], dia: float,
                  px: float, py: float, folder: Path) -> bool:
    """die 맵이 웨이퍼 전체 목록인가 — 일부 die 만 담긴 맵이면 min/max 가 좁아져 기준이
    ±1 안에서 **조용히** 틀어진다(±1 클램프로는 못 거른다).

    중심을 모르면 맵이 차지한 범위의 가운데를 중심으로 놓고 센다 — 원 안에 온전히 드는
    칸 수는 웨이퍼가 어디 놓였든 거의 같아서(T254: 131 안팎) 부분 맵(50칸)을 가른다.
    중심이 없다고 판정을 건너뛰면 ±1 클램프가 상수 폴백과 비교하게 돼 부분 맵이 그대로
    통과한다."""
    if cx is None:
        cx = (min(i for i, _ in cells) + max(i for i, _ in cells) + 1) * px / 2.0
    if cy is None:
        cy = (min(j for _, j in cells) + max(j for _, j in cells) + 1) * py / 2.0
    r = dia / 2.0
    inside = sum(
        1 for i in range(math.floor((cx - r) / px), math.ceil((cx + r) / px))
        for j in range(math.floor((cy - r) / py), math.ceil((cy + r) / py))
        if all(math.hypot(x - cx, y - cy) <= r
               for x in (i * px, (i + 1) * px) for y in (j * py, (j + 1) * py)))
    if inside and len(cells) < _MIN_MAP_COVERAGE * inside:
        _LOG.warning("%s 가 웨이퍼 die 의 일부(%d/%d칸)만 담고 있어 쓰지 않습니다"
                     "(부분 맵 — 기준이 좁아진다): %s", _DIE_MAP_FILE, len(cells),
                     inside, folder)
        return False
    return True


def die_map_cells(folder: Path, px: float, py: float
                  ) -> Optional[frozenset[tuple[int, int]]]:
    """die 맵의 die 전체 — ``(x_index, y_index)`` 집합(stage 인덱스, 보정 전).

    :func:`_die_map_origins` 와 **같은 읽기**다(그 함수의 fail-safe 조건이 전부 여기 있다).
    Wafer map 이 'die 가 실제로 있는 칸' 만 격자로 그리는 데 쓴다.  같은 LOT 의 형제
    슬롯이 서로의 맵을 읽으므로(:func:`lot_die_map_cells`) 파일 단위로 캐시한다 —
    키에 수정 시각·크기를 넣어 파일이 바뀌면 다시 읽는다."""
    for base in _search_dirs(folder):
        dat = base / _DIE_MAP_FILE
        try:
            st = dat.stat()
            md = Path(str(dat) + ".md").stat()
        except OSError:
            continue
        got = _dat_cells(dat, st.st_mtime_ns, st.st_size, md.st_mtime_ns, px, py)
        if got is not None:
            return got
    return None


@lru_cache(maxsize=256)
def _dat_cells(dat: Path, _mtime_ns: int, _size: int, _md_mtime_ns: int,
               px: float, py: float) -> Optional[frozenset[tuple[int, int]]]:
    layout = _dat_layout(dat)
    if layout is None:
        return None
    rec, fields = layout
    try:
        off_x, vt_x = fields["x"]
        off_y, vt_y = fields["y"]
    except KeyError:
        return None
    if vt_x != _VT_DOUBLE or vt_y != _VT_DOUBLE:
        return None
    try:
        data = dat.read_bytes()
    except OSError:
        return None
    if rec <= 0 or not data or len(data) % rec:
        return None
    count = len(data) // rec
    if count < _MIN_DIE_MAP:
        return None
    cells: set[tuple[int, int]] = set()
    try:
        for i in range(count):
            b = i * rec
            x = struct.unpack_from("<d", data, b + off_x)[0]
            y = struct.unpack_from("<d", data, b + off_y)[0]
            cells.add((math.floor(x / px), math.floor(y / py)))
    except (struct.error, ValueError, OverflowError) as e:
        # ★ 깨진 맵 하나는 **그 맵만** 버린다.  예전에는 여기서 난 예외가
        #   camtek_geometry 의 except 까지 올라가 LOT 형제 전부가 기하 None(=절대좌표)
        #   으로 조용히 떨어졌다(사이드카 오프셋이 레코드 밖이거나 x 가 nan 일 때).
        _LOG.warning("%s 를 읽지 못해 이 die 맵은 쓰지 않습니다(%s): %s", dat.name, e, dat)
        return None
    col_origin = min(i for i, _ in cells)
    row_total = max(j for _, j in cells)
    if not (0 <= col_origin <= _MAX_DIE_INDEX
            and 0 <= row_total <= _MAX_DIE_INDEX):
        return None
    return frozenset(cells)


def _dat_layout(dat: Path) -> Optional[tuple[int, dict[str, tuple[int, int]]]]:
    """``<이름>.dat.md`` 가 알려 주는 ``(레코드크기, {필드: (오프셋, vartype)})``.

    장비 소프트웨어마다 레코드 배치가 달라서(실측 72 / 128) 하드코딩할 수 없다.
    사이드카가 없거나 형식이 아니면 ``None``."""
    txt = read_ini_text(Path(str(dat) + ".md"))
    if not txt:
        return None
    m = _RECSIZE_PAT.search(txt)
    if not m:
        return None
    fields = {name: (int(off), int(vt))
              for name, off, vt in _FIELD_PAT.findall(txt)}
    return (int(m.group(1)), fields) if fields else None


# KLA 원점을 헤더의 웨이퍼 중심(SampleCenterLocation)으로 유도했다는 꼬리표.  그 밖의 경로
# (SampleTestPlan 최솟값 · 상수)는 번호가 틀렸을 수 있어 화면·엑셀에 경고를 단다.
KLA_CENTER_SOURCE = "DiePitch+SampleCenterLocation"


def _kla_zero(center: float, diameter: float, pitch: float) -> Optional[int]:
    """die 인덱스 원점 = **−(웨이퍼에 온전히 들어오는 첫 인덱스)**.  비상식적이면 None.

    ``col = XINDEX + zero_x`` 가 0 부터 시작하게 하는 값이다.  Camtek
    :func:`_col_origin` 과 **같은 규칙**이고, KLA 는 Y 가 위로 커져서 두 축 모두 '첫' 을
    쓴다(Camtek 은 Y 가 아래로 커져 row 만 '마지막' 을 쓴다 — :func:`_row_total`)."""
    zero = -math.ceil((center - diameter / 2.0) / pitch)
    return zero if 0 <= zero <= _MAX_DIE_INDEX else None


def _kla_zeros_from_center(text: str, px: float, py: float
                           ) -> Optional[tuple[int, int]]:
    """``SampleCenterLocation`` + ``SampleSize`` 로 ``(zero_x, zero_y)`` 산출.

    실측 검증(``docs/디바이스_하드코딩_조사.md`` §6-K) — 사용자가 장비로 확인한 KLA↔Camtek
    대응 **7건이 두 device 에서 전부 일치**한다(T254 `zero=(9,4)`, TB500 `zero=(3,3)`).
    ``SampleTestPlan`` 범위와도 5웨이퍼 × 2축 전부 맞는다."""
    cm = _SAMPLE_CENTER_PAT.search(text)
    sm = _SAMPLE_SIZE_PAT.search(text)
    if cm is None or sm is None:
        return None
    try:
        cx, cy = float(cm.group(1)), float(cm.group(2))
        dia = float(sm.group(1)) * 1000.0        # SampleSize 는 mm 단위
    except ValueError:
        return None
    if not (_MIN_DIAMETER <= dia <= _MAX_DIAMETER):
        return None
    zx, zy = _kla_zero(cx, dia, px), _kla_zero(cy, dia, py)
    return None if zx is None or zy is None else (zx, zy)


def parse_kla_header(text: str) -> Optional[KlaGeometry]:
    """KLA ``.001`` 헤더 텍스트 → KlaGeometry.  DiePitch 가 없으면 None.

    ``zero_x``/``zero_y`` 는 **``SampleCenterLocation`` 기하**로 구한다 — Camtek 의
    ``col_origin``/``row_total`` 과 같은 규칙이라 두 장비가 자동으로 정렬된다.
    ⚠ ``KLA_ZERO_Y=4`` 를 상수로 쓰던 시절엔 **TB500 자재에서 row 가 1 컸다**(실측:
    `08235234EWA1` 은 3 이 맞다).  device 마다 다른 값이므로 상수로 되돌리지 말 것.

    그게 없을 때만 옛 경로로 폴백한다: ``zero_x`` 는 ``SampleTestPlan`` 의 XINDEX
    최솟값, ``zero_y`` 는 상수.  ⚠ 그 목록에는 **검사한 die 만** 있어서 맵 가장자리
    행/열이 통째로 미사용이면 최솟값이 맵 원점과 어긋난다 — 그래서 폴백이다.

    순수 함수 — 파일 없이 헤드리스 테스트할 수 있다.
    """
    pm = _DIEPITCH_PAT.search(text)
    if pm is None:
        return None
    try:
        px, py = float(pm.group(1)), float(pm.group(2))
    except ValueError:
        return None
    if not (_MIN_PITCH <= px <= _MAX_PITCH and _MIN_PITCH <= py <= _MAX_PITCH):
        return None

    zeros = _kla_zeros_from_center(text, px, py)
    if zeros is not None:
        return KlaGeometry(pitch_x=px, pitch_y=py, zero_x=zeros[0], zero_y=zeros[1],
                           source=KLA_CENTER_SOURCE)

    zero_x, src = KLA_ZERO_X, "DiePitch"
    tm = _TESTPLAN_PAT.search(text)
    if tm:
        pairs = _INDEX_PAIR_PAT.findall(tm.group(1))
        if pairs:
            zero_x = -min(int(a) for a, _ in pairs)
            src = "DiePitch+SampleTestPlan"
    return KlaGeometry(pitch_x=px, pitch_y=py, zero_x=zero_x, zero_y=KLA_ZERO_Y,
                       source=src)


@lru_cache(maxsize=256)
def kla_geometry(folder: Path) -> KlaGeometry:
    """폴더의 KLA die 격자 기하.  못 읽으면 TB500 폴백(+경고).  fail-safe."""
    from . import kla_info        # 순환 import 회피

    try:
        info = kla_info._find_info_file(folder)
        if info is not None:
            with info.open("rb") as fh:
                head = fh.read(kla_info._HEAD_BYTES)
            geom = parse_kla_header(head.decode("utf-8", errors="replace"))
            if geom is not None:
                if geom.source == "DiePitch":
                    _LOG.warning(
                        "KLA %s 에 SampleTestPlan 이 없어 die 인덱스 원점 X 도 "
                        "기본값(%d)을 씁니다.", info.name, KLA_ZERO_X)
                elif geom.source == "DiePitch+SampleTestPlan":
                    # 검사한 die 목록의 최솟값 — 가장자리 열을 검사하지 않은 레시피면 원점이
                    # 어긋나고, row 원점은 상수다(부분 목록에서 원점을 잡는 같은 부류의 위험,
                    # 좌표 전반 점검 2026-10-24).  조용히 쓰지 않는다.
                    _LOG.warning(
                        "KLA %s 에 SampleCenterLocation 이 없어 die 원점을 검사 목록"
                        "(SampleTestPlan) 최솟값 X=%d · 기본값 Y=%d 로 잡습니다 — 목록이 "
                        "일부 die 만 담으면 col/row 가 어긋날 수 있습니다.",
                        info.name, geom.zero_x, geom.zero_y)
                return geom
        _LOG.warning(
            "KLA die 격자 정보를 찾지 못해 기본값을 씁니다: %s", folder)
        return FALLBACK_KLA
    except Exception:
        _LOG.warning("KLA die 격자 판독 실패 — 기본값 사용: %s", folder, exc_info=True)
        return FALLBACK_KLA
