"""IDE(VS Code 등) 와 PyInstaller 빌드 양쪽에서 안전한 경로 헬퍼."""

from __future__ import annotations

import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Resource resolution
# ---------------------------------------------------------------------------
def _project_root() -> Path:
    """`aoi_verification/` 패키지 루트의 부모 (저장소 루트)."""
    return Path(__file__).resolve().parents[3]


def resource_path(relative: str | os.PathLike[str]) -> Path:
    """애플리케이션 리소스(스타일시트, 양식 파일 등) 의 절대 경로를 돌려준다.

    IDE 의 작업 디렉토리가 어디로 설정돼 있든 일관된 경로를 보장하기 위해
    모든 리소스는 이 헬퍼를 통해 접근해야 한다.  PyInstaller `--onefile`
    모드에서는 `sys._MEIPASS` 가 임시 디렉토리를 가리키므로 그것을 우선 사용.
    """
    rel = Path(relative)

    # 1) PyInstaller frozen executable
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        candidate = Path(meipass) / rel
        if candidate.exists():
            return candidate

    # 2) Repo root (개발 환경)
    candidate = _project_root() / rel
    if candidate.exists():
        return candidate

    # 3) Package-relative fallback
    candidate = Path(__file__).resolve().parents[2] / rel
    return candidate


# ---------------------------------------------------------------------------
# 로고 리소스
# ---------------------------------------------------------------------------
def logo_path(name: str) -> Path:
    """로고 파일(``logo.ico``·``logo_big.png``·``logo_clear.png``) 의 절대 경로.

    앱 폴더 안(`ui/assets/`)에 두어 포터블 빌드 복사·자동 업데이트 미러에
    자동으로 따라오게 한다."""
    return resource_path(f"aoi_verification/app/ui/assets/{name}")


# ---------------------------------------------------------------------------
# Shared cache directory — always in the user's home, never inside source data
# ---------------------------------------------------------------------------
_CACHE_DIRNAME = ".aoi_verification_cache"

# 이 프로세스가 이미 만든 캐시 폴더.  경로 계산은 매번 그대로 하되(환경변수
# AOI_DATA_HOME 변경을 계속 따른다) mkdir 만 건너뛴다 — 사진 1장을 처리할 때마다
# 아래 헬퍼들이 여러 번 불려 잉여 syscall 이 사진 수만큼 쌓였다.
# 폴더를 지우는 코드는 없다(prune_old_cache 는 파일만 unlink 한다).
_MADE_DIRS: set = set()


def _ensure_dir(d: Path) -> Path:
    if d not in _MADE_DIRS:
        d.mkdir(parents=True, exist_ok=True)
        _MADE_DIRS.add(d)
    return d


def cache_root() -> Path:
    """캐시(썸네일/특징/임베딩/점수/세션) 폴더.

    기본은 사용자 홈의 ``~/.aoi_verification_cache``.  단, 환경변수 ``AOI_DATA_HOME``
    이 지정되면 그 폴더 아래(``<AOI_DATA_HOME>/cache``)에 둔다 — exe 설치 시 launcher 가
    설치 폴더("AOI Recipe Verification")를 가리키게 해, **앱·패키지·캐시를 모두 한 폴더**
    안에 담기 위함."""
    home = os.environ.get("AOI_DATA_HOME")
    root = (Path(home) / "cache") if home else (Path.home() / _CACHE_DIRNAME)
    return _ensure_dir(root)


def thumb_cache_dir() -> Path:
    return _ensure_dir(cache_root() / "thumbs")


def mid_cache_dir() -> Path:
    return _ensure_dir(cache_root() / "mid")


def feature_cache_dir() -> Path:
    return _ensure_dir(cache_root() / "features")


def embedding_cache_dir() -> Path:
    """GPU/OpenVINO 임베딩 벡터(.npy) 영속 캐시 — 재실행 시 재추출 생략(#3).

    썸네일/중간이미지와 달리 1일 TTL 정리 대상이 아니다(재계산 비용이 크고
    원본 mtime 키라 자동 무효화됨)."""
    return _ensure_dir(cache_root() / "embeddings")


def score_cache_dir() -> Path:
    """(ref, val) 유사도 점수의 슬롯 단위 영속 캐시 폴더 (#5B)."""
    return _ensure_dir(cache_root() / "scores")


def session_cache_dir() -> Path:
    return _ensure_dir(cache_root() / "session")


def _exe_install_root() -> Path | None:
    """'python + app 폴더' 설치 루트.  개발 실행이면 None.

    런처가 넘겨주는 ``AOI_APP_HOME`` 이 1순위지만, **백신이 서명 없는 exe 를 막아
    ``run_aoi.bat`` 으로 켜는 경우**에는 그 변수가 없다(설치방법.txt 가 그 방법을
    안내한다).  그때는 레이아웃 자체로 판정한다 — 안 그러면 결과 엑셀이 ``app\\`` 안에
    쌓이고 다음 업데이트 교체 때 통째로 사라진다.

    ※ ``updater._install_root()`` 는 이 함수를 쓰면 안 된다.  거기서 판단하는 것은
      '설치 루트가 어디냐' 가 아니라 '**교체해 줄 런처가 있느냐**' 이고, 포터블에는
      런처가 없다.  레이아웃으로 판정하면 포터블이 ``app.new`` 에 스테이징만 하고
      영원히 적용되지 않는다."""
    home = os.environ.get("AOI_APP_HOME")
    if home:
        return Path(home)
    root = _project_root().parent          # app/ 의 부모 = 설치 루트 후보
    launcher = (root / "run_aoi.bat").is_file() or (root / "AOI_Verify.exe").is_file()
    if launcher and (root / "python").is_dir():
        return root
    return None


def install_root() -> Path | None:
    """'exe + app 폴더' 설치 루트 — 패키지 **바깥**(``main.py``)에서 쓰는 공개 이름.

    개발/포터블이면 None.  판정 규칙은 `_exe_install_root` 참고."""
    return _exe_install_root()


def bundled_ir_dir() -> Path | None:
    """백본 OpenVINO IR 폴더(``runtime/ir``).  없으면 None.

    백본을 IR 로 바꾸는 데는 torch 가 필요한데, 그것 하나 때문에 배포본이 torch 를 통째로
    안고 다녔다.  그래서 **변환 결과만** 들고 다니고 앱은 읽기만 한다.

    ★ 조회 규칙은 ``resource_path`` **하나**다 — 개발·포터블·exe·온라인 네 배포가 모두
      '앱 트리 루트' 기준으로 같은 자리를 본다.  설치 루트 기반 판정을 쓰면 온라인 배포
      (앱을 GitHub 에서 받아 푸는 형태)에서 못 찾는다.
    IR 이 없으면 호출부가 CPU 고전으로 폴백한다(앱은 정상 동작, 가속만 없음)."""
    d = resource_path("runtime/ir")
    return d if d.is_dir() else None


# ---------------------------------------------------------------------------
# 양식.xlsx 위치 찾기 — ‘양식’ 폴더 안의 ‘양식.xlsx’ 를 우선 탐색한다.
# ---------------------------------------------------------------------------
def template_path() -> Path:
    """엑셀 출력용 ``양식.xlsx`` 의 실제 경로를 찾는다 (없으면 후보 중 가장 가까운 것).

    개발 트리에서는 사용자가 직접 건드리지 않는 파일을 모은 ``dev/`` 안에 둔다.
    포터블/PyInstaller 빌드에서는 호환을 위해 루트·_MEIPASS 후보도 함께 본다."""
    candidates = [
        _project_root() / "dev" / "양식.xlsx",      # 개발 트리(dev/ 로 정리)
        _project_root() / "양식" / "양식.xlsx",      # 폴더형(호환)
        _project_root() / "양식.xlsx",              # 루트 fallback(포터블 빌드)
        resource_path("양식.xlsx"),                 # PyInstaller 번들(_MEIPASS) 대응
    ]
    for c in candidates:
        if c.exists():
            return c
    # 존재하지 않으면 첫 후보 경로를 그대로 돌려준다 (호출자가 존재 여부 검사)
    return candidates[0]


def results_dir() -> Path:
    """결과 엑셀이 저장될 기본 폴더 — 프로젝트 루트의 ‘결과’ 폴더에 자동 생성한다.

    단 'exe + app 폴더' 설치에서는 **설치 루트 바로 아래**(=``app\\`` 바깥)에 둔다.
    자동 업데이트가 ``app\\`` 을 통째로 새 트리로 교체하므로, 안에 두면 사용자가 만든
    결과 파일이 업데이트 때 사라진다.  ``run_aoi.bat`` 으로 켜서 ``AOI_APP_HOME`` 이
    없는 경우까지 포함해 판정해야 한다(`_exe_install_root`)."""
    root = _exe_install_root()
    d = (root if root is not None else _project_root()) / "결과"
    d.mkdir(parents=True, exist_ok=True)
    return d
