"""Slot 단위 in-RAM 특징 / 점수 캐시 + 사전 계산 워커.

Stage 2 에서 한 슬롯의 모든 검증측 이미지 ``Feature`` 객체를 한 번만 추출하고,
같은 슬롯의 여러 reference 가 매칭될 때 디스크 재로드 없이 그대로 재사용한다.
나아가 (ref, val) 모든 쌍의 점수도 Stage 2 진입 시 미리 한 번에 계산해서
``SlotScoreCache`` 에 보관 → 매 reference 마다 점수 재계산 없이 즉시 응답.

설계 원칙:
- **per-image 디스크 캐시 (``feature_cache_dir`` 의 .npz) 는 그대로 사용**.
  이 모듈은 그 위에 ‘얼마 동안 RAM 에 들고 있을지’ 를 결정하는 매니저일 뿐이다.
- 메모리 규율을 위해 ‘활성 슬롯 1 개’ + 옵션으로 ‘미리 로드해둘 다음 슬롯 1 개’
  만 유지. 슬롯 변경 시 이전 슬롯의 dict 를 명시적으로 비워 RAM 을 빠르게
  돌려준다.
- thread-safe: ``threading.Lock`` 으로 보호.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import logging
import os
import threading
from collections import OrderedDict
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from PyQt6.QtCore import QObject, QThread, pyqtSignal

from ..models.slot import ImageItem
from . import pipeline as _pipeline
from .pipeline import Feature

_LOG = logging.getLogger("aoi.match")

# OpenCV 가 내부에서 multi-threading 하면 우리 ThreadPoolExecutor 와
# over-subscription 발생 → 오히려 느려짐.  외부에서만 병렬화하도록 끔.
try:
    import cv2 as _cv2
    _cv2.setNumThreads(1)
except Exception:
    pass


def _worker_count() -> int:
    """ThreadPoolExecutor 워커 수 — CPU 코어 -1 (UI 응답성 확보)."""
    return max(2, (os.cpu_count() or 2) - 1)


# ---------------------------------------------------------------------------
# 점수 디스크 영속 캐시 (#5B) — 옵션. 슬롯당 1 파일(gzip-JSON).
#
# 한 쌍의 점수는 (전처리 cfg, 엔진, active 모델, 가중치) 에 따라 달라지므로
# 이 모든 요소를 묶은 ``signature`` 로 파일을 분리한다.  개별 엔트리 키에는
# ref/val 의 절대경로 + mtime 을 박아두어, 사진이 바뀌면 키가 달라져 자동으로
# 무효화(재계산)된다 (utils/cache.py 와 동일한 패턴).
# ---------------------------------------------------------------------------
def _score_signature(cfg) -> str:
    """점수에 영향을 주는 모든 설정을 묶은 sha1 시그니처."""
    from .. import config as _config
    src = "|".join([
        # 특징 추출·점수 공식이 바뀌면 옛 점수 파일이 적중하지 않게 한다(pipeline 참고).
        _pipeline._FEATURE_VERSION,
        getattr(cfg, "engine", "basic"),
        cfg.cache_extra("ref") if cfg is not None else "",
        cfg.cache_extra("val") if cfg is not None else "",
        # 재채점 항 선택·중앙가중도 점수를 바꾸므로 시그니처에 포함(캐시 분리).
        repr(sorted(getattr(cfg, "rerank_components", None) or [])) if cfg is not None else "",
        repr(float(getattr(cfg, "orb_center_weight", 0.0) or 0.0)) if cfg is not None else "",
        repr(_config.CONFIG.similarity.normalized()),
    ])
    return hashlib.sha1(src.encode("utf-8")).hexdigest()


def _stat_mtime(path: Path, cache: Dict[Path, int]) -> int:
    m = cache.get(path)
    if m is None:
        try:
            m = int(Path(path).stat().st_mtime)
        except OSError:
            m = 0
        cache[path] = m
    return m


def _slot_score_file(slot: str, sig: str) -> Path:
    from ..utils import paths as _paths
    name = hashlib.sha1(slot.encode("utf-8")).hexdigest()
    return _paths.score_cache_dir() / f"{name}_{sig[:16]}.json.gz"


def _load_slot_scores(slot: str, sig: str) -> Dict[str, float]:
    """슬롯의 디스크 점수 맵 로드. 없거나 손상되면 빈 dict (손상 파일은 삭제)."""
    f = _slot_score_file(slot, sig)
    try:
        if not f.exists() or f.stat().st_size == 0:
            return {}
        with gzip.open(f, "rt", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            return {str(k): float(v) for k, v in data.items()}
    except Exception:
        try:
            f.unlink()
        except OSError:
            pass
    return {}


def _save_slot_scores(slot: str, sig: str, mapping: Dict[str, float]) -> None:
    if not mapping:
        return
    f = _slot_score_file(slot, sig)
    tmp = f.parent / (f.name + ".tmp")
    try:
        with gzip.open(tmp, "wt", encoding="utf-8") as fh:
            json.dump(mapping, fh)
        tmp.replace(f)
    except OSError:
        try:
            tmp.unlink()
        except OSError:
            pass


class SlotFeatureCache:
    """슬롯명 → ``{Path: Feature}`` 매핑. ``set_active`` 로 활성 슬롯만 유지."""

    def __init__(self, *, keep_lookahead: bool = True) -> None:
        self._lock = threading.Lock()
        self._slots: Dict[str, Dict[Path, Feature]] = {}
        self._active: Optional[str] = None
        self._lookahead: Optional[str] = None
        self._keep_lookahead = bool(keep_lookahead)

    # ------------------------------------------------------------------
    def active_slot(self) -> Optional[str]:
        return self._active

    def has(self, slot: str) -> bool:
        with self._lock:
            return slot in self._slots

    def get_features(self, slot: str) -> Optional[Dict[Path, Feature]]:
        with self._lock:
            d = self._slots.get(slot)
            return None if d is None else dict(d)

    def size(self) -> int:
        with self._lock:
            return sum(len(d) for d in self._slots.values())

    # ------------------------------------------------------------------
    def set_active(self, slot: str) -> None:
        """``slot`` 을 활성으로 표시. 활성 + (옵션) lookahead 외의 슬롯은 제거."""
        with self._lock:
            self._active = slot
            keep = {slot}
            if self._keep_lookahead and self._lookahead:
                keep.add(self._lookahead)
            for k in list(self._slots.keys()):
                if k not in keep:
                    del self._slots[k]

    def set_lookahead(self, slot: Optional[str]) -> None:
        """다음에 진입할 가능성이 높은 슬롯을 표시. 활성/lookahead 외 슬롯 제거."""
        with self._lock:
            self._lookahead = slot
            keep = {self._active or "", slot or ""}
            for k in list(self._slots.keys()):
                if k not in keep:
                    del self._slots[k]

    def clear(self) -> None:
        """전부 비운다 — 세션이 끝났을 때(검증 중단 후 재실행) 쓴다.

        ``set_active`` 는 **활성 슬롯 하나는 남기므로** 세션 초기화에 못 쓴다.
        특징은 전처리 설정(cfg)에 따라 달라지는데 메모리 캐시엔 그 시그니처가
        박혀 있지 않다 — 설정을 바꿔 다시 돌릴 때 옛 특징이 남아 있으면 안 된다
        (디스크 캐시는 ``_score_signature`` 로 분리돼 있어 안전하다)."""
        with self._lock:
            self._slots.clear()
            self._active = None
            self._lookahead = None

    # ------------------------------------------------------------------
    def build(self, slot: str, items: Iterable[ImageItem],
              *, cfg=None, progress=None) -> Dict[Path, Feature]:
        """슬롯의 ``Feature`` 들을 추출(또는 캐시 로드) 해서 dict 로 반환·저장.

        이미 빌드된 슬롯은 그대로 반환한다 (idempotent). 항목이 추가됐다면
        새 path 만 추가 추출한다.  ``cfg`` 는 강화/KLA 전처리를 extract 에 전달.

        ``progress(done, total)`` 콜백이 주어지면 **사진 1장을 처리할 때마다**
        호출한다.  이 함수는 슬롯의 val 특징을 전부 뽑는 구간이라 콜드 캐시·NAS
        에서 가장 오래 걸리는데, 그동안 호출자가 진행을 보고할 방법이 없어
        로딩 바가 0 에 멈춰 있다가 튀었다(CLAUDE.md 로딩 계약 위반).
        캐시 hit 로 건너뛴 항목도 세어 done 이 단조 증가하게 한다.
        """
        items_list = list(items)
        existing: Dict[Path, Feature] = {}
        with self._lock:
            existing = dict(self._slots.get(slot, {}))

        total = len(items_list)

        def _tick(done: int) -> None:
            if progress is None:
                return
            try:
                progress(done, total)
            except Exception:
                # 진행 보고 실패가 추출을 막으면 안 된다 — 보조 기능이다.
                pass

        # 누락된 항목만 새로 추출 (디스크 캐시가 있다면 거의 무비용).
        # 검증측 특징 캐시이므로 side='val' (중앙 30% crop 의 side 별 적용).
        for idx, it in enumerate(items_list, start=1):
            if it.path in existing:
                _tick(idx)
                continue
            try:
                existing[it.path] = _pipeline.extract(
                    it.path, cfg=cfg, side=getattr(it, "side", "val"),
                )
            except Exception:
                # 단일 이미지 실패는 이 사진만 빠진다 — 호출자가 빈 dict 로 처리.
                # 조용히 삼키면 '왜 이 후보가 없지' 를 추적할 수 없으므로 남긴다.
                _LOG.warning("특징 추출 실패 — 이 사진은 후보에서 빠집니다: %s",
                             it.path, exc_info=True)
            _tick(idx)

        with self._lock:
            self._slots[slot] = existing
            # 만약 set_active 가 아직 호출되지 않았으면 이 슬롯을 활성으로 간주.
            if self._active is None:
                self._active = slot
        return dict(existing)

    # ------------------------------------------------------------------
    def release(self, slot: str) -> None:
        """슬롯의 RAM features 를 즉시 폐기.

        점수 계산이 끝나 더는 features 가 필요 없을 때 (스트리밍 사전 계산
        워커가 다음 슬롯으로 넘어갈 때) 호출. 점수 캐시는 별도 객체에 남아
        있어 그대로 유지되고, RAM 만 비운다.
        """
        with self._lock:
            self._slots.pop(slot, None)
            if self._active == slot:
                self._active = None
            if self._lookahead == slot:
                self._lookahead = None

    def known_slots(self) -> List[str]:
        with self._lock:
            return list(self._slots.keys())


# ---------------------------------------------------------------------------
# 점수 캐시 — (slot, ref_path, val_path) → score
# ---------------------------------------------------------------------------
class SlotScoreCache:
    """Stage 2 에서 모든 reference 와 모든 검증 후보 사이의 유사도 점수를
    미리 계산해 보관. 매 reference 마다 점수를 다시 매길 필요 없음.

    메모리 비용: 한 항목 ≈ 수십~수백 bytes(tuple+Path 참조).  대용량(슬롯
    수백 개 × 수백만 쌍)에서 무제한 증가하면 GB 단위가 되므로 **슬롯 LRU
    상한**(``max_pairs``)을 둔다.  상한 초과 시 가장 오래 접근하지 않은
    슬롯부터 제거 — 제거된 슬롯이 다시 필요해지면 matcher 폴백이 재계산
    하므로 정확도는 유지되고 메모리만 절약된다 (#17).
    """

    def __init__(self, *, max_pairs: int = 3_000_000) -> None:
        self._lock = threading.Lock()
        self._scores: "OrderedDict[str, Dict[Tuple[Path, Path], float]]" = OrderedDict()
        self._max_pairs = int(max_pairs)
        self._total = 0

    def _evict_locked(self, protect: str) -> None:
        """상한 초과 시 LRU 슬롯 제거 (``protect`` 슬롯은 보존)."""
        while self._total > self._max_pairs and len(self._scores) > 1:
            # OrderedDict 앞쪽 = 가장 오래 접근한 슬롯.
            victim = next(iter(self._scores))
            if victim == protect:
                # 보호 슬롯이 앞에 있으면 뒤로 미루고 다음 후보 평가.
                self._scores.move_to_end(victim)
                victim2 = next(iter(self._scores))
                if victim2 == protect:
                    break
                victim = victim2
            d = self._scores.pop(victim, None)
            if d:
                self._total -= len(d)

    def put(self, slot: str, ref_path: Path, val_path: Path, score: float) -> None:
        with self._lock:
            d = self._scores.get(slot)
            if d is None:
                d = {}
                self._scores[slot] = d
            self._scores.move_to_end(slot)
            key = (ref_path, val_path)
            if key not in d:
                self._total += 1
            d[key] = float(score)
            if self._total > self._max_pairs:
                self._evict_locked(protect=slot)

    def has_pair(self, slot: str, ref_path: Path, val_path: Path) -> bool:
        with self._lock:
            return (slot in self._scores
                    and (ref_path, val_path) in self._scores[slot])

    def get_pair(self, slot: str, ref_path: Path, val_path: Path) -> Optional[float]:
        with self._lock:
            d = self._scores.get(slot)
            if d is None:
                return None
            self._scores.move_to_end(slot)        # LRU 갱신
            return d.get((ref_path, val_path))

    def has_all_pairs(self,
                      slot: str,
                      ref_path: Path,
                      val_paths: Iterable[Path]) -> bool:
        """ref 와 주어진 모든 val 쌍 점수가 캐시에 있는지."""
        with self._lock:
            slot_scores = self._scores.get(slot)
            if not slot_scores:
                return False
            for v in val_paths:
                if (ref_path, v) not in slot_scores:
                    return False
            self._scores.move_to_end(slot)        # LRU 갱신
            return True

    def has_slot(self, slot: str) -> bool:
        with self._lock:
            return slot in self._scores

    def clear_slot(self, slot: str) -> None:
        with self._lock:
            d = self._scores.pop(slot, None)
            if d:
                self._total -= len(d)

    def clear(self) -> None:
        with self._lock:
            self._scores.clear()
            self._total = 0

    def size(self) -> int:
        with self._lock:
            return self._total


# ---------------------------------------------------------------------------
# 사전 계산 워커 — 슬롯 단위 스트리밍 점수 계산
# ---------------------------------------------------------------------------
class _PrecomputeSignals(QObject):
    progress = pyqtSignal(int, int)            # done_pairs, total_pairs
    slot_finished = pyqtSignal(str, int, int)  # slot, idx (1-base), total_slots
    phase = pyqtSignal(str)                    # 현재 작업 단계 라벨 (#8)
    finished = pyqtSignal()
    failed = pyqtSignal(str)


class SlotPrecomputeWorker(QThread):
    """주어진 슬롯들의 (ref, val) 쌍 점수를 슬롯 하나씩 계산해서
    ``SlotScoreCache`` 에 저장한다.

    슬롯 하나의 점수 계산이 끝날 때마다 ``slot_finished`` 시그널을 발생.
    ``release_after_slot=True`` 면 그 슬롯의 features 를 즉시 RAM 에서 폐기
    (점수만 남기고 메모리 회수) → 백그라운드에서 돌아도 메모리 사용 최소화.
    """

    def __init__(self,
                 tasks: List[Tuple[str, List[ImageItem], List[ImageItem]]],
                 slot_cache: SlotFeatureCache,
                 score_cache: SlotScoreCache,
                 *,
                 release_after_slot: bool = False,
                 cfg=None,
                 parent: Optional[QObject] = None) -> None:
        super().__init__(parent)
        # (slot 이름, ref ImageItem 리스트, val ImageItem 리스트)
        self._tasks = [
            (slot, list(refs), list(vals)) for slot, refs, vals in tasks
        ]
        self._slot_cache = slot_cache
        self._score_cache = score_cache
        self._release_after_slot = bool(release_after_slot)
        self._cfg = cfg                 # 강화/KLA 전처리 설정 (extract 에 전달)
        self._stop = False
        self.signals = _PrecomputeSignals()

    def stop(self) -> None:
        self._stop = True

    def run(self) -> None:        # type: ignore[override]
        self._run_sequential()

    # ------------------------------------------------------------------
    def _run_sequential(self) -> None:
        """슬롯마다 임베딩 완료 후 스코어링 — 이 워커의 유일한 실행 경로.

        ※ 한때 생산자/소비자 파이프라인 경로가 함께 있었으나, 그 선택 조건이
          CNN 임베딩 가용 여부였고 그 기능이 제거되면서 도달 불가가 되어 지웠다.
        """
        try:
            total = sum(len(r) * len(v) for _, r, v in self._tasks)
            total_slots = len(self._tasks)
            if total == 0:
                self.signals.finished.emit()
                return
            # 점수 디스크 캐시 옵션 (#5B) — active 모델은 실행 중 불변이므로
            # 시그니처는 한 번만 계산한다.
            persist = bool(getattr(self._cfg, "persist_scores", False))
            score_sig = _score_signature(self._cfg) if persist else ""
            done = 0
            for slot_idx, (slot, refs, vals) in enumerate(self._tasks):
                if self._stop:
                    return
                if not refs or not vals:
                    self.signals.slot_finished.emit(
                        slot, slot_idx + 1, total_slots,
                    )
                    continue
                # 1) val features 빌드 (디스크 캐시 있으면 빠름)
                from .. import i18n
                # 특징 분석 단계도 진행률을 표시해 '0 에서 멈춘 것처럼' 보이지 않게
                # 한다(#2) — 이미지 장수(ref+val) 기준 카운트.
                self.signals.phase.emit(i18n.KO.PHASE_FEATURE)
                feat_total = len(refs) + len(vals)
                self.signals.progress.emit(0, feat_total)
                # ★ val 특징 추출은 이 슬롯에서 가장 오래 걸리는 구간이다.  콜백
                #   없이 build() 를 통째로 기다리면 바가 0 에 얼어붙어 있다가
                #   len(vals) 로 튄다 — 사진 1장마다 중계해 계속 움직이게 한다.
                val_feats = self._slot_cache.build(
                    slot, vals, cfg=self._cfg,
                    progress=lambda done, _t: self.signals.progress.emit(
                        done, feat_total),
                )
                # 2) ref features (sim.extract 가 디스크 캐시 자동 사용)
                ref_feats: Dict[Path, Feature] = {}
                for ri, r in enumerate(refs, start=1):
                    if self._stop:
                        return
                    try:
                        ref_feats[r.path] = _pipeline.extract(
                            r.path, cfg=self._cfg, side="ref",
                        )
                    except Exception:
                        _LOG.warning("기준 특징 추출 실패 — 이 기준은 점수가 없습니다: %s",
                                     r.path, exc_info=True)
                    self.signals.progress.emit(len(vals) + ri, feat_total)

                # 3) 모든 (ref, val) 쌍 점수 — ThreadPoolExecutor 로 병렬 (#5).
                # _pipeline.score 의 cv2/numpy/skimage 호출은 GIL 을 잘 양보
                # 하므로 thread 가 실제 병렬 처리 가능.  cv2 내부 multi-thread
                # 는 over-subscription 회피 위해 외부에서만 병렬화한다.
                self.signals.phase.emit(i18n.KO.PHASE_SCORING)
                # 디스크 캐시가 켜져 있으면 슬롯의 기존 점수를 불러와 재계산을
                # 건너뛰고, 새로 계산한 점수까지 합쳐 다시 저장한다 (#5B).
                disk_scores = (_load_slot_scores(slot, score_sig)
                               if persist else None)
                out_map = self._score_pairs_parallel(
                    slot, refs, vals, ref_feats, val_feats,
                    done_offset=done, total=total, disk_scores=disk_scores,
                )
                done += len(refs) * len(vals)
                if persist and out_map:
                    _save_slot_scores(slot, score_sig, out_map)
                # 슬롯 단위로 진행률 + 슬롯 완료 emit.
                self.signals.progress.emit(done, total)
                self.signals.slot_finished.emit(
                    slot, slot_idx + 1, total_slots,
                )
                # 메모리 절약: 점수 계산이 끝났으니 features 는 더 이상
                # 필요 없음 (점수 캐시만 남으면 _launch_matcher 가 즉시 응답).
                if self._release_after_slot:
                    self._slot_cache.release(slot)
                    # ref features 도 같이 회수.
                    ref_feats.clear()
                    val_feats.clear()
            self.signals.finished.emit()
        except Exception as exc:        # pragma: no cover — 안전망
            self.signals.failed.emit(str(exc))

    def _score_pairs_parallel(self,
                               slot: str,
                               refs: List[ImageItem],
                               vals: List[ImageItem],
                               ref_feats: Dict[Path, Feature],
                               val_feats: Dict[Path, Feature],
                               *,
                               done_offset: int,
                               total: int,
                               disk_scores: Optional[Dict[str, float]] = None,
                               ) -> Optional[Dict[str, float]]:
        """(ref × val) 모든 쌍을 ThreadPoolExecutor 로 병렬 계산해 score_cache 에 저장.

        쌍을 한꺼번에 전부 제출하지 않고 in-flight future 를 ``window`` 개로
        제한한다(#5A) — 50,000+ 쌍에서도 ``pair_args``/``futures`` 리스트가
        한꺼번에 메모리를 점유하지 않아 속도 저하/메모리 급증을 막는다.

        ``disk_scores`` 가 주어지면(#5B) 이미 계산된 쌍은 계산을 건너뛰고
        캐시 값을 그대로 사용하며, 슬롯의 전체 점수 맵을 돌려줘 호출자가 다시
        디스크에 저장하게 한다.  ``None`` 이면 영속 캐시 비활성(반환값 None).
        """
        persist = disk_scores is not None
        out_map: Optional[Dict[str, float]] = {} if persist else None
        mtime_cache: Dict[Path, int] = {}
        done = done_offset

        def _key(rp: Path, vp: Path) -> str:
            return (f"{rp}|{_stat_mtime(rp, mtime_cache)}"
                    f"|{vp}|{_stat_mtime(vp, mtime_cache)}")

        def _iter_miss_pairs():
            """미계산 쌍만 yield. 디스크 캐시 hit 은 즉석에서 처리(진행 카운트 포함)."""
            nonlocal done
            for r in refs:
                rf = ref_feats.get(r.path)
                if rf is None:
                    continue
                for v in vals:
                    vf = val_feats.get(v.path)
                    if vf is None:
                        continue
                    rp, vp = r.path, v.path
                    if persist:
                        k = _key(rp, vp)
                        cached = disk_scores.get(k)
                        if cached is not None:
                            self._score_cache.put(slot, rp, vp, cached)
                            out_map[k] = cached
                            done += 1
                            if done % 25 == 0:
                                self.signals.progress.emit(done, total)
                            continue
                    yield (rp, vp, rf, vf)

        # 점수 시그니처(`_score_signature`)가 키로 삼는 재채점 항·중앙가중을 **실제 채점에도
        # 똑같이** 넘긴다 — 키에는 있는데 채점엔 안 쓰면, 다른 설정으로 만든 점수가 이
        # 설정의 이름으로 디스크에 저장된다.  값은 ``score_ref_classical`` 과 동일하게 해석.
        _comps = getattr(self._cfg, "rerank_components", None)
        comps = set(_comps) if _comps else None
        center_strength = float(getattr(self._cfg, "orb_center_weight", 0.0) or 0.0)

        def _score(args):
            rp, vp, rf, vf = args
            try:
                return rp, vp, float(_pipeline.score(
                    rf, vf, components=comps, center_strength=center_strength))
            except Exception:
                _LOG.warning("점수 계산 실패 — 이 쌍은 건너뜁니다: %s ↔ %s",
                             rp, vp, exc_info=True)
                return rp, vp, None

        n_workers = _worker_count()
        window = max(8, n_workers * 4)
        miss = _iter_miss_pairs()
        inflight: set = set()
        with ThreadPoolExecutor(max_workers=n_workers) as pool:
            for _ in range(window):
                try:
                    inflight.add(pool.submit(_score, next(miss)))
                except StopIteration:
                    break
            while inflight:
                if self._stop:
                    pool.shutdown(wait=False, cancel_futures=True)
                    return out_map
                finished, inflight = wait(
                    inflight, timeout=0.5,
                    return_when=FIRST_COMPLETED,
                )
                for fut in finished:
                    rp, vp, s = fut.result()
                    done += 1
                    if s is not None:
                        self._score_cache.put(slot, rp, vp, s)
                        if persist:
                            out_map[_key(rp, vp)] = s
                    if done % 25 == 0:
                        self.signals.progress.emit(done, total)
                    try:
                        inflight.add(pool.submit(_score, next(miss)))
                    except StopIteration:
                        pass
        return out_map
